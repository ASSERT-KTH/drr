import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test001");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "R", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1", 67, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1" + "'", str3.equals("124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                   4444444444444444444444444414.0", "...    ...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0a0.0a1.0", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                                                         ###########################");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test005");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("MV revreS tiB-46 )MT(topStoH avaJ", "hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str2.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 8);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 8 + "'", byte3 == (byte) 8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test008");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 71, 97.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "-1.0a0.0a1.0", 89);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test011");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/s:/Users/so", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test012");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" a#a#a#", "100 0 1 1 -1 3                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#a#a#" + "'", str2.equals(" a#a#a#"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test014");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/USERS/SOPHI", (double) 18.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...US", 100404140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test016");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) (byte) 8);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 8 + "'", short3 == (short) 8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test018");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 75, 2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Librry/Jv/JvVirtulM", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librry/Jv/JvVirtulM" + "'", str3.equals("/Librry/Jv/JvVirtulM"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test020");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("OracleCorporation", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 33, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test022");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "3a1-a1a1a0a0010140.040.0140.0140.01O", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "3a1-a1a1a0a0010140.040.0140.0140.01O" + "'", charSequence2.equals("3a1-a1a1a0a0010140.040.0140.0140.01O"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test023");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("    http://java.oracle.com/    ", "                1.8                ", (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA##########################################", 9, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "    http://java.oracle.com/    " + "'", str8.equals("    http://java.oracle.com/    "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100", "Java HotSpot(TM) 6a-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100" + "'", str2.equals("/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" 4#4#4#", "OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4#4#4#" + "'", str2.equals(" 4#4#4#"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test028");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mac os x", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaform API S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test030");
        char[] charArray8 = new char[] { ' ', '#', '#', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) ' ', (int) (byte) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100404140", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/USERS/SOPHIE", charArray8);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " ######" + "'", str15.equals(" ######"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test031");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("en", "", 3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD", "", 2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ####", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "en" + "'", str5.equals("en"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ####" + "'", str10.equals(" ####"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.5.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 10, (double) (short) 100, (double) 23.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                .8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                .8" + "'", str2.equals("                .8"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "erj/emoH/stnetnoC/kdj.08_0.7....");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test037");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0#10.0#10.0#0.0#100.0" + "'", str9.equals("10.0#10.0#10.0#0.0#100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test038");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 10, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 5, 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment", (int) '4', "uTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment" + "'", str3.equals("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironment" + "'", str1.equals("sunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironmentsunwtCGrphicsEnvironment"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test041");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                               10.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test043");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 8, (short) (byte) 4, (short) 8);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a1a100a10a-1a1", "1.7.0_80", (int) (byte) 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEaJ7v7P7f.mAPISfMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...racleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "24.80-b11 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...racleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("...racleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                        ", 7, "erj/emoH/sOracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        " + "'", str3.equals("                        "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test047");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test048");
        long[] longArray3 = new long[] { (short) -1, 33, 35 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#33#35" + "'", str6.equals("-1#33#35"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a33a35" + "'", str8.equals("-1a33a35"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test049");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                  /uSERS/SOPHIE", 31, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test051");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 176L, 10.0d, 7.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 176.0d + "'", double3 == 176.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS X#########", (java.lang.CharSequence) "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test053");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("form API S                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "form API S" + "'", str1.equals("form API S"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test055");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test056");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 0.0 1.0" + "'", str8.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#0.0#1.0" + "'", str11.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.040.041.0" + "'", str13.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0#0.0#1.0" + "'", str15.equals("-1.0#0.0#1.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.5.", "0.01                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5." + "'", str2.equals("1.5."));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", (int) (short) 0, 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAA"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test060");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("lass [Ljava.lang.String;", "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lass [Ljava.lang.String;" + "'", str2.equals("lass [Ljava.lang.String;"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test062");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 100, (int) (byte) 100);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("              0a27a0               ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              0a27a0               " + "'", str3.equals("              0a27a0               "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test066");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracl/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracl", (double) 1318L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1318.0d + "'", double2 == 1318.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test067");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444", "4-143");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10.14.3");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0#1#100#10#-1#1", 94, "                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  java(tm) se runtime e0#1#100#10#-1#1                  java(tm) se runtime en" + "'", str3.equals("                  java(tm) se runtime e0#1#100#10#-1#1                  java(tm) se runtime en"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test073");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test074");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "042740", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test076");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100404140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100404140" + "'", str3.equals("100404140"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test077");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28L, 10.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test078");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaa", 73, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test080");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b1524.80-B11 ", "-1.0a0.0a1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", "J7v7P7f.mAPISf7Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test083");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 0, (int) (byte) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 1324, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test084");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "#############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test086");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("         -1.0A0.0A1.0         ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "               " + "'", str1.equals("               "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test088");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                          sophie", (java.lang.CharSequence) "24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                                0", "erj/emoH/stnetnoC/kdj.08_0.7....", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                0" + "'", str3.equals("                                                                                                0"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X", "1.7.0_80-b1524.80-B11 ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X" + "'", str3.equals("Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test091");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(6.0d, 1240.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1240.0d + "'", double3 == 1240.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test092");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".1.1JAV", 6, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test093");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) -1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 28, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophi" + "'", str1.equals("/users/sophi"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ".8", (java.lang.CharSequence) "jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJjerraraeaea-ea3jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444", "http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test098");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test099");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test100");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ######", "1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444", 73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Sun.awt.CGraphicsEnvironment.8", "/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment.8" + "'", str2.equals("Sun.awt.CGraphicsEnvironment.8"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaform API S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                   4444444444444444444444444414.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444414.0" + "'", str1.equals("4444444444444444444444444414.0"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                               SOPHIE                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test109");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("AAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAAAAAAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test110");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test111");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 4, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test113");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\n\n\n\n\n\n\n\n\n\n", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test114");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("form API S                                                                               ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1#33#35");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#33#35" + "'", str1.equals("-1#33#35"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test116");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 8);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "4");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (short) 0, 5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "####" + "'", str6.equals("####"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS0a27a0                          hi!0a27a0                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test119");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "#################################################1.8IXED #################################################1.8ODE", (java.lang.CharSequence) "10#100#0#-1#1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#################################################1.8IXED #################################################1.8ODE" + "'", charSequence2.equals("#################################################1.8IXED #################################################1.8ODE"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test120");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10#100#0#-1#1", (java.lang.CharSequence) "1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10#100#0#-1#1" + "'", charSequence2.equals("10#100#0#-1#1"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test121");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaJ7v7P7f.mAPISfaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaJ7v7P7f.mAPISfaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaJ7v7P7f.mAPISfaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test123");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("R");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("         -1.0a0.0a1.0         ", 1466, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         -1.0a0.0a1.0         ############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("         -1.0a0.0a1.0         ############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test125");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence) "                             10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironmen", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str3.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test129");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "9.0a51.0a32.0a1.0040414E8a30.0", (java.lang.CharSequence) "o10.0410.0410.040.0410100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "9.0a51.0a32.0a1.0040414E8a30.0" + "'", charSequence2.equals("9.0a51.0a32.0a1.0040414E8a30.0"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("8                         ", "va HaSpa(TM) 64-Ba Sava VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8                         " + "'", str2.equals("8                         "));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0", (int) ' ', "-1.0#0.0#1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1" + "'", str3.equals("-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", "                               ", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test133");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 29, 28);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#0.0#1.0" + "'", str8.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0#0.0#1.0" + "'", str10.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test134");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "...######7######.######0######_######80######.######jdk######/######C######ontents######/######H######ome######/######jre", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test135");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ", "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1324 + "'", int2 == 1324);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("44444444444444444444444440040414044444444444444444444444444", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04140400" + "'", str2.equals("04140400"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test137");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1.0a0.0a1.0", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test139");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test140");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 1, 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 71, 71);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("a Platform API SpecificationJava Platform API SpecificationJava Platform");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a Platform API SpecificationJava Platform API SpecificationJava Platform" + "'", str1.equals("a Platform API SpecificationJava Platform API SpecificationJava Platform"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test142");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1240L, 26L, (long) 47);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test143");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 1325, 65);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 27 0" + "'", str7.equals("0 27 0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "042740" + "'", str13.equals("042740"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi" + "'", str1.equals("hi!hi!hi"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test145");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                  java(tm) se runtime e0#1#100#10#-1#1                  java(tm) se runtime en", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0410.0410.040.04100.0                            ", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 97, 73);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("os/sresU/:s/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "os/sresU/:s/sresU/" + "'", str2.equals("os/sresU/:s/sresU/"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test150");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 72, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 72 + "'", int3 == 72);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("            0.0410.0410.040.04100.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            0.0410.0410.040.04100.0" + "'", str2.equals("            0.0410.0410.040.04100.0"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...                                                                     ...", 0, 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                                                     ..." + "'", str3.equals("...                                                                     ..."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0.HI!  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ss [Ljava.lang.String;", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ss [Ljava.lang.String;" + "'", str2.equals("ss [Ljava.lang.String;"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 5, (long) 72, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 72L + "'", long3 == 72L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("14.0", 45, "100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14.010010010010010010010010010010010010010010" + "'", str3.equals("14.010010010010010010010010010010010010010010"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj", 0, "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj" + "'", str3.equals("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test158");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3", (java.lang.CharSequence) "                          ", 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", "/#L#ib###################################################1#.#8#IXED");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test160");
        long[] longArray2 = new long[] { 12, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 1, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 75, (int) (short) -1);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1240" + "'", str8.equals("1240"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1240" + "'", str10.equals("1240"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "12a0" + "'", str17.equals("12a0"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1010101010101010101010101010101010101010101010101010101010101010101010", "AAAAAAAAAAAAAAA", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test162");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD", "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD" + "'", str2.equals("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test164");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4.", "x86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test165");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mV revreS tiB-46 )MT(topStoH avaJ", "sunawtGraphics1nvironment", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sunawtGraphics1nvironment", 32, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " 10.0#10.0#10.0#0.0#100.0 10.0#10.0#10.0#0.0#100.0 10.0#10.0#10.0#0.0#100.0 -10.0#10.0#10.0#0.0#100.0 3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  # # #", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                         ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mV revreS tiB-46 )MT(topStoH avaJ", "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", 67);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "mV revreS tiB-46 )MT(topStoH avaJ" + "'", str5.equals("mV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ss [Ljava.lang.String;", 4, "\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ss [Ljava.lang.String;" + "'", str3.equals("ss [Ljava.lang.String;"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("tionatform API Specifica P", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ca P" + "'", str2.equals("ca P"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004041414-143", "class [Bclass [Bclass [Bclass [Dclass [Ljava.lang.String;", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test175");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/USERS/SOPH", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test176");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "                                               SOPHIE                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test177");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("          ", 3, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "sophie", "1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Sun.awt.CGraphicsEnvironment.8", 1324, "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.awt.CGraphicsEnvironment.8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-" + "'", str3.equals("Sun.awt.CGraphicsEnvironment.8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X                                            ", (int) (short) 0, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X                                            " + "'", str3.equals("Mac OS X                                            "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "            0                                                    ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "/00404/40");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80-b15" + "'", str6.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str11.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str13.equals("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test184");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test185");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 8, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("s#10#.#0", "            0                                                    ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1", "7P7f.mAPISf7", 71);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test188");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(".040.041.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X" + "'", str1.equals("Sun.awt.CGraphicsEnvironment.8-1.0a0.0a1Mac OS X"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/users/sophi", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "-1.0 0.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1.0a0.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test194");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("12 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "12 0" + "'", str1.equals("12 0"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.", 65, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51." + "'", str3.equals("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51."));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                sun.lwawt.macosx.LWCToolkit                ", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                sun.lwawt.macosx.LWCToolkit                                                     " + "'", str2.equals("                sun.lwawt.macosx.LWCToolkit                                                     "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test200");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Libr#ry/J#v#/Extensions:/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extensions:/usr/lib/j#v", 33, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test201");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444441.8", (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.44444451E15f + "'", float2 == 4.44444451E15f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USE", " ####", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USE" + "'", str3.equals("/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USERS/SOPHI/USE"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test203");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test204");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("r");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 59, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test205");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n\n\n\n\n\n\n\naa", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test206");
        char[] charArray1 = new char[] {};
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray1, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray1, ' ');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 0, 176);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test208");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("X86_64", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("wt.r4444444444444444444444444444444444444444444444444444444444444444", "/Users/s:/Users/so");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wt.r4444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("wt.r4444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test212");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 31, 31);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 75, 5);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test213");
        short[] shortArray1 = new short[] { (byte) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 30, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test214");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("8", "", 18);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "44444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test215");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla", 1323);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla" + "'", str2.equals("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444" + "'", str1.equals("444444444444444"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test218");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MIXED MODE", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            0                                                    ", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "#################################################1.8");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1 -1 100 -1 100", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#################################################1.8IXED #################################################1.8ODE" + "'", str7.equals("#################################################1.8IXED #################################################1.8ODE"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test219");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", 0, 1324);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test220");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "            ", (java.lang.CharSequence) "                                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test222");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#", (java.lang.CharSequence) "http://java.oracle.com/         ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444444444444444444444444444444444444444444444444444444444444444444444##########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444##########################" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444##########################"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaa", 71, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test225");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-14-141004-14100", (java.lang.CharSequence) "-1 33 35");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1004041414-143", "1.00404144E8 27.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-143" + "'", str2.equals("-143"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("-1a1a-1a1a", "Java Virtual Machine Specification", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a1a-1a1a" + "'", str3.equals("-1a1a-1a1a"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test229");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(3.0f, (float) 8L, (float) 172L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 172.0f + "'", float3 == 172.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test230");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/        ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test232");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " a#a#a#", (java.lang.CharSequence) " /00404/40", 1325);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0, (int) (short) 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/e..." + "'", str3.equals("erj/e..."));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "        ############################################", "24.80-B11 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test235");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTJ7v7P7f.mAPISf7Mac OS X#########rarrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" a#a#a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " a#a#a#" + "'", str1.equals(" a#a#a#"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "erj/emoH/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test238");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                SUN.LWAWT.MACOSX.LWCTOOLKIT                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                SUN.LWAWT.MACOSX.LWCTOOLKIT                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test239");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0 27", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test240");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test241");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (java.lang.CharSequence) "1.8", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("44444", 172);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test243");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test245");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "34-14141404100", (java.lang.CharSequence) " ####", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test246");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCorp", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test248");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("9.0a51.0a32.0a1.0040414E8a30.0", 6, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9.0a51.0a32.0a1.0040414E8a30.0" + "'", str3.equals("9.0a51.0a32.0a1.0040414E8a30.0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test250");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment.8", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-b1524.80-B11 ", "        /moc.elcro.vj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1524.80-B11" + "'", str2.equals("1.7.0_80-b1524.80-B11"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test252");
        byte[] byteArray6 = new byte[] { (byte) 8, (byte) 10, (byte) 8, (byte) 8, (byte) 4, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "841048484441" + "'", str8.equals("841048484441"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "0 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEaJ7v7P7f.mAPISfMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE", (int) (short) 8, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DE" + "'", str3.equals("DE"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test255");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 23, 3);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test256");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 97, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test258");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD", "            sun.awt.CGraphicsEnvironment            ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HPOS/SRESU/", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 299 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test260");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test261");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 1324, 14);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 27L + "'", long7 == 27L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test262");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 23, (int) (byte) 4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 27L + "'", long10 == 27L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "        /moc.elcaro.avaj//:ptth", "mac#OS#X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ry/Ja/Libr", "1.7", "                               10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ry/Ja/Libr" + "'", str3.equals("ry/Ja/Libr"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("form API S", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test268");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("        CGr ph  E vr   e  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CGr ph  E vr   e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0 27 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 27 0" + "'", str1.equals("0 27 0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test270");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100404140", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1240281325.075.0", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1240281325.075.0" + "'", str2.equals("1240281325.075.0"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla", "                 444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla" + "'", str2.equals("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test274");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 8);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test275");
        short[] shortArray1 = new short[] { (byte) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 65, 7);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) '#', (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test276");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0a0.0a1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a0.0a1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test277");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test278");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "", (int) (short) 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (java.lang.CharSequence) "Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test280");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100404140" + "'", str6.equals("100404140"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100404140" + "'", str8.equals("100404140"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 0 1 0" + "'", str10.equals("100 0 1 0"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test281");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test283");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.", "10.0 10.0 10.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51." + "'", str2.equals("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/", 35, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test287");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 12, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', (int) (short) 1, 0);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HTTP://JAVA.ORACLE.COM/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test289");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "1.5");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "1.81.81.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81." + "'", str2.equals("1.81.81."));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test291");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test292");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", (java.lang.CharSequence) "X86_64", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test293");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 4);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 4 + "'", byte3 == (byte) 4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test295");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10#100#0#-1#1", charSequence1, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JAV", "O10.0410.0410.040.0410100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAV" + "'", str2.equals("JAV"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment.8" + "'", str1.equals("sun.awt.CGraphicsEnvironment.8"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test298");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 8, (short) (byte) 4, (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 8 + "'", short3 == (short) 8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("herj/emoH/...h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Herj/emoH/...h" + "'", str1.equals("Herj/emoH/...h"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "r", "Mac OS X                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("12 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "12 0" + "'", str1.equals("12 0"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test304");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 22, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444" + "'", str3.equals("4444444444444444444444"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test306");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test307");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.", (java.lang.CharSequence) "###############################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test308");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 100, (int) (byte) 100);
        java.lang.Class<?> wildcardClass17 = doubleArray5.getClass();
        double double18 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double19 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double22 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10.0410.0410.040.04100.0" + "'", str21.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test310");
        char[] charArray6 = new char[] { ' ', '#', '#', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "  # # #" + "'", str10.equals("  # # #"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1240281325.075.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test313");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("tionatform API Specifica P", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatform API Specifica P" + "'", str3.equals("tionatform API Specifica P"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (java.lang.CharSequence) "          -1.0a0.0a1.0         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test316");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("erj/emoH/sOracleCorporation");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("lass [Ljava.lang.String;", 0, "                                                                                         97#0#-1#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "lass [Ljava.lang.String;" + "'", str3.equals("lass [Ljava.lang.String;"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test318");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ", "http://java.oracle.com/         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "os/sresU/:s/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8", (java.lang.CharSequence) "wt.r4444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("          -1.0a0.0a1.0         ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test324");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " ######44", (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac#OS#X", (java.lang.CharSequence) "OracleCorporation4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.", 2, "    http://jsvs.orscle.com/   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj." + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj."));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test327");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 100, (int) (byte) 100);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 35, (int) (short) -1);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test329");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 4, (float) '#', (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test330");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1 -1 100 -1 100", "10.0 10.0 10.0 0.0 100.0", 1324, 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 -1 100 -1 10010.0 10.0 10.0 0.0 100.0" + "'", str4.equals("-1 -1 100 -1 10010.0 10.0 10.0 0.0 100.0"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java HotSpot(TM) 6a-Bit Server VM", "", "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 6a-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 6a-Bit Server VM"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test332");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test333");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), (double) 18, (double) 0.01f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test334");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Environment Runtime SE J#v#(TM)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Environment Runtime SE J#v#(TM)" + "'", str1.equals("Environment Runtime SE J#v#(TM)"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test336");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 65, 3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 80, 73);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "                                                                                                            ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                                             ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100404140" + "'", str6.equals("100404140"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "                  ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', (int) 'a', 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("SUN.LWAWT.MACOSX.LWCTOOLKIT", strArray7, strArray11);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Oracle Corporation");
        java.lang.Class<?> wildcardClass19 = strArray18.getClass();
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray18);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.awt.CGraphicsEnvironmen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str16.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test338");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a27a0" + "'", str7.equals("0a27a0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 27L + "'", long8 == 27L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 27L + "'", long9 == 27L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 27L + "'", long10 == 27L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("wt.r4444444444444444444444444444444444444444444444444444444444444444", "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test340");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(4.444444505931776E15d, (double) 172.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.444444505931776E15d + "'", double3 == 4.444444505931776E15d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1111111111111111111111" + "'", str2.equals("1111111111111111111111"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...", (int) (byte) 100, 45);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...oracle.com/http://java.oracle.com/http:..." + "'", str3.equals("...oracle.com/http://java.oracle.com/http:..."));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("AMAC OS XA", (int) (short) 10, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AMAC OS XA" + "'", str3.equals("AMAC OS XA"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test345");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        boolean boolean13 = javaVersion8.atLeast(javaVersion10);
        boolean boolean14 = javaVersion4.atLeast(javaVersion8);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean16 = javaVersion0.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion17 = null;
        try {
            boolean boolean18 = javaVersion0.atLeast(javaVersion17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test346");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("OracleCorporationHI!", (short) 8);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 8 + "'", short2 == (short) 8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test349");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(14L, 0L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "    /00404/40                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "1.7.0_80-b1524.80-B11", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test352");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ');
        java.lang.Class<?> wildcardClass3 = byteArray0.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 158, 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Lib#################################################1.8IXED #################################################1.8ODE/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "poration444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("poration444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444", (java.lang.CharSequence) "wt.CGrphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...ava....", (java.lang.CharSequence) "tionatform API Specifica PlavaJ", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test356");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (short) 100, 89);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (byte) 8, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a0.0a1.0" + "'", str11.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#################################################100 0 1 1 1100 0 1 1 .100 0 1 1 8", (java.lang.CharSequence) "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test358");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                          sophie", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.9", "/uSERS/SOPHIE/uSERS/SOPHIE/uSERS/SOPH7P7f.mAPISf7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test360");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) 80, (float) 1318L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4", "-1#1#0#10#10", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b1524.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.HI!  ", "  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.HI!  " + "'", str3.equals("0.HI!  "));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "x86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test365");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) (byte) 0, 1);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (short) 10, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10.0410.0410.040.04100.0" + "'", str18.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0" + "'", str22.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100a0a1a0", "44444444444444444444444444444444444444444444444444444444444444444444444444##########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test367");
        long[] longArray2 = new long[] { 12, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 1, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 75, (int) (short) -1);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long17 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1240" + "'", str8.equals("1240"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1240" + "'", str10.equals("1240"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 12L + "'", long16 == 12L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test368");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test369");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test370");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj7v7P7f.mAPISf7Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test371");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################/Users/sophie####################", 9, 1324);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test372");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1#33#35");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ava.oracle.com/http://j", "sophie                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.com/http://j" + "'", str2.equals("ava.oracle.com/http://j"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("s10.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 10, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "s#10#.#0" + "'", str8.equals("s#10#.#0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                            ", (java.lang.CharSequence) "/00404/40                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJjerraraeaea-ea3jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJjerraraeaea-ea3jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJj" + "'", str1.equals("jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJjerraraeaea-ea3jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJj"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachine...", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachine..." + "'", str3.equals("/Library/Java/JavaVirtualMachine..."));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##########################j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test379");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test380");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                  -1a1a0a10a10pecifica PlavaJti", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test381");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 176, 0);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 27, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test382");
        short[] shortArray5 = new short[] { (short) -1, (short) -1, (short) 100, (byte) -1, (byte) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) (byte) 1, 158);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test383");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 8, (short) 0, (short) 8);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test384");
        double[] doubleArray1 = new double[] { 1.0f };
        double[] doubleArray3 = new double[] { 1.0f };
        double[] doubleArray5 = new double[] { 1.0f };
        double[] doubleArray7 = new double[] { 1.0f };
        double[] doubleArray9 = new double[] { 1.0f };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        double[] doubleArray12 = new double[] { 1.0f };
        double[] doubleArray14 = new double[] { 1.0f };
        double[] doubleArray16 = new double[] { 1.0f };
        double[] doubleArray18 = new double[] { 1.0f };
        double[] doubleArray20 = new double[] { 1.0f };
        double[][] doubleArray21 = new double[][] { doubleArray12, doubleArray14, doubleArray16, doubleArray18, doubleArray20 };
        double[] doubleArray23 = new double[] { 1.0f };
        double[] doubleArray25 = new double[] { 1.0f };
        double[] doubleArray27 = new double[] { 1.0f };
        double[] doubleArray29 = new double[] { 1.0f };
        double[] doubleArray31 = new double[] { 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray23, doubleArray25, doubleArray27, doubleArray29, doubleArray31 };
        double[] doubleArray34 = new double[] { 1.0f };
        double[] doubleArray36 = new double[] { 1.0f };
        double[] doubleArray38 = new double[] { 1.0f };
        double[] doubleArray40 = new double[] { 1.0f };
        double[] doubleArray42 = new double[] { 1.0f };
        double[][] doubleArray43 = new double[][] { doubleArray34, doubleArray36, doubleArray38, doubleArray40, doubleArray42 };
        double[] doubleArray45 = new double[] { 1.0f };
        double[] doubleArray47 = new double[] { 1.0f };
        double[] doubleArray49 = new double[] { 1.0f };
        double[] doubleArray51 = new double[] { 1.0f };
        double[] doubleArray53 = new double[] { 1.0f };
        double[][] doubleArray54 = new double[][] { doubleArray45, doubleArray47, doubleArray49, doubleArray51, doubleArray53 };
        double[][][] doubleArray55 = new double[][][] { doubleArray10, doubleArray21, doubleArray32, doubleArray43, doubleArray54 };
        java.lang.String str56 = org.apache.commons.lang3.StringUtils.join(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test385");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HPOS/SRESU/", 23, "        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            HPOS/SRESU/" + "'", str3.equals("            HPOS/SRESU/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "s10.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0 0.0 1.0", "ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test389");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test390");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-143");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-143) + "'", int1.equals((-143)));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test391");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 28, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("amac os xa", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "amac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xa" + "'", str2.equals("amac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xa"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!hi!hi", "44444444444444444444444440040414044444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444440040414044444444444444444444444444" + "'", str2.equals("44444444444444444444444440040414044444444444444444444444444"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEaJ7v7P7f.mAPISfMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachine...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", 32, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444" + "'", str3.equals("http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test397");
        java.lang.CharSequence charSequence5 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] {};
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5.", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mac#OS#X", charArray10);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100 0 1 1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test399");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                    0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.0410.0410.040.04100.0                           ", "4444444444444                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0410.0410.040.04100.0                           " + "'", str2.equals("10.0410.0410.040.04100.0                           "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "x86_64");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("7P7f.mAPISf7", (int) (short) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7P7f.mAPISf" + "'", str3.equals("7P7f.mAPISf"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test403");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                    0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 67 + "'", int1 == 67);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("            0.0410.0410.040.04100.0", "-BIT SERVER VM4JAVA HOTSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVER VM4JAVA HOTSPOT(TM) 6" + "'", str2.equals("-BIT SERVER VM4JAVA HOTSPOT(TM) 6"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JAV", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAV" + "'", str2.equals("JAV"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test407");
        java.lang.CharSequence charSequence7 = null;
        java.lang.CharSequence charSequence8 = null;
        char[] charArray12 = new char[] {};
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence8, charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence7, charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charArray12);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100", charArray12);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                         ", charArray12);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               10.0", charArray12);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/00404/40", charArray12);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com/                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/                             " + "'", str1.equals("HTTP://JAVA.ORACLE.COM/                             "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Sun.awt.CGraphicsEnvironment.8", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "erj/emoH/stnetnoC/kdj.08_0.7...");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "t/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/USERS/SOPHIE" + "'", str5.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test411");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlauOracleCorperj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlau", (java.lang.CharSequence) "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("4", " ######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 32, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test414");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("OracleCorporation4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCor\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test415");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie", charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test416");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 143 + "'", int1 == 143);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0#27#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#27#0" + "'", str1.equals("0#27#0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test418");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, (long) (byte) 10, 1318L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                                                ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA##########################################", " ######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA##########################################" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA##########################################"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test421");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, 18);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test422");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "-14-141004-14100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test424");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test425");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                            ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 108 + "'", int2 == 108);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test426");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#############################################", 15, 158);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test427");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("J7v7P7f.mAPISf7Mac OS X#########");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 65, "HPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HPOS/SRESU/HPOS/SRESU/HPOS/SRESUHPOS/SRESU/HPOS/SRESU/HPOS/SRESU/" + "'", str3.equals("HPOS/SRESU/HPOS/SRESU/HPOS/SRESUHPOS/SRESU/HPOS/SRESU/HPOS/SRESU/"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test430");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "/7s7s7/.esss/7", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...                                            ", (-1), "51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                            " + "'", str3.equals("...                                            "));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test433");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" 3  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 3  " + "'", str2.equals(" 3  "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test435");
        char[] charArray9 = new char[] { ' ', '#', '#', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) ' ', (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100404140", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray9);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a27a0", charArray9);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/                             ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " ######" + "'", str16.equals(" ######"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 23 + "'", int20 == 23);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test436");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                ", (double) (-143));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-143.0d) + "'", double2 == (-143.0d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("\n888", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n888" + "'", str2.equals("\n888"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test438");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "OracleCorporationHI!", (java.lang.CharSequence) "ava.oracle.com/http://j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                               SOPHIE                                               ", "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("s 100404140  ph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s 100404140  ph" + "'", str1.equals("s 100404140  ph"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test441");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test443");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test445");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 26, (int) (byte) 1);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "    /00404/40                  ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                        ", "-1 33 35");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100a0a1a1a-1a3", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a0a1a1a-1a" + "'", str2.equals("100a0a1a1a-1a"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                                                                                            ", "aaaaerj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                            " + "'", str2.equals("                                                                                                                                                                            "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test449");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HPOS/SRESU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HPOS/SRESU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...ava....", "va.oracle.com/http://j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("-BIT SERVER VM4JAVA HOTSPOT(TM) 6", "            HPOS/SRESU/", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-BIT SERVER VM4JAVA HOTSPOT(TM) 6" + "'", str3.equals("-BIT SERVER VM4JAVA HOTSPOT(TM) 6"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test452");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                0", (java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7.../Users/so");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test453");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###############################", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test455");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1 33 35", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test456");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444                        " + "'", str2.equals("                        wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444                        "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "04140400");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test459");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mod", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100404140", "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100404140" + "'", str2.equals("100404140"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("S.7.X_8X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S.7.X_8X" + "'", str1.equals("S.7.X_8X"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "aaaaerj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test464");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#################################################1.8", (long) (byte) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test466");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                         ###########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###########################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" ######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######" + "'", str1.equals("######"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test468");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#0#1#1#-1#3" + "'", str9.equals("100#0#1#1#-1#3"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100 0 1 1 -1 3                  ", "                  /uSERS/SOPHIE", "hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100h0h1h1h-1h3hhhhhhhhhhhhhhhhhh" + "'", str3.equals("100h0h1h1h-1h3hhhhhhhhhhhhhhhhhh"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Library/Java/JavaVirtualMachine...", "DE", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachine..." + "'", str3.equals("/Library/Java/JavaVirtualMachine..."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test473");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 1, 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 9, 0);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                             J7v7P7f.mAPISf7Mac OS X", (int) (byte) 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test475");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                               10.0", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "amac os  ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti", 0, (int) (byte) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test477");
        float[] floatArray1 = new float[] { (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 31, (int) (short) 10);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test479");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ca P", (java.lang.CharSequence) "0 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ca P" + "'", charSequence2.equals("ca P"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Ja a#a#a# HotSpot(TM) 6a-Bit Server VM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HTTP://JAVA.ORACLE.COM/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Usesophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100", "100h0h1h1h-1h3hhhhhhhhhhhhhhhhhh");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1.040.041.0", "1.81.81.", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.0" + "'", str3.equals("-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.0"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test488");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/00404/40                  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/00404/40                  " + "'", str2.equals("/00404/40                  "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444##########################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test491");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "                  ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4', (int) 'a', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("SUN.LWAWT.MACOSX.LWCTOOLKIT", strArray5, strArray9);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/s:/Users/so", (java.lang.CharSequence[]) strArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "x86_64", (int) '4', (int) (short) 10);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str14.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.lwctoolkit", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "Oracle Corporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("97a0a-1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97a0a-1a100" + "'", str1.equals("97a0a-1a100"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test495");
        short[] shortArray1 = new short[] { (byte) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 94, 10);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test496");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                           X86_64", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8" + "'", str1.equals("  AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("erj/emoH/sOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/sOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("erj/emoH/sOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test500");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/7s7s7/.esss/7");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

