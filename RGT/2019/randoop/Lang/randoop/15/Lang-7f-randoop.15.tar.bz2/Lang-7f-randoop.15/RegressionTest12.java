import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10#100#0#-1#1", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#100#0#-1#1" + "'", str2.equals("10#100#0#-1#1"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test004");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", 18, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test005");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0", (java.lang.CharSequence) " SiluSihHuccc ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test007");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test008");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("\n888");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test009");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("r", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      r                                                                      " + "'", str2.equals("                                                                      r                                                                      "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test011");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test012");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test013");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 65, 3);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100404140" + "'", str6.equals("100404140"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test014");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "44444444444444444444444444444P4f44APISf44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("noitacificepS enihcaM lautriV avaJ", "0 27 0                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str2.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment.8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                 .8                ", 7, "J7v7P7f.mAPISf7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 .8                " + "'", str3.equals("                 .8                "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test018");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.81.81.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.81.81.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test019");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test020");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 75, 35);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test022");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("24.80-B11 ", "                            10.0", 100, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                            10.0" + "'", str4.equals("                            10.0"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test023");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", "100404140");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Librry/Jv/JvVirtulM", "Erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librry/Jv/JvVirtulM" + "'", str2.equals("/Librry/Jv/JvVirtulM"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test025");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { ' ', '#', '#', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...######7######.######0######_######80######.######jdk######/######C######ontents######/######H######ome######/######jre", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test026");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0410.0410.040.04100.0", "hi!", (-1));
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test027");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                               sophie                                               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("OracleCorporationHI!", "100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationHI!" + "'", str2.equals("OracleCorporationHI!"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "               " + "'", str1.equals("               "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java HotSpot(TM) 6a-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 6a-Bit Server V" + "'", str1.equals("Java HotSpot(TM) 6a-Bit Server V"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "vaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1.040.041.0", (int) '#', "100a0a1a1a-1a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.040.041.0100a0a1a1a-1a100a0a1a1a" + "'", str3.equals("-1.040.041.0100a0a1a1a-1a100a0a1a1a"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachine...", "OracleCorporationHI!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("100a0a1a0", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 11 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                               sophie                                               ", "", (int) (short) 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/         " + "'", str1.equals("Http://java.oracle.com/         "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test036");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aa", (byte) 4);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 4 + "'", byte2 == (byte) 4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "amac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xaamac os xa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test038");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                  java(tm) se runtime e0#1#100#10#-1#1                  java(tm) se runtime en", charSequence1, 92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "  1240  ", "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test040");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "14.010010010010010010010010010010010010010010", (java.lang.CharSequence) "                   4444444444444444444444444414.0", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test041");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          -1.00.01.0          ", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          -1.00.01.0          " + "'", str3.equals("          -1.00.01.0          "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test043");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 3, (-1));
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44444444444444444444444440040414044444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444041404004444444444444444444444444" + "'", str1.equals("44444444444444444444444444041404004444444444444444444444444"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test046");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-14-141004-14100", "erj/emoH/stnetnoC/kdj.08_0.7...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-14-141004-14100" + "'", str4.equals("-14-141004-14100"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt.macosx.CPrinterJob", "#############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test048");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "form API S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("        /moc.elcro.vj//:ptt", "10.14.3", "100 0 1 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        /moc.elcro.vj//:ptt" + "'", str3.equals("        /moc.elcro.vj//:ptt"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test050");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ss [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa", (java.lang.CharSequence) "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1#33#35", "...    ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#33#35" + "'", str2.equals("-1#33#35"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test055");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test056");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/httpwt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.6", 1466);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a Platform API SpecificationJava Platform API SpecificationJava Platform", "4444444444444                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a Platform API SpecificationJava Platform API SpecificationJava Platform" + "'", str2.equals("a Platform API SpecificationJava Platform API SpecificationJava Platform"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", "               http://java.oracle.com/                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test060");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1.040.041.0100a0a1a1a-1a100a0a1a1a", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test061");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444440040414044444444444444444444444444", (java.lang.CharSequence) "44444444444444444444444444041404004444444444444444444444444", 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test062");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004041414-143" + "'", str10.equals("1004041414-143"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test065");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                               sophie                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                sophie                                                is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) " 100  ", (java.lang.CharSequence) "java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test067");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 100, (int) (byte) 100);
        double double17 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double20 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', (int) (byte) 1, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10.0 10.0 10.0 0.0 100.0" + "'", str19.equals("10.0 10.0 10.0 0.0 100.0"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":", "24.80-b11 ", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":24.80-b11 :24.80-b11 :" + "'", str3.equals(":24.80-b11 :24.80-b11 :"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "HTTP://JAVA.ORACLE.COM/        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "              0a27a0                                                            ", "S.7.X_8X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test071");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla", "0 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 0", "-1433435");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla" + "'", str3.equals("34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaform API S", "s 100404140  ph");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test075");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0410.0410.040.04100.0", "hi!", (-1));
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "                                                    ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1.0 0.0 1.0", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "10.0a10.0a");
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0410.0410.040.04100.0" + "'", str9.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0410.0410.040.04100.0" + "'", str11.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0410.0410.040.04100.0" + "'", str12.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("...4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test079");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) 1323, 4.44444451E15f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.44444451E15f + "'", float3 == 4.44444451E15f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("         ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test081");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "amac os xa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test082");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1240281325.075.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test084");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test085");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                 4444444444444441.8                 ", (float) 141);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.44444451E15f + "'", float2 == 4.44444451E15f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test086");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1325L, (long) (byte) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test088");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1.0 0.0 1.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1.0 0.0 1.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specification" + "'", str1.equals("java platform api specification"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test090");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (short) 1, 1466);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100404140" + "'", str6.equals("100404140"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj" + "'", str1.equals("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test092");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0#10.0#10.0#0.0#100.0" + "'", str12.equals("10.0#10.0#10.0#0.0#100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0#10.0#10.0#0.0#100.0" + "'", str14.equals("10.0#10.0#10.0#0.0#100.0"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test093");
        int[] intArray4 = new int[] { 'a', 0, (byte) -1, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 100404140, 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 2, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 4, 3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97#0#-1#100" + "'", str6.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97404-14100" + "'", str18.equals("97404-14100"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                   4444444444444444444444444414.0", "100a0a1a1a-1a324.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 24.80-b11 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test095");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 0, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test096");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "            0.0410.0410.040.04100.0erj/emoH/sOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "erj######/######emo######H######/######stnetno######C######/######kdj######.######08######_######0######.######7######...", 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test097");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) 80, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1004041414-143");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041414-143" + "'", str1.equals("1004041414-143"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test099");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("        /moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("J7v7P7f.mAPISf7Mac OS X#########", "                 444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.01.81.81.-1.040.041.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test102");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test103");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        boolean boolean20 = javaVersion15.atLeast(javaVersion17);
        boolean boolean21 = javaVersion11.atLeast(javaVersion15);
        boolean boolean22 = javaVersion0.atLeast(javaVersion15);
        java.lang.String str23 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.1" + "'", str23.equals("1.1"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test104");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Environment Runtime SE Java(TM)", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test105");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 100, (int) (byte) 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 10, (int) (short) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1#33#35");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1#33#35");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("042740", "class [Bclass [Bclass [Bclass [Dclass [Ljava.lang.String;", 1466);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "042740" + "'", str5.equals("042740"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("    http://java.oracle.com/    ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA##########################################", 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    http://java.oracle.com/    " + "'", str3.equals("    http://java.oracle.com/    "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n", ' ');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0 27 0", "/7s7s7/.esss/7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/7s7s7/.esss/7" + "'", str2.equals("/7s7s7/.esss/7"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                       " + "'", str1.equals("                       "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test111");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("                                                    ", "-1.0 0.0 1.0", (int) (byte) 1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0410.0410.040.04100.0", "hi!", (-1));
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophie                                               ", strArray5, strArray10);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sophie                                               " + "'", str13.equals("sophie                                               "));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test112");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100 0 1 1 -1 3", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("00404140");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "00404140" + "'", str1.equals("00404140"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test114");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                         ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj", "                                           X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj" + "'", str2.equals("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test116");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444##########################", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test117");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ".8", (java.lang.CharSequence) "Oracle ...", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test118");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 0, 45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a27a0" + "'", str7.equals("0a27a0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 27L + "'", long8 == 27L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 27L + "'", long9 == 27L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("R");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r" + "'", str1.equals("r"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test120");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    /00404/40                  ", 2, "...ava....");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    /00404/40                  " + "'", str3.equals("    /00404/40                  "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-1.0 0.0 1.0Us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 0.0 1.0Us" + "'", str1.equals("-1.0 0.0 1.0Us"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100 0 1 1 -1 3                  ", "                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 1 -1 3                  " + "'", str2.equals("100 0 1 1 -1 3                  "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("-1#1#0#10#10", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "va HaSpa(TM) 64-Ba Sava VM" + "'", str8.equals("va HaSpa(TM) 64-Ba Sava VM"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test126");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10.0a10.0a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444444444444                                                    ", "/#L#ib###################################################1#.#8#IXED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444                                                    " + "'", str2.equals("4444444444444                                                    "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       ", "aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test129");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) ' ', 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                             1.1", "              0a27a0               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test131");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("lass [Ljava.lang.String;", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lass [Ljava.lang.String;" + "'", str2.equals("lass [Ljava.lang.String;"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test133");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, (long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test136");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                  -1a1a0a10a10pecifica PlavaJti", 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj7v7P7f.mAPISf7Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj7v7P7f.mAPISf7Mac OS X" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj7v7P7f.mAPISf7Mac OS X"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.0 0.0 1.0", " ######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 0.0 1.0" + "'", str2.equals("-1.0 0.0 1.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10.0 10.0 10.0 0.0 100.0", "\n888", "                        wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444                        ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test140");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test142");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 176, 0);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 1324, 75);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 10 + "'", short12 == (short) 10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test143");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "04140400");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("form API S                                                                               ", "                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "form API S               " + "'", str2.equals("form API S               "));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("        /moc.elcro.vj//:ptth", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        /moc.elcro.vj//:ptth" + "'", str3.equals("        /moc.elcro.vj//:ptth"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("....ava...", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           ....ava...                                           " + "'", str2.equals("                                           ....ava...                                           "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 72, 71);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test148");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test149");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 12, 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("97a0a-1a100", "    http://java.oracle.com/    ", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test151");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444414.0", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test152");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                             10.", (java.lang.CharSequence) "24.80-b11", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 94, "\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test154");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test155");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1", (double) 14.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1004041414-143");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100404140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/moc.elcaro.avaj//:ptth", 'a');
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "        ############################################", (java.lang.CharSequence[]) strArray7);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100404140" + "'", str3.equals("100404140"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlauOracleCorperj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlau", "s 100404140  ph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlauOracleCorperj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlau" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlauOracleCorperj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlau"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1433435");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1433435" + "'", str1.equals("-1433435"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test160");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...4444444444444444444444444444444444444444444444444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100 0 1 1 ", "          -1.0a0.0a1.0         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          -1.0a0.0a1.0         " + "'", str2.equals("          -1.0a0.0a1.0         "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ", "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100", (int) (short) 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test163");
        int[] intArray4 = new int[] { 'a', 0, (byte) -1, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 1324, 18);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 176, 0);
        int int18 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.Class<?> wildcardClass19 = intArray4.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97#0#-1#100" + "'", str6.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97404-14100" + "'", str9.equals("97404-14100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test164");
        int[] intArray4 = new int[] { 'a', 0, (byte) -1, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 33, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97#0#-1#100" + "'", str6.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97 0 -1 100" + "'", str8.equals("97 0 -1 100"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test165");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test166");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100a0a1a1a-1a3.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.", "          ", 1325, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          " + "'", str4.equals("          "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("14.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14.0" + "'", str1.equals("14.0"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ry/Ja/Libr", ".040.041.0", "                         ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test169");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "sun.lwawt.macosx.CPrinterJob", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "Oracle Corporation", (int) (byte) 0, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "10.0410.0410.040.04100.0", (int) 'a', (int) (byte) 10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                SUN.LWAWT.MACOSX.LWCTOOLKIT                ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0                                                    ", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test171");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test172");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (-1433435));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test173");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8", (double) 80);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 80.0d + "'", double2 == 80.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                  java(tm) se runtime e0#1#100#10#-1#1                  java(tm) se runtime en", (java.lang.CharSequence) "444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test175");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test176");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  ", "1.", (int) (byte) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split(":", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 4#4#4#", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach(".1", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ".1" + "'", str10.equals(".1"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test177");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaJ7v7P7f.mAPISfaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0410", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test179");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 8, (float) 92, (float) 1318L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test180");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "OracleCorporation4", 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test182");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("s10.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (int) (byte) 1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "                  ");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, '4', (int) 'a', 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("SUN.LWAWT.MACOSX.LWCTOOLKIT", strArray10, strArray14);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/s:/Users/so", (java.lang.CharSequence[]) strArray10);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "x86_64", (int) '4', (int) (short) 10);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray10);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("sunawtGraphics1nvironment", strArray4, strArray10);
        java.lang.Class<?> wildcardClass27 = strArray10.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str19.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "sunawtGraphics1nvironment" + "'", str26.equals("sunawtGraphics1nvironment"));
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test183");
        long[] longArray3 = new long[] { (short) -1, 33, 35 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#33#35" + "'", str6.equals("-1#33#35"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a33a35" + "'", str8.equals("-1a33a35"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", (int) (short) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n" + "'", str3.equals("J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "######", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test186");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1#33#35", charArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray2, '4', (int) (byte) 100, 35);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0#27#0", (java.lang.CharSequence) "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("          -1.0a0.0a1.0          ", "10.0410.0410.040.04100.0                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a0.0a1.0          " + "'", str2.equals("-1.0a0.0a1.0          "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                             10.", (java.lang.CharSequence) "100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("SiluSihHuccc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "silusihhuccc" + "'", str1.equals("silusihhuccc"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test191");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Ja a#a#a# HotSpot(TM) 6a-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test192");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0.01                               ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("              0a27a0                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              0A27A0                                                            " + "'", str1.equals("              0A27A0                                                            "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test194");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) 10, (byte) -1, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#1#100#10#-1#1" + "'", str9.equals("0#1#100#10#-1#1"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("silusihhuccc", "0.9", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":24.80-b11 :24.80-b11 :", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":24.80-b11 :24.80-b11 :" + "'", str3.equals(":24.80-b11 :24.80-b11 :"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ." + "'", str1.equals(".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ."));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...", "-1a1a-1a1a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test199");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test200");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100a0a1a1a-1a3.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaerj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaerj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  aaa" + "'", str1.equals("aaaaerj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  aaa"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("herj/emoH/...h", "MIXEDMODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "herj/emoH/...h" + "'", str2.equals("herj/emoH/...h"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1111111111111111111111", "-1a33a35");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "1.81.81.", "T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test205");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, " ######");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "1.1");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("erj/emoH/...", strArray4, strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "lass [Ljava.lang.String;");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "erj/emoH/..." + "'", str12.equals("erj/emoH/..."));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/#L#ib###################################################1#.#8#IXED", "erj/emoH/sOracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#L#ib###################################################1#.#8#IXED" + "'", str2.equals("/#L#ib###################################################1#.#8#IXED"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1" + "'", str1.equals("-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test208");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("lass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test209");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b1524.80-B11 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".../STNETNOC/KDJ.08_0.7...", "erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "4444444444444441.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test212");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-143", (java.lang.CharSequence) "OracleCorp");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test213");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "        ", (java.lang.CharSequence) "         -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                               ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "silusihhuccc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####", "os/sresU/:s/sresU/", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualM" + "'", str2.equals("/Library/Java/JavaVirtualM"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444" + "'", str1.equals("4444444444444444444444"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                 4444444444444441.8                 ", "                                           X86_64", "97#0#-1#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 4444444444444441.8                 " + "'", str3.equals("                 4444444444444441.8                 "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1" + "'", str1.equals("124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test223");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0", (java.lang.CharSequence) "Erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/10.14.3erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test224");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("###################/Users/sophie####################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##################/Users/sophie####################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                    0a1a100a10a-1a1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test227");
        long[] longArray2 = new long[] { 12, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 1, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 29, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1240" + "'", str8.equals("1240"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1240" + "'", str10.equals("1240"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12L + "'", long12 == 12L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" ", "wt.CGrphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", "/users/sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test229");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test230");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(52.0f, (float) 9, (float) 1318);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1318.0f + "'", float3 == 1318.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test231");
        int[] intArray4 = new int[] { 'a', 0, (byte) -1, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97#0#-1#100" + "'", str6.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97#0#-1#100" + "'", str8.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test233");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("herj/emoH/...h");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "14.0", "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "...                                                                     ...", "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test236");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Librry/Jv/JvVirtulM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Librry/Jv/JvVirtulM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test237");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test238");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("###############################", "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###############################" + "'", str4.equals("###############################"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test239");
        char[] charArray9 = new char[] { ' ', '#', '#', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) ' ', (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100404140", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                         97#0#-1#100", charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5.", charArray9);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "erj/emoH/...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " ######" + "'", str16.equals(" ######"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 89 + "'", int18 == 89);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test240");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", 75);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("s10.0");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "   ", (java.lang.CharSequence[]) strArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence[]) strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/s:/Users/so", strArray7, strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Users/s:/Users/so" + "'", str16.equals("/Users/s:/Users/so"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.7.0_80" + "'", str17.equals("1.7.0_80"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test241");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                sun.lwawt.macosx.LWCToolkit                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test243");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                  -1a1a0a10a10pecifica PlavaJti", (double) 158);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 158.0d + "'", double2 == 158.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                         97#0#-1#100", (int) (short) 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                         97#0#-1#100" + "'", str2.equals("                                                                                         97#0#-1#100"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3", "", "12a0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0", "mac os x");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test247");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("8                         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sunawtGraphics1nvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUNAWTgRAPHICS1NVIRONMENT" + "'", str1.equals("SUNAWTgRAPHICS1NVIRONMENT"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test250");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "        ############################################", (java.lang.CharSequence) "http://java.oracle.com/                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test252");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test253");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                 444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/                                                                                                                                                     ", (java.lang.CharSequence) "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test255");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "            HPOS/SRESU/", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/00404/40");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/00404/40" + "'", str1.equals("/00404/40"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0" + "'", str3.equals("51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test258");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1240281325.075.0", (java.lang.CharSequence) "1111111111111111111111", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("erj/e...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/e..." + "'", str1.equals("erj/e..."));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 1318, "...oracle.com/http://java.oracle.com/http:...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit...oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://j" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit...oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://j"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("          -1.0a0.0a1.0         ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           - 1 . 0 a 0 . 0 a 1 . 0          " + "'", str3.equals("           - 1 . 0 a 0 . 0 a 1 . 0          "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test262");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test263");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100 0 1 1 -1 3", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44", "######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1.040.041.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test267");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                             1.1", "Herj/emoH/...h", 45);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", 100404140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                 .8                ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test271");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', (int) 'a', 0);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split(" ", 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ####", (java.lang.CharSequence[]) strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " " + "'", str16.equals(" "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "12 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "         -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test274");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", 32, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("12#0", 3, "100 0 1 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "12#0" + "'", str3.equals("12#0"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("3", 100404140);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test277");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "   ", (java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence[]) strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "sophie");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...", (java.lang.CharSequence[]) strArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "java platform api specification");
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (-143), "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "form API S                                                                               ", (java.lang.CharSequence) "                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test281");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("erj/emoH/stnetnoC/kdj.08_0.7...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                 444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 444444444" + "'", str1.equals("                 444444444"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test284");
        short[][][] shortArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("erj/emoH/...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 0 1 1 -1 3                  ", "24.80-B11 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("            0.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            0.0410.0410.040.04100.0" + "'", str1.equals("            0.0410.0410.040.04100.0"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test289");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#0.0#1.0" + "'", str8.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0#0.0#1.0" + "'", str10.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0#0.0#1.0" + "'", str12.equals("-1.0#0.0#1.0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test290");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444441.8", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test291");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.0410.0410.040.04100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test292");
        char[] charArray4 = new char[] { '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "              0A27A0                                                            ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                    ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test293");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 100, (int) (byte) 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 10, (int) (short) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 71, 176);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 71");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "              0A27A0                                                            ", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test295");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                               sophie                                               ", charSequence1, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence) "12 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test297");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.0410.0410.040.0410100a0a1a1a-1a3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test299");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 1, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', (-143), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -143");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a0a1a1a-1a3" + "'", str13.equals("100a0a1a1a-1a3"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a0a1a1a-1a3" + "'", str15.equals("100a0a1a1a-1a3"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#0#1#1#-1#3" + "'", str17.equals("100#0#1#1#-1#3"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n" + "'", str2.equals("J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/#L#ib###################################################1#.#8#IXED", 1325, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test302");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 67, (float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-BIT SERVER VM4JAVA HOTSPOT(TM) 6", 94, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-BIT SERVER VM4JAVA HOTSPOT(TM) 6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-BIT SERVER VM4JAVA HOTSPOT(TM) 6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test304");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "...racleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test306");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0410.0410.040.04100.0                            ", charArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 89, (int) (short) 4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                        ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test307");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test308");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97a0a-1a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test310");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 31, 9L, 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test311");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(12L, (long) '#', (-1433435L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test313");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "                SUN.LWAWT.MACOSX.LWCTOOLKIT                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test314");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-B11 ", (java.lang.CharSequence) "...ava....", (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test315");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444041404004444444444444444444444444", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test316");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen                                                                      ", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "AAAAAAAAAAAAAAA", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test318");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("OracleCorp", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.0410.0410.040.0410100a0a1a1a-1a3", "         -1.0a0.0a1.0         ############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test322");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', 8L, 14L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa", "\n888");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.1", "###############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################" + "'", str2.equals("###############################################"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test325");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("7P7f.mAPISf", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                1.8                /7s7s7/.esss/7", "HPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.8                /7s7s7/.esss/7" + "'", str2.equals("                1.8                /7s7s7/.esss/7"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test327");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit...oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr", "14141441                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test329");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "##12 0###", (java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("lass [Ljava.lang.String;", "####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                            10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test332");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi", (double) 141L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 141.0d + "'", double2 == 141.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1 33 35");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 33 35" + "'", str1.equals("-1 33 35"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 100404140, 9);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test335");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int18 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 65, 47);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 0 1 1 -1 3" + "'", str10.equals("100 0 1 1 -1 3"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a0a1a1a-1a3" + "'", str12.equals("100a0a1a1a-1a3"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004041414-143" + "'", str14.equals("1004041414-143"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#0#1#1#-1#3" + "'", str17.equals("100#0#1#1#-1#3"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "100a0a1a1a-1a3" + "'", str25.equals("100a0a1a1a-1a3"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("14.0", 45, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test337");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 0, (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) ' ', 27);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 176, 26);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (-1), 47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test338");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100 0 1 1 -1 3", charArray3);
        java.lang.Class<?> wildcardClass13 = charArray3.getClass();
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "va HaSpa(TM) 64-Ba Sava VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test340");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "amac os  ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti", 72);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test341");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", 2, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...noitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacifi", 158, 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...                                            ", 6, "3a1-a1a1a0a0010140.040.0140.0140.01O");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                            " + "'", str3.equals("...                                            "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("14.010010010010010010010010010010010010010010", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14.010010010010010010010010010010010010010010" + "'", str2.equals("14.010010010010010010010010010010010010010010"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test345");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 44.0f + "'", float1 == 44.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100h0h1h1h-1h3hhhhhhhhhhhhhhhhhh", 80, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa100h0h1h1h-1h3hhhhhhhhhhhhhhhhhhaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaa100h0h1h1h-1h3hhhhhhhhhhhhhhhhhhaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "J7v7P7f.mAPISf7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("97404-14100", (int) 'a', "http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97404-14100http://java.oracle.com/         http://java.oracle.com/         http://java.oracle.com" + "'", str3.equals("97404-14100http://java.oracle.com/         http://java.oracle.com/         http://java.oracle.com"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test349");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass15 = floatArray3.getClass();
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 0.0 1.0" + "'", str8.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#0.0#1.0" + "'", str11.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.040.041.0" + "'", str13.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + (-1.0f) + "'", float16 == (-1.0f));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" ######44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######44" + "'", str1.equals("######44"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test351");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 176, 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float17 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 0.0 1.0" + "'", str8.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0#0.0#1.0" + "'", str15.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test352");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "3a1-a1a1a0a0010140.040.0140.0140.01O", (java.lang.CharSequence) "3a1-a1a1a0a0010140.040.0140.0140.01O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test353");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 35, 35);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test354");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) ' ', (int) ' ');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 0 1 1 -1 3" + "'", str10.equals("100 0 1 1 -1 3"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a0a1a1a-1a3" + "'", str12.equals("100a0a1a1a-1a3"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004041414-143" + "'", str14.equals("1004041414-143"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test355");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test356");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 1323, 0);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" 100  ", "HTTP://JAVA.ORACLE.COM/        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 100  " + "'", str2.equals(" 100  "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test358");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("form API S", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test359");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("va.oracle.com/http://j", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test360");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HTTP://JAVA.ORACLE.COM/        ", (byte) 8);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 8 + "'", byte2 == (byte) 8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", (java.lang.CharSequence) "                  -1a1a0a10a10pecifica PlavaJti");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test362");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 3, (-1));
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray5);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test363");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 158, 26);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 0.0 1.0" + "'", str8.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.81.81.", "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81." + "'", str2.equals("1.81.81."));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test365");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  ", "a Platform API SpecificationJava Platform API SpecificationJava Platform", 108, 65);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJa Platform API SpecificationJava Platform API SpecificationJava PlatformOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  " + "'", str4.equals("ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJa Platform API SpecificationJava Platform API SpecificationJava PlatformOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/moc.elcaro.avaj//:ptth", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "va HaSpa(TM) 64-Ba Sava VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test369");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test370");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8", "                 444444444", 14);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("   ", 'a');
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "wt.r4444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.HI!  ", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.HI!  " + "'", str11.equals("0.HI!  "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test371");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", "sun.awt.CGraphicsEnvironmen", 35);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "\n\n\n\n\n\n\n\naa", 6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/users/sophi", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophi" + "'", str3.equals("/users/sophi"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test373");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1324, (float) 8L, (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " 10.0#10.0#10.0#0.0#100.0 10.0#10.0#10.0#0.0#100.0 10.0#10.0#10.0#0.0#100.0 -10.0#10.0#10.0#0.0#100.0 3", (java.lang.CharSequence) "       ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    /00404/40                  ", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test376");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 8, (byte) 8, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test377");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray2, '#', 32, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "r", (java.lang.CharSequence) "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "    /00404/40                  ", (java.lang.CharSequence) "##############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("H/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ", "4444444444444                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  " + "'", str2.equals("H/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test381");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 0, (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) ' ', 27);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) 'a', (-1));
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10.0#10.0#10.0#0.0#100.0" + "'", str23.equals("10.0#10.0#10.0#0.0#100.0"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test382");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mac os x", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("wt.r4444444444444444444444444444444444444444444444444444444444444444", "/users/sophi", 1324);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "wt.r4444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("wt.r4444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test384");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test385");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("   http://java.oracle.com/                             ", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("JAVA VIRTUAL MACHINE SPECIFICATION");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "wt.r4444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test387");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 8, (short) (byte) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" ######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######" + "'", str1.equals("######"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test389");
        long[] longArray2 = new long[] { 12, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 1, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1240" + "'", str8.equals("1240"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12a0" + "'", str12.equals("12a0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############" + "'", str2.equals("###############"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE", "Erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test392");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 0, (int) (byte) 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 27L + "'", long12 == 27L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("###################/Users/sophie####################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################/Users/sophie####################" + "'", str1.equals("###################/Users/sophie####################"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test394");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("x86_64", (float) 94);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 94.0f + "'", float2 == 94.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test395");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("ss [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ss [Ljava.lang.String; is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test396");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "-1a1a-1a1a", (java.lang.CharSequence) "####");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1a1a-1a1a" + "'", charSequence2.equals("-1a1a-1a1a"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test397");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test398");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test399");
        float[] floatArray2 = new float[] { 100404140, 27L };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.00404144E8f + "'", float3 == 1.00404144E8f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.00404144E8f + "'", float4 == 1.00404144E8f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.00404144E8f + "'", float5 == 1.00404144E8f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1.0a0.0a1.0", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0a0.0a1.0" + "'", str3.equals("-1.0a0.0a1.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "14.0", (java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "###########################", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ", (java.lang.CharSequence) "/uSERS/SOPHIE/uSERS/SOPHIE/uSERS/SOPH7P7f.mAPISf7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("uTF-8", "", "53#33#1-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uTF-8" + "'", str3.equals("uTF-8"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", (-1433435));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "0#1#100#10#-1#1", "UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test408");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("        /moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                         97#0#-1#100", "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str2.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mod", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit...oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://java.oracle.com/http:......oracle.com/http://j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test411");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen                                                                      ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 1466);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JAVA VIRTUAL MACHINE SPECIFICATION", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION##################################################################" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATION##################################################################"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachine...", (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Environment Runtime SE Java(TM)", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("            sun.awt.CGraphicsEnvironment            ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test416");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1.0#0.0#1.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "HI!", (int) (short) 0, 92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#0.0#1.0" + "'", str2.equals("-1.0#0.0#1.0"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("14141441                            ", 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test418");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test419");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 3, (-1));
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "######", charArray5);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5.", charArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1#1#0#10#10", 32, 158);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/moc.elcaro.avaj//:ptth", "Mac OS X", "44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str3.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test422");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment", (double) 27.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 27.0d + "'", double2 == 27.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "14.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment", "1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment" + "'", str3.equals("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Herj/emoH/...h", "0a27a0                           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test426");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("t/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###############", 71, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444###############" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444###############"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http" + "'", str2.equals("/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444441.8", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444441.8" + "'", str2.equals("4444444444444441.8"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test430");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Libr#ry/J#v#/Extensions:/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extensions:/usr/lib/j#v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "J7v7P7f.mAPISf7", (java.lang.CharSequence) "-1.0#0.0#1.0-110.0-1.0#0.0#1.0-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test434");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 4, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("#################################################1.8IXED #################################################1.8ODE", "/00404/40                  ", 47);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                               SOPHIE                                               ", (java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test437");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/", "4444444444444441.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test440");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test441");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (short) 100, 89);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float17 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a0.0a1.0" + "'", str11.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + (-1.0f) + "'", float16 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + (-1.0f) + "'", float17 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1.040.041.0" + "'", str19.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...                                                                     ...", "tionUStion", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1325);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("3a1-a1a1a0a0010140.040.0140.0140.01O");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3a1-a1a1a0a0010140.040.0140.0140.01O" + "'", str1.equals("3a1-a1a1a0a0010140.040.0140.0140.01O"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100" + "'", str2.equals("/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0 0.0 1.0Us", ".1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test448");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100a0a1a1a-1a3.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.", (java.lang.CharSequence) "10#100#0#-1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("00404140", "", (-143));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", '#');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-14-141004-14100");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                         ###########################");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str7.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "         -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("...oracle.com/http://java.oracle.com/http:...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP:..." + "'", str1.equals("...ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP:..."));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj" + "'", str2.equals("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test455");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                    ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test456");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(141.0d, (double) 158L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "...                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1004041414-143");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041414-143" + "'", str1.equals("1004041414-143"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test461");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" ######44");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test463");
        double[] doubleArray1 = new double[] { 14 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "14.0" + "'", str4.equals("14.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 14.0d + "'", double5 == 14.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test464");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test465");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########################", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test466");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                .8", "mixed mode", 12);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0 27 0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "##12 0###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/00404/40", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test469");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "01", (java.lang.CharSequence) "                       ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#################################################1.8ixed #################################################1.8ode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100a0a1a1a-1a3", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a0a1a1a-1a3                  " + "'", str2.equals("100a0a1a1a-1a3                  "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test472");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "                  ");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4', (int) 'a', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("SUN.LWAWT.MACOSX.LWCTOOLKIT", strArray4, strArray8);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/s:/Users/so", (java.lang.CharSequence[]) strArray4);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str13.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80-b15" + "'", str16.equals("1.7.0_80-b15"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test474");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("        /moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test475");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Librar...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Librar...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("        CGr ph  E vr   e  ", "   http://java.oracle.com/                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        CGr ph  E vr   e  " + "'", str2.equals("        CGr ph  E vr   e  "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla" + "'", str3.equals("4-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("##########################", "                            10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################" + "'", str2.equals("##########################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test479");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "\n\n\n\n\n\n\n\n", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "\n\n\n\n\n\n\n\n" + "'", charSequence2.equals("\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", "Java Platform API Specification");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                                                                                                                                            ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test481");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.1f, (double) 28L, 26.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.100000023841858d + "'", double3 == 1.100000023841858d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("12#0", "                                                                                                0", "                            10.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test483");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b1524.80-B11", (java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test484");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), 72, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 72 + "'", int3 == 72);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###############################################", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0", "                                                                                                0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0" + "'", str2.equals("100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (byte) 1, (-1433435));
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test488");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("              0A27A0                                                            ", 71, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test489");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " ######", (java.lang.CharSequence) "          -1.0a0.0a1.0          ", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test490");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\n", (short) 4);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test491");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("...    ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test492");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1322 + "'", int1 == 1322);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test493");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] {};
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1#33#35");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#33#3" + "'", str1.equals("-1#33#3"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.81.81.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.81.81." + "'", str1.equals("1.81.81."));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test496");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) '#', (int) (short) -1);
        float float18 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 0.0 1.0" + "'", str11.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.040.041.0" + "'", str13.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test497");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 12, 10);
        java.lang.Class<?> wildcardClass10 = byteArray5.getClass();
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test498");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a10.0a10.0a0.0a100.0" + "'", str10.equals("10.0a10.0a10.0a0.0a100.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("97404-14100", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97404-14100" + "'", str2.equals("97404-14100"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "###################/Users/sophie####################", (java.lang.CharSequence) "                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

