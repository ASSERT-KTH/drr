import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] {};
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray9);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', (int) (short) 10, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "erj/emoH/...", "/00404/40");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlauOracleCorperj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlau", 59, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MIXEDMODE", (java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...noitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacificepS enihcaM lautriV avaJnoitacifi", 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#100#0#-1#1", "0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTJ7v7P7f.mAPISf7Mac OS X#########rarrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj", "1.5.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTJ7v7P7f.mAPISf7Mac OS X#########rarrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj" + "'", str2.equals("jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTJ7v7P7f.mAPISf7Mac OS X#########rarrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "...ava....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#0.0#1.0" + "'", str8.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1240");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                1.8                /7s7s7/.esss/7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                1.8                /7s7s7/.esss/7" + "'", str1.equals("                1.8                /7s7s7/.esss/7"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f.mAPISf7Mac OS XJ7v7P7f\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("tionUStion", "###############################################", "##########################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", 89, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachine...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1004041414-143");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1004041414-143\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "3", (java.lang.CharSequence) "Mac OS X", 100404140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle ...", charArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', (int) (byte) 8, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/00404/40", (java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Ja a#a#a# HotSpot(TM) 6a-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment.8", "1.7.0_80-b15", (int) (byte) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) 'a', 0);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split(" ", 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray6, strArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 6a-Bit Server VM", (java.lang.CharSequence[]) strArray6);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "O10.0410.0410.040.0410100a0a1a1a-1a3", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                            " + "'", str1.equals("                                                                                                            "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("OracleCorporation", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation" + "'", str3.equals("OracleCorporation"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#################################################1.8", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  " + "'", str3.equals("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/USERS/SOPHI", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHI" + "'", str3.equals("/USERS/SOPHI"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS X#########", (java.lang.CharSequence) "...ava....");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "1.1");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a33a35", 172, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a Platform API SpecificationJava Platform API SpecificationJava Platform", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 8, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 8 + "'", short3 == (short) 8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("97#0#-1#100", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97#0#-1#100" + "'", str2.equals("97#0#-1#100"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", "    http://java.oracle.com/    ", "\n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1.0#0.0#1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0#0.0#1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 0, (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) ' ', 27);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.Class<?> wildcardClass18 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("MIXED MODE", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray4 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray4);
        org.junit.Assert.assertNotNull(numberUtilsArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100 0 1 1", (java.lang.CharSequence) "                             1.1", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        char[] charArray8 = new char[] { ' ', '#', '#', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) ' ', (int) (byte) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100404140", charArray8);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".8", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " ######" + "'", str15.equals(" ######"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1.0#0.0#1.0", (java.lang.CharSequence) "01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "01", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "100a0a1a1a-1a3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "7P7f.mAPISf7", (java.lang.CharSequence) "###############################", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100 0 1 1 -1 3", (java.lang.CharSequence) "t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100", "0 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 00 27 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) 4, 172);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004041414-143" + "'", str10.equals("1004041414-143"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen                                                                      ", (java.lang.CharSequence) "     ", 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 75 + "'", int3 == 75);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(27, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("erj/emoH/stnetnoC/kdj.08_0.7....", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7...." + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7...."));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0", "tionatform API Specifica P");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                         ", "10#100#0#-1#1", 14);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########################j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 4, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.HI!  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444##########################", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/uSERS/SOPHIE/uSERS/SOPHIE/uSERS/SOPH7P7f.mAPISf7", "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T1CL111:1.11111dCUMNT11DFCT14J1FMWK1LB1T1T_GNTN1GNTN1ND-CUNTJ" + "'", str3.equals("T1CL111:1.11111dCUMNT11DFCT14J1FMWK1LB1T1T_GNTN1GNTN1ND-CUNTJ"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0 27 0                                                                                              ", "                sun.lwawt.macosx.LWCToolkit                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 27 0                                                                                              " + "'", str2.equals("0 27 0                                                                                              "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "erj/emoH/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 1325, 65);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 27 0" + "'", str7.equals("0 27 0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                            ", (java.lang.CharSequence) "amac os xa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("O10.0410.0410.040.0410100a0a1a1a-1a3", "sophie", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                         97#0#-1#100", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/USERS/SOPH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HPOS/SRESU/" + "'", str1.equals("HPOS/SRESU/"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100404140", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray4 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray4);
        org.junit.Assert.assertNotNull(stringUtilsArray4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 6a-Bit Server VM", "##########################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " 100404140  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               " + "'", str2.equals("               "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("herj/emoH/...h", "    http://java.oracle.com/   ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " SiluSihHuccc " + "'", str3.equals(" SiluSihHuccc "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", 158);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-1.0 0.0 1.0Us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 0.0 1.0Us" + "'", str1.equals("-1.0 0.0 1.0Us"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28L, (float) 10L, (float) 1323);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "amac os xa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444##########################", (java.lang.CharSequence) "/uSERS/SOPHIE/uSERS/SOPHIE/uSERS/SOPH7P7f.mAPISf7", 172);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                 444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("         -1.0a0.0a1.0         ", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         -1.0a0.0a1.0         " + "'", str3.equals("         -1.0a0.0a1.0         "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        long[] longArray3 = new long[] { 8L, 1325L, 35 };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...UShttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                              ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJjerraraeaea-ea3jjj/STNETNOC/KDJjr8_rj7jjjjjj/STNETNOC/KDJj", (java.lang.CharSequence) "4444444444444444444444444414.0", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "##########################j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.01                               ", "1.7Sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7Sun.awt.CGraphicsEnvironment.8" + "'", str2.equals("1.7Sun.awt.CGraphicsEnvironment.8"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444414.0", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   4444444444444444444444444414.0" + "'", str2.equals("                   4444444444444444444444444414.0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0#27#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#27#0" + "'", str1.equals("0#27#0"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("97404-14100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97404-14100" + "'", str1.equals("97404-14100"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "/", (int) (byte) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4444444444444                                                    ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Mac OS X" + "'", str5.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "class [Bclass [Bclass [Bclass [Dclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("erj/emoH/sOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(141, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.0#0.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.100011-13.../STNETNOC/KDJ.08_0.7....../STNETNOC/KDJ.", (java.lang.CharSequence) "97404-14100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0410.0410.040.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("erj######/######emo######H######/######stnetno######C######/######kdj######.######08######_######0######.######7######...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "erj/emoH/...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj######/######emo######H######/######stnetno######C######/######kdj######.######08######_######0######.######7######..." + "'", str3.equals("erj######/######emo######H######/######stnetno######C######/######kdj######.######08######_######0######.######7######..."));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "herj/emoH/...h", (java.lang.CharSequence) "100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', 80, 1325);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        short[] shortArray5 = new short[] { (short) -1, (short) -1, (short) 100, (byte) -1, (byte) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 31, 9);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("100 0 1 0", "OracleCorp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                 444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.44444444E8d + "'", double1.equals(4.44444444E8d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                                                                                          sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                             J7v7P7f.mAPISf7Mac OS X", "s 100404140  ph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ", "J7v7P7f.mAPISf7Mac OS X", "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification", "sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment.8" + "'", str2.equals("sun.awt.CGraphicsEnvironment.8"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) 1323, (float) 176);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" a#a#a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a#a#a#" + "'", str1.equals("a#a#a#"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sunawtGraphics1nvironment", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtGraphics1nvironment" + "'", str2.equals("sunawtGraphics1nvironment"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj7v7P7f.mAPISf7Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7....", (java.lang.CharSequence) "97 0 -1 100", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence) " 3  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "sun.awt.CGraphicsEnvironmen                                                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("         -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          ", "0a27a0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(72, (int) ' ', 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0a27a0                          hi!0a27a0                          ", "124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1", (int) (byte) 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          " + "'", str3.equals("0a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("        /moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str1.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "12a0", (java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b1524.80-B11 ", (int) (byte) 8, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("###########################", "/7s7s7/.esss/7", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########################" + "'", str3.equals("###########################"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                sun.lwawt.macosx.LWCToolkit                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8", "44444444444444444444444444444444444444444444444444444444444444444444444444##########################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/00404/40", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixedmode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("en", (long) (byte) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10.0 10.0 10.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 10.0 10.0 0.0 100.0" + "'", str1.equals("10.0 10.0 10.0 0.0 100.0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 27L, (double) (short) -1, (double) 1.8f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "form API S", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str4.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/00404/40");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/00404/40" + "'", str1.equals("/00404/40"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "12a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.Class<?> wildcardClass9 = longArray3.getClass();
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27L + "'", long5 == 27L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 27L + "'", long7 == 27L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" ######", 9, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " ######44" + "'", str3.equals(" ######44"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "wt.CGrphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", " /00404/40");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) (byte) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "0 27 0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  ", "10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "ss [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 100, (byte) 10, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", "-1.0#0.0#1.0");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 1324);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.0a10.0a10.0a0.0a100.0", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n\n\n\n\n\n\n\n", "                                                                             ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 5, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0 27 0                                                                                              ", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 " + "'", str2.equals("                                                                 "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/10.14.3ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironmen", 1324);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.awt.CGraphicsEnvironmen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.awt.CGraphicsEnvironmen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("    http://java.oracle.com/   ", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    http://java.oracle.com/   " + "'", str2.equals("    http://java.oracle.com/   "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.1 .3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "100 0 1 1 -1 3", 28);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0#0.0#1.0" + "'", str12.equals("-1.0#0.0#1.0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double19 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10.0410.0410.040.04100.0" + "'", str18.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10.0410.0410.040.04100.0" + "'", str21.equals("10.0410.0410.040.04100.0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" 100  ", "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        long[] longArray3 = new long[] { (short) 0, 27, (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 27L + "'", long4 == 27L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 27L + "'", long6 == 27L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", 1318, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1.0 0.0 1.0", (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "J7v7P7f.mAPISf7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.5");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444", "/00404/40");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("3", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8L, 31.0d, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "/uSERS/SOPHIE", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 15, 158L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", "4444444444444441.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str4 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion3.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion3.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion8.atLeast(javaVersion10);
        boolean boolean13 = javaVersion0.atLeast(javaVersion10);
        java.lang.String str14 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.8" + "'", str4.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3" + "'", str11.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.1" + "'", str14.equals("1.1"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0a27a0                           ", (java.lang.CharSequence) "100erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("T/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################/Users/sophie####################", (java.lang.CharSequence) "100 0 1 1", (int) (short) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                          ", "", "100 0 1 1 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                          " + "'", str3.equals("                          "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "x86_64", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "   ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("         -1.0A0.0A1.0         ", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "         -1.0A0.0A1.0         " + "'", str6.equals("         -1.0A0.0A1.0         "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                 4444444444444441.8                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 4444444444444441.8                 " + "'", str1.equals("                 4444444444444441.8                 "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("###############################################", "7P7f.mAPISf7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualM", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "OracleCorporation" + "'", str7.equals("OracleCorporation"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                         97#0#-1#100", charArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', (int) (short) 100, 94);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD" + "'", str1.equals("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  8_  7   erj/emoH/stnetnoC/kdj  ", "24.80-B11 ", (int) (byte) 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("X86_64", "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", 141);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1 33 35", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 33 35" + "'", str4.equals("-1 33 35"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("form API S", "                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "form API S" + "'", str2.equals("form API S"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Java HotSpot(TM) 6a-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1), (float) 27L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 27.0f + "'", float3 == 27.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7", "10.0410.0410.040.0410100a0a1a1a-1a3", 176);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(".1", "jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTJ7v7P7f.mAPISf7Mac OS X#########rarrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".1" + "'", str2.equals(".1"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0 27 0                                                                                              ", (java.lang.CharSequence) "                  /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1433435", "Chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7", "/Users/s:/Users/so");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10", (java.lang.CharSequence) ".8", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("s10.0", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s10.0" + "'", str2.equals("s10.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0                                                    ", (java.lang.CharSequence) " ####tionatform API Specifica PlavaJtionatform API Specifica PlavaJtionatform API Specifica PlavaJti");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0                                                    " + "'", charSequence2.equals("                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0                                                    "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8" + "'", str2.equals("1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                   4444444444444444444444444414.0", (int) (byte) 100, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4", ":", "0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444444444444444444444444444444444444444444444444444444444444444##########################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 100, (int) (byte) 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 10, (int) (short) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 33, 3);
        byte byte22 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 100 + "'", byte22 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                   4444444444444444444444444414.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                  -1a1a0a10a10pecifica PlavaJti");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        " + "'", str2.equals("                                                                        "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Lib#################################################1.8IXED #################################################1.8ODE/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.11.UTF-8");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "34-14141404100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:...", (java.lang.CharSequence) "/Users/s:/Users/so");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sunawtGraphics1nvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sunawtGraphics1nvironment" + "'", str1.equals("sunawtGraphics1nvironment"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", 52, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8" + "'", str4.equals("  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ERJ/EMOH/STNETNOC/KDJ.08_0.7..." + "'", charSequence2.equals("ERJ/EMOH/STNETNOC/KDJ.08_0.7..."));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                             1.1", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             1.1" + "'", str2.equals("                             1.1"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.0a10.0a", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a10.0a" + "'", str2.equals("10.0a10.0a"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle ...", "##########################", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) ' ', 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Librry/Jv/JvVirtulM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (-1), 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 0.0 1.0" + "'", str8.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#0.0#1.0" + "'", str11.equals("-1.0#0.0#1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.040.041.0" + "'", str13.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0a0.0a1.0" + "'", str15.equals("-1.0a0.0a1.0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("JAV");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 176, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                " + "'", str3.equals("                                                                                                                                                                                "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", "-1.0#0.0#1.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100404140");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100404140L + "'", long1.equals(100404140L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/uSERS/SOPHIE/uSERS/SOPHIE/uSERS/SOPH7P7f.mAPISf7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        long[] longArray2 = new long[] { 12, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 1, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 97, (int) (short) -1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 49, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1240" + "'", str8.equals("1240"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1240" + "'", str10.equals("1240"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "        /moc.elcro.vj//:ptt");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "os/sresU/:s/sresU/", (java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                .8");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                 4444444444444441.8                 ", "/00404/40                  ", 97, (int) (byte) 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "    /00404/40                  " + "'", str4.equals("    /00404/40                  "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.00404144E8 27.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.00404144E8 27.0" + "'", str2.equals("1.00404144E8 27.0"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " ######44", (java.lang.CharSequence) "0a27a0                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                  -1a1a0a10a10pecifica PlavaJti", (double) 72);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 72.0d + "'", double2 == 72.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("\n\n\n\n\n\n\n\naa", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\naa" + "'", str3.equals("\n\n\n\n\n\n\n\naa"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-1.0#0.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100 0 1 0", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                                                                         ###########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEaJ7v7P7f.mAPISfMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEaJ7v7P7f.mAPISfMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.3", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        float[] floatArray2 = new float[] { 100404140, 27L };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.00404144E8f + "'", float3 == 1.00404144E8f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.00404144E8f + "'", float4 == 1.00404144E8f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.00404144E8#27.0" + "'", str6.equals("1.00404144E8#27.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.00404144E8f + "'", float7 == 1.00404144E8f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 27.0f + "'", float8 == 27.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        boolean boolean11 = javaVersion6.atLeast(javaVersion8);
        boolean boolean12 = javaVersion2.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 14, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/                             ", (java.lang.CharSequence) "-1a1a0a10a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444P4f44APISf44444444444444444444444444", (java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                 4444444444444441.8                 ", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "34-14141404100Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Pla", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a Platform API SpecificationJava Platform API SpecificationJava Platform", "Mac OS X                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################-1.0#0.0#1.0#######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(15, (int) '4', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!h############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(27, 72, 1466);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1466 + "'", int3 == 1466);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...ava....");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, 52L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-1.0a0.0a1Mac OS X", "    /00404/40                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a0.0a1Mac OS X" + "'", str2.equals("-1.0a0.0a1Mac OS X"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444", "tionUStion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("WT.cgRAPHICSeNVIRONMENT444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" SiluSihHuccc ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SiluSihHuccc" + "'", str1.equals("SiluSihHuccc"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("R", " ######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R" + "'", str2.equals("R"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#################################################1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "t/cla:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "0.01                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#################################################1.8");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 1, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("http://java.oracle.com/                             ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1010101010101010101010101010101010101010101010101010101010101010101010", 176, 47);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.0 10.0 10.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.0 10.0 10.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 10.0 10.0 0.0 100.0" + "'", str1.equals("10.0 10.0 10.0 0.0 100.0"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3", "J7v7P7f.mAPISf7Mac OS X#########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "tionUStion", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), (long) 33, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "s10.0", (java.lang.CharSequence) "Erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj.08_0.7...erj/emoH/stnetnoC/kdj. ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("wt.CGrphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444" + "'", str2.equals("444444444444444"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) ' ', 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HPOS/SRESU/" + "'", str1.equals("HPOS/SRESU/"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444" + "'", str2.equals("erj/emoH/stnetnoC/kdj1.7Sun.awt.CGraphicsEnvironment.8444444444444444444444"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "97 0 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8" + "'", str1.equals("Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.5.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5." + "'", str1.equals("1.5."));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32L, 0.0d, (double) 1466);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1466.0d + "'", double3 == 1466.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "0 27");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", "#################################################1.8", 35);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  ");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("042740", 94, ".1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1" + "'", str3.equals(".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 1323, 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("        /moc.elcaro.avaj//:ptth", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence) "erj/emoH/...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  Java(TM) SE Runtime Environment                  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0410.0410.040.04100.0", "hi!", (-1));
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444            sun.awt.CGraphicsEnvironment            444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("            ", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 26, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100404140, 28, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1042740.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(23, 47, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", 29, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("100#0#1#1#-1#3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    .                                                    0                                                    4                                                    0                                                    .                                                    0                                                    4                                                    1                                                    0                                                    0                                                    .                                                    0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/Lib#################################################1.8IXED #################################################1.8ODE/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.awt.CGraphicsEnvironment.8", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str4.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1.0#0.0#1.0", (java.lang.CharSequence) " 100  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################", "1004041414-143");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########################################"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1240");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1240" + "'", str1.equals("1240"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0" + "'", str1.equals("-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0-1.040.041.0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("            sun.awt.CGraphicsEnvironment            ", "/Users/s:/Users/so");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            sun.awt.CGraphicsEnvironment            " + "'", str2.equals("            sun.awt.CGraphicsEnvironment            "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0 27 0                                                                                              ", "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", "O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a34O10.0410.0410.040.0410100a0a1a1a-1a31O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3.O10.0410.0410.040.0410100a0a1a1a-1a30O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3 O10.0410.0410.040.0410100a0a1a1a-1a3");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1240");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1240" + "'", str1.equals("1240"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                                                                                          sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Ja a#a#a# HotSpot(TM) 6a-Bit Server VM", "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "x86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("###############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################" + "'", str1.equals("###############################################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.00404144E8#27.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.00404144E8#27.0" + "'", str2.equals("1.00404144E8#27.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0                                     97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                                                                                         97#0#-1#100                     1.8", "100 0 1 1 -1 3                  ", 1466);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1240", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1240" + "'", str2.equals("1240"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        short[] shortArray3 = new short[] { (byte) -1, (byte) 0, (short) 8 };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 3, (-1));
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int[] intArray6 = new int[] { 100, 0, (short) 1, 1, (-1), 3 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 1, 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 172, (int) (byte) 1);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 14, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 96, 1.1f, 23.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.1f + "'", float3 == 1.1f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1#33#35", 0, "/USERS/SOPH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#33#35" + "'", str3.equals("-1#33#35"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                               10.", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             10." + "'", str2.equals("                             10."));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                               SOPHIE                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "jJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj3ae-aeaeararrejJDK/CONTENTS/jjjjjj7jr_8rjJDK/CONTENTS/jjj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.00404144E8#27.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                sun.lwawt.macosx.LWCToolkit                ", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                1.8                /7s7s7/.esss/7", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/moc.elcaro.avaj//:ptth", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1240");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { bigDecimal1, 28L, 1325.0d, 75.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(numberArray5);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1240281325.075.0" + "'", str6.equals("1240281325.075.0"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a#a#a#", "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", 141);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/USERS/SOPHI", 2, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#1#0#10#10", "0 27 0                                                                                              ", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, (long) 27, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "12 0", (java.lang.CharSequence) "1.00404144E8#27.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http" + "'", str2.equals("/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/10.14.3erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", (java.lang.CharSequence) "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100a0a1a1a-1a3", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a0a1a1a-1a3" + "'", str2.equals("100a0a1a1a-1a3"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0\n\n\n\n\n\n\n\n-1.040.041.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 32, 1318);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 5, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OracleCorporation", 158, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("OracleCorporation444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, (int) (byte) 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, (int) ' ', 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJob", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironmen");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  java(tm) se runtime environment                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachine...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachine..." + "'", str1.equals("/Library/Java/JavaVirtualMachine..."));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.0a10.0a10.0a0.0a100.0", "                                                                                                                                                                          sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a10.0a10.0a0.0a100.0" + "'", str2.equals("10.0a10.0a10.0a0.0a100.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                             J7v7P7f.mAPISf7Mac OS X", "-1a1a0a10a10", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                             J7v7P7f.mAPISf7Mac OS X" + "'", str3.equals("                                                                             J7v7P7f.mAPISf7Mac OS X"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a#a#a#", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracl/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracl", 89);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "   ", (java.lang.CharSequence[]) strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence[]) strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("wt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "wt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444" + "'", str15.equals("wt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        short[] shortArray5 = new short[] { (short) -1, (short) -1, (short) 100, (byte) -1, (byte) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 1, 1325);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100 0 1 1 -1 3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac#OS#X", "ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  8_  7   ERJ/EMOH/STNETNOC/KDJ  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(TM) SE Runtime Environment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Environment Runtime SE Java(TM)" + "'", str2.equals("Environment Runtime SE Java(TM)"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 3, (-1));
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", (java.lang.CharSequence) "100 0 1 1 -1 3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "tionatform API Specifica P", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                            ", charSequence1, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("###############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################" + "'", str1.equals("###############################"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HI!", "4444444444444441.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "##########");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "         -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 172, 100404140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "            ", (java.lang.CharSequence) ".../STNETNOC/KDJ.08_0.7.../Users/so", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sophie                                               ", "Mac OS XMac OS XMac OS XMac OS0a27a0                          hi!0a27a0                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 6, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3sun.awt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444100a0a1a1a-1a3", (java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS X#########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "wt.CGraphicsEnvironment4444444444444444444444444444444444444444497404-14100", (int) (short) -1, 172);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        int[] intArray4 = new int[] { 'a', 0, (byte) -1, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 49, 1318);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97#0#-1#100" + "'", str6.equals("97#0#-1#100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97404-14100" + "'", str9.equals("97404-14100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0", "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0" + "'", str2.equals("100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0100 0 1 0"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "OracleCorporationHI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk7_8jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "-1a1a0a10a10", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("s#10#.#0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 141, "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                             " + "'", str3.equals("                                                                                                                                             "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0" + "'", str1.equals("0a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0 124051.0 -1.0a0.0a1.0 51.0 -1.0a0.0a1.0 51.0 -1.0a0.0a10a27a0 hi!0a27a0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str12 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        boolean boolean15 = javaVersion11.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean17 = javaVersion11.atLeast(javaVersion16);
        boolean boolean18 = javaVersion6.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.8" + "'", str12.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("   1.6    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   1.6    " + "'", str1.equals("   1.6    "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 4, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaa10.0aaaaaaaaaaaaaa", "                                                                                                                                                                          sophie");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100 0 1 1 -1 3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "S.7.X_8X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("s10.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1240", strArray4, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("s10.0");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1240", strArray10, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("t/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray6, strArray10);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "24.80-b11", 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("va HaSpa(TM) 64-Ba Sava VM", strArray6, strArray18);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1240" + "'", str7.equals("1240"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1240" + "'", str13.equals("1240"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "t/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str14.equals("t/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "va HaSpa(TM) 64-Ba Sava VM" + "'", str19.equals("va HaSpa(TM) 64-Ba Sava VM"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "J7v7P7f.mAPISf7Mac OS X#########", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KDJ  8_  7   ERJ/EMOh/STNETNOc/KD", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100", "0a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          124051.0          -1.0a0.0a1.0          51.0          -1.0a0.0a1.0          51.0          -1.0a0.0a10a27a0                          hi!0a27a0                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100" + "'", str2.equals("97404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-1410097404-14100"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("s10.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 10, 3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "            0                                                    ", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass9 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(89, (int) (short) 1, 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 89 + "'", int3 == 89);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444wt.CGraphicsEnvironment444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("###########################", "12a0", "24.80-B11 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 0, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("s10.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1240", strArray4, strArray6);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                sun.lwawt.macosx.LWCToolkit                ", (int) (short) 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "   ", (java.lang.CharSequence[]) strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence[]) strArray14);
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray14);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray14);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "sun.lwawt.macosx.CPrinterJob", (int) '#');
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, "Oracle Corporation", (int) (byte) 0, 0);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, "10.0410.0410.040.04100.0", (int) 'a', (int) (byte) 10);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray24);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr", strArray14, strArray24);
        java.lang.Class<?> wildcardClass35 = strArray14.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1240" + "'", str7.equals("1240"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr" + "'", str34.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/LibralMaVirtuava/Javary/Ja/Libr"));
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        float[] floatArray3 = new float[] { (byte) -1, 0L, 1.0f };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a0.0a1.0" + "'", str5.equals("-1.0a0.0a1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 0.0 1.0" + "'", str11.equals("-1.0 0.0 1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.040.041.0" + "'", str13.equals("-1.040.041.0"));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 27, (int) (byte) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 141, 96);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0a10.0a10.0a0.0a100.0", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a10.0a10.0a0.0a100.0" + "'", str2.equals("10.0a10.0a10.0a0.0a100.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8Sun.awt.CGraphicsEnvironment.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.0410.0410.040.04100.0                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0410.0410.040.04100.0                           " + "'", str1.equals("10.0410.0410.040.04100.0                           "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", (java.lang.CharSequence) "wt.SUN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444", 1324);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 92 + "'", int3 == 92);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\nOracleCorp\n\n\n\n\n\n\n\n", "                 .8                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        double[] doubleArray5 = new double[] { 10L, 10.0f, (byte) 10, 0.0f, 100L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (int) (short) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) (byte) 0, 1);
        double double23 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 65, 1325);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 65");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.040.04100.0" + "'", str8.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10.0410.0410.040.04100.0" + "'", str18.equals("10.0410.0410.040.04100.0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10.0" + "'", str22.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http:", "0a1a100a10a-1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("HTTP://JAVA.ORACLE.COM/        ", "/7s7s7/.esss/7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/        " + "'", str2.equals("HTTP://JAVA.ORACLE.COM/        "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Environment Runtime SE Java(TM)", (java.lang.CharSequence) "erj/emoH/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0410.0410.040.04100.0", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            0.0410.0410.040.04100.0" + "'", str3.equals("            0.0410.0410.040.04100.0"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed100/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librar..." + "'", str2.equals("/Librar..."));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "            0.0410.0410.040.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals("vaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10.0410.0410.040.04100.0", (java.lang.CharSequence) "HPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie100 0 1 0100 0 1 0100 0 1 0100 0 1 0100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) " 100  ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 4);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 8, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test494");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
//        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
//        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean12 = javaVersion6.atLeast(javaVersion11);
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str14 = javaVersion13.toString();
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean16 = javaVersion11.atLeast(javaVersion13);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.8" + "'", str14.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 30, 8L, (long) (byte) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                                                                            ", (java.lang.CharSequence) "                             10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAV", "-1433435", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#################################################1.8");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51124_1560278169", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "100 0 1 1 ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#################################################100 0 1 1 1100 0 1 1 .100 0 1 1 8" + "'", str7.equals("#################################################100 0 1 1 1100 0 1 1 .100 0 1 1 8"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        double[] doubleArray1 = new double[] { 14 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "14.0" + "'", str4.equals("14.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 14.0d + "'", double5 == 14.0d);
    }
}

