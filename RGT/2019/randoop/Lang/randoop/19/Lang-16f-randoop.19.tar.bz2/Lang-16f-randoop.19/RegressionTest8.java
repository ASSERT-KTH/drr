import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 968 + "'", int1 == 968);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                        UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-" + "'", str1.equals("UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("O acla CS aS atSn");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "m Java HotSpot(TM) ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2", 141, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str6.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1", (long) 86);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86L + "'", long2 == 86L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/#########/uSERS/SOPHIE/dOCUMENTS/D", 139, 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        int[] intArray6 = new int[] { (byte) 1, ' ', 0, ' ', (byte) 10, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-", "eneneneneneneneneenenenenenenenenen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = null;
        try {
            boolean boolean2 = javaVersion0.atLeast(javaVersion1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.9", "1#.#7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sophie");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6", 169, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" Java Platform API Specification", 44, 1725);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 1725, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "             ASUN.LWAWT.MACOSX.cpRINTERjOBAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7100.90", "                                                                                                                                                    HotSpot(TM) .4-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7100.90" + "'", str2.equals("1.7100.90"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        double[] doubleArray5 = new double[] { 1.0d, 1.6d, (-1.0d), (-1.0f), 1 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaa/moc.elcaro.avaj//:ptthaaaaaaaaaaaaaaa", "16.", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc", 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc" + "'", str2.equals("ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("  Java HotSpot(TM) 64-Bit Server VM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", "J");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("  Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aUTF-otSa#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aUTF-otSa#########################" + "'", str1.equals("aUTF-otSa#########################"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) .4-Bit Server VM ava HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java J" + "'", str2.equals(" HotSpot(TM) .4-Bit Server VM ava HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java J"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80-b15");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.6                                                                                              ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nu", (java.lang.CharSequence) "aUTF-otSa#########################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                  ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM ", "1.7100.90");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                              1.6", "                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", "java HotSa#########################", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                              1.6" + "'", str4.equals("                                                                                              1.6"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JSTCEFED/STNEMUCOD/EIHPOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JSTCEFED/STNEMUCOD/EIHPOS" + "'", str1.equals("             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JSTCEFED/STNEMUCOD/EIHPOS"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444441.7", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444441.7" + "'", str2.equals("44444441.7"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", "x86_64      1.6                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str2.equals("61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/LibJ/Libr", "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LibJ/Libr" + "'", str2.equals("/LibJ/Libr"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "en/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7", ' ');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/#########/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95773_1560210905/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.9                          ...", " Java HotSpot(TM) .4-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9                          ..." + "'", str2.equals("0.9                          ..."));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                1.6                ", 55, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                1.6                                    " + "'", str3.equals("                1.6                                    "));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eneneneneneneneneenenenenenenenenen");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eneneneneneneneneenenenenenenenenen" + "'", str3.equals("eneneneneneneneneenenenenenenenenen"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str1.equals("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("210905/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", " Java HotSpot(TM) 64-Bit Serv");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "210905/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/" + "'", str3.equals("210905/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "tnemnorivn", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aUTF-otSa#########################", " jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aUTF-otSa#########################" + "'", str2.equals("aUTF-otSa#########################"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("java HotSa#########################", 968);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSa#########################" + "'", str2.equals("java HotSa#########################"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        double[] doubleArray1 = new double[] { (short) -1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java HotSa#########################", (int) '#', 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSa#########################" + "'", str3.equals("Java HotSa#########################"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/aJ/yravarbiL/metsyS/:sno", (java.lang.CharSequence) "/LibJ/Libr##################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J", 85);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Libr" + "'", str2.equals("ophie/Libr"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                1.6                ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6d + "'", double1 == 1.6d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("       ...", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str1.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.", (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", "sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905" + "'", str2.equals("_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.2", 35, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.3", "44444444444444/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_156021090544444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "                                                                               UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("51.0", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("uTF", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("O acla CS aS atSnO a################################", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O acla CS aS atSnO a################################" + "'", str2.equals("O acla CS aS atSnO a################################"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61" + "'", str2.equals("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("...", "                 oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1725, (float) (byte) 1, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(46, 32, 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.9                          ...", " Java Platform API Specificatio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("  Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str9 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("x86_64      1.6                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: x86_64      1.6                 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1560210905", (java.lang.CharSequence) " JAVA PLATFH/M API SI/C/F/CAT/HU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6", "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "asun.lwawt.macosx.CPrinterJobaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "asun.lwawt.macosx.CPrinterJobaa" + "'", charSequence2.equals("asun.lwawt.macosx.CPrinterJobaa"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion5.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124", (java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 131);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(24.0f, 0.0f, (float) 86L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 86.0f + "'", float3 == 86.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/", 53, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/" + "'", str3.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 67, 1.7d, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7d + "'", double3 == 1.7d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "x86_64      1.6                ", (java.lang.CharSequence) "oraclecorporation", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444444444444444444mixed mode", 2, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444mixed mode" + "'", str3.equals("44444444444444444444mixed mode"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.0                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                               0.15" + "'", str1.equals("                                                                                                                               0.15"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ot(TM) 64-Bit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "  Java HotSpot(TM) 64-Bit Server VM", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "USm", (java.lang.CharSequence) "JAVA HOTSA#########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "####################################################################", (java.lang.CharSequence) "/libj/libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                 oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 oRACLE cORPORATION" + "'", str1.equals("                 oRACLE cORPORATION"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", "j", "                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61." + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61."));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", 168);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/                                            4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "/Library/Java/Ja...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("tnemnorivn", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/#########", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JAVAHOTSA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.6                                                                                              ", (java.lang.CharSequence) "16.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", 101, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".../tegrat/5090120651_37759_..." + "'", str3.equals(".../tegrat/5090120651_37759_..."));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "tnemnoriv", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                        UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("51.051.051.0n51.051.051.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.051.051.0n51.051.051.0" + "'", str1.equals("51.051.051.0n51.051.051.0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/moc.elcaro.av");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "5.60");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                     asumixed m", 1725L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1725L + "'", long2 == 1725L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Java Platform API Specification", "Java Platform API Specification");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 268, (int) (byte) 1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     asumixed mod", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/LibJ/Libr##################################################################################################################################################################################################################################################################", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LibJ/Libr##################################################################################################################################################################################################################################################################" + "'", str2.equals("/LibJ/Libr##################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6" + "'", str2.equals("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(267.0f, (float) (byte) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ", "java HotSa#########################", "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 86L, 0.0f, (float) 86L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 86.0f + "'", float3 == 86.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/LibJ/Lib", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        long[] longArray3 = new long[] { 3, (short) 1, 18 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 18L + "'", long4 == 18L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 18L + "'", long5 == 18L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 18L + "'", long6 == 18L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "16.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "eneneneneneneneneenenenenenenenenen", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                              uTF-                                               ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        int[] intArray6 = new int[] { (byte) 1, ' ', 0, ' ', (byte) 10, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                                                                                                                 aaaaOaaaaa", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!" };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                            1.7.0_80                                             ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.9    ...", (java.lang.CharSequence) "                  ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.lw#wt.m#cosx.LWCToolkit", "", "1.6                      5.60                                                                                                ", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lw#wt.m#cosx.LWCToolkit" + "'", str4.equals("sun.lw#wt.m#cosx.LWCToolkit"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "a1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", (java.lang.CharSequence) "5", 968);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ophie/Libr", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                                                              1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                       sun.lwawt.macosx.CPrinterJob                                                        ", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                        " + "'", str3.equals("                                                       sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                                                                               sun.lwawt.macosx.CPrinterJob                                                        "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "m", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "m", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM ", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", "5.60                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.60                               " + "'", str2.equals("5.60                               "));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "Spot(TM) 64-Bit S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" Java HotSpot(TM) 64-Bit Serv", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 68, (long) 268, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " Java Platfh/m API Si/c/f/cat/hU", (java.lang.CharSequence) "Java Platform API Specificatio1", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSa#########################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "rbiL/aJ/yravaJ/avautriVaMladesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_801.61.61.61.61.61.61.61.", 268);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.61.61.61.61.61.61.61." + "'", str2.equals("1.7.0_801.61.61.61.61.61.61.61."));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("             ASUN.LWAWT.MACOSX.cpRINTERjOBAA");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.7", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit", "1.7100.90");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61", (java.lang.CharSequence) "O");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSa#########################", "...DK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSa#########################" + "'", str2.equals("Java HotSa#########################"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " Java HotSpot(TM) .4-Bit Server VM                                                                  ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                                " + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                                "));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("X86_64                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64                                                                                                                                                                   " + "'", str1.equals("x86_64                                                                                                                                                                   "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2" + "'", str2.equals("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                               US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("     AAAAAAAAAA mod", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     AAAAAAAAAA mod" + "'", str2.equals("     AAAAAAAAAA mod"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        int[] intArray6 = new int[] { (byte) 1, ' ', 0, ' ', (byte) 10, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificatio" + "'", str1.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java HotSa########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########################aStoH avaJ" + "'", str1.equals("########################aStoH avaJ"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ava HotSa#########################", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avaaHotSa#########################" + "'", str3.equals("avaaHotSa#########################"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("http://java.oracle.comn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.comn" + "'", str1.equals("http://java.oracle.comn"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATIO", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", 29, 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tnemnori", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ORACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("asun.lwawt.macosx.CPrinterJobaa", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/eihpos/sresu/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucod/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asun.lwawt.macosx.CPrinterJobaa" + "'", str2.equals("asun.lwawt.macosx.CPrinterJobaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 1725, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str1.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("O acla CS aS atSnO a###############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O ACLA CS AS ATSNO A###############################" + "'", str1.equals("O ACLA CS AS ATSNO A###############################"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8" + "'", str1.equals("mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm  java hotspot(tm) .4-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("X86_64                                                                                                                                                                   ", 32, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        " + "'", str3.equals("                        "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                              1.6", 68, "1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                              1.6" + "'", str3.equals("                                                                                              1.6"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "5.60");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specificatio", "JAVA HOTSA#########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVA HOTSA#########################" + "'", str2.equals("AVA HOTSA#########################"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("             ASUN.LWAWT.MACOSX.cpRINTERjOBAA", "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             ASUN.LWAWT.MACOSX.cpRINTERjOBAA" + "'", str2.equals("             ASUN.LWAWT.MACOSX.cpRINTERjOBAA"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####a#####", "JAVA HOTSA#########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            " + "'", str1.equals("                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/", (java.lang.CharSequence) "b1124.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JSTCEFED/STNEMUCOD/EIHPOS", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "tnemnori", (java.lang.CharSequence) "X86_64                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 5, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str3.equals("61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "M", (java.lang.CharSequence) "6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("j", "RAJ.TNERRUC-POODNAR/NOIT", 0, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RAJ.TNERRUC-POODNAR/NOIT" + "'", str4.equals("RAJ.TNERRUC-POODNAR/NOIT"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "uTF", charSequence1, 169);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                                        UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                     asun.lwawt.macosx.CPrinterJobaa", 55, "JAVAHOTSA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAV                     asun.lwawt.macosx.CPrinterJobaa" + "'", str3.equals("JAV                     asun.lwawt.macosx.CPrinterJobaa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("  Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:   Java HotSpot(TM) 64-Bit Server VM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J" + "'", str1.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                 aaaaOaaaaa" + "'", str1.equals("                                                                                                                                                                                                                                                                 aaaaOaaaaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", 968);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        long[] longArray1 = new long[] { 1725 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1725L + "'", long2 == 1725L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1725L + "'", long3 == 1725L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/LibJ/Lib", " Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ons:/System/Libravary/Ja/", "x86_64");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophie", strArray4, strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/libj/libr");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '#');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sophie" + "'", str13.equals("sophie"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        double[] doubleArray4 = new double[] { 1, 100L, 1.0d, (byte) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "4444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/LibJ/Libr##################################################################################################################################################################################################################################################################", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("en", 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" Java Platform API Specificatio");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                1.6                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151" + "'", str1.equals("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String[] strArray5 = new java.lang.String[] { "en", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr", "1560210905" };
        java.lang.String[] strArray11 = new java.lang.String[] { "en", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr", "1560210905" };
        java.lang.String[] strArray17 = new java.lang.String[] { "en", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr", "1560210905" };
        java.lang.String[][] strArray18 = new java.lang.String[][] { strArray5, strArray11, strArray17 };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[][]) strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  Java Platform API Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION" + "'", str1.equals("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 44, (long) 267);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("OT(tm) 64-bIT");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("     AAAAAAAAAA mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAmod" + "'", str1.equals("AAAAAAAAAAmod"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(" Java HotSpot(TM) 64-Bit Serv", "             ASUN.LWAWT.MACOSX.cpRINTERjOBAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Serv" + "'", str2.equals(" Java HotSpot(TM) 64-Bit Serv"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.9    ...", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9    " + "'", str2.equals("0.9    "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_801.61.61.61.61.61.61.61.", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("     AAAAAAAAAA mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAAAA mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                     asumixed mod", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("...DK1.7.0_80.JDK/cONTENTS/hOME/JRE", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...DK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("...DK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/lIBRARY/jAVA/jAVAvIRTUALmACHI" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/lIBRARY/jAVA/jAVAvIRTUALmACHI"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 31, (float) 31L, (float) 24);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 24.0f + "'", float3 == 24.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("M", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                1.6                                    ", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                              1.6", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!" };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aUTF-otSa#########################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "JavaHotSa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX" + "'", str1.equals("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("O");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "5.60", (java.lang.CharSequence) " HotSpot(TM) .4-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 168);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA...", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..."));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                 1.6", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 " + "'", str2.equals("                                                 "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "edom dexim", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7", "Java HotSa########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7" + "'", str2.equals("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str2.equals("                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/aJ/yravarbiL/metsyS/:sno", (java.lang.CharSequence) "ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("m", "/LibJ/Libr", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.2", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/#########/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95773_1560210905/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) " Java Platform API Specificatio", (java.lang.CharSequence) "                                                                                               US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) .4-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                     asumixed mod");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                1.6                                    ", "b1124.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.6                                    " + "'", str2.equals("                1.6                                    "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("x86_65.60                               ", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_65.60                               " + "'", str2.equals("x86_65.60                               "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aUTF-otSa#########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aUTF-otSa######################### is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/e...", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j#stcefed/stnemucod/e..." + "'", str3.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j#stcefed/stnemucod/e..."));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporatio" + "'", str1.equals("OracleCorporatio"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc", 1725);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", "UTF", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64                                                                                                                                                                   ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        float[] floatArray4 = new float[] { 32L, (-1), 'a', 97.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 97.0f + "'", float8 == 97.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("en", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 268.0f, (double) 34, (double) 25);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 268.0d + "'", double3 == 268.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4, (double) 268L, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JAVAHOTSA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAHOTSA" + "'", str1.equals("JAVAHOTSA"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7", "sun.awt.CGraphicsEnvironment                                                                        ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                       ", "1560210905");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.9                          ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", " Java Platform API Specificatio", "nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.", (java.lang.CharSequence) "/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 168, (float) 68, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 168.0f + "'", float3 == 168.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444mixed mode" + "'", str1.equals("44444444444444444444mixed mode"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        long[] longArray6 = new long[] { (byte) -1, (short) 1, (-1L), 100L, (-1), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("JAVA HOTSA#########################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JAVA HOTSA#########################" + "'", str4.equals("JAVA HOTSA#########################"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.9", "1#.#7");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "mixed mode");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                              1.6", strArray3, strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                  ");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str10.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "                                                                                              1.6" + "'", str12.equals("                                                                                              1.6"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0.9" + "'", str16.equals("0.9"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 164);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..." + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..."));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", (java.lang.CharSequence) "bravary/Ja/Users/sophie/Libr2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;" + "'", str1.equals("S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ot(TM) 64-Bit", "", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "nt", 68, 6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 43, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", "x86_64      1.6                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.2", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aUTF-otSa#########################", (java.lang.CharSequence) "51.0                                                                                                                               ", 117);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "Java HotSpot(TM) .4-Bit Server VM", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence6, charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSa#########################", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "rbiL/aJ/yravaJ/avautriVaMladesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 22 + "'", int15 == 22);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaa", (java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "########################aStoH avaJ", (java.lang.CharSequence) "/aJ/yravarbiL/metsyS/:sno");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("a", "stcefed/stnemucoD/eihpos/sresU/                                            4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!" };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "24.80-b11");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "         :");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "n", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger bigInteger3 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger bigInteger5 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger bigInteger7 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger bigInteger9 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger bigInteger11 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1560210905");
        java.math.BigInteger[] bigIntegerArray12 = new java.math.BigInteger[] { bigInteger1, bigInteger3, bigInteger5, bigInteger7, bigInteger9, bigInteger11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(bigIntegerArray12);
        org.junit.Assert.assertNotNull(bigInteger1);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "156021090515602109051560210905156021090515602109051560210905" + "'", str13.equals("156021090515602109051560210905156021090515602109051560210905"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        double[][][] doubleArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(doubleArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(24, 40, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 40 + "'", int3 == 40);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/Ja...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/Ja...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8 jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("tnemnorivnEscihparGC.twa.nu", "                1.6                ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                                ", 34, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 31, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j" + "'", str1.equals("j"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        long[] longArray5 = new long[] { (byte) 100, 0L, (short) -1, (short) 10, '4' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.Class<?> wildcardClass12 = longArray5.getClass();
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.1", 31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" Java Platfh/m API Si/c/f/cat/hU", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JAVA HOTSA#########################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "OT(tm) 64-bIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        double[] doubleArray4 = new double[] { 1, 100L, 1.0d, (byte) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        float[] floatArray4 = new float[] { (byte) 0, 10L, 10, (byte) -1 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                           " + "'", str2.equals("                                                                                                                                           "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.9    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                           ", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "                                                                                               US", 169);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "6.1                                                                                              ", (java.lang.CharSequence) "M", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(44, 180, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 180 + "'", int3 == 180);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaOaaaaa", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J", "MacOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaOaaaaa" + "'", str3.equals("aaaaOaaaaa"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 19, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("210905/Users/sophie/Documents/defects4j/tmp", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) -1, (double) '#', (double) 164);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 164.0d + "'", double3 == 164.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.1", "210905/Users/sophie/Documents/defects4j/tmp", "sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensio...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i" + "'", str3.equals("6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i6.i"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("m Java HotSpot(TM) ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m Java HotSpot(TM)\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/#########/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95773_1560210905/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###################################", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 45");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Us/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrers/s/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreph/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/JavaV/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrertualMach/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jren/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jres/j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek1.7.0_80.j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek/C/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrent/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrents/H/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/jr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/N/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jretw/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrerk/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/Syst/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/usr/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb/java" + "'", str8.equals("/Us/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrers/s/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreph/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/JavaV/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrertualMach/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jren/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jres/j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek1.7.0_80.j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek/C/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrent/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrents/H/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/jr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/N/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jretw/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrerk/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/Syst/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/usr/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb/java"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaa", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("oRACLE cORPORATIO", "1.7.0_80-b15", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 0, 139);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/aJ/yravarbiL/metsyS/:sno");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/", "UTF                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("USm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USm" + "'", str1.equals("USm"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        double[] doubleArray4 = new double[] { 1, 100L, 1.0d, (byte) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-Java HotSa########################1.7.0_80-");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", "", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("b1124.80-b1124.80-b1124.", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", "uTF");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8 jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/#########", "b1124.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("####a#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Oracle Corporation", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", (int) (short) 100, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USm", (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "java HotSa#########################", (java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mode");
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str6.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "O", (java.lang.CharSequence) "X86_64                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("uTF", "", 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "http://java.oracle.com/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/LibJ/Libr");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java HotSa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", 10, 139);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61..." + "'", str3.equals("...AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61..."));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "j", 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA HOTSA#########################", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ava HotSa#########################", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" Java Platfh/m API Si/c/f/cat/hU");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "sun.awt.CGraphicsEnvironment                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5L, 97.0f, (float) 131);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 131.0f + "'", float3 == 131.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.", '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 0, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/#########/Users/sophie/Documents/d", 5, "1.7.0_80-Java HotSa########################1.7.0_80-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#########/Users/sophie/Documents/d" + "'", str3.equals("/#########/Users/sophie/Documents/d"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " JAVA PLATFH/M API SI/C/F/CAT/HU", (java.lang.CharSequence) " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", 169);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52L, (float) 86, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 86.0f + "'", float3 == 86.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("u", "R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCorporation", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15161.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi!", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("          ", "1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "eneneneneneneneneenenenenenenenenen", (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "       ...", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        int[] intArray6 = new int[] { (byte) 1, ' ', 0, ' ', (byte) 10, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "b1124.80-b1124.80-b1124.", (java.lang.CharSequence) "16.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/UER/PHIE/LIBRARY/JAVA/ETENIN:/LIBRARY/JAVA/ETENIN:/NETWRK/LIBRARY/JAVA/ETENIN:/YTE5/LIBRARY/JAVA/ETENIN:/UR/LIB/JAVA:.", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                              1.", 512, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                              1." + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                                                                              1."));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", "                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "44444441.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java HotSa#########################");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                            ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", "mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                1.6                                    ", (int) (byte) 10, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", "ons:/System/Libravary/Ja/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa         :", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-Java HotSa########################1.7.0_80-", 169, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-Java HotSa########################1.7.0_80-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80-Java HotSa########################1.7.0_80-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                 1.6", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray7);
        java.lang.Class<?> wildcardClass12 = strArray7.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/var/folders/_v/", strArray4, strArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 131, (int) (byte) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass19 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/var/folders/_v/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/var/folders/_v/" + "'", str13.equals("/var/folders/_v/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/var/folders/_v/"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b15", "                                            1.7.0_80                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0.9                                ", "                                                                                                                                                    HotSpot(TM) .4-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9                                " + "'", str2.equals("0.9                                "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "http://java.oracle.comn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8" + "'", str2.equals("mixedmod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi" + "'", str2.equals("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                1.6                                    ", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                1.6                                    " + "'", str3.equals("                1.6                                    "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi" + "'", str3.equals("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n2Java Platform API Specificatio24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaa/moc.elcaro.avaj//:ptthaaaaa", "x86_64                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.CharSequence charSequence9 = null;
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence9, (java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "###################################", (java.lang.CharSequence[]) strArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("X86_64", strArray4, strArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aUTF-otSa#########################", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "X86_64" + "'", str18.equals("X86_64"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                              ", "         :", 268);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 968, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("24.80-b11", 139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 18L, 180.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 180.0d + "'", double3 == 180.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("tnemnori");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAV                     asun.lwawt.macosx.CPrinterJobaa", (java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "asun.lwawt.macosx.CPrinterJobaa", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ava HotSa#########################", "                                                       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "6.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444444444444444444444444445", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444445" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444445"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.CPrinterJob", "/Library/Java/Ja...", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "                     asumixed m");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 141, " Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA...", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..." + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                            ", (java.lang.CharSequence) "/libj/libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.2", "/libj/libr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(101.0f, (float) 3L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 101.0f + "'", float3 == 101.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        float[] floatArray2 = new float[] { 32L, (short) -1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("avaaHotSa#########################", (int) (short) 10, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avaaHotSa#########################" + "'", str3.equals("avaaHotSa#########################"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSax86_64 1.6 Java HotSa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotS" + "'", str2.equals("Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotSx86_64 1.6 Jv HotS"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "0.9                          ...", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X86_64                                                                                                                                                                   ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6                                                                                                                                                                    " + "'", str3.equals("X86_6                                                                                                                                                                    "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "1.7.0_80-b15", (int) (short) 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "###################################");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie" + "'", str11.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str12.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str13.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("AVA HOTSA#########################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa", 32, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa##" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa##"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444mixed mode", "UTF-8                                                                                                                              ", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("O acla CS aS atSnO a################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################a OnSta Sa SC alca O" + "'", str1.equals("################################a OnSta Sa SC alca O"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/Ja...", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             /Library/Java/Ja..." + "'", str2.equals("             /Library/Java/Ja..."));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11", (java.lang.CharSequence) "aaaa/moc.elcaro.avaj//:ptthaaaaa", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, 31.0d, (double) 268.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

