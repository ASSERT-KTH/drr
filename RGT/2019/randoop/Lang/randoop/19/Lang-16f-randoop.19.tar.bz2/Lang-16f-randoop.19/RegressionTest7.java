import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "J", (java.lang.CharSequence) "                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", "                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            " + "'", str2.equals("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            "));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray3, strArray12);
        java.lang.Class<?> wildcardClass14 = strArray12.getClass();
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X" + "'", str13.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed mod1.44444441.7 sERVER vm ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa", 169, 267);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n2Java Platform API Specificatio24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n2", "", 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("en/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen", "x86_64");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 31, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("tnemnorivnEscihparGC.twa.nus", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tn..." + "'", str2.equals("tn..."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophiee");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" Java HotSpot(TM) .4-Bit Server VM                                                                  ", "aaaaaaaaaaaaaa/moc.elcaro.avaj//:ptthaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", "aUTF-otSa#########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str2.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6", "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.2");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2" + "'", str3.equals("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.2", "hi!", (int) (byte) 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 64-Bit Server VM", 8, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Spot(TM) 64-Bit S" + "'", str3.equals("Spot(TM) 64-Bit S"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            ", (java.lang.CharSequence) "/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("tnemnorivnEscihparGC.twa.nus", "x86_64      1.6                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "       Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(24, 3, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("X86_64                                                                                                                                                                   ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsa" + "'", str1.equals("java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsax86_64      1.6                java hotsa"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", "U");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION", "m", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905" + "'", str2.equals("_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                        UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                              uTF-                                               ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("UTF-", "", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] { ' ', 'a' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray3);
        java.lang.Class<?> wildcardClass5 = charArray3.getClass();
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                       MacOSX                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie", "aaaaaaaaaaaaaaaaaaa         :");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaa         :" + "'", str2.equals("aaaaaaaaaaaaaaaaaaa         :"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", (java.lang.CharSequence) "ORACLE cORPORATION", 268);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("tnemnorivnEscihparGC.twa.nus", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("5.60", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5.60" + "'", str6.equals("5.60"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "16.", 139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("tn...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tn..." + "'", str1.equals("tn..."));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("asun.lwawt.macosx.CPrinterJobaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "asun.lwawt.macosx.CPrinterJobaa" + "'", str1.equals("asun.lwawt.macosx.CPrinterJobaa"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int[] intArray6 = new int[] { (byte) 1, ' ', 0, ' ', (byte) 10, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "O acla CS aS atSnO a################################", (java.lang.CharSequence) "1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 512L, 0.0d, 25.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 512.0d + "'", double3 == 512.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905" + "'", str2.equals("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/                                            ", " Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str9 = javaVersion8.toString();
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean11 = javaVersion7.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str14 = javaVersion13.toString();
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        boolean boolean16 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean18 = javaVersion13.atLeast(javaVersion17);
        boolean boolean19 = javaVersion8.atLeast(javaVersion13);
        java.lang.String str20 = javaVersion13.toString();
        boolean boolean21 = javaVersion3.atLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.2" + "'", str14.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.2" + "'", str20.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ot(TM) 64-Bit", 85);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ot(TM) 64-Bit" + "'", str2.equals("ot(TM) 64-Bit"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/#########", (java.lang.CharSequence) "/LibJ/Lib");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "mixed mod1.44444441.7 sERVER vm ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "mixed mode");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str7.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                        UTF-                                                                                        ", (java.lang.CharSequence) "/#########/Users/sophie/Documents/d");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.awt.CGraphicsEnvironment                                                                        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("tnemnorivnEscihparGC.twa.nus", "                                0.9                                get/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                             ", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str3.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed4lM4Virtu4v4/J4v4ry/J4/Libr1.7", "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        char[] charArray12 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "A", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64      1.6                ", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "####a#####", "     AAAAAAAAAA mod", 101);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            " + "'", str4.equals("r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ons:/System/Libravary/Ja/", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ons:/System/Libravary/Ja/" + "'", str3.equals("ons:/System/Libravary/Ja/"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("6.1                                                                                              ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:", ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6.1                                                                                              " + "'", str3.equals("6.1                                                                                              "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "###################################");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/libj/libr", strArray4, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "", 30, 22);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/libj/libr" + "'", str9.equals("/libj/libr"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####a#####", 52, 131);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "A", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '#', (double) 3, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6J", 169);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("edom dexim", 168);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("6.1                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6.1" + "'", str1.equals("6.1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "J", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("O acla CS aS atSnO a###############################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"O acla CS aS atSnO a###############################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "en/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen/Users/sophieen", (java.lang.CharSequence) "Java HotSpot(TM) .4-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                             ", (java.lang.CharSequence) "                    chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Us/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrers/s/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreph/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/JavaV/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrertualMach/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jren/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jres/j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek1.7.0_80.j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek/C/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrent/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrents/H/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/jr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/N/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jretw/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrerk/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/Syst/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/usr/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb/java", (java.lang.CharSequence) "    1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa         :", (java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/                                            4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm " + "'", str3.equals("R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachi", "/Users/sophie", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi" + "'", str3.equals("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa", "_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa" + "'", str4.equals("Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97.0f, 0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", "/LibJ/Lib");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            " + "'", str2.equals("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u" + "'", str1.equals("u"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment                                                                        ", (java.lang.CharSequence) "                                                       sun.lwawt.macosx.CPrinterJob                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("O acla CS aS atSnO a################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O acla CS aS atSnO a################################" + "'", str1.equals("O acla CS aS atSnO a################################"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                              uTF-                                               ", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 1725);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray3, strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X" + "'", str13.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/t/ng00..." + "'", str3.equals("/t/ng00..."));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                       sun.lwawt.macosx.CPrinterJob                                                        ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 18 + "'", int13 == 18);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 131, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  " + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "USm", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "         rbiL/aJ/yravaJ/avautriVaMladesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc", 169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("JavaHotSa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSa" + "'", str1.equals("JavaHotSa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaa         :");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaa         :" + "'", str1.equals("aaaaaaaaaaaaaaaaaaa         :"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", "ORACLE cORPORATION");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 22, 169);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", 117);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "         :", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/eihpos/sresu/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucod/eihpos/sresu/", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray3, strArray12);
        java.lang.Class<?> wildcardClass14 = strArray12.getClass();
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4', 35, 512);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 45");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X" + "'", str13.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/LibJ/Libr", 268, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LibJ/Libr##################################################################################################################################################################################################################################################################" + "'", str3.equals("/LibJ/Libr##################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 512);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 512L + "'", long2 == 512L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/                                            ", (java.lang.CharSequence) "                                                                                              1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(268.0f, (float) 3L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "210905/Users/sophie/Documents/defects4j/tmp/", (java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("  sers sop  e", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  sers sop  e" + "'", str2.equals("  sers sop  e"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "16.", (java.lang.CharSequence) "                                                                                                                                                                        1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.A61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/LibJ/Lib", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "U", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", 97, 139);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61." + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specificatio1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/e...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("eneneneneneneneneenenenenenenenenen", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eneneneneneneneneenenenenenenenenen" + "'", str2.equals("eneneneneneneneneenenenenenenenenen"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                 1.6", "                                              uTF-                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 1.6" + "'", str2.equals("                                                 1.6"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/                                            4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("...", "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61." + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("             asun.lwawt.macosx.CPrinterJobaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.7100.90");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/systehi!/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/systehi!/library/java/extensions:/usr/lib/java:." + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/systehi!/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("tnemnorivn", "nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnori" + "'", str2.equals("tnemnori"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  " + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                  "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray1, strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "O acla CS aS atSn");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "6.1                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                            1.7.0_80                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaa         :");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit", (int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macosx.LWCToolkit" + "'", str3.equals("un.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("X86_64", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            ", (java.lang.CharSequence) "aUTF-otSa#########################", 169);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("5.60", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.60" + "'", str2.equals("5.60"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " JAVA PLATFH/M API SI/C/F/CAT/HU", (java.lang.CharSequence) "                                                                                              1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("uTF-");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "X86_64                                                                                                                                                                   ");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "uTF-" + "'", str4.equals("uTF-"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", " Java HotSpot(TM) 64-Bit Server VM ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 168, 8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) 44, (long) 24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.6                      5.60                                                                                                ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6                      5.60                                                                                                " + "'", str2.equals("1.6                      5.60                                                                                                "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oRACLE cORPORATIO", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6" + "'", str4.equals("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                 1.6", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.6                      5.60                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                              ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                              " + "'", str2.equals("                                                                                                             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                              "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("tnemnori", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnori" + "'", str3.equals("tnemnori"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.9                          ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9                          ..." + "'", str1.equals("0.9                          ..."));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "                                                                                        UTF-                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("tnemnorivnEscihparGC.twa.nus", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oRACLE cORPORATION");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 101, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ons:/System/Libravary/Ja/", "x86_64");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophie", strArray3, strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "/libj/libr");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 0, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sophie" + "'", str12.equals("sophie"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("5.60", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5.60" + "'", str3.equals("5.60"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (java.lang.CharSequence) "                                                 1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("uTF", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVi/Users/sophieva/JavaVirtualMachi", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "tnemnoriv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "       ...", "                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "11b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.42", (java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("         :", "1.");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         :" + "'", str3.equals("         :"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ", "    1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("stcefed/stnemucoD/eihpos/sresU/                                            4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray5, strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                 1.6");
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", strArray14, strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 45 vs 50");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Mac OS X" + "'", str15.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("       Oracle Corporation", 19, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-", (java.lang.CharSequence) "vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Platform API Specificatio", "5.60                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificatio" + "'", str2.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.LWCToolkit", "Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa" + "'", str2.equals("Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSax86_64      1.6                Java HotSa"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/#########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("         rbiL/aJ/yravaJ/avautriVaMladesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihc", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", "O acla CS aS atSn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        float[] floatArray4 = new float[] { 32L, (-1), 'a', 97.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 97.0f + "'", float8 == 97.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/aJ/yravarbiL/metsyS/:sno", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("en", "http://java.oracle.com", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.comn" + "'", str4.equals("http://java.oracle.comn"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                       MacOSX                                        ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", "/moc.elcaro.av", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaOaaaaa", (java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9                          ...", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("##########                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##########                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("                                             rj.tnerruc-poodnr/noitreneg/noitreneg_tset/bil/krowemrf/jstcefed/stnemucoD/eihpos/sresU/:sesslc/tegrt/5090120651_37759_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(267, (int) (short) 1, 168);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/eihpos/sresu/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucod/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaHotSa"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        float[] floatArray5 = new float[] { (byte) 0, 100.0f, 100.0f, 100.0f, '#' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1.equals(Float.POSITIVE_INFINITY));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Java Platform API Specificatio1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.051.051.0n51.051.051.0", 1725);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.0n51.051.051.0" + "'", str2.equals("51.051.051.0n51.051.051.0"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        float[] floatArray4 = new float[] { (byte) 0, 10L, 10, (byte) -1 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "X", (java.lang.CharSequence) "tnemnorivn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                         1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/LibJ/Libr", (java.lang.CharSequence) "...", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/" + "'", str2.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                              uTF-                                               ", "/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie" + "'", str2.equals("/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), 100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM" + "'", str1.equals(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("A", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "Java Platform API Specificatio");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 97.0d, (double) 1.6f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "6.1                                                                                              ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac", "O");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac" + "'", str2.equals("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("edom dexim", "1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom dexim" + "'", str2.equals("edom dexim"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", (java.lang.CharSequence) "_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", 101);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_65.60                               ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("UTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1" + "'", str1.equals("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specificatio1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "UTF-8                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RAJ.TNERRUC-POODNAR/NOIT" + "'", str2.equals("RAJ.TNERRUC-POODNAR/NOIT"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Oracle Corporation", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                         1.7.0_80", (java.lang.CharSequence) "     AAAAAAAAAA mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91 + "'", int2 == 91);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("       oRACLE cORPORATION", "oRACLE cORPORATION", 68);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATIO", (java.lang.CharSequence) "/moc.elcaro.av");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("210905/Users/sophie/Documents/defects4j/tmp/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "210905/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/" + "'", str1.equals("210905/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (java.lang.CharSequence) "/aJ/yravarbiL/metsyS/:sno");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("O acla CS aS atSnO a################################", (int) (byte) -1, "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O acla CS aS atSnO a################################" + "'", str3.equals("O acla CS aS atSnO a################################"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", ":", (-1));
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "       Oracle Corporation", 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.6                      5.60                                                                                                ", 1725, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6                      5.60                                                                                                " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6                      5.60                                                                                                "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray5, strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray14);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11");
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/var/folders/_v/", strArray14, strArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 45 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Mac OS X" + "'", str15.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################" + "'", str1.equals("###################################"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                    chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", "/aJ/yravarbiL/metsyS/:sno");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM ", 101);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("m");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "m" + "'", str1.equals("m"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mixed mod1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8 jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM", (long) 169);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 169L + "'", long2 == 169L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "tnemnorivn", (java.lang.CharSequence) "1#.#7", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0L, (float) (byte) 1, (float) 40);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "                1.6                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", (int) 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_156021090544444444444444" + "'", str3.equals("44444444444444/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_156021090544444444444444"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11" + "'", str1.equals("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "             asun.lwawt.macosx.CPrinterJobaa", (java.lang.CharSequence) "-Bit Server VM 4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("5.60", 168, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", ":");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0.9                          ...", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9    ..." + "'", str2.equals("0.9    ..."));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "O acla CS aS atSnO a###############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", "n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2", (int) (byte) 10, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2" + "'", str3.equals("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { ' ', 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ot(TM) 64-Bit ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa         :               ", (java.lang.CharSequence) "java hotsa#########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "####################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) 169, (float) 139);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.71.7", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ", (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 46, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "UTF                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("####################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("6.1                                                                                              ", 168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168 + "'", int2 == 168);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("    1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("    1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "...", (java.lang.CharSequence) "http://java.oracle.comn", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, (double) 3, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("tn...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tn..." + "'", str1.equals("tn..."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        long[] longArray5 = new long[] { (byte) 100, 0L, (short) -1, (short) 10, '4' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "J", (java.lang.CharSequence) "                     asumixed mod", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("asun.lwawt.macosx.CPrinterJobaa", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asun.lwawt.macosx.CPrinterJobaa" + "'", str2.equals("asun.lwawt.macosx.CPrinterJobaa"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/#########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#########/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95773_1560210905/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr" + "'", str2.equals("/#########/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95773_1560210905/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                         1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "JavaHotSa", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                               US", "mixed mod", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " Java Platform API Specification", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 117);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 86 + "'", int3 == 86);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " Java Platfh/m API Si/c/f/cat/hU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "###################################");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSa#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSA#########################" + "'", str1.equals("JAVA HOTSA#########################"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specificatio1", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specificatio1" + "'", str3.equals("Java Platform API Specificatio1"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa" + "'", str1.equals("aaaaaaaaaa"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 97, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("5", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lw#wt.m#cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "  Java HotSpot(TM) 64-Bit Server VM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                 1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 1.6" + "'", str1.equals("                                                 1.6"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr.sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr2", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "bravary/Ja/Users/sophie/Libr2" + "'", str2.equals("bravary/Ja/Users/sophie/Libr2"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ", (java.lang.CharSequence) "                                                                                                    ", 139);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            ", "             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            " + "'", str2.equals("                                             RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/                                            "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("http://java.oracle.comn", "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.comn" + "'", str2.equals("http://java.oracle.comn"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                              1.6", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        short[] shortArray2 = new short[] { (byte) 100, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("             asun.lwawt.macosx.CPrinterJobaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             ASUN.LWAWT.MACOSX.cpRINTERjOBAA" + "'", str1.equals("             ASUN.LWAWT.MACOSX.cpRINTERjOBAA"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 31, 131);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                         1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/e...", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 139);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/e..." + "'", str3.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucod/e..."));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.9    ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        short[] shortArray2 = new short[] { (byte) 100, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.Class<?> wildcardClass4 = shortArray2.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java HotSa", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSa" + "'", str2.equals("Java HotSa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ava HotSa#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava HotSa#########################" + "'", str1.equals("ava HotSa#########################"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", 168, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b1124.80-b1124.80-b1124." + "'", str3.equals("b1124.80-b1124.80-b1124."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                             raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/5090120651_37759_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/                                            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", 3, 512);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61." + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61."));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "1.7.0_80-b15", (int) (short) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;S [LSvSSSU;", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/#########/Users/sophie/Documents/d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/#########/uSERS/SOPHIE/dOCUMENTS/D" + "'", str1.equals("/#########/uSERS/SOPHIE/dOCUMENTS/D"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification", 169L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 169L + "'", long2 == 169L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                     asumixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.61.61.61.61.");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/", 32, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 35, (double) 68.0f, (double) 34);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 68.0d + "'", double3 == 68.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM  Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 164 + "'", int2 == 164);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                             r#j.tnerruc-poodn#r/noit#reneg/noit#reneg_tset/bil/krowem#rf/j4stcefed/stnemucoD/eihpos/sresU/:sess#lc/tegr#t/5090120651_37759_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/                                            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6" + "'", str3.equals("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JREAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        long[] longArray5 = new long[] { (byte) 100, 0L, (short) -1, (short) 10, '4' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                        UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        ", "", 43, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                               UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        " + "'", str4.equals("                                                                               UTF-                                                                                                                                                                                UTF-                                                                                                                                                                                UTF-                                                                                        "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "O acla CS aS atSn", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          ", "61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 55);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "          " + "'", str5.equals("          "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "n", (java.lang.CharSequence) "1.7.0_80-Java HotSa########################1.7.0_80-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        long[] longArray3 = new long[] { 3, (short) 1, 18 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 18L + "'", long4 == 18L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 18L + "'", long5 == 18L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 18L + "'", long7 == 18L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.2", 46, 85);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Us/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrers/s/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreph/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/JavaV/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrertualMach/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jren/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jres/j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek1.7.0_80.j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrek/C/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrent/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrents/H/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/jr/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret:/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/N/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jretw/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrerk/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/Syst/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/L/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrebrary/Java/E/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jret/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrens:/usr/l/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreb/java", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ORACLE cORPORATION", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophiee", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnvironment", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("A");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "http://java.oracle.com/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################################", (int) 'a');
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java HotSa########################", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java HotSa########################" + "'", str6.equals("Java HotSa########################"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.LWCToolkit", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" Java Platfh/m API Si/c/f/cat/hU");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsEnvironment", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", "                        x86_64      1.6                          MacOSX                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     w  CG       E v        " + "'", str3.equals("     w  CG       E v        "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aUTF-otSa#########################", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aUTF-otSa#########################" + "'", str2.equals("aUTF-otSa#########################"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b11" + "'", str3.equals("2 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b112 .80-b11"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                  ", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:", (java.lang.CharSequence) "1560210905");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc" + "'", str3.equals("/t/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc;gnirtS.gnal.avajL[ ssalc"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophiee", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophiee" + "'", str3.equals("/Users/sophiee"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "                     asumixed mod", 55);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("210905/Users/sophie/Documents/defects4j/tmp/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 210905/Users/sophie/Documents/defects4j/tmp/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aUTF-otSa#########################", "1.6                                                                                              ", "       Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aUTF-otSa#########################" + "'", str3.equals("aUTF-otSa#########################"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        short[] shortArray2 = new short[] { (byte) 10, (byte) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.051.051.0n51.051.051.0");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 180, 268);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 180");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 24.0d, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "###################################");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "java hotsa#########################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(30L, 30L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("JavaHotSa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAHOTSA" + "'", str1.equals("JAVAHOTSA"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                 aaaaOaaaaa" + "'", str1.equals("                                                                                                                                                                                                                                                                 aaaaOaaaaa"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80-b15");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                 aaaaOaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray12 = new char[] { '#', 'a', '#', ' ', '#' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "A", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr1.7", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/#########/uSERS/SOPHIE/dOCUMENTS/D", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 267);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       " + "'", str2.equals("                                                       "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "     w  CG       E v        ", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n" + "'", str2.equals("nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/nhttp://java.oracle.com/n"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "6.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.16.1", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7100.90", "n", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#", (java.lang.CharSequence) "####################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124", (java.lang.CharSequence) "             asun.lwawt.macosx.CPrinterJobaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.6" + "'", str5.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.6" + "'", str7.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaa/moc.elcaro.avaj//:ptthaaaaaaaaaaaaaaa", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa/moc.elcaro.avaj//:ptthaaaaa" + "'", str2.equals("aaaa/moc.elcaro.avaj//:ptthaaaaa"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hines/jdk1.7.0_80.jdk/ ontents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/ ibr", "oraclecorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, (float) 2, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        boolean boolean11 = javaVersion5.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("MacOSX");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1#.#7", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "nt");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#.#7" + "'", str4.equals("1#.#7"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                0.9                                get/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                0.9                                get/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                             " + "'", str1.equals("                                0.9                                get/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                             "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence6, charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSa#########################", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                  ", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "U", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/" + "'", str2.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", " Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM  Java HotSpot(TM) .4-Bit Server VM ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "mixed mode", (int) (byte) 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "1.7.0_80-b15", (int) (short) 0);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.9", "1#.#7");
        java.lang.CharSequence charSequence14 = null;
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence14, (java.lang.CharSequence[]) strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "mixed mode");
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                              1.6", strArray13, strArray21);
        java.lang.Class<?> wildcardClass23 = strArray21.getClass();
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "1.7.0_80-b15", (int) (short) 0);
        boolean boolean29 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", (java.lang.CharSequence[]) strArray28);
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.stripAll(strArray28);
        java.lang.Class<?> wildcardClass31 = strArray28.getClass();
        java.lang.Class[] classArray33 = new java.lang.Class[4];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray34 = (java.lang.Class<?>[]) classArray33;
        wildcardClassArray34[0] = wildcardClass4;
        wildcardClassArray34[1] = wildcardClass9;
        wildcardClassArray34[2] = wildcardClass23;
        wildcardClassArray34[3] = wildcardClass31;
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray34);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str20.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "                                                                                              1.6" + "'", str22.equals("                                                                                              1.6"));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(classArray33);
        org.junit.Assert.assertNotNull(wildcardClassArray34);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str43.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/Systehi!/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "O", (java.lang.CharSequence[]) strArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/", 32, (int) ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-b15", 10, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("210905/Users/sophie/Documents/defects4j/tmp/", "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "210905/Users/sophie/Documents/defects4j/tmp/" + "'", str2.equals("210905/Users/sophie/Documents/defects4j/tmp/"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6", 46, 267);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        float[] floatArray2 = new float[] { 32L, (short) -1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 32.0f + "'", float4 == 32.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 32.0f + "'", float6 == 32.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Mac OS X", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                              uTF-                                               ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              uTF-                                               " + "'", str2.equals("                                              uTF-                                               "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.61.61.61.61.");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.61.61.61.61." + "'", str2.equals("1.61.61.61.61."));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/LibJ/Libr##################################################################################################################################################################################################################################################################", "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "x86_64      1.6                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("X86_64                                                                                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEHI!/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("####a#####", "sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensio...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####a#####" + "'", str2.equals("####a#####"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        float[] floatArray2 = new float[] { 32L, (short) -1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.Class<?> wildcardClass6 = floatArray2.getClass();
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 32.0f + "'", float4 == 32.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "o");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java", "/LibJ/Libr##################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java" + "'", str2.equals("vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java vm server .4-bit hotspot(tm) java"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "5.60                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.6                                            ", "1.6                                                                                              ", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str5.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "R vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm  jAVA hOTsPOT(tm) 64-bIT sERVER vm ", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6", 1, 268);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.6"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/5090120651_37759_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/#########/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95773_1560210905/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95773_1560210905", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie61/Users/sophie./Users/sophie6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '4', (long) 268, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 268L + "'", long3 == 268L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                            1.7.0_80                                             ", "/UER/PHIE/LIBRARY/JAVA/ETENIN:/LIBRARY/JAVA/ETENIN:/NETWRK/LIBRARY/JAVA/ETENIN:/YTE5/LIBRARY/JAVA/ETENIN:/UR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UER/PHIE/LIBRARY/JAVA/ETENIN:/LIBRARY/JAVA/ETENIN:/NETWRK/LIBRARY/JAVA/ETENIN:/YTE5/LIBRARY/JAVA/ETENIN:/UR/LIB/JAVA:." + "'", str2.equals("/UER/PHIE/LIBRARY/JAVA/ETENIN:/LIBRARY/JAVA/ETENIN:/NETWRK/LIBRARY/JAVA/ETENIN:/YTE5/LIBRARY/JAVA/ETENIN:/UR/LIB/JAVA:."));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                       sun.lwawt.macosx.CPrinterJob                                                        ", (java.lang.CharSequence) "1.7.0_801.61.61.61.61.61.61.61.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("210905/Users/sophie/Documents/defects4j/tmp/", "...DK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "210905/Users/sophie/Documents/defects4j/tmp" + "'", str2.equals("210905/Users/sophie/Documents/defects4j/tmp"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaa/moc.elcaro.avaj//:ptthaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensio...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" Java HotSpot(TM) 64-Bit Server VM ", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Serv" + "'", str2.equals(" Java HotSpot(TM) 64-Bit Serv"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61" + "'", str3.equals("1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.6                  1.7.0_801.61.61.61.61.61.61.61.oRACLE cORPORATION1.7.0_801.61.61.61.61.61.61"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "                                                       sun.lwawt.macosx.CPrinterJob                                                        ", "51.0                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEHI!/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "bravary/Ja/Users/sophie/Libr2", (java.lang.CharSequence) "MacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ot(TM) 64-Bit ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ot(TM) 64-Bit " + "'", str1.equals("ot(TM) 64-Bit "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-b15", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }
}

