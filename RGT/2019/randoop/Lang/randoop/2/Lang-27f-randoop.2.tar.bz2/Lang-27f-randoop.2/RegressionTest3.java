import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Hi !", "hi !      ", 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(202);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("US", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "java platform api specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi4!      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("http://j4v4.or4cle.com/", "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sohttpen//javaioracleicom/", "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", (int) (byte) -1, 68);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str4.equals("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(" HotSpot(TM) 64-Bit Server VMavaJ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.14.3a", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/mocielcaroiavaj//neptthos/sresU/", "", 231);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.", (java.lang.CharSequence) "       ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", "J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "sun.awt.CGraphicsEnvironment", 60, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("!!ihih", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi4!      ", "S", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "S" + "'", str4.equals("S"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 9L, 0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.awt.CGraphicsEnvironment", "hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("A!", "/Users/sohttp://java.oracle.com/", 218);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("Mac OS X", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str5.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7", "Oracle Corporatio", "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 231);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("X86_64", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64" + "'", str3.equals("X86_64"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("http://java.oracle.com/", "MIXEDMODE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("lat", 202, "/Users/sop");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat" + "'", str3.equals("/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/US##S/S#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/US##S/S#####" + "'", str1.equals("/US##S/S#####"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixedmode", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                               0.1#.                                                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("UTF-8", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sers/sophie", "#################################sun.awt.CGraphicsEnvironmentsun.awt", 202);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sers/sophie" + "'", str3.equals("sers/sophie"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("es", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str1.equals("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machine Specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("\nJava Virtual Machine Specification", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "es", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX" + "'", str2.equals("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#############################################################################################10.14.3", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################################################################10.14.3" + "'", str3.equals("#############################################################################################10.14.3"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("A!sun.lwawt.macosx.CPrinterJ", "J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A!sun.lwawt.macosx.CPrinterJ" + "'", str2.equals("A!sun.lwawt.macosx.CPrinterJ"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sers/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Users/sophie", "10.14.", "/Us##s/s#####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie" + "'", str3.equals("Users/sophie"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("I!!86_HIHI!!86_HIHI!!86_HIHI!!8", 47, "hihi!!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi" + "'", str3.equals("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "MIXEDMODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("HIHI!!", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                hi !                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                HI !                                                " + "'", str1.equals("                                                HI !                                                "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", (int) (byte) 100, "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih" + "'", str3.equals(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(33.0f, 100.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.CPrinterJob", "                                                HI !                                                ", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "J v  Pl tform API Specific tion", "UTF-8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7      ", "1.7", " x86_hihi!!x86_hihi!!x86_hihi!!x");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", "hi4!", "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str4.equals("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("A!sun.lwawt.macosx.CPrinterJob", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene", 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A!sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("A!sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED" + "'", str1.equals("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("\nJava Virtual Machine Specification", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ion" + "'", str2.equals("ion"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("X86_64                                                                                                                                                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                HI !                                                ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                HI !                                                " + "'", str2.equals("                                                HI !                                                "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("X86_64                                                                                                                                                                                                                                 ", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tem/Library/Java/Extensions:/usr/lib/java:.", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 56");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                HI !                                                ", "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                HI !                                                " + "'", str2.equals("                                                HI !                                                "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " x86_hihi!!x86_hihi!!x86_hihi!!x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java Virtual Machine Specification", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0.1#.");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification", "Hi !", "/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi4!      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi4!      " + "'", str1.equals("hi4!      "));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80-b15", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 170, (double) (byte) -1, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!" + "'", str1.equals("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str2.equals("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "51.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", "utf-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("MIXED MODE", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("J v  Pl tform API Specific tion");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J v  Pl tform API Specific tion" + "'", str2.equals("J v  Pl tform API Specific tion"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                               0.1#.                                                ", (int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0.1#.");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("hi4!      ", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("08_0.7.1", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.1" + "'", str3.equals("08_0.7.1"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64                                                                                                                                                                                                 ..." + "'", str1.equals("x86_64                                                                                                                                                                                                 ..."));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "ion", 215);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-b15", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sohttp://java.oracle.com/", "MIXEDMODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sohttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/Ja!/Library/Java/Ja", "4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                               0.1#.                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sohttp://java.oracle.com/", "/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "1.7.0_80-b15");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "24.80-b11", (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sohttpen//java.oracle.com/", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sohttpen//java.oracle.com/" + "'", str9.equals("/Users/sohttpen//java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.14.3", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-b15", "#################################sun.awt.CGraphicsEnvironmentsun.awt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.awt.CGraphicsEnvironment", "es");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv" + "'", str1.equals("/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/     " + "'", str2.equals("http://java.oracle.com/     "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str1.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_64                                                                                                                                                                                                                                 ", 8, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64                                                                                                                                                                                                                                 " + "'", str3.equals("X86_64                                                                                                                                                                                                                                 "));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (short) 1, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("J v  Pl tform API Specific tion", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, (int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sohttpen//java.oracle.com/", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sohttpen//java.oracle.com/" + "'", str2.equals("/Users/sohttpen//java.oracle.com/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Us##s/s#####", " HotSpot(TM) 64-Bit Server VMavaJ", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi4!      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("!", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("mixed mode", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/mocielcaroiavaj//neptthos/sresU/", (int) (byte) 10, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mocielcaroiavaj//neptthos/sresU/" + "'", str3.equals("/mocielcaroiavaj//neptthos/sresU/"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                               \n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("10.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JretnirPC.xsocam.twawl.nus!A", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("mixedmode", "                               \n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!", "http://j4v4.or4cle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MIXEDMODE", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification" + "'", str1.equals("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("HI!", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!                         " + "'", str2.equals("HI!                         "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("jAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pLATFORM api sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("lat");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(218, 211, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", (int) '4', "lat");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("J v  Pl tform API Specific tion", (int) (byte) -1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http://java.oracle.com/     ", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/     " + "'", str3.equals("http://java.oracle.com/     "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str1.equals("I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                     24.80-B11                      ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("I!!86_HIHI!!86_HIHI!!86_HIHI!!8", (double) 67);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.0d + "'", double2 == 67.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Users/sohttpen//javaioracleicom/", "08_0.7.1                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("       ...", "08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, (int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...ava/Ja", 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ion", "/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", 231);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "A!sun.lwawt.macosx.CPrinterJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        char[] charArray6 = new char[] { ' ', 'a', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("24.80-b11", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("http://j4v4.or4cle.com/", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("JretnirPC.xsocam.twawl.nus!A");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("MIXEDMODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMODE" + "'", str1.equals("MIXEDMODE"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("S", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str2.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sohttp://java.oracle.com/");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sohttp://java.oracle.com/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporatio" + "'", str1.equals("OracleCorporatio"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray4, strArray6);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray9, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray6, strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ');
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray19, strArray21);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray24, strArray26);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray21, strArray24);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, 'a');
        int int31 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sohttp://java.oracle.com/", strArray24);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray6, strArray24);
        int int33 = org.apache.commons.lang3.StringUtils.indexOfAny("MIXEDMODE", strArray24);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "!" + "'", str12.equals("!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie" + "'", str13.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi !" + "'", str15.equals("hi !"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "!" + "'", str22.equals("!"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "!" + "'", str27.equals("!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "/Users/sophie" + "'", str28.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "/" + "'", str32.equals("/"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MIXED MODE", "/Us##s/s#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "Java Virtual Machine Specification", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                               0.1#.                                                ", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Users/sophie", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("A!sun.lwawt.macosx.CPrinterJ", "hisers/sophie!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A!sun.lwawt.macosx.CPrinterJ" + "'", str2.equals("A!sun.lwawt.macosx.CPrinterJ"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit", 231, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int[] intArray6 = new int[] { (byte) 10, 10, 100, 67, (short) 0, 0 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10.14.3a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "10.14.3", (int) (byte) 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80", strArray1, strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sun.lwawt.macosx.cprinterjob", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85 + "'", int2 == 85);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("x86_hihi!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str1.equals("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi4!      ", "tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi4!      " + "'", str2.equals("hi4!      "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI !" + "'", str1.equals("hI !"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("en");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "A!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "/Library/Java/Ja!/Library/Java/Ja", "...ava/Ja");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     24.80-b11                      " + "'", str1.equals("                     24.80-b11                      "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US", "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "08_0.7.1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("UTF-8", "#################################\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java platform api specification", "       ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene" + "'", str1.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray5, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        java.lang.Class<?> wildcardClass11 = strArray7.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny("x86_hihi!!", strArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM) SE Runtime Environment", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "!" + "'", str8.equals("!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hia!" + "'", str10.equals("hia!"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("51.0", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 en" + "'", str3.equals("                                 en"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                               \n", 211);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sers/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Users/sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie" + "'", str2.equals("Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih", "http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                               0.1#.                                                ", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed" + "'", str3.equals("/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    Java(TM) SE Runtime Environment" + "'", str3.equals("    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                hi !                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                hi !                                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "http://java.oracle.com/     ", (java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/     " + "'", charSequence2.equals("http://java.oracle.com/     "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Mac OS X", (int) (short) 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("x86_64", "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("    Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("a!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("I!!86_HIHI!!86_HIHI!!86_HIHI!!8", "                               \n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!!86_HIHI!!86_HIHI!!86_HIHI!!8" + "'", str2.equals("I!!86_HIHI!!86_HIHI!!86_HIHI!!8"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80", "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80" + "'", str2.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! iH" + "'", str1.equals("! iH"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hisers/sophie!", "x86_64", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("\n", "es");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", (int) (byte) 100, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0" + "'", str3.equals("51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "/US##S/S#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("es", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MIXED MODE", 49, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 52L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("X86_64                                                                                                                                                                                                 ...", "Hi !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        char[] charArray7 = new char[] { ' ', 'a', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(":", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("MIXED MODE", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("\n", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("A!sun.lwawt.macosx.CPrinterJ", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.14.3", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "", (int) '#', 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "/", 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("0.1#.", strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.", strArray5, strArray10);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Users/sophie" + "'", str11.equals("Users/sophie"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.14." + "'", str13.equals("10.14."));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.CGraphicsEnvironment", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Users/sophie", "/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0", "A!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("HIHI!!", "utf-8", 231);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI" + "'", str1.equals("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "0.1#.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HIHI!!", (java.lang.CharSequence) "/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 233 + "'", int2 == 233);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sers/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat" + "'", str2.equals("/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", "hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen" + "'", str2.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str2.equals("10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                                                     0.1#.                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/mocielcaroiavaj//neptthos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 215, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 215 + "'", int3 == 215);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "http://j4v4.or4cle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("x86_64", 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", "/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed", "#############################################################################################10.14.3", 85);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI" + "'", str4.equals("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9L, (float) 10L, 8.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (-1));
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("a!", "/Users/sohttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/sop/Users/solat\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b11", 60, 60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi", "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi" + "'", str2.equals("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", 1, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932" + "'", str3.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 213 + "'", int1 == 213);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "#################################\n", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Platform#API", "    Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                     24.80-b11                      ", "Java Platform API Specification", (int) (short) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("MIXED MODE", "http://j4v4.or4cle.com/", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MODE" + "'", str3.equals("MIXED MODE"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hI !", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi !" + "'", str1.equals("hi !"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("JAVA VIRTUAL MACHINE SPECIFICATION", "08_0.7.1", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", "lat", 32, 213);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTlat" + "'", str4.equals("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTlat"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi !      ", 218);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi !                                                                                                                                                                                                                      " + "'", str2.equals("hi !                                                                                                                                                                                                                      "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                   ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hia!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hia!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("x86_64", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hI !", "#############################################################################################10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HI!", 233);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 218);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.14.3a", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("X86_64                                                                                                                                                                                                                                 ", "sophie", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64                                                                                                                                                                                                                                 " + "'", str3.equals("X86_64                                                                                                                                                                                                                                 "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hisers/sophie!", "10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("0.1#.", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Users/sophie" + "'", str5.equals("Users/sophie"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Users/sophie" + "'", str7.equals("Users/sophie"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str2.equals("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 9, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64", 6, 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...ava/Ja", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...av..." + "'", str2.equals("...av..."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/     ", "                                   ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("MIXEDMODE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: MIXEDMODE is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7     " + "'", str1.equals("1.7     "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("mixedmode", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(202, 31, 85);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defec..." + "'", str2.equals("/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("MIXEDMODE", 31, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/     ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sohttpen//java.oracle.com/", 27, 233);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                               \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 211, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str3.equals("###############################################################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 7, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("es");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sun.lwawt.macosx.LWCToolkit", "X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "java platform api specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("...av...", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str1.equals("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                     24.80-B11                      ", "                                                HI !                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                 en", 67, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 enx86_64x86_64x86_64x86_64x86_64x8" + "'", str3.equals("                                 enx86_64x86_64x86_64x86_64x86_64x8"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "mixed mode", "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.0d + "'", double12 == 52.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!" + "'", str1.equals("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Platform#API", "A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int[] intArray1 = new int[] { 31 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64                                                                                                                                                                                                 ..." + "'", str1.equals("X86_64                                                                                                                                                                                                 ..."));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray3, strArray5);
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray8, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray5, strArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        java.lang.String[] strArray18 = new java.lang.String[] {};
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray18, strArray20);
        java.lang.String[] strArray23 = new java.lang.String[] {};
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray23, strArray25);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray20, strArray23);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, 'a');
        int int30 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sohttp://java.oracle.com/", strArray23);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray5, strArray23);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "", (int) (byte) -1, (-1));
        java.lang.String[] strArray36 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray36);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "!" + "'", str6.equals("!"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "!" + "'", str11.equals("!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie" + "'", str12.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi !" + "'", str14.equals("hi !"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "!" + "'", str21.equals("!"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "!" + "'", str26.equals("!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/Users/sophie" + "'", str27.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "/" + "'", str31.equals("/"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 4, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", "I!!86_HIHI!!86_HIHI!!86_HIHI!!8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sohttpen//javaioracleicom/", "                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("HI!                         ", "Hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I" + "'", str2.equals("I"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hisers/sophie!", "sophie", (int) (byte) 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Users/sohttp://java.oracle.com/", "http://java.oracle.com/", 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS" + "'", str2.equals("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 213);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 213 + "'", int2 == 213);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                               \n", "Oracle Corporatio", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 67);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("X86_64", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", charSequence2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("jAVA pLATFORM api sPECIFICATION", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "! iH");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (-1));
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("S", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (-1));
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sohttpen//javaioracleicom/", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80", "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt", 100, 218);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt" + "'", str4.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(":", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x86_64" + "'", str5.equals("x86_64"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" x86_hihi!!x86_hihi!!x86_hihi!!x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " X86_HIHI!!X86_HIHI!!X86_HIHI!!X" + "'", str1.equals(" X86_HIHI!!X86_HIHI!!X86_HIHI!!X"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("08_0.7.1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.1" + "'", str2.equals("08_0.7.1"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", 33, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444/Users/sophie4444444444" + "'", str3.equals("4444444444/Users/sophie4444444444"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", "http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/     " + "'", str2.equals("http://java.oracle.com/     "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("es", "/Users/sohttp://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie", "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0", "x86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray4, strArray6);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray9, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray6, strArray9);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (-1));
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("                     24.80-b11                      ", strArray6, strArray17);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (-1));
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray22);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray22);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("JAVA VIRTUAL MACHINE SPECIFICATION", strArray6, strArray22);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "!" + "'", str12.equals("!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie" + "'", str13.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "                     24.80-b11                      " + "'", str18.equals("                     24.80-b11                      "));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str25.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("\n", "#################################sun.awt.CGraphicsEnvironmentsun.awt");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("en", "A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S" + "'", str1.equals("S"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Hi !", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11" + "'", str2.equals("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.14.", "\nJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       ...", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       ..." + "'", str3.equals("       ..."));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "       ..." + "'", str5.equals("       ..."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("!!ihih", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HIHI!!", 60);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60 + "'", int2 == 60);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "       ...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("! iH", (int) (byte) 100, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "HIHI!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/http://j4v4.or4cle.com//Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv", "hia!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray4, strArray6);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray9, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray6, strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ');
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray19, strArray21);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray24, strArray26);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray21, strArray24);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, 'a');
        int int31 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sohttp://java.oracle.com/", strArray24);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray6, strArray24);
        int int33 = org.apache.commons.lang3.StringUtils.indexOfAny("ion", strArray24);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "!" + "'", str12.equals("!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie" + "'", str13.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi !" + "'", str15.equals("hi !"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "!" + "'", str22.equals("!"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "!" + "'", str27.equals("!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "/Users/sophie" + "'", str28.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "/" + "'", str32.equals("/"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hiHI!!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eI!!" + "'", str3.equals("eI!!"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(" HotSpot(TM) 64-Bit Server VMavaJ", "A!sun.lwawt.macosx.CPrinterJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                hi !                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi !" + "'", str1.equals("hi !"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("mixed mode", "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", "HIHI!!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "A!sun.lwawt.macosx.CPrinterJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi", 68, "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hiX86_64X86_64X86_64X86" + "'", str3.equals("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hiX86_64X86_64X86_64X86"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                               0.1#.                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                               0.1#.                                                " + "'", str1.equals("                                               0.1#.                                                "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle Corporatio", "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "###############################################################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 6, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hisers/sophie!", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hisers/sophie!" + "'", str3.equals("hisers/sophie!"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mixedmode", 202, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JAVA VIRTUAL MACHINE SPECIFICATION", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "x86_hihi!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "I");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                 en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("! iH", "eI!!", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "! iH" + "'", str3.equals("! iH"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        char[] charArray7 = new char[] { '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Users/sophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("tem/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3a", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixedmode", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" ", 27, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaa " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaa "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80" + "'", str2.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java HotSpot(TM) 64-Bit Server VM", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server " + "'", str2.equals("Java HotSpot(TM) 64-Bit Server "));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                     24.80-B11                      ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64                                                                                                                                                                                                                                 ", "", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7.0f, (double) 52, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.1#.", "                     24.80-B11                      ", 202);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1#." + "'", str3.equals("10.1#."));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                 enx86_64x86_64x86_64x86_64x86_64x8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt" + "'", str1.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("java platform api specification");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "HI!");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI!                         ", "hia!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!                         " + "'", str2.equals("HI!                         "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("MIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MOD" + "'", str1.equals("MIXED MOD"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "#################################\n", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    Java(TM) SE Runtime Environment", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "I!!86_HIHI!!86_HIHI!!86_HIHI!!8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!!86_HIHI!!86_HIHI!!86_HIHI!!8" + "'", str1.equals("i!!86_HIHI!!86_HIHI!!86_HIHI!!8"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("10.14.", "/Users/sohttpen//javaioracleicom/", 231);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server V", "MIXED MODE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" HotSpot(TM) 64-Bit Server VMavaJ", 3, "http://j4v4.or4cle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str3.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                               0.1#.                                                ", "X86_64                                                                                                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!", "A!sun.lwawt.macosx.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene" + "'", str2.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 217 + "'", int1 == 217);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, "HI!                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenene..." + "'", str2.equals("enenenenenenenenenenenenenene..."));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java HotSpot(TM) 64-Bit Server ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                     24.80-b11                      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!", "HI!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi !      ", (java.lang.CharSequence) "Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...ava/Ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ...ava/Ja is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", 59);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "A!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '#', (double) 8, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MIXED MODE", "Oracle Corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("A!sun.lwawt.macosx.CPrinterJob", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MIXEDA!sun.lwawt.macosx.CPrinterJobMA!sun.lwawt.macosx.CPrinterJobDE" + "'", str4.equals("MIXEDA!sun.lwawt.macosx.CPrinterJobMA!sun.lwawt.macosx.CPrinterJobDE"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/mocielcaroiavaj//neptthos/sresU/", 59, "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/" + "'", str3.equals("Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MIXEDMODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMODE" + "'", str1.equals("MIXEDMODE"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) -1, (double) 213, (double) 215.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 215.0d + "'", double3 == 215.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi !      ", 85);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                           hi !      " + "'", str2.equals("                                                                           hi !      "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444", "/Library/Java/Ja!/Library/Java/Ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444" + "'", str2.equals("4U4444444phi44Lib444y4J4444E4t444i444:4Lib444y4J4444J444Vi4tu44M44hi4444j4k4.4.4484.j4k4C44t44t44H4444j4444ib444t:4Lib444y4J4444E4t444i444:4N4tw44k4Lib444y4J4444E4t444i444:4Sy4t444Lib444y4J4444E4t444i444:4u4444ib4j444"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                     24.80-B11                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     24.80-b11                      " + "'", str1.equals("                     24.80-b11                      "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 215);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                       " + "'", str2.equals("                                                                                                                                                                                                                       "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "#############################################################################################10.14.3", (java.lang.CharSequence) "######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#############################################################################################10.14.3" + "'", charSequence2.equals("#############################################################################################10.14.3"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sohttp://java.oracle.com/", (int) (byte) -1, 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7", "hisers/sophie!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

