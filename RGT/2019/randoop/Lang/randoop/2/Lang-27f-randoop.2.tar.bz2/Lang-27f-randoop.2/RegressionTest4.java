import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/mocielcaroiavaj//neptthos/sresU/", "10.14.3a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MIXED MODE", "S", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 49);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 49.0d + "'", double2 == 49.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java platform api specification", "Mac OS X", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java platform api specification" + "'", str3.equals("java platform api specification"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MIXED MODE", "/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", 202);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt", "                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", "A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED" + "'", str2.equals("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("x86_64", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi !" + "'", str1.equals("Hi !"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", 215);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 27, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi !      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H" + "'", str1.equals("I!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.14.3", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("http://java.oracle.com/     ", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("jAVA pLATFORM api sPECIFICATION", "enenenenenenenenenenenenenene...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7      ", "51.0####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0####" + "'", str2.equals("51.0####"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("HIHI!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIHI!!" + "'", str1.equals("HIHI!!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("I!!86_HIHI!!86_HIHI!!86_HIHI!!8", "eI!!", "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "I!!86_HIHI!!86_HIHI!!86_HIHI!!8" + "'", str4.equals("I!!86_HIHI!!86_HIHI!!86_HIHI!!8"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Us##s/s#####", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih" + "'", str1.equals(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "x86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "eI!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification" + "'", str1.equals("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java HotSpot(TM) 64-Bit Server VM", 202, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                               0.1#.                                                ", "...ava/Ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str2.equals("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("X86_64                                                                                                                                                                                                 ...", "                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixed mode", "                                               0.1#.                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("...av...", "ion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...av..." + "'", str2.equals("...av..."));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("ion", "1.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("J v  Pl tform API Specific tion", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Platform#API");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray4, strArray6);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray9, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray6, strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ');
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray19, strArray21);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray24, strArray26);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray21, strArray24);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, 'a');
        int int31 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sohttp://java.oracle.com/", strArray24);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray6, strArray24);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.startsWithAny("######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H", strArray24);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "!" + "'", str7.equals("!"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "!" + "'", str12.equals("!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie" + "'", str13.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi !" + "'", str15.equals("hi !"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "!" + "'", str22.equals("!"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "!" + "'", str27.equals("!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "/Users/sophie" + "'", str28.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "/" + "'", str32.equals("/"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80", 0, "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80" + "'", str3.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                       " + "'", str1.equals("                                                                                                                                                                                                                       "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MIXEDA!sun.lwawt.macosx.CPrinterJobMA!sun.lwawt.macosx.CPrinterJobDE", "Oracle Corporatio", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...av...", "UTF-8", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("A!sun.lwawt.macosx.CPrinterJob", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 33, "                     24.80-B11                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "10.14.3a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("J v  Pl tform API Specific tion", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporatio", "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTlat");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatio" + "'", str2.equals("Oracle Corporatio"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.1#.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HIHI!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!IHIH" + "'", str1.equals("!!IHIH"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!", "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("    Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 47, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 217, (float) ' ', (float) 67);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "Oracle Corporatio", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/", "hi4!      ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/" + "'", str3.equals("Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7     ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "0.1#.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1#." + "'", str1.equals("0.1#."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sohttpen//javaioracleicom/", "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hihi!!", "", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi!!" + "'", str3.equals("hihi!!"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http://j4v4.or4cle.com/", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j4v4.or4cle.com/" + "'", str2.equals("http://j4v4.or4cle.com/"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.LWCToolkit", "Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "!!ihih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("http://java.oracle.com/", "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih", 4, "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih" + "'", str3.equals(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java Virtual Machine Specification", "Hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("http://j4v4.or4cle.com/", "mixedmode", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "enenenenenenenenenenenenenene...", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "enenenenenenenenenenenenenene..." + "'", charSequence2.equals("enenenenenenenenenenenenenene..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS X", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("eI!!", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eI!!" + "'", str3.equals("eI!!"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hiX86_64X86_64X86_64X86", 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("...ava/Ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...ava/Ja" + "'", str1.equals("...ava/Ja"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "#################################\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sohttpen//javaioracleicom/", 213);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sohttpen//javaioracleicom/" + "'", str2.equals("/Users/sohttpen//javaioracleicom/"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                hi !                                                ", 28, "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                hi !                                                " + "'", str3.equals("                                                hi !                                                "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\nJava Virtual Machine Specification", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Oracle Corporatio", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatio" + "'", str2.equals("Oracle Corporatio"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HIHI!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        char[] charArray8 = new char[] { '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Users/sophie", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("1.7", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\nJava Virtual Machine Specification", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment", "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTlat");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment" + "'", str2.equals("sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                 enx86_64x86_64x86_64x86_64x86_64x8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hiHI!!", "10.14.3", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification" + "'", str2.equals("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", "10.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX", "tem/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX" + "'", str4.equals("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hOSX"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sohttp://java.oracle.com/", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sohttp://java.oracle.com/" + "'", str3.equals("/Users/sohttp://java.oracle.com/"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H" + "'", str2.equals("######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleCorporatio", "!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444/Users/sophie4444444444", "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt" + "'", str2.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("...ava/Ja", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...ava/Ja" + "'", str2.equals("...ava/Ja"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("es", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "es                                 " + "'", str3.equals("es                                 "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...ava/Ja", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...ava/Ja" + "'", str2.equals("...ava/Ja"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "Java Platform API Specification", (int) (short) -1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sun.lwawt.macosx.CPrinterJob", strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("enenenenenenenenenenenenenene...", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("i!!86_HIHI!!86_HIHI!!86_HIHI!!8", 67, 231);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28, (double) 218, (double) 7.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", "ion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", "A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/" + "'", str2.equals("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " X86_HIHI!!X86_HIHI!!X86_HIHI!!X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.1#.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" X86_HIHI!!X86_HIHI!!X86_HIHI!!X", "                               \n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " X86_HIHI!!X86_HIHI!!X86_HIHI!!X" + "'", str2.equals(" X86_HIHI!!X86_HIHI!!X86_HIHI!!X"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("! iH", 233, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "! iH                                                                                                                                                                                                                                     " + "'", str3.equals("! iH                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0.1#.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", (int) (byte) -1, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hisers/sophie!", "#############################################################################################10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               \n", "eI!!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hi !      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("en", 218, "/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extens" + "'", str3.equals("en/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extens"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://j4v4.or4cle.com/", "ion", 27);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("JretnirPC.xsocam.twawl.nus!A", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ion", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ion" + "'", str3.equals("ion"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("x86_64", 0, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        char[] charArray4 = new char[] { '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(31, 0, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "http://java.oracle.com/     ", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                                     0.1#.                                                ", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(47, 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 47 + "'", int3 == 47);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                hi !                                                ", 218, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(218, 215, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("A!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hia!", "a!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A" + "'", str3.equals("A"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                           hi !      ", "a!", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7     ", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7#####" + "'", str3.equals("1.7#####"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hisers/sophie!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hisers/sophie!" + "'", str1.equals("hisers/sophie!"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HIHI!!", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8.0f, (double) 170, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Platform#API", 34, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform#API" + "'", str3.equals("Platform#API"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http://j4v4.or4cle.com/", 1, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://j4v4.or4cle.com/" + "'", str3.equals("http://j4v4.or4cle.com/"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 170L, 68.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "I");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/US##S/S#####", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/US##S/S#####" + "'", str2.equals("/US##S/S#####"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih", (java.lang.CharSequence) "                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih" + "'", charSequence2.equals(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "hi4!      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU/" + "'", str1.equals("/MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU/"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "1.7.0_80-b15", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java(TM) SE Runtime Environment", "Hi !", 211, 233);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime EnvironmentHi !" + "'", str4.equals("Java(TM) SE Runtime EnvironmentHi !"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ion", "hi4!      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 217, 0.0f, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7#####" + "'", str1.equals("1.7#####"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hi !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 4, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("\n", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int[] intArray3 = new int[] { 10, 'a', (byte) 100 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("i!!86_HIHI!!86_HIHI!!86_HIHI!!8", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!!86_HIHI!!86_HIHI!!86_HIHI!!8" + "'", str2.equals("i!!86_HIHI!!86_HIHI!!86_HIHI!!8"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 217, "! iH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH" + "'", str3.equals("/! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        float[] floatArray3 = new float[] { '#', (short) 100, 0 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "10.1.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4444444444/Users/sophie4444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444/Users/sophie4444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedmode" + "'", str3.equals("mixedmode"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixedmode" + "'", str4.equals("mixedmode"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Hi !", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hh86_hh86_hh86_hh86_hhi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hh86_hh86_hh86_hh86_hhi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) 47, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 47L + "'", long3 == 47L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "i!!86_HIHI!!86_HIHI!!86_HIHI!!8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specification" + "'", str1.equals("java virtual machine specification"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("! iH                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                     Hi !" + "'", str1.equals("                                                                                                                                                                                                                                     Hi !"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sun1.7.0_80-b15.1.7.0_80-b15awt1.7.0_80-b15.1.7.0_80-b15C1.7.0_80-b15Graphics1.7.0_80-b15Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun.lwawt.macosx.CPrinterJob", "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double[] doubleArray4 = new double[] { 6, (byte) 1, 10, 100.0f };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob", "51.0####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi" + "'", str1.equals("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hi", 233, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                     0.1#.                                                ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     ..." + "'", str2.equals("     ..."));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt" + "'", str1.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                           hi !      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                           hi !      " + "'", str1.equals("                                                                           hi !      "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hI !", (int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I !" + "'", str3.equals("I !"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa", "MIXEDA!sun.lwawt.macosx.CPrinterJobMA!sun.lwawt.macosx.CPrinterJobDE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", " X86_HIHI!!X86_HIHI!!X86_HIHI!!X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " X86_HIHI!!X86_HIHI!!X86_HIHI!!X" + "'", str2.equals(" X86_HIHI!!X86_HIHI!!X86_HIHI!!X"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification", "enenenenenenenenenenenenenene...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("http://java.oracle.com/     ", "es", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/     " + "'", str3.equals("http://java.oracle.com/     "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt" + "'", str1.equals("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), (float) 85, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "HI!                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", "I !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str2.equals("/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0.1#.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".1#.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentHi !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                               0.1#.                                                ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               0.1#.                                                " + "'", str2.equals("                                               0.1#.                                                "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi !" + "'", str1.equals("Hi !"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.awt.CGraphicsEnvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CG" + "'", str2.equals("sun.awt.CG"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                           hi !      ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "! hi" + "'", str2.equals("! hi"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("I!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H", 233, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:" + "'", str3.equals("I!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU/" + "'", str2.equals("/MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU//MOC.ELCARO.AVAJ//NEPTTHOS/SRESU/"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "A!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hia!", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hia!" + "'", str3.equals("hia!"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.awt.CGraphicsEnvironment");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.", strArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X" + "'", str5.equals("M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 43 + "'", int6 == 43);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HIHI!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hI !", (int) (short) 0, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Us##s/s#####", 67, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih", "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih" + "'", str2.equals(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("US", "1.7", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hiX86_64X86_64X86_64X86");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIHI!!HIi!!86_hihi!!86_hihi!!86_hihi!!8HIHI!!HIx86_64x86_64x86_64x86" + "'", str1.equals("HIHI!!HIi!!86_hihi!!86_hihi!!86_hihi!!8HIHI!!HIx86_64x86_64x86_64x86"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 202);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 202 + "'", int2 == 202);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 215L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 215L + "'", long3 == 215L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", "! iH                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "###############################################################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXEDMODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" x86_hihi!!x86_hihi!!x86_hihi!!x", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " x86_hihi!!x86_hihi!!x86_hihi!!x" + "'", str2.equals(" x86_hihi!!x86_hihi!!x86_hihi!!x"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "Java Virtual Machine Specification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 211, 6);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 6, (long) 7, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11" + "'", str1.equals("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932", "...ava/Ja", 33);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "! hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str1.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt" + "'", str2.equals("Java(TM) SE Runt/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/m/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/ Env/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/r/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nm/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/nt"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/Ja!/Library/Java/Ja", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi !aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        int[] intArray6 = new int[] { (byte) 10, 10, 100, 67, (short) 0, 0 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", 6, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/" + "'", str3.equals("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java HotSpot(TM) 64-Bit Server ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", "JAVA VIRTUAL MACHINE SPECIFICATION", "hihi!!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED" + "'", str3.equals("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/" + "'", str1.equals("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "Oracle Corporation", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7     ", "", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7     " + "'", str5.equals("1.7     "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Users/sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("! hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! hi" + "'", str1.equals("! hi"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11", 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11" + "'", str3.equals("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("...ava/Ja", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Java..." + "'", str2.equals("/Java..."));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int[] intArray5 = new int[] { 6, 4, 34, (byte) -1, (byte) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 34 + "'", int7 == 34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "aaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mixedmode", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64                                                                                                                                                                                                 ...", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED" + "'", str2.equals("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://j4v4.or4cle.com/", "ion", 27);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                           hi !      ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/", "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4444444444/Users/sophie4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444/Users/sophie4444444444" + "'", str1.equals("4444444444/Users/sophie4444444444"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    Java(TM) SE Runtime Environment", 0, "a!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    Java(TM) SE Runtime Environment" + "'", str3.equals("    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH", 47, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 47, (double) '#', (double) 43);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.0d + "'", double3 == 47.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen" + "'", str1.equals("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("       ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGraphicsEnvironment", "#################################\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", " x86_hihi!!x86_hihi!!x86_hihi!!x");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 215, (long) 34, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                     24.80-B11                      ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "hi !                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     24.80-B11                      " + "'", str3.equals("                     24.80-B11                      "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java HotSpot(TM) 64-Bit Server V", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ion", 32, "Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ionJava(TM) SE Runt/Users/soh/mo" + "'", str3.equals("ionJava(TM) SE Runt/Users/soh/mo"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\n", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...av...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...av.." + "'", str1.equals("...av.."));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\nJava Virtual Machine Specification", 5, "                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nJava Virtual Machine Specification" + "'", str3.equals("\nJava Virtual Machine Specification"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed", "", "/Users/sohttpen//javaioracleicom/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        double[] doubleArray6 = new double[] { '#', (-1), '#', 10, '4', (short) 1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                     24.80-b11                      ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("...ava/Ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...ava/Ja" + "'", str1.equals("...ava/Ja"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) ":hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_8913_1560226932/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", " X86_HIHI!!X86_HIHI!!X86_HIHI!!X", 202);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hia!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hia!" + "'", str1.equals("hia!"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/mocielcaroiavaj//neptthos/sresU/", 0, "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mocielcaroiavaj//neptthos/sresU/" + "'", str3.equals("/mocielcaroiavaj//neptthos/sresU/"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        short[] shortArray3 = new short[] { (byte) 1, (short) 1, (byte) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, (-1L), (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob", "! iH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 0, (double) 52L, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.cprinterjob", "hi !      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("##########", "HIHI!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HIHI!!" + "'", str2.equals("HIHI!!"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "1.7.0_80-b15", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Us##s/s#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HIHI!!", (java.lang.CharSequence) "     ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hihi!!hiI!!86_HIHI!!86_HIHI!!86_HIHI!!8hihi!!hiX86_64X86_64X86_64X86", "##########", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 43, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", "/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str2.equals("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "       ...", 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 60, 7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        long[] longArray1 = new long[] { (short) 1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("51.0####", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "sers/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str2.equals("i!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runt/Users/soh/mocielcaroiavaj//neptthos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "4444444444/Users/sophie4444444444", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MIXEDMODE", "Java Platform API Specification", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                       " + "'", str1.equals("                                                                                                                                                                                                                       "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Platform#API");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi !      ", 1, "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi !      " + "'", str3.equals("hi !      "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0", "A!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0" + "'", str2.equals("51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "MIXED MOD", (java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "MIXED MOD" + "'", charSequence2.equals("MIXED MOD"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Hi !", "/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi !" + "'", str2.equals("Hi !"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "hi !                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '4', 67.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.0d + "'", double3 == 67.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("US", "10.14.3a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MIXEDMODE", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444MIXEDMODE4444444444444444444444" + "'", str3.equals("444444444444444444444MIXEDMODE4444444444444444444444"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("86_hihi!!", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defec...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HIHI!!HIi!!86_hihi!!86_hihi!!86_hihi!!8HIHI!!HIx86_64x86_64x86_64x86", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI!", "x86_hihi!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("                     24.80-B11                      ", "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80-b15", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b15" + "'", str2.equals("-b15"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        char[] charArray9 = new char[] { ' ', 'a', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("24.80-b11", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("hia!", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("A!sun.lwawt.macosx.CPrinterJob", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("http://java.oracle.com/", "i!!86_HIHI!!86_HIHI!!86_HIHI!!8", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("tem/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: tem/Library/Java/Extensions:/usr/lib/java:. is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                               \n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##########", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JAVA VIRTUAL MACHINE SPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "#################################\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#################################\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "http://j4v4.or4cle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 8, (long) 170);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("A!sun.lwawt.macosx.CPrinterJ", "A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A!sun.lwawt.macosx.CPrinterJ" + "'", str2.equals("A!sun.lwawt.macosx.CPrinterJ"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/", 85);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/" + "'", str2.equals("/mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU//mocielcaroiavaj//neptthos/sresU/"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("jAVA pLATFORM api sPECIFICATION", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N" + "'", str2.equals("N"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                                                                     0.1#.                                                ", "", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str1.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("enenenenenenenenenenenenenene...", (int) (short) 0, "S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenene..." + "'", str3.equals("enenenenenenenenenenenenenene..."));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("! hi", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("tem/Library/Java/Extensions:/usr/lib/java:.", 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun1.7.0_80-b15.1.7.0_8sun1.7.0_80-b15.1.7.0_80java(tm) se runt/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/m/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/ env/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/r/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nm/users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com//users/sohttpen//java.oracle.com/nt", 31, 202);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Library/Java/Ja!/Library/Java/Ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/Ja!/Library/Java/Ja" + "'", str1.equals("/Library/Java/Ja!/Library/Java/Ja"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Us##s/s#####");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporation", "HIHI!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str2.equals("I!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie", 49, "                                 enx86_64x86_64x86_64x86_64x86_64x8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie" + "'", str3.equals("Users/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophieUsers/sophie"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "!!ihih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("444444444444444444444MIXEDMODE4444444444444444444444", "\nJava Virtual Machine Specification", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 211);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "86_hihi!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0L, (double) 9, (double) 170.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 47L, (double) 215.0f, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.0d + "'", double3 == 47.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/" + "'", str1.equals("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("MIXEDMODE", "!!ihih", "!!IHIH");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/Users/sohttpen//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("enenenenenenenenenenenenenene...", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "Java1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecificationJava1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hPlatform1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hAPI1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", "HIHI!!HIi!!86_hihi!!86_hihi!!86_hihi!!8HIHI!!HIx86_64x86_64x86_64x86");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                                                                                                                                                     Hi !");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                     Hi !\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) 0, "/Users/sohttpen//javaioracleicom/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTUAL#M#ACHINES#/#JDK#1#.#7#.#0#_#80#.#JDK#/#C#ONTENTS#/#H#OME#/#JRE#/#LIB#/#ENDORSED", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("...ava/Ja", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...ava/Ja" + "'", str2.equals("...ava/Ja"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HIHI!!HIi!!86_hihi!!86_hihi!!86_hihi!!8HIHI!!HIx86_64x86_64x86_64x86", (java.lang.CharSequence) "10.14.3a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7     ", (int) (short) 0, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit", "enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("##########", "                                                                                                                                                                                                                                     Hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "1.7      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7      " + "'", str1.equals("1.7      "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("#################################\n", 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!" + "'", str2.equals("x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        char[] charArray9 = new char[] { ' ', 'a', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("24.80-b11", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("hia!", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("A!sun.lwawt.macosx.CPrinterJob", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "######################################################################10.14.86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_HIHI!!86_H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################..." + "'", str2.equals("################################..."));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!24.80-b11", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".80-b114hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!2" + "'", str2.equals(".80-b114hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!2"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3, 97.0f, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("A!sun.lwawt.macosx.CPrinterJ", "! iH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi !      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi !      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI", "N", "#################################\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI" + "'", str3.equals("HIHI!!HII!!86_HIHI!!86_HIHI!!86_HIHI!!8HIHI!!HI"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 28, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("X86_64                                                                                                                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...                                                                                                                                                                                                 46_68X" + "'", str1.equals("...                                                                                                                                                                                                 46_68X"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("A!sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A!sun.lwawt.macosx.CPrinterJob is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CG", "hi !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CG" + "'", str2.equals("sun.awt.CG"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("eI!!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Java...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Java...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ion", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ion" + "'", str2.equals("ion"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM//USERS/SOHTTPEN//JAVA.ORACLE.COM/", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0.1#.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("##########", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("A!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJobA!sun.lwawt.macosx.CPrinterJob", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("enenenenenenenenenenenenenene...", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ene" + "'", str2.equals("ene"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(" X86_HIHI!!X86_HIHI!!X86_HIHI!!X", "es");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 0, (double) 10.0f, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        char[] charArray7 = new char[] { '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/#L#ibrary#/#J#ava#/#J#ava#V#irtual#M#achines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#C#ontents#/#H#ome#/#jre#/#lib#/#endorsed", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "51.051.051.051.051.051.051.051.051.0sun.lwawt.macosx.CPrinterJob51.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                HI !                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                HI !                                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sophie", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           sophie" + "'", str2.equals("                                                                                           sophie"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("######################################################################10.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h" + "'", str2.equals("_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...av...", "tem/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...av..." + "'", str3.equals("...av..."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("en/Users/http://j4v4.or4cle.com//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extens", "                                                                                           sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("enenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene\nenenenenenenenenenenenenenenenenen", "mixedmode", 68);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hiHI!!", (double) 7L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMIXED MODEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("!", strArray3, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", "x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!!x86_hihi!", 215);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/", strArray5, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "!" + "'", str6.equals("!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hia!" + "'", str8.equals("hia!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/" + "'", str14.equals("/Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com//Users/sohttpen//java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ene", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (short) 100, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("N", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N" + "'", str2.equals("N"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ".80-b114hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!!hihi!2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("-b15", "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                                                                                                                                                                       ", "/#L#IBRARY#/#J#AVA#/#J#AVA#V#IRTlat");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("jAVA pLATFORM api sPECIFICATION", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH! iH");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "java platform api specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/M1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h1.7.0_8010.14.86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_hihi!!86_h OS X/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("JAVA VIRTUAL MACHINE SPECIFICATION", (int) 'a', 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "/Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

