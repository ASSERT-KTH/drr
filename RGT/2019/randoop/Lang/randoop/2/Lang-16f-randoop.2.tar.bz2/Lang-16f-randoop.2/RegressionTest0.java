import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_ONE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0d + "'", double0.equals(1.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ZERO;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0.equals(0.0f));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_5;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_COUNTRY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "US" + "'", str0.equals("US"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("US", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] {};
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "US", charSequenceArray1);
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_4;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_1;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_INFO;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "mixed mode" + "'", str0.equals("mixed mode"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_UTIL_PREFS_PREFERENCES_FACTORY;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "US", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java Virtual Machine Specification" + "'", str0.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VENDOR_URL;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "http://java.oracle.com/" + "'", str0.equals("http://java.oracle.com/"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_IRIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ZERO;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0.equals((byte) 0));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0.equals((-1)));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: US is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_VISTA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_DIR;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("US", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("http://java.oracle.com/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cle.com/a.oravahttp://j" + "'", str2.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "", "", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specification" + "'", str4.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str0.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", "US", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "hi!");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_OS2;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (int) 'a', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ONE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0.equals(1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_FONTS;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_GRAPHICSENV;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str0.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_UNIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + (-1.0f) + "'", float0.equals((-1.0f)));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80-b15" + "'", str0.equals("1.7.0_80-b15"));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_2000;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ZERO;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 0 + "'", short0.equals((short) 0));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_SOLARIS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", "sun.awt.CGraphicsEnvironment", "Java HotSpot(TM) 64-Bit Server VM", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("cle.com/a.oravahttp://j", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cle.com/a.oravahttp://j" + "'", str2.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) (byte) 10, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.EMPTY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_HOME;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_ENCODING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "UTF-8" + "'", str0.equals("UTF-8"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "###################################", "hi!", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str4.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "cle.com/a.oravahttp://j", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "51.0" + "'", str0.equals("51.0"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ZERO;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0.equals(0L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 100, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mixed mode is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Java HotSpot(TM) 64-Bit Server VM", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("cle.com/a.oravahttp://j", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cle.com/a.oravahttp://j" + "'", str3.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "cle.com/a.oravahttp://j", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 1 + "'", short0.equals((short) 1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_COMPILER;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0.equals(1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_ME;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "US", "hi!", "", "", "hi!" };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray5, '4', (int) (byte) 100, 3);
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java HotSpot(TM) 64-Bit Server VM", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSp" + "'", str2.equals("Java HotSp"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", "Java Virtual Machine Specification", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.0", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_HP_UX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_3;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.AWT_TOOLKIT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str0.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.PATH_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + ":" + "'", str0.equals(":"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (int) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 127 + "'", int3 == 127);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_IO_TMPDIR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str0.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "Java HotSp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_EXT_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0.equals(1.0f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://j v .or cle.com/" + "'", str3.equals("http://j v .or cle.com/"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.LINE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "\n" + "'", str0.equals("\n"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", (int) (short) 100, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208" + "'", str3.equals("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 100, (long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Mac OS X" + "'", str0.equals("Mac OS X"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0.0f, (double) (short) 10, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "cle.com/a.oravahttp://j", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "mixed mode");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "\n", 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_LINUX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_LANGUAGE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "en" + "'", str0.equals("en"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-1L) + "'", long0.equals((-1L)));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_6;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208", 3, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208" + "'", str3.equals("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit", (int) 'a', "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("###################################", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_HEADLESS;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0.equals(0));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_ARCH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "x86_64" + "'", str0.equals("x86_64"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7d + "'", double1 == 1.7d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 127, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit                                                                                                    " + "'", str3.equals("sun.lwawt.macosx.LWCToolkit                                                                                                    "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.isJavaAwtHeadless();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) 127, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_FREE_BSD;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_NT;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 3, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "1.7", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, (-1), 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (int) (short) 1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/so..." + "'", str3.equals("/Users/so..."));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http://j v .or cle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_NET_BSD;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC_OSX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/so...", "Java HotSp", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSp.." + "'", str4.equals("Java HotSp.."));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_TIMEZONE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mixed mode", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_7;
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_95;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_98;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "51.0", "cle.com/a.oravahttp://j", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 10, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208" + "'", str1.equals("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://j v .or cle.com/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j v .or cle.com/" + "'", str2.equals("http://j v .or cle.com/"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208", "51.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jav51.0208" + "'", str3.equals("Jav51.0208"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "US", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lw wt.m cosx.LWCToolkit" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lw wt.m cosx.LWCToolkit"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_HOME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie" + "'", str0.equals("/Users/sophie"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (java.lang.CharSequence) ":", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208" + "'", charSequence2.equals("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_XP;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/so...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "cle.com/a.oravahttp://j", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_ENDORSED_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a" + "'", str2.equals("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_7;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (java.lang.CharSequence) "Java HotSp..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/so...", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", "http://j v .or cle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80" + "'", str0.equals("1.7.0_80"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSp..", "http://j v .or cle.com/", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSp.." + "'", str3.equals("Java HotSp.."));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/Users/so...", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/so..." + "'", charSequence2.equals("/Users/so..."));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("http://j v .or cle.com/", "Java HotSp..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j v .or cle.com/" + "'", str2.equals("http://j v .or cle.com/"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java HotSp", "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSp" + "'", str2.equals("Java HotSp"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-b11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (int) (byte) -1, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.LWCToolkit                                                                                                    M" + "'", str4.equals("sun.lwawt.macosx.LWCToolkit                                                                                                    M"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) 100L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit                                                                                                    M", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lw wt.m cosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaM" + "'", str3.equals("aaM"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "hi!", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "http://j v .or cle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSp", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSp" + "'", str2.equals("Java HotSp"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("US", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "U" + "'", str3.equals("U"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/so...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/so..." + "'", str2.equals("/Users/so..."));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ONE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0.equals((byte) 1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolkit                                                                                                    ", "hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", "/Users/so...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) -1 + "'", short0.equals((short) -1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "24.80-b11", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("US", (int) ' ', 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.String[] strArray6 = new java.lang.String[] { "mixed mode", "http://java.oracle.com/", "US", "hi!", "mixed mode", "hi!" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac OS X", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M c OS X" + "'", str3.equals("M c OS X"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("http://j v .or cle.com/", "a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j v .or cle.com/" + "'", str2.equals("http://j v .or cle.com/"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str0.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "en", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.LWCToolkit                                                                                                    M", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit                                                                                                    " + "'", str2.equals("sun.lwawt.macosx.LWCToolkit                                                                                                    "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("UTF-8", (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8" + "'", str3.equals("8"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cle.com/a.oravahttp://j", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "8", "/Users/so...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray17 = new java.lang.String[] { "mixed mode", "http://java.oracle.com/", "US", "hi!", "mixed mode", "hi!" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "cle.com/a.oravahttp://j", (java.lang.CharSequence[]) strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray5, strArray18);
        java.lang.Class<?> wildcardClass21 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str20.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int0 = org.apache.commons.lang3.StringUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("UTF-8", "", "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 10, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java HotSpot(TM) 64-Bit Server VM", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "/Users/sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!" + "'", str2.equals("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_AIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("U", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_SUN_OS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.LWCToolkit                                                                                                    M");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (java.lang.CharSequence) "Jav51.0208");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java HotSp..", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "24.80-b11", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("cle.com/a.oravahttp://j", (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        java.lang.Class<?> wildcardClass1 = numberUtils0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("x86_64", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cle.com/a.oravahttp://j" + "'", str1.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_VERSION;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "10.14.3" + "'", str0.equals("10.14.3"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3, 2.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaM", (int) (short) 10, "class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [Iclass [I");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaMclass [" + "'", str3.equals("aaMclass ["));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", "hi", "###################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str3.equals("/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacOSX" + "'", str2.equals("MacOSX"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java(TM) SE Runtime Environment", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(12.0d, (double) 32, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "MacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!" + "'", str2.equals("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a" + "'", str2.equals("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "en", 100, 12);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: : is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/so...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/so...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("en", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkit                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("java(tm) se runtime environment", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("MacOSX", (int) (byte) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX" + "'", str3.equals("MacOSX"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "51.0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) '#', 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 214 + "'", int2 == 214);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_PRINTERJOB;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str0.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Java HotSp");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, 35L, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 0, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str4.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSp", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.LWCToolkit", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("cle.com/a.oravahttp://j", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.String[] strArray7 = new java.lang.String[] { "mixed mode", "http://java.oracle.com/", "US", "hi!", "mixed mode", "hi!" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray8, strArray11);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "x86_64" + "'", str12.equals("x86_64"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.5", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "1.7.0_80-b15", "51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, 0.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!" + "'", str2.equals("mixed mode4http://java.oracle.com/4US4hi!4mixed mode4hi!"));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_PATH;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java HotSp..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "http://j v .or cle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java Platform API Specification" + "'", str0.equals("Java Platform API Specification"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    ", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "MacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_OPEN_BSD;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit                                                                                                    M", '4');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "1.7.0_80", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java HotSp", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java HotSp..", 2, 127);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSp.." + "'", str3.equals("Java HotSp.."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", 1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java HotSp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSp" + "'", str1.equals("java HotSp"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("mixed mode", "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mix" + "'", str2.equals("mix"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", (int) (short) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208 Machine Virtual a", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208MachineVirtuala" + "'", str2.equals("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208MachineVirtuala"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("UTF-8", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(12, 0, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mixed mode", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 1, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J" + "'", str3.equals("J"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("a Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208", "Java HotSp..", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1200 + "'", int1 == 1200);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208MachineVirtuala");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SPECIFICATION/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208MACHINEVIRTUALA" + "'", str1.equals("SPECIFICATION/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208MACHINEVIRTUALA"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("cle.com/a.oravahttp://j", "java(tm) se runtime environment", "1.7.0_80", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cle.com/a.oravahttp://j" + "'", str4.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.LWCToolkit                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit                                                                                                    " + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit                                                                                                    "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("http://java.oracle.com/", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", 1, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                                                                    M", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/so...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/so..." + "'", str2.equals("/Users/so..."));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208MachineVirtuala");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sPECIFICATION/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208mACHINEvIRTUALA" + "'", str1.equals("sPECIFICATION/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208mACHINEvIRTUALA"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826Java Virtual Mac###################################ne Specification/Users/sop###################################e/Documents/defects4j/tmp/run_randoop.pl_94192_1560208826");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java(TM) SE Runtime Environment", (-1), 214);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sPECIFICATION/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208mACHINEvIRTUALA", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sPECIFICATION/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208mACHINEvIRTUALA" + "'", str2.equals("sPECIFICATION/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94192_1560208mACHINEvIRTUALA"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.lwctoolkit" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime Environment", 127, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################Java(TM) SE Runtime Environment################################################" + "'", str3.equals("################################################Java(TM) SE Runtime Environment################################################"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-1.0d) + "'", double0.equals((-1.0d)));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/" + "'", str0.equals("/"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [Iclass [I");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bsun.lw wt.m cosx.LWCToolkit", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208" + "'", str1.equals("Java Virtual Machine Specification/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94192_1560208"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Sun.lwawt.macosx.LWCToolkit                                                                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java HotSp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pStoH avaJ" + "'", str1.equals("pStoH avaJ"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "US", (java.lang.CharSequence) "hi", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [Iclass [I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class[Ljava.lang.String;class[Ljava.lang.String;class[Iclass[Iclass[I" + "'", str1.equals("class[Ljava.lang.String;class[Ljava.lang.String;class[Iclass[Iclass[I"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSp..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, (float) 0L, (float) 127);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("java HotSp", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j" + "'", str2.equals("j"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "aaM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        short[][] shortArray0 = new short[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }
}

