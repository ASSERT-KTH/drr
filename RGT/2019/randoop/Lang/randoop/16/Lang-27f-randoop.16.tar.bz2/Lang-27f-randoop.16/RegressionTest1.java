import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, 52L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", charSequence2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(".7.0_80-b15", 9, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "15" + "'", str3.equals("15"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(18, 9, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 18, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("x86_64", 0, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x8" + "'", str3.equals("x8"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 179, (long) 2, (long) 179);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("44444444Oracle4Corporation444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str1.equals("brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                   \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(".7.0_80-b15", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("!", "                                                                                                            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                             jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("h!", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h!" + "'", str2.equals("h!"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(":", "ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specification", "444444444444444444444444444444444444444444444444Oracle Corporation##################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 178 + "'", int2 == 178);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int[] intArray2 = new int[] { 0, (byte) 1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.Class<?> wildcardClass4 = intArray2.getClass();
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################h!#################################################", "Oracle Corporation", (int) (byte) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#################################################h!#################################################" + "'", str6.equals("#################################################h!#################################################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "         :");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("n", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle4Corporation" + "'", str8.equals("Oracle4Corporation"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation##################################", strArray2, strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle4Corporation" + "'", str7.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation##################################" + "'", str8.equals("Oracle Corporation##################################"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("!", "                                                                                                            Java Virtual Machine Specification", "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE CORPORATION", 31, "                                                                                                   \n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION             " + "'", str3.equals("ORACLE CORPORATION             "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("US", "ORACLE CORPORATION             ", "15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444444444444444444444444444444Oracle Corporation##################################", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444Oracle Corporation##################################" + "'", str2.equals("444444444444444444444444444444444444444444444444Oracle Corporation##################################"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("US", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  US" + "'", str2.equals("                                                                                                  US"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(":", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              :" + "'", str2.equals("                              :"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                            Java Virtual Machine Specif", "444444444444444444444444444444444444444444444444Oracle Corporation##################################", "/Users/sophie");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-b11", "         :", "/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                            Java Virtual Machine Specif", "/", "/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                            Java Virtual Machine Specif" + "'", str3.equals("                                                                                                            Java Virtual Machine Specif"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE CORPORATION", 3, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mac OS X", "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie", (int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie" + "'", str4.equals("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API Specification", "Oracle Corporation", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 142, (long) (short) 10, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 142L + "'", long3 == 142L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "ORACLE CORPORATION             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "Ja", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/" + "'", str6.equals("/"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/", "/", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(32L, (-1L), (long) 170);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("         :", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "10.14.3", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("!", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Oracle4Corporation" + "'", str9.equals("Oracle4Corporation"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(142, (int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 142 + "'", int3 == 142);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie51.0sophie51.0sophie", 31, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####sophie51.0sophie51.0sophie" + "'", str3.equals("#####sophie51.0sophie51.0sophie"));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_DIR;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ":", (java.lang.CharSequence) "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie" + "'", str2.equals("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("15", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 178, (long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("#####sophie51.0sophie51.0sophie", 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 31, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/", (int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLE CORPORATION", (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(".7.0_80-b15", "                                                                                                            Java Virtual Machine Specif", (int) 'a');
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_LANGUAGE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "en" + "'", str0.equals("en"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("OracleCorporation", "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str1.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("1.7", "#####sophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "                             jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                             jar" + "'", str1.equals("                             jar"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oracle Corporation#################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcarO" + "'", str1.equals("noitaroproCelcarO"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                 1.7.0_80-b15                                                                 ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 1.7.0_80-b15                                                                 " + "'", str2.equals("                                                                 1.7.0_80-b15                                                                 "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                              :", "ORA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              :" + "'", str2.equals("                              :"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str1.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "#####sophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_PRINTERJOB;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str0.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ORACLE CORPORATION             ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("h!", "                                                                                                            Java Virtual Machine Specification", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                   \n", "ocuments/defects4j/framework/lib/test_generation/...", (int) '4');
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80\n1.7.0_80-", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80\n1.7.0_80-" + "'", str2.equals("1.7.0_80\n1.7.0_80-"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle4Corporation", (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "mixed mode", "brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(".7.0_80-b15", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/", (int) (byte) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 142, (float) 3, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 142.0f + "'", float3 == 142.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_GRAPHICSENV;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str0.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("h!", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h!" + "'", str2.equals("h!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1.7f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        char[] charArray8 = new char[] { '#', '4', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle4Corporation", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophie", "         :", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation#################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Virtual Machine Specification", 30);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation#################" + "'", str4.equals("Oracle Corporation#################"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Oracle4Corporation", "Oracle Corporation#################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("x8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification " + "'", str3.equals("Java Platform API Specification "));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                             jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Virtual Machine Specification", "1.7", 178);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hi!", "ORA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("         :", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "Ja", (int) (byte) 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", "brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (int) (short) 100);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x8", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                 1.7.0_80-b15                                                                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 1.7.0_80-b15                                                                 " + "'", str2.equals("                                                                 1.7.0_80-b15                                                                 "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                              :", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                   \n", "         :");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   \n" + "'", str2.equals("                                                                                                   \n"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Java Platform API Specification ", "Java Platform API Specification ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) (-1L), (float) 30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "1.7.0_80\n1.7.0_80-", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ORACLE CORPORATION", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("OracleCorporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCorporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str1.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mode", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#####sophie51.0sophie51.0sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####sophie51.0sophie51.0sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                 1.7.0_80-b15                                                                 " + "'", str1.equals("                                                                 1.7.0_80-b15                                                                 "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("OracleCorporation", "                             jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 0, "24.80-B11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("15", "!", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                                                                                                   \n", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macosx.LWCToolkit", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '#', 142);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.LWCToolkit4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("sun.lwawt.macosx.LWCToolkit4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80", 31, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                  US", (int) (byte) -1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specification", "                                                                                                            Java Virtual Machine Specif", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("#####sophie51.0sophie51.0sophie", "24.80-B11", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle Corporation##################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("h!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h!" + "'", str1.equals("h!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 2, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/" + "'", str2.equals("/Users/sophie/Users/sophie/Users/Java Virtual Machine Specification/Users/sophie/Users/sophie/Users/"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444Oracle Corporation##################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("mixed mode", "                             jar", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.LWCToolkit4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                                                 1.7.0_80-b15                                                                 ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52L, (float) (-1), (float) 30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#################################################h!#################################################", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################h!#################################################" + "'", str2.equals("#################################################h!#################################################"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                             jar", "Mac OS X", "x8", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                             jar" + "'", str4.equals("                             jar"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Oracle4Corporation", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_7;
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ocuments/defects4j/framework/lib/test_generation/..." + "'", str1.equals("ocuments/defects4j/framework/lib/test_generation/..."));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(142, (int) 'a', 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 142 + "'", int3 == 142);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("         :", "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION", "Oracle Corporation##################################");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                            Java Virtual Machine Specif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                            Java Virtual Machine Specif\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("java(tm) se runtime environment", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x8", "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x8" + "'", str2.equals("x8"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS " + "'", str1.equals("Mac OS "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporation##################################", 178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle#Corporation" + "'", str4.equals("Oracle#Corporation"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "ORACLE CORPORATION", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("X86_64", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 178, (double) 30.0f, (double) 178);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 178.0d + "'", double3 == 178.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        char[] charArray8 = new char[] { '#', '4', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), (double) (byte) 0, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaa" + "'", str3.equals("sun.lwawt.macosx.CPrinterJobaaaaaaa"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.CPrinterJobaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaa" + "'", str1.equals("sun.lwawt.macosx.CPrinterJobaaaaaaa"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                  US", "15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                             jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Mac OS ", "n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Ja", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 31, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) 3, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ORACLE CORPORATION             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "Ja", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en", "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Oracle#Corporation", "jar", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-b15" + "'", str1.equals(".7.0_80-b15"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 31, (long) 52, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(31, 170, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sophie51.0sophie51.0sophie", "x86_64", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("24.80-b11", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", 18, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporation#################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation#################" + "'", str1.equals("OracleCorporation#################"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sophie51.0sophie51.0sophie", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie51.0sophie51.0sophie" + "'", str2.equals("sophie51.0sophie51.0sophie"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Platform API Specification", "15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                            Java Virtual Machine Specification", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                            Java Virtual Machine Specification" + "'", str2.equals("                                                                                                            Java Virtual Machine Specification"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "                                                                                                            Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(":", "                             jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                   \n", "EN", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("java(tm) se runtime environment", "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80\n1.7.0_80-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80\n1.7.0_80-" + "'", str1.equals("1.7.0_80\n1.7.0_80-"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("OracleCorporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCorporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("jAVA pLATFORM api sPECIFICATION", 52, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie" + "'", str1.equals("sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "                             jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#", (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#####sophie51.0sophie51.0sophie", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(":", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi!", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIE", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE" + "'", str3.equals("/USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(170, (int) (byte) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporation", "Java(TM) SE Runtime Environment", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "jar", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 170, "#####sophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5" + "'", str3.equals("Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle4Corporation", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle4Corporation" + "'", str2.equals("Oracle4Corporation"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 'a', (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 179, (double) (byte) 1, (double) 2L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("x8", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x8" + "'", str2.equals("x8"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("OracleCorporation#################", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation#################" + "'", str2.equals("OracleCorporation#################"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                                                            Java Virtual Machine Specif", "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OracleCorporation#################", 3, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation#################" + "'", str3.equals("OracleCorporation#################"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "java(tm) se runtime environment", 18, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ", (java.lang.CharSequence) "Ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "Oracle4Corporation", 178);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                 1.7.0_80-b15                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ORA", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORA" + "'", str2.equals("ORA"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(".7.0_80-b15", "Mac OS X", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sophie", "                                                                                                            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("n", ":", 142);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n" + "'", str3.equals("n"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "ORA");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) 'a', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("OracleCorporation", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("EN", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EN" + "'", str3.equals("EN"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444Oracle4Corporation444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2522 + "'", int1 == 2522);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        short[] shortArray6 = new short[] { (byte) 1, (byte) 0, (short) 1, (short) 10, (short) 0, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444Oracle4Corporation444444444", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("noitaroproCelcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproCelcarO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 142, (long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("mixed mode", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                  US", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS ", (int) '4', 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS " + "'", str3.equals("Mac OS "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", "#####sophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle Corporation##################################", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                             jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(142L, 0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 142L + "'", long3 == 142L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation##################################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                 1.7.0_80-b15                                                                 ", "ORA", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 97.0f, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Oracle4Corporation", "Java HotSpot(TM) 64-Bit Server VM", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("EN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EN\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "Ja", (int) (byte) 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJobaaaaaaa", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/" + "'", str6.equals("/"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaa" + "'", str8.equals("sun.lwawt.macosx.CPrinterJobaaaaaaa"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 31, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification ", "444444444444444444444444444444444444444444444444Oracle Corporation##################################", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Oracle#Corporation", "1.7.0_80\n1.7.0_80-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.CPrinterJobaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 3, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "1.7.0_80-b15", (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "/");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/USERS/SOPHIE", strArray4, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/USERS/SOPHIE" + "'", str8.equals("/USERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("UTF-8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie", "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str3.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("EN", 178);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", 5, "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("en");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("h!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.CPrinterJobaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaa" + "'", str2.equals("sun.lwawt.macosx.CPrinterJobaaaaaaa"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("h!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 15 + "'", byte1 == (byte) 15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97L, (float) (short) 10, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("15", "jAVA pLATFORM api sPECIFICATION", "Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "!", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "java(tm) se runtime environment", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkit", (int) (short) -1, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444Oracle4Corporation444444444", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("ORA", "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("jar", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA pLATFORM api sPECIFICATION", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#####sophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####sophie51.0sophie51.0sophie" + "'", str1.equals("#####sophie51.0sophie51.0sophie"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 2522, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2522 + "'", int3 == 2522);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJobaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle#Corporatio" + "'", str1.equals("Oracle#Corporatio"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("#####sophie51.0sophie51.0sophie", "Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5", "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####sophie51.0sophie51.0sophie" + "'", str3.equals("#####sophie51.0sophie51.0sophie"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                            Java Virtual Machine Specif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                                                             Java Virtual Machine Specif is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("44444444Oracle4Corporation444444444", "", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", 30, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation############" + "'", str3.equals("Oracle Corporation############"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("http://java.oracle.com/", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 170);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("\n", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("US", "#", "Oracle Corporation##################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                 1.7.0_80-b15                                                                 ", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 1.7.0_80-b15                                                                 " + "'", str2.equals("                                                                 1.7.0_80-b15                                                                 "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                 1.7.0_80-b15                                                                 ", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        float[] floatArray1 = new float[] { '#' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 35.0f + "'", float5 == 35.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str2.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa", "                              :", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.CPrinterJobaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaa" + "'", str1.equals("sun.lwawt.macosx.CPrinterJobaaaaaaa"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                            Java Virtual Machine Specif", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ORACLE CORPORATION", "                                                                                                            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                              :");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("ORA", "", "OracleCorporation#################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5" + "'", str1.equals("Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Oracle#Corporatio", "Java Virtual Machine Specification#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie5", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "x8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80-b15", 9, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64", "x8", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                             jar", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             jar" + "'", str2.equals("                             jar"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa", "X86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Oracle Corporation#################", "sophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444Oracle4Corporation444444444", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               44444444Oracle4Corporation444444444                               " + "'", str2.equals("                               44444444Oracle4Corporation444444444                               "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "10.14.3");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ocuments/defects4j/framework/lib/test_generation/...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/..." + "'", str2.equals("ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/..."));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Java Virtual Machine Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u" + "'", str3.equals("u"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 15, (short) (byte) 15, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str1.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("44444444Oracle4Corporation444444444", (int) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#################################################h!#################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Ja", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("noitaroproCelcarO", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE", "", 9, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE" + "'", str4.equals("/USERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                             jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("15", "jAVA pLATFORM api sPECIFICATION", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "15" + "'", str3.equals("15"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironment", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Oracle4Corporation", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80\n1.7.0_80-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x8" + "'", str1.equals("x8"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", charSequence2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle4Corporation" + "'", str1.equals("Oracle4Corporation"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("15", "         :", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, 35.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\n", "sun.awt.CGraphicsEnvironment", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("h!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Oracle Corporation############", "US", 0, 179);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US" + "'", str4.equals("US"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sophie51.0sophie51.0sophie", "1.7.0_80\n1.7.0_80-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie51.0sophie51.0sophie" + "'", str2.equals("sophie51.0sophie51.0sophie"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }
}

