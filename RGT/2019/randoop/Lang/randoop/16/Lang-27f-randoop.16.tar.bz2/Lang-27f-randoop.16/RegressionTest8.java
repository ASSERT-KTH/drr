import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                 1.7.0_80-b15                                                                 ", "HMsophie51.0soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HMsophie51.0soph" + "'", str2.equals("HMsophie51.0soph"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", ":", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                             j  ", "aAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aro", (int) (short) 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aro            " + "'", str2.equals("aro            "));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                              :", "/LibrJAVA PLATFORM API SPECIFICATION ", 30);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "                                         #ORACLE#CORPORATION#                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray11 = new char[] { '#', '4', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle4Corporation", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa", "OracleCorporation#################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "/Users/sophie", 16);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("racle#Corporatio", strArray5);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray5, strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str8.equals("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "...             ", (java.lang.CharSequence) "                                                                                          mixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "aaracle.com/aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaracle.com/aaa" + "'", str1.equals("Aaracle.com/aaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635", (int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", 49, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                              :", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              :" + "'", str2.equals("                              :"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1", "java platform api specification ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#####sophie51.0sophie51.0sophie", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie" + "'", str2.equals("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARHOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR!#################################################" + "'", str1.equals("#################################################OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARHOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR!#################################################"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "                                                                                                                                                                                                                                                   ORACLE CORPORATION                                                                                                                                                                                                                                                                ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrecorporation" + "'", str1.equals("oracle/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrecorporation"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("java:.", "En");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("OracleCorporation", "O#.15 i##o#####neeeeeeeeeeee.15ei##o#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("oRAoracle4Corporationnnnnnnnnnnnnnn", "java(tm) se runtime environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaracle.com/aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaracle.com/aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophi...", "                                                                                          mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                  1.7.0_80-b15", "hMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  1.7.0_80-b15" + "'", str2.equals("                  1.7.0_80-b15"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JavaMac OS Xr VM", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JvMc OS Xr VM" + "'", str2.equals("JvMc OS Xr VM"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...             defects4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...             defects4" + "'", str2.equals("...             defects4"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "NOITAROPROcELCARo", (java.lang.CharSequence) "brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sophie", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("             X SO caM              ", "S )Bt#C- p- )ti");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(".7.0_80-b15", "USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 15, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie51.0sophie51.0sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie51.0sophie51.0soph" + "'", str1.equals("sophie51.0sophie51.0soph"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-B11", "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                             jar", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", strArray4, strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str6.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                             j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str7.equals("                             j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635", 23, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/defects4j/tmp/run_randoop.pl" + "'", str3.equals("/defects4j/tmp/run_randoop.pl"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaau", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sophie", "noitaroproC4elcaro", (int) (short) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("       1       ", "USERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("hMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie!", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, 23.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.0d + "'", double3 == 23.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaary/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "nu.ntnlpmutDlPuaentsufuen4xtePpt.a.asllppa365622635te.guetannun:tUnu.ntnlpmutDlPuaentsufuen4xtf.Puwl.tam.teuneguau.emlatguau.emlat.asllp-..uaex.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaary/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaary/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        double[] doubleArray6 = new double[] { 'a', 100L, 100.0d, 10.0d, 35.0f, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) -1, (byte) 10, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "/Users/sophie", 16);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("...             defects4", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Platfm API Scfcatn" + "'", str5.equals("Java Platfm API Scfcatn"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification                  1.7.0_80-b15Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle4Corporation" + "'", str6.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "OracleCorporation" + "'", str8.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ORAoracle4Corporationnnnnnnnnnnnnnn", 208, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Ocor##lcplc#pl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ocor##lcplc#pl" + "'", str1.equals("Ocor##lcplc#pl"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-b11", 135);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                  US", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  US" + "'", str2.equals("                                                                                                  US"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie51.0sophie51.0sophie", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION", "Oracle Corporation##################################");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray6, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("44444444Oracle4Corporation444444444", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie" + "'", str11.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "44444444Oracle4Corporation444444444" + "'", str12.equals("44444444Oracle4Corporation444444444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "racle.com/", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("HMsophie51.0soph", 69);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sophie", "USERSSOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Ja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("oitaroproC#elcar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "http://java.oracle.com/", (int) (byte) 100, 300);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vmhttp://java.oracle.com/" + "'", str4.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vmhttp://java.oracle.com/"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAA/USERS/SOPHIEACLECORPORATION#################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "ocuments Cdefects4j Cframework Clocuments Cdefects4/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi!", "", (-1), 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, (float) 16, 18.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 15, (byte) 15, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle#################################################h!#################################################Corporatio", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("u", ".7.0_80-B15", "oracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u" + "'", str3.equals("u"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensio", "                  1.7.0_80-b15", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hMsophie51.0sop                                                                 1.7.0_80-b15                                                                             1.7.0_80-b15             ie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("15", '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.concatWith("java(tm) se runtime environment", (java.lang.Object[]) strArray13);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".7.0_80-b15", "sun.lwawt.macosx.LWCToolkit", (int) (short) 100);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS ", strArray13, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray18);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.startsWithAny("                                                                                                                                                                                                                                                                                                            ", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle4Corporation" + "'", str7.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "15" + "'", str14.equals("15"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Mac OS " + "'", str19.equals("Mac OS "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                            Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int[] intArray6 = new int[] { 517, 10, 300, 10, 35, 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 517 + "'", int7 == 517);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 517 + "'", int8 == 517);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 517 + "'", int9 == 517);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects", "aro            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aro            " + "'", str2.equals("aro            "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 0, (double) 208L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(49, 32, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("aAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/", "Sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("racle.com", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) '4', (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", 97, "jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarj" + "'", str3.equals("Oracle Corporationjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarjarj"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("rjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarrarjarra", "Desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (byte) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "         Mac OS", (java.lang.CharSequence) "44Java Virtual Machine Specif44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Cd...! Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j hocuments");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("15", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("OracleCorporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(2522.0f, 32.0f, (float) 69);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("poration#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "poration#" + "'", str1.equals("poration#"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("jAVA hOTsPOT(tm) 64-bIT sERVE...44444444444444444444444444444444444444444444444444444444444444444444", "USERSSOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cd...!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cd...!" + "'", str2.equals("hocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cd...!"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sophie51.0sophie51.0soph", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hiesophie51.0sophie51.0sophiesophie51.0sophie51.0sop", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiesophie51.0sophie51.0sophiesophie51.0sophie51.0sop" + "'", str3.equals("hiesophie51.0sophie51.0sophiesophie51.0sophie51.0sop"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("44Java Virtual Machine Specif44", "1.7.0_80\n1.7.0_80-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("X SO caM", "aaaaaaaaaaaaaaaa", "", 54);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X SO caM" + "'", str4.equals("X SO caM"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3L, (float) (byte) 1, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("edom dexim                                                                                          ", "51.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 300, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sU/", "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS X", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JavaMac OS Xr VM", (java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(":", "jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("oracle4Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracle4Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        char[] charArray10 = new char[] { '#', '4', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#####sophie51.0sophie51.0sophie", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_64", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 15, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 15 + "'", byte3 == (byte) 15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Oracle Corporation############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 509);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        short[] shortArray2 = new short[] { (byte) 0, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/", "S )Bt#C- p- )ti");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation############cle#Corporatio", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaary/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("defects4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "defects4" + "'", str2.equals("defects4"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                /LibrJAVA PLATFORM API SPECIFICATION", "#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JAVA(TM) SE RUNTIME ENVIRONMENT", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  en                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("         Mac OS", 24, "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n         Mac OS" + "'", str3.equals("\n\n\n\n\n\n\n\n\n         Mac OS"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sophie5suesophie5suesophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie5suesophie5suesophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "JavaMac OS Xr VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sophie51.0sophie51.0sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie51.0sophie51.0sophi" + "'", str1.equals("sophie51.0sophie51.0sophi"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jar");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, (double) (byte) 15, (double) 142.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 142.0d + "'", double3 == 142.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("#################################################h!#################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#################################################h!#################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        double[] doubleArray5 = new double[] { (-1L), 0L, 10.0d, ' ', 2 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.Class<?> wildcardClass8 = doubleArray5.getClass();
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "X8");
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "oracle/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrecorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                          x86_64", "##########################JavaMac OS Xr VM###########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("      US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("               MNOITAROPROcELCARoOSX                ", "jAVA hOTsPOT(tm) 64-bIT sERVE...44444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              " + "'", str1.equals("                              "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitaroproCelcarO", 441, "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua" + "'", str3.equals("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("15", "Java HotSpot(TM) 64-Bit Server VM", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "UTF-8", (int) (byte) 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) 32L, (float) 142);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 142.0f + "'", float3 == 142.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("\n\n\n\n\n\n\n\n\n         Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n\n\n\n\n\n\n\n\n         Mac OS" + "'", str1.equals("\n\n\n\n\n\n\n\n\n         Mac OS"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("u", 300, "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str3.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("        Oracle4Corporation      US", "                                Oracle#Corporatio", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        Oracle4Corporation      US" + "'", str3.equals("        Oracle4Corporation      US"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Oracless                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  USCorporation", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracless                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  USCorporation" + "'", str2.equals("Oracless                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  USCorporation"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hMsophie51.0soph", (java.lang.CharSequence) "/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Sophie", 0, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Sophie" + "'", str4.equals("Sophie"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7.0X80-", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0X80-" + "'", str2.equals("1.7.0X80-"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "", "sun.lwawt.macosx.CPrinterJobaaaaaaa", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        char[] charArray11 = new char[] { '#', '4', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "h !", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("24.80-B11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                                                                                                                                                                                /LibrJAVA PLATFORM API SPECIFICATION", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\n        ", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n        " + "'", str3.equals("\n        "));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ja", 8, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ja######" + "'", str3.equals("ja######"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                            ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cd...!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cd...!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        char[] charArray10 = new char[] { '#', '4', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle4Corporation", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation############cle#Corporatio", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("Java Virtual Machine Specification", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie51.0sophie51.0sophie", "#################################################h!#################################################", (int) (short) 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("JAVA PLATFORM API SPECIFICATION", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "Ja", (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("JavaMac OS Xr VM", strArray5, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sophie51.0sophie51.0sophie" + "'", str6.equals("sophie51.0sophie51.0sophie"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JavaMac OS Xr VM" + "'", str11.equals("JavaMac OS Xr VM"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JAVA(TM) SE RUNTIME ENVIRONMENT", 509);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int[] intArray2 = new int[] { 0, (byte) 1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ihpos0.15eihpos0.15eihpos");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ihpos0.15eihpos0.15eihpos" + "'", str3.equals("ihpos0.15eihpos0.15eihpos"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...             ", 5, "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...             " + "'", str3.equals("...             "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "ramework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/AAAAAAAAAAAAAAAAAAAAAAeihpo", (java.lang.CharSequence) "USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 167 + "'", int2 == 167);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        char[] charArray10 = new char[] { '#', '4', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification ", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "O", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "11B-08.42", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Ja", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCorporation#################", "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 300, (long) 167);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cd...!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sophie5suesophie5suesophi", "java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("51.0", strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                            Java Virtual Machine Specif", strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.concatWith("aaaaaaaaaaaaaaaaaaaaaaEIHPOS/SRESU/", (java.lang.Object[]) strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Oracle4Corporation" + "'", str14.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "OracleCorporation" + "'", str16.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "OracleaaaaaaaaaaaaaaaaaaaaaaEIHPOS/SRESU/Corporation" + "'", str17.equals("OracleaaaaaaaaaaaaaaaaaaaaaaEIHPOS/SRESU/Corporation"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                             j");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("n", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Or/Users/sophieporation", "J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("s                                              h !s                                              ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaary/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("Java Virtual Machine Specif", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("O#.15 i##o#####neeeeeeeeeeee.15ei##o#####", 23, 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ss                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:" + "'", str1.equals("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ORAoracle4Corporationnnnnnnnnnnnnnn", 1, 208);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RAoracle4Corporationnnnnnnnnnnnnnn" + "'", str3.equals("RAoracle4Corporationnnnnnnnnnnnnnn"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaEIHPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION             ", "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0uMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0", 517);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JAVA(TM) SE RUNTIME ENVIRONMENT", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str3.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specif", 5, "ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specif" + "'", str3.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863", "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("444444444444444444444444444444444444444444444444craelerCorporation##################################rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("USERSDEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USERSDEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str1.equals("USERSDEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) 25, (long) 208);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 208L + "'", long3 == 208L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                Oracle#Corporatio", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("       oraclecorporation       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       ORACLECORPORATION       " + "'", str1.equals("       ORACLECORPORATION       "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("ORA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X8", 0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSERSSOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X8" + "'", str3.equals("X8"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 18, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 170, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ...", "AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oitaroproC#elcar", 135, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########################################################oitaroproC#elcar############################################################" + "'", str3.equals("###########################################################oitaroproC#elcar############################################################"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("JvMc OS Xr VM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSERSSOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(142, 509, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                             ...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/USERS/SOPHIEACLECORPORATION#################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", "#####sophie51.0sophie51.0sophie", (-1));
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                                                   \n", 49, 34);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("\n\n\n\n\n\n\n\n\n         Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aro", "          Java(TM) SE Runtime Environment           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          Java(TM) SE Runtime Environment           " + "'", str2.equals("          Java(TM) SE Runtime Environment           "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun....", "Oracle#################################################h!#################################################Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun...." + "'", str2.equals("sun...."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporation##################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/librjava(tm) se runtime environmentvirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS X/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPECIFICsun.lwawt.macosx.CPrinterJobaaaaaaa/LibrJAVA PLATFORM API SPECIFIC/LibrJAVA PLATFORM API SPEC", 2525);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Cd...! Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j hocuments", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444tiklooTCWL.xsocam.twawl.nus", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 49, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...va..." + "'", str3.equals("...va..."));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(8L, 1L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/", "###########################################################oitaroproC#elcar############################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 30, 0);
        java.lang.Class<?> wildcardClass7 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        float[] floatArray2 = new float[] { 52.0f, 97L };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oRAoracle4Corporationnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("#################################################!h#################################################", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "", 97, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("       1       ", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("#################################################OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARHOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR!#################################################", "hMsophie51.0sop                                                                 1.7.0_80-b15                                                                             1.7.0_80-b15             ie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARHOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR!#################################################" + "'", str2.equals("#################################################OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARHOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR!#################################################"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hMsophie51.0sop                                                                 1.7.0_80-b15                                                                             1.7.0_80-b15             ie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0", "ophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hMsophie51.0sop                                                                 1.7.0_80-b15                                                                             1.7.0_80-b15             ie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0" + "'", str2.equals("hMsophie51.0sop                                                                 1.7.0_80-b15                                                                             1.7.0_80-b15             ie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/defects4j/tmp/run_randoop.pl", (java.lang.CharSequence) "eihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("usJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausJrs/sophiJ/DocumJats/dJfJcts4j/tmp/rua_raadoop.pl_10306_1560228635/targJt/classJs:/UsJrs/sophiJ/DocumJats/dJfJcts4j/framJwork/lib/tJst_gJaJratioa/gJaJratioa/raadoop-currJat.jar", 21);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie", 517);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie" + "'", str2.equals("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 15, (byte) 15, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSERSSOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSERSSOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          Java(TM) SE Runtime Environment           ", "MacOSX", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 15, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 15 + "'", short3 == (short) 15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 3);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635", 0, 2525);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                  1.7.0_80-b15", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Oracle#Corporatio", "sophie5suesophie5suesophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#Corporatio" + "'", str2.equals("Oracle#Corporatio"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 1, (byte) 10, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("ORAoracle4Corporation", "\n        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORAoracle4Corporation" + "'", str2.equals("ORAoracle4Corporation"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects" + "'", str1.equals("j/framework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 30L, (double) (short) -1, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Ocor##lcplc#pl", "ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle#################################################h!#################################################Corporation", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#################################################h!#################################################Corporation" + "'", str2.equals("Oracle#################################################h!#################################################Corporation"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Xohhhh", (int) (byte) 15, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Xohhhh#########" + "'", str3.equals("Xohhhh#########"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("h !       h !       h !       h", "                                             ...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie", "Oracle Corporation############cle#Corporatio                                                                                         US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US", (int) (short) 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("h !       ", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                Oracle#Corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", 509, "                                         #ORACLE#CORPORATION#                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                         #ORACLE#CORPORATION#                                                                                   #ORACLE#CORPORATION#                                                                                   #/Users/sophie                                         #ORACLE#CORPORATION#                                                                                   #ORACLE#CORPORATION#                                                                                   #" + "'", str3.equals("                                         #ORACLE#CORPORATION#                                                                                   #ORACLE#CORPORATION#                                                                                   #/Users/sophie                                         #ORACLE#CORPORATION#                                                                                   #ORACLE#CORPORATION#                                                                                   #"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("         Mac OS", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation##################################", "                                                                 1.7.0_80-b15                                                                 ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation#################", strArray2, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("...");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "OracleCorporation#################" + "'", str6.equals("OracleCorporation#################"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie", "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ora                                                                                              ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Orcle Corportion############cle#Corportio", "Xohhhh");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportion############cle#Corportio" + "'", str2.equals("Orcle Corportion############cle#Corportio"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "Oracle Corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("/USERS/SOPHIEacleCorporation...", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "h/USERS/SOPHIEacleCorporation...!" + "'", str4.equals("h/USERS/SOPHIEacleCorporation...!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", "                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str2.equals("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("jAVA pLATFORM api sPECIFICATION###############################################################################################################", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVA pLATFORM api sPECIFICATION###############################################################################################################" + "'", str2.equals("AVA pLATFORM api sPECIFICATION###############################################################################################################"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("defects4", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                                                                                                                                                                                   ORACLE CORPORATION                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "jar", (java.lang.CharSequence) "/USERS/SOPHIEoproC#elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("X8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x8" + "'", str1.equals("x8"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                            Java Virtual Machine Specification", 100, 4583);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        Java Virtual Machine Specification" + "'", str3.equals("        Java Virtual Machine Specification"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                 1.7.0_80-b15                                                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ORAoracle4Corporationnnnnnnnnnnnnnn", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation##################################", strArray3, strArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny("sophie", strArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle4Corporation" + "'", str8.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Oracle Corporation##################################" + "'", str9.equals("Oracle Corporation##################################"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hiesophie51.0sophie51.0sophiesophie51.0sophie51.0sop");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                                                                          ", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########################################################################################################################################################################" + "'", str3.equals("##########################################################################################################################################################################"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                               44444444Oracle4Corporation444444444                               ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("      ", "ramework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac OS X", "", 208);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mac OS X" + "'", str4.equals("mac OS X"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                             ...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "racle.com");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/LibrJAVA PLATFORM API SPECIFICATION", 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################OracleaCorporation###################################################################################!raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucohraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemuco#################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorMac OS XoracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleC/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635", (java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("jAVA pLATFORM api sPECIFICATION###############################################################################################################", "OracleaCorporation##################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION###############################################################################################################" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION###############################################################################################################"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Orcle Corportion############cle#Corportio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 15, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle#################################################h!#################################################Corporation", "       OracleCorporation       ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("ocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Cl");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Cl is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("#", strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("444444444444444444444444444444444444444444444444Oracle Corporation##################################                                          ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle4Corporation" + "'", str6.equals("Oracle4Corporation"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 55 + "'", int9 == 55);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", "#####sophie51.0sophie51.0sophie", (-1));
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE" + "'", str5.equals("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################" + "'", str1.equals("#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 10, (short) 1, (byte) 100, (byte) 1, (short) 1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaau");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaau" + "'", str1.equals("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaau"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...va...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...va.." + "'", str1.equals("...va.."));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platfm API Scfcatn", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                              :", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("        Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...va..", "En", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str1.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Oracle Corporation############cle#Corporatio                                                                                         US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION############CLE#cORPORATIO                                                                                         us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us" + "'", str1.equals("oRACLE cORPORATION############CLE#cORPORATIO                                                                                         us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("X8", "ORAoracle4Corporationnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X8" + "'", str2.equals("X8"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Corporation", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac OS X", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specif", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("EUS", "1.7AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/AAAAAAAAAAAAAAAAAAAAAAeihpo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("             X SO caM              ", "oRACLE#################################################H!#################################################cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             X SO caM              " + "'", str2.equals("             X SO caM              "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("O", "1.7.0X80-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("O", (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10306_1560228635/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "", (int) (byte) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80\n1.7.0_80-", 97, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "HMsophie51.0soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                         #Oracle#Corporation#                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ss                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US", (java.lang.CharSequence) "                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1359 + "'", int2 == 1359);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "1.7.0X80-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0X80-" + "'", str1.equals("1.7.0X80-"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("oRACLE cORPORATION############CLE#cORPORATIO                                                                                         us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us", "s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aro", "                                          x86_64", "                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aro" + "'", str3.equals("aro"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  en                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 2, 2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cdefectsj Cframework Clocuments Cd...!", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHI", "Xohhhh#########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHI" + "'", str2.equals("SERS/SO_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHI"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                            Java Virtual Machine Specification", "/USERS/SOPHIEACLECORPORATION#################", 4583);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sophie51.0sophie51.0sophi", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 34L, (double) 48.0f, 1.7000000476837158d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "defects4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Platform API Specification ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("RACLE CORPORATION", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RACLE CORPORATION" + "'", str3.equals("RACLE CORPORATION"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Oracle#################################################h!#################################################Corporati", "s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("h/USERS/SOPHIEacleCorporation...!", "Ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/USERS/SOPHIEacleCorporation...!" + "'", str2.equals("h/USERS/SOPHIEacleCorporation...!"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cd...!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cd...!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                         #Oracle#Corporation#                                          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOJavaOVirtualOMachineOSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                             j", 55, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                      j" + "'", str3.equals("                                                      j"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 15);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 15 + "'", byte3 == (byte) 15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "Oracle4CorporationneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUSeneUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635", 21, "ORACLE CORPORATION             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635" + "'", str3.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_10306_1560228635"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/USERS/SOPHIEacleCorporation#################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("h !", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "oracle/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrecorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        long[] longArray3 = new long[] { '4', 142, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 142L + "'", long4 == 142L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 142L + "'", long6 == 142L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        char[] charArray10 = new char[] { '#', '4', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("h !       ", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "jAVA hOTsPOT(tm) 64-bIT sERVE...", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        float[] floatArray1 = new float[] { '#' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 35.0f + "'", float5 == 35.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 35.0f + "'", float6 == 35.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 0, (float) 52L, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#################################################h!#################################################");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.Object[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################" + "'", str3.equals("#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 " + "'", str2.equals("                                                 "));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIEoproC#elcarO", "X86_64", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarO" + "'", str3.equals("/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarO"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("noitaroproC4elcaro", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC4elcaro" + "'", str2.equals("noitaroproC4elcaro"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        char[] charArray10 = new char[] { '#', '4', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                            Java Virtual Machine Specif", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 109 + "'", int17 == 109);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specification", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".7.0_80-b15", "sun.lwawt.macosx.LWCToolkit", (int) (short) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("X8");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', 0, (int) (short) -1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("ro", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ".7.0_80-b15" + "'", str5.equals(".7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "      US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                Oracle#Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                Oracle#Corporatio" + "'", str1.equals("                                Oracle#Corporatio"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("EN", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN" + "'", str2.equals("EN"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/USERS/SOPHIEacleCorporation#################", 55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(30.0f, 52.0f, (float) 300);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 30.0f + "'", float3 == 30.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "S )Bt#C- p- )ti");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie51.0sophie51.0sophie", "http://java.oracle.com/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                                                  US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("4444444444444444444444444444444444", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US" + "'", str5.equals("s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i44444444444444444444444444444444445144444444444444444444444444444444440s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i44444444444444444444444444444444445144444444444444444444444444444444440s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i4444444444444444444444444444444444" + "'", str6.equals("s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i44444444444444444444444444444444445144444444444444444444444444444444440s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i44444444444444444444444444444444445144444444444444444444444444444444440s444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i4444444444444444444444444444444444"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/..." + "'", str1.equals("ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/...ocuments/defects4j/framework/lib/test_generation/..."));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("tionatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation                  1.7.0_80-b15Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica Plavation Jatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIONATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION                  1.7.0_80-B15JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVAJ" + "'", str1.equals("TIONATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION                  1.7.0_80-B15JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVAJ"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                      ", 54.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54.0d + "'", double2 == 54.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "                                                                 1.7.0_80-b15                                                                 ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("51.0", strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "oitaroproC#elcar", (int) (short) 100, (-1));
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        char[] charArray9 = new char[] { '#', '4', 'a' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle4Corporation", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("##################################################h#!#################################################", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                               44444444Oracle4Corporation444444444                               ", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                               44444444Oracle4Corporation444444444                               " + "'", charSequence2.equals("                               44444444Oracle4Corporation444444444                               "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                 1.7.0_80-b15                 ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/defects4j/tmp/run_randoop.pl", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 100, 135);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "X8");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCorporation" + "'", str4.equals("OracleCorporation"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ", (java.lang.CharSequence) "ORAoracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "10.14.3", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Cd...! Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j Clocuments Cframework Cdefects4j hocuments");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JvMc OS Xr VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("       oraclecorporation       ", "hiesophie51.0sophie51.0sophiesophie51.0sophie51.0sop", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("n", "/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle#Corporation", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########Oracle#Corporation#########" + "'", str3.equals("########Oracle#Corporation#########"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0X80-", 100, 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ja######", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnunnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("h!ocuments/defects4j/framework", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) 100, 3L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("USERShttp://java.oracle.com/SOPHIE");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Serve...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("eihpos/sresU/", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JvMc OS Xr VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JvMc OS Xr VM" + "'", str1.equals("JvMc OS Xr VM"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/defects4j/tmp/run_randoop.pl", "####################################################################################################################################Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0####################################################################################################################################", 441);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 15.0f, (double) 51.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("             X SO caM              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             X SO caM             " + "'", str1.equals("             X SO caM             "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("             X SO caM             ", "                                                                                                                                                                                                                                                               ", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444444444444444444444444444444444444444444444444Oracle Corporation##################################                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/USERS/SOPHIEacleCorporation#################    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 6, (long) 170);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("TIONATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION                  1.7.0_80-B15JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVAJ", "sophie5suesophie5suesophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION                  1.7.0_80-B15JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVAJ" + "'", str2.equals("TIONATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION                  1.7.0_80-B15JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVATION JATFORM API SPECIFICA PLAVAJ"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ramework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ts/Home/jre", 179, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie51.0sophie#####sophie51.0sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-B11", "                                             ...", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1Mac OS .Mac OS 7Mac OS .Mac OS 0Mac OS _Mac OS 80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1Mac OS .Mac OS 7Mac OS .Mac OS 0Mac OS _Mac OS 80" + "'", str1.equals("1Mac OS .Mac OS 7Mac OS .Mac OS 0Mac OS _Mac OS 80"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AVA pLATFORM api sPECIFICATION###############################################################################################################", "1", 135);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ocuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/l", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                             ...", "ocuments/defects4j/framework/lib/test_generation/...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        char[] charArray11 = new char[] { '#', '4', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ja", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU/", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle...ecifCorporation", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "esU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Orcle4Corportion", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("##########################JavaMac OS Xr VM###########################", "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIEacleCorporation#################    ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA hOTsPOT(tm) 64-bIT sERVE...", "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("USERSSOPHIE", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("E", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 109);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E" + "'", str3.equals("E"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("AAAAAAAAAAAAAAAAAAAAAAeihpos/sresu/", "ja######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("h/USERS/SOPHIEacleCorporation...!", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!" + "'", str2.equals("h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!h/USERS/SOPHIEacleCorporation...!"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification                  1.7.0_80-b15Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification ", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS", strArray4, strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mac OS" + "'", str7.equals("Mac OS"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("oRACLE#################################################H!#################################################cORPORATION", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "oracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIE", "aaaaaaaaaaaaaaaa", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE" + "'", str4.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("ora                                                                                              ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("java(tm) se runtime environment", strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java:.", "ocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Clocuments Cdefects4j Cframework Cl");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", 23, "/users/so_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t//users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "             X SO caM             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "##########################JavaMac OS Xr VM###########################", (java.lang.CharSequence) "sophie51.0sophie51.0soph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Aaracle.com/aaa", "/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarOX86_64/USERS/SOPHIEoproC#elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1Mac OS .Mac OS 7Mac OS .Mac OS 0Mac OS _Mac OS 80", (int) (byte) 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0L, 2525.0d, (double) 16.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(208, 11, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 208 + "'", int3 == 208);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation############cle#Corporatio                                                                                         US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US", "Oracle/LIBRJAVA(TM) SE RUNTIME ENVIRONMENTVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRECorporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("51.0", "                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("oracle#Corporation", "444444444444444444444444444444444444444444444444Oracle Corporation##################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("RA", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation############cle#Corporatio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                             j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "qc13v_4nmz795v6/v_/sredlof/rav/EIHPOS/SRESU//T/ng0000cf4n1x2n2qc13v_4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RA", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj..." + "'", str2.equals("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj..."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("\n\n\n\n\n\n\n\n\n         Mac OS", "/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RO" + "'", str1.equals("RO"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaau", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("USERShttp://java.oracle.com/SOPHIE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework", "ophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework" + "'", str2.equals("ocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframeworkClocumentsCdefects4jCframework"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Oracle Corporation############cle#Corporatio                                                                                         US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US51                                                                                                  US0s                                                                                                  US                                                                                                  US                                                                                                  USi                                                                                                  US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tionnnnnnnnnnnnnnnacle4CorporaORAor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#################################################h!#################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################H!#################################################" + "'", str1.equals("#################################################H!#################################################"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52, (double) 135, (double) 208);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua", 55, ".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua" + "'", str3.equals("/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtuanoitaroproCelcarO/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Librjava(tm) se runtime environmentVirtua"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "NOITAROPROcELCARo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("##########################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########################################################################################################################################################################" + "'", str1.equals("##########################################################################################################################################################################"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS " + "'", str1.equals("Mac OS "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie", "X8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7.0X80-", 25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444Oracle4Corporation444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("15", "", "o#####neeeeeeeeeeee.15ei##o#####");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 2, 135);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 135 + "'", int3 == 135);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("users/so_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophi", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "RAoracle4Corporationnnnnnnnnnnnnnn", "/USERS/SOPHIEoproC#elcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0" + "'", str2.equals("hMsophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("ramework/lib/test_generation/generation/randoop-current.jar4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4users/sophie/Documents/defects", "rcle.com/sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 15, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 15 + "'", short3 == (short) 15);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("1.7", "ocuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/locuments/defects4j/framework/l");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("racle.com/", "en", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie" + "'", str1.equals("Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("jAVA pLATFORM api sPECIFICATION", "jAVA hOTsPOT(tm) 64-bIT sERVE...", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                             jar");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java(tm) se runtime environment", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", 3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.Object[] objArray10 = new java.lang.Object[] { strArray1, strArray6, "Mac OS X" };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat(objArray10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java(tm) se runtime environment" + "'", str7.equals("java(tm) se runtime environment"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle Corporation############cle#Corporatio", "                             j  ", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("jar", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj" + "'", str2.equals("raj"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/defects4j/tmp/run_randoop.pl", 54.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54.0d + "'", double2 == 54.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863", "Msophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophiesophie51.0sophie51.0sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635O/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_156022863"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "...va..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...va.." + "'", str1.equals("...va.."));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreCorporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Or\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                                                                                                                                                /LibrJAVA PLATFORM API SPECIFICATION", "!eihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposeihpos0.15eihpos0.15eihposMh");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 4583);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification                  1.7.0_80-b15Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification", "                                                                 1.7.0_80-b15                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification                  1.7.0_80-b15Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification" + "'", str2.equals("Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification                  1.7.0_80-b15Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification Java Platform API Specification"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        int[] intArray2 = new int[] { 69, 9 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("esU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                                                 1.7.0_80-b15                 ...", "ORAoracle4Corporationnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("JavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaaaaaaaaaaaaaaaaaa1.7.0_80-b15JavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationaJavaaPlatformaAPIaSpecificationa", 179, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporatio", '4');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("oRACLE cORPORATION############CLE#cORPORATIO                                                                                         us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us51                                                                                                  us0S                                                                                                  us                                                                                                  us                                                                                                  usI                                                                                                  us", strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#################################################h!#################################################");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.Object[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################" + "'", str9.equals("#################################################ocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jarhocuments/defects4j/framework/lib/test_generation/generation/randoop-current.jar!#################################################"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java platform api specification ", "DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj...", 18);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 35, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.CPrinterJob");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIEoproC#elcarO", "", "Oracle/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreCorporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIEoproC#elcarO" + "'", str3.equals("/USERS/SOPHIEoproC#elcarO"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "x8");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(32.0d, (double) 3, (double) 21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENENEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str1.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle#Corporati");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle#Corporati" + "'", str1.equals("Oracle#Corporati"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA hOTsPOT(tm) 64-bIT sERVE...", "users/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnusers/sophie/Documents/defects4j/tmp/run_randoop.pl_10306_1560228635/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation##################################", "                                                                 1.7.0_80-b15                                                                 ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleaCorporation##################################" + "'", str4.equals("OracleaCorporation##################################"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }
}

