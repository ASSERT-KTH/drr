import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tionatformapispecificaplavaj", 212, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("           /Users/sophie           ", "1.4#################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "           /Users/sophie           ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.CharSequence[] charSequenceArray3 = new java.lang.CharSequence[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                   /", "//java.oracle.com/" };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray3);
        org.junit.Assert.assertNotNull(charSequenceArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                   /", 144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", (java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("\n", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c", (java.lang.CharSequence) "0.14.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("################################################hi!#################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################################hi!#################################################" + "'", str1.equals("################################################hi!#################################################"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8     ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (-1));
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "en");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "1.7", (int) (short) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.Class<?> wildcardClass9 = strArray7.getClass();
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 14 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ":" + "'", str8.equals(":"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "tionatformapispecificaplavaj", ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("  ", "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 97, "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xa/" + "'", str3.equals("aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xa/"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/LIBRARY/JAVA/JAVAVIRTUALMACHINE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("tnemnorivnEscihparGC.twa.nus", "uSERSSOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3420 + "'", int1 == 3420);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mixed mode", 52, "                     4.1                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     Mixed mode                     " + "'", str3.equals("                     Mixed mode                     "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "cosx.CP", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP" + "'", str3.equals("cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime environment" + "'", str1.equals("java(tm) se runtime environment"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", 97, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oraclesun.awt.CGraphicsEnvironmentCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str1.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97, (double) (-1.0f), (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(":", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode", "", 144);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 105);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.9f, 88.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 88.0f + "'", float3 == 88.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", "                                   ", "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv" + "'", str3.equals("en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("OracleCor", "UTF-8     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCor" + "'", str2.equals("OracleCor"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7", "Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String[] strArray5 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray5, strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray8, strArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray8, strArray17);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0.9", (java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str13.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Oracle Corporation" + "'", str19.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!", 56, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libred mode", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/uSERS/SOPHIE", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray2, strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray5, strArray9);
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str10.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" Java HotSpot(TM) 64-Bit Server VM", "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server "));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                      Http://java.oracle.com/                                       ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      Http://java.oracle.com/                                       " + "'", str3.equals("                                      Http://java.oracle.com/                                       "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ", "/var/folders/_v/6v597zmn4_v31cq2n2x", "1.7.0_80-b1", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      " + "'", str4.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph" + "'", str1.equals("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(" ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr" + "'", charSequence2.equals("chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ", (java.lang.CharSequence) "US", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      " + "'", str2.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String[] strArray2 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, ":");
        java.lang.String[] strArray6 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, ":");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle Cor" + "'", str11.equals("Oracle Cor"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("tnemnorivnEscihparGC.twa.nus", "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                   /");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/                                                                                                   " + "'", str1.equals("/                                                                                                   "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" Java HotSpot(TM) 64-Bit Server VM ################################################", "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM ################################################" + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM ################################################"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr", "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr" + "'", str2.equals("chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 88.0f, 88.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 88.0f + "'", float3 == 88.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.4################################################################################################", charSequence1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mixed mode", "   1.4    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tem/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tem/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.4", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode" + "'", str1.equals("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, (double) 63, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 63.0d + "'", double3 == 63.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode" + "'", charSequence2.equals("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.LWCToolkit", " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" Java HotSpot(TM) 64-Bit Server VM ", "graphicsenvironment1.71.71.71.7");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", 31, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", "", "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int[] intArray5 = new int[] { (-1), ' ', (short) 100, ' ', (byte) 10 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...EALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str1.equals("...EALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Http://java.oracle.com/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("3", "noitacificepS IPA mroftalP ava                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:" + "'", str2.equals("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaautf-8     ", " Java HotSpot(TM) 64-Bit Server VM ################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv" + "'", str3.equals("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..." + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..."));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", 83);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS X");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!", 459);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                     Mixed mode                     ", (java.lang.CharSequence) "tionatformapispecificap", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444444444444444444444", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("           /Users/sophie           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        long[] longArray1 = new long[] { 0L };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(144.0f, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 144.0f + "'", float3 == 144.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7.0_80-B15", "n", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15" + "'", str3.equals("1.7.0_80-B15"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr", 34, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b/javary/J" + "'", str3.equals("b/javary/J"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", (java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ", "Mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 105, (float) 52L, (float) 459);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 459.0f + "'", float3 == 459.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.4", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28L, (double) 35L, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oraclesun.awt.CGraphicsEnvironmentCorporation", "######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oraclesun.awt.CGraphicsEnvironmentCorporation" + "'", str2.equals("Oraclesun.awt.CGraphicsEnvironmentCorporation"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR" + "'", str1.equals("CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("################################################hi!#################################################", "0.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################hi!#################################################" + "'", str2.equals("################################################hi!#################################################"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0", 80L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 80L + "'", long2 == 80L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        long[] longArray6 = new long[] { 0, 'a', 100, (byte) 10, (byte) 1, '#' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.Class<?> wildcardClass9 = longArray6.getClass();
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oraclesun.awt.CGraphicsEnvironmentCorporation", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1.equals(0.0f));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM", "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaautf-8     ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification                                                               ", "UserssophieDocumentsdefects4jtmprun_randoop.pl_95497_1560210540targetclasses:Us24.80-b1", 56);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", "                                                 4.1                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "1.5################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.", 212, 63);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 72, 6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 6, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("11b-08. 2", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11b-08. 2" + "'", str2.equals("11b-08. 2"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.4################################################################################################", 86, "                                                 4.1                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4################################################################################################" + "'", str3.equals("1.4################################################################################################"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("graphicsenvironment1.71.71.71.7", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phicsenvironment1.71.71.71.7agr" + "'", str2.equals("phicsenvironment1.71.71.71.7agr"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "           /Users/sophie           ", (java.lang.CharSequence) "java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "OracleCor/Users/sophie/Documents...", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.7", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("n", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ne", (int) (short) 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7Oracle Cor1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7", "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("boJretnirPC.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"boJretnirPC.xsocam.twawl.nus\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.1");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ", (java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 72, (long) 7, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (int) '#', 212);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 212 + "'", int3 == 212);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("tnemnorivnEscihparGC.twa.nus", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ".71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr                                      ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("utf-8     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     8-ftu" + "'", str1.equals("     8-ftu"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "utf-8", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("tnemnorivnEscihparGC.twa.nus", "ar", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", "     8-ftu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str2.equals("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                 Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("CHINESa...", "", "OracleCor", 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CHINESa..." + "'", str4.equals("CHINESa..."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        double[] doubleArray6 = new double[] { 0L, 1.0f, 1.0f, 100, (byte) 100, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA" + "'", str1.equals("AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 86, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 67 + "'", int1 == 67);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Http://java.oracle.com/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/" + "'", str2.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "################################################hi!#################################################", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                 Java Platform API Specification                                 ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 Java Platform API Specification                                 " + "'", str2.equals("                                 Java Platform API Specification                                 "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("...EALMAVIRTUAVA/JAVARY/JA/LIBR", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", "       ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 31L, 35.0f, (float) 63);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.9");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ar", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "tionatform API Specifica PlavaJ", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        float[] floatArray6 = new float[] { (-1.0f), (short) 100, 52L, 0, (short) 10, 1L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ar" + "'", str1.equals("ar"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed mode", "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.CharSequence[] charSequenceArray0 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[] charSequenceArray3 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[] charSequenceArray4 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[][] charSequenceArray6 = new java.lang.CharSequence[][] { charSequenceArray0, charSequenceArray1, charSequenceArray2, charSequenceArray3, charSequenceArray4, charSequenceArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charSequenceArray6);
        org.junit.Assert.assertNotNull(charSequenceArray0);
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertNotNull(charSequenceArray3);
        org.junit.Assert.assertNotNull(charSequenceArray4);
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertNotNull(charSequenceArray6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("OracleCor/Users/sophie/Documents..", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor/Users/sophie/Documents.." + "'", str3.equals("OracleCor/Users/sophie/Documents.."));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "//java.oracle.com/", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("3", 0, ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3" + "'", str3.equals("3"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JavaPlatformAPISpecification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("b/javary/J", 80, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################################################################b/javary/J" + "'", str3.equals("######################################################################b/javary/J"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", (java.lang.CharSequence) "UTF-8     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444", (java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(988, 0, 988);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 988 + "'", int3 == 988);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "1.4################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("       ...", "utf-8     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORHI!HI!HI!HI!HI!HI!HI!H0.9!HI!HI!HI!HI!HI!HI!HI!HI!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.7d, (double) 31L, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeusers/sophie1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenv" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeusers/sophie1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenv"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("44444444444444444444444444444444444", "en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Virtual Machine Specification                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Virtual Machine Specification                                                                is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Cor", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 6, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("tionatformapispecificap");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionatformapispecificap\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444" + "'", str2.equals("444444444444444444"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "Oracle Corporation", "sun.awt.CGraphicsEnvironment", "Oracle Cor", "" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Oracle Cor");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "porationasun.awt.CGraphicsEnvironmentaa" + "'", str12.equals("porationasun.awt.CGraphicsEnvironmentaa"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        byte[][][] byteArray0 = new byte[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHC" + "'", str1.equals("RBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHC"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "Oracle Corporation", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 146);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...EALMAVIRTUAVA/JAVARY/JA/LIBR", "                                                                                                   /");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...EALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str2.equals("...EALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.5################################", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("noitacificepS IPA mroftalP ava                                                  ", "######################################################################b/javary/J", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("noitacificepS IPA mroftalP ava", "en", 88);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS IPA mroftalP ava" + "'", str3.equals("noitacificepS IPA mroftalP ava"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str3.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7" + "'", str2.equals("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("  ", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", 2, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("b/javary/J", "1.4#############################################1.4##############################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b/javary/J" + "'", str3.equals("b/javary/J"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", (int) (byte) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("porationasun.awt.CGraphicsEnvironmentaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "porationasun.awt.CGraphicsEnvironmentaa" + "'", str2.equals("porationasun.awt.CGraphicsEnvironmentaa"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("CHINESa...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(67, (int) (short) 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".41.0" + "'", str1.equals(".41.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "################################################hi!#################################################", charSequence1, 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", 124);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("US", "", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X", "                                                 4.1                                                ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("a", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("cosx.CP", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.CP" + "'", str3.equals("cosx.CP"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                     4.1                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("7.1", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" Java HotSpot(TM) 64-Bit Server VM ", "OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Http://java.oracle.com/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "tionatform API Specifica PlavaJ", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########################################hi!#################################################", (java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", 86);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "uS", (java.lang.CharSequence) "Java Virtual Machine Speci");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!", (java.lang.CharSequence) "uS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n", 146);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", ":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java.oracle.com");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mixed mode is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) (byte) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 212, 88);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str3.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71." + "'", str1.equals("24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71."));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "tionatformAPISpecificaPlavaJ", 3420, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                   /", "Mixed mode", "1.4#################################################################################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", 97, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..." + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xa/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCor", "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("OracleCor/Users/sophie/Documents..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCor/Users/sophie/Documents.." + "'", str1.equals("OracleCor/Users/sophie/Documents.."));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachine");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINE" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINE"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "uS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("x86_64", "Java Virtual Machine Specification", "RBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHC");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/                                                                                                   ", (java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("utf-8", "######################################################################b/javary/J");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "  ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                1.4                                                 ", ".3410.1", (int) '4');
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (short) 0, "11b-08. 2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.", ".41.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle Cor", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor" + "'", str2.equals("Oracle Cor"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHI..." + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHI..."));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("######", "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######" + "'", str3.equals("######"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray2, strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray5, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "US");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.Class<?> wildcardClass16 = strArray14.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str10.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("     8-ftu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-ftu" + "'", str1.equals("8-ftu"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle Corhi!hi!hi!hi!hi!hi!hi!...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "phicsenvironment1.71.71.71.7agr", (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("IBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3007 + "'", int1 == 3007);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 63, (long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 63L + "'", long3 == 63L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "Oracle Corporation1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7Oracle Cor1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tionatform API Specifica PlavaJ");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "e                           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("http://java.oracle.com/", "", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("tem/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion4.atLeast(javaVersion6);
        java.lang.String str8 = javaVersion4.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("C", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "46_68x", (int) '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "tionatformapispecificaplavaj");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "\n", (java.lang.CharSequence) "3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "\n" + "'", charSequence2.equals("\n"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        char[] charArray8 = new char[] { ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "3", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "   1.4    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac OS X", "Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("HTTP://JAVA.ORACLE.COM/", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3", 988, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3" + "'", str4.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.4#############################################1.4##############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4#############################################1.4##############################################" + "'", str1.equals("1.4#############################################1.4##############################################"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.14.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("e                           ", "Java HotSpot(TM) 64-Bit Server VM", "chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e                           " + "'", str3.equals("e                           "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                      Http://java.oracle.com/                                       ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xa/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("11b-08.42", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11b-08.42" + "'", str3.equals("11b-08.42"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("tem/Library/Java/Extensions:/usr/lib/java:.", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tem/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("utf-8", "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/                                                                                                   " + "'", str1.equals("/                                                                                                   "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mode" + "'", str1.equals("Mixed mode"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("x86_64", ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray4, strArray7);
        java.lang.String[] strArray9 = null;
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", strArray7, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#', 212, 52);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie" + "'", str8.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa" + "'", str10.equals("aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0." + "'", str1.equals("0."));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                1.4                                                 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.", (java.lang.CharSequence) "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71." + "'", charSequence2.equals("24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71."));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.", (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.14.", (java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", 459);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String[] strArray4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray7, strArray11);
        java.lang.String[] strArray14 = null;
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray14, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray7, strArray17);
        java.lang.String[] strArray20 = null;
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie", strArray17, strArray20);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str12.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.4" + "'", str18.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTF-8" + "'", str19.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "/Users/sophie" + "'", str21.equals("/Users/sophie"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(13, 146, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 146 + "'", int3 == 146);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str1.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                     Mixed mode                     ", "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", " ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java Virtual Machine Speci");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Speci" + "'", str1.equals("java Virtual Machine Speci"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformAPISpecificaPlavaJ" + "'", str1.equals("tionatformAPISpecificaPlavaJ"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("46_68x", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.5################################", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("24.80-b11");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("x86_64", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("graphicsenvironment1.71.71.71.7", strArray3, strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "graphicsenvironment1.71.71.71.7" + "'", str7.equals("graphicsenvironment1.71.71.71.7"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                   /", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               /" + "'", str2.equals("                                                                                               /"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-8     ", 0, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8     " + "'", str3.equals("UTF-8     "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachine", "Oracle Corhi!hi!hi!hi!hi!hi!hi!...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        float[] floatArray3 = new float[] { 35.0f, ' ', '#' };
        float[] floatArray7 = new float[] { 35.0f, ' ', '#' };
        float[][] floatArray8 = new float[][] { floatArray3, floatArray7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray8);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachine");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(212, 83, 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 212 + "'", int3 == 212);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("SUN.AWT.cgRAPHICSeNVIRONMENT", "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHI...", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "uS", (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0.9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".9\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHI...", (java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 86);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      " + "'", str2.equals("                                                                                      "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 35, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", "noitacificepS IPA mroftalP ava                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray3, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray6, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "US");
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Http://java.oracle.com/", (java.lang.CharSequence[]) strArray15);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str11.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("//java.oracle.com/", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".3410.1", "/lIBRARY/jAVA/jAVAvIRTUALmACHINE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "OracleCor", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libred mode", (java.lang.CharSequence) "Oracle Corporation1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7Oracle Cor1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "11b-08.42", (java.lang.CharSequence) "  ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "porationasun.awt.CGraphicsEnvironmentaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode" + "'", str2.equals("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java.oracle.com", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.oracle.com" + "'", str3.equals("java.oracle.com"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                               /", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /" + "'", str2.equals("                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("   1.4    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   1.4    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("################################################hi!#################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7", "CHINESa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                               /", 10, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("##########################################hi!#################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        char[] charArray7 = new char[] { '4', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b1", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("8-ftu", "7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", "JAVA(TM) SE RUNTIME ENVIRONMENT", "Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv" + "'", str3.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeuSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-b15", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!", (int) (byte) -1, 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!0-b15" + "'", str4.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!0-b15"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444" + "'", str1.equals("444444444444444444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", "/Users/sophie", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str3.equals(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("  ", 144, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                " + "'", str3.equals("                                                                                                                                                "));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "     8-ftu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachine");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#Library#/#Java#/#Java#Virtual#Machine" + "'", str3.equals("/#Library#/#Java#/#Java#Virtual#Machine"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporation", "NOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corporation" + "'", str2.equals("racle Corporation"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "CHINESa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("e                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                           e" + "'", str1.equals("                           e"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.", charSequence1, 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        char[] charArray6 = new char[] { '4', '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ar", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(" Java HotSpot(TM) 64-Bit Server VM", ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                                ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                " + "'", str2.equals("                                                                                                                                                "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "1.1", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.CPrinterJob", 63, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:", ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:" + "'", str2.equals("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }
}

