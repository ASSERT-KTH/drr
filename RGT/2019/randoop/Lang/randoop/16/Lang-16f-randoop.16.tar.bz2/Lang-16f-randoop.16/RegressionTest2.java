import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification                                                               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", "Oracle Cor", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification                                                               ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oraclesun.awt.CGraphicsEnvironmentCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", "", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Mixed mode", "                                                                                                    ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode" + "'", str3.equals("Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("######", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######" + "'", str2.equals("######"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Virtual Machine Specif", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Platform API Specification", "tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 7L, (float) 88L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 88.0f + "'", float3 == 88.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "#10.14.3##", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("######", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######" + "'", str2.equals("######"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String[] strArray3 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, ":");
        java.lang.String[] strArray7 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, ":");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Oracle Cor" + "'", str14.equals("Oracle Cor"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa", (java.lang.CharSequence) "UTF-8     ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.4#############################################1.4##############################################", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4#############################################1.4##############################################" + "'", str3.equals("1.4#############################################1.4##############################################"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "OracleCor/Users/sophie/Documents...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540" + "'", str1.equals("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String[] strArray6 = new java.lang.String[] { "Oracle Corporation", "sun.awt.CGraphicsEnvironment", "Oracle Cor", "" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Oracle Cor");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", "tionatformAPISpecificaPlavaJ", "tionatformapispecificaplavaj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification" + "'", str3.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   1.4    ", (java.lang.CharSequence) "46_68x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str1.equals(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("cosx.CP", 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        char[] charArray6 = new char[] { '#', '4', 'a', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", "boJretnirPC.xsocam.twawl.nus", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8     ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tionatformapispecificap", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "cosx.CP", (java.lang.CharSequence) "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.4#################################################################################################", (int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", "                                           mixed mode                                            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("C", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C" + "'", str2.equals("C"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################################hi!#################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0.9", "//java.oracle.com/", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9" + "'", str3.equals("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ", (java.lang.CharSequence) "Oraclesun.awt.CGraphicsEnvironmentCorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                           mixed mode                                            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.9", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) 'a', (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x", "##########################################hi!#################################################", "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.7d, (double) 18, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("tionatformapispecificaplavaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformapispecificaplavaj" + "'", str1.equals("tionatformapispecificaplavaj"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) (byte) 100, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.", (int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("utf-8     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("noitacificepS IPA mroftalP avaJ", "", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", "Mac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String[] strArray4 = new java.lang.String[] { "Oracle Corporation", "sun.awt.CGraphicsEnvironment", "Oracle Cor", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Cor");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, ":");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.Class<?> wildcardClass11 = strArray4.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str10.equals("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(":", (int) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", charSequence1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: : is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR" + "'", str1.equals(":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("en", 31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9" + "'", str3.equals("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str1.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64", "                                                 4.1                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.3", 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.14." + "'", str3.equals("0.14."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) (-1.0f), (double) 88.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 88.0d + "'", double3 == 88.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/uSERS/SOPHIE", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "0.9", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n", "", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("//java.oracle.com/", "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.oracle.com" + "'", str2.equals("java.oracle.com"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("...EALMAVIRTUAVA/JAVARY/JA/LIBR", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...EALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str2.equals("...EALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCor", "graphicsenvironment1.71.71.71.7", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 31L, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OracleCor/Users/sophie/Documents...", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor/Users/sophie/Documents..." + "'", str3.equals("OracleCor/Users/sophie/Documents..."));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "utf-8", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray1, strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" Java HotSpot(TM) 64-Bit Server VM ", "graphicsenvironment1.71.71.71.7");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.5", 63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("java.oracle.com", "tionatformapispecificap", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.oracle.com" + "'", str3.equals("java.oracle.com"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("tionatformapispecificap", (int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str1.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "n", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7", (java.lang.CharSequence) "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", (java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, 97.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "noitacificepS IPA mroftalP ava");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("utf-8     ", "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8     " + "'", str2.equals("utf-8     "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("http://java.oracle.com/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 31L, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b1", "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1" + "'", str2.equals("1.7.0_80-b1"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "//java.oracle.com/", charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "", 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation" + "'", str4.equals("Oracle Corporation"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9", (java.lang.CharSequence) "1.4#############################################1.4##############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("java.oracle.com", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.oracle.com" + "'", str2.equals("java.oracle.com"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("################################################hi!#################################################", "################################################hi!#################################################", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "cosx.CP", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("noitacificepS IPA mroftalP avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 52, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("US", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachine");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0.9", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification                                                               ", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("en", "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", 28, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv" + "'", str4.equals("en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        char[] charArray3 = new char[] { ' ' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oraclesun.awt.CGraphicsEnvironmentCorporation", "######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oraclesun.awt.CGraphicsEnvironmentCorporation" + "'", str2.equals("Oraclesun.awt.CGraphicsEnvironmentCorporation"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "                                           mixed mode                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("46_68x", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x" + "'", str2.equals("46_68x"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "0.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, 31, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode", (double) 83);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 83.0d + "'", double2 == 83.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("tionatformAPISpecificaPlavaJ", "/Library/Java/JavaVirtualMachine");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachine" + "'", str2.equals("/Library/Java/JavaVirtualMachine"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.4#################################################################################################", "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4#################################################################################################" + "'", str2.equals("1.4#################################################################################################"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("#10.14.3##", "", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) (byte) -1, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!", 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("######", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "java.oracle.com");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle Cor", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", ":");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA(TM) SE RUNTIME ENVIRONMENT", 63, ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::" + "'", str3.equals("::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        short[][][] shortArray0 = new short[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("24.80-b11");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("x86_64", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("graphicsenvironment1.71.71.71.7", strArray3, strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "   1.4    ", 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "sun.awt.CGraphicsEnvironment");
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                 4.1                                                ", strArray6, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "graphicsenvironment1.71.71.71.7" + "'", str7.equals("graphicsenvironment1.71.71.71.7"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Oraclesun.awt.CGraphicsEnvironmentCorporation" + "'", str13.equals("Oraclesun.awt.CGraphicsEnvironmentCorporation"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.9", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", "\n", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("noitacificepS IPA mroftalP avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.4#############################################1.4##############################################", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4#############################################1.4##############################################" + "'", str3.equals("1.4#############################################1.4##############################################"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "1.7.0_80-B15", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0L, 0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mixed mode", "                                                1.4                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 97, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4#################################################################################################", ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 80, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 80L + "'", long3 == 80L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", "graphicsenvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str2.equals(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.5", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                 Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("utf-8", "UTF-8     ", "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "utf-8" + "'", str3.equals("utf-8"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specification                                                               ", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification                                                               " + "'", str3.equals("Java Virtual Machine Specification                                                               "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.4#############################################1.4##############################################", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("           /Users/sophie           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "JAVA(TM) SE RUNTIME ENVIRONMENT", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("   1.4    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   1.4    " + "'", str1.equals("   1.4    "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR" + "'", str1.equals("CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" Java HotSpot(TM) 64-Bit Server VM ################################################", "0.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM ################################################" + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM ################################################"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" Java HotSpot(TM) 64-Bit Server VM ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 88);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("##########################################hi!#################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JAVA(TM) SE RUNTIME ENVIRONMENT", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str2.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                           mixed mode                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str2.equals(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", "/", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification" + "'", str4.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1", "sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.4################################################################################################", charSequence1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPS IPA MROFTALP AVAJ" + "'", str1.equals("NOITACIFICEPS IPA MROFTALP AVAJ"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.4f, (double) 18, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4################################################################################################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", (java.lang.CharSequence) "tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "cosx.CP", (java.lang.CharSequence) "OracleCor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "US", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10, (float) 3, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\n", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                 Java Platform API Specification                                 ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ne", (java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("tnemnorivnEscihparGC.twa.nus", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformAPISpecificaPlavaJ" + "'", str1.equals("tionatformAPISpecificaPlavaJ"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(":", "                                           mixed mode                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           mixed mode                                            " + "'", str2.equals("                                           mixed mode                                            "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OracleCor", "sun.lwawt.macosx.LWCToolkit", 97);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "", "C");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA" + "'", str3.equals(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 63, (long) (short) 1, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 63L + "'", long3 == 63L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence) "                                                1.4                                                 ", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 80L, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 80L + "'", long3 == 80L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("OracleCor/Users/sophie/Documents...", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCor/Users/sophie/Documents.." + "'", str2.equals("OracleCor/Users/sophie/Documents.."));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                                                                                   " + "'", str2.equals("/                                                                                                   "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "11b-08.42", 0, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "11b-08.42" + "'", str4.equals("11b-08.42"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                 Java Platform API Specification                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", (int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", 1.4f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4f + "'", float2 == 1.4f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String[] strArray5 = new java.lang.String[] { "Oracle Corporation", "sun.awt.CGraphicsEnvironment", "Oracle Cor", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Oracle Cor");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "//java.oracle.com/", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("java.oracle.com", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "tionatformapispecificaplavaj", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80", 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", "                                           mixed mode                                            ", "tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str3.equals("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "utf-8     ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", 28, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540" + "'", str3.equals("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("OracleCor/Users/sophie/Documents..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", (java.lang.CharSequence) "1.4#############################################1.4##############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                 4.1                                                ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "#10.14.3##", (java.lang.CharSequence) "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!", "/Library/Java/JavaVirtualMachine");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr" + "'", str1.equals("chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mixed mode", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("tionatformAPISpecificaPlavaJ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformAPISpecificaPlavaJ" + "'", str2.equals("tionatformAPISpecificaPlavaJ"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.4", 2, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "C", (java.lang.CharSequence) "                                   ", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 18, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.14.3", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/uSERS/SOPHIE", (java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   /" + "'", str1.equals("                                                                                                   /"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) ' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 105 + "'", int3 == 105);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv" + "'", str2.equals("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x", "US", "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..." + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.3", "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.5", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0.9", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor" + "'", str2.equals("Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, (int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("NOITACIFICEPS IPA MROFTALP AVAJ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ" + "'", str2.equals("NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540" + "'", str2.equals("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                    ", (double) 1.4f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.399999976158142d + "'", double2 == 1.399999976158142d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 4.1                                                ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                           mixed mode                                            ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63 + "'", int2 == 63);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/" + "'", str1.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Mixed mode", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "OracleCor/Users/sophie/Documents..");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/var/folders/_v/6v597zmn4_v31cq2n2x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str1.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "1.4#################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("   1.4    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   1.4    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double[] doubleArray4 = new double[] { 1, 1, (short) -1, (byte) -1 };
        double[] doubleArray9 = new double[] { 1, 1, (short) -1, (byte) -1 };
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X", 34, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..." + "'", str4.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi..."));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa" + "'", str2.equals("ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.3", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tionatform API Specifica PlavaJ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/                                                                                                   ", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("################################################hi!#################################################", "1.7.0_80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.7.0_80-b1", 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ne", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5################################" + "'", str3.equals("1.5################################"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specif" + "'", str1.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("boJretnirPC.xsocam.twawl.nus", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle Cor", (java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ", "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ" + "'", str2.equals("NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                 4.1                                                ", (long) 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                                   /", "Java Virtual Machine Specification", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   /" + "'", str3.equals("                                                                                                   /"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "######", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.14.3", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".3410.1" + "'", str2.equals(".3410.1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "noitacificepS IPA mroftalP avaJ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0.14.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", 105, "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      " + "'", str3.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR", 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 144 + "'", int2 == 144);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "OracleCor", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("##########################################hi!#################################################", "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################################hi!#################################################" + "'", str2.equals("##########################################hi!#################################################"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str3.equals("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR" + "'", str5.equals("CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) (-1L), (double) 31L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) 6, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "tionatformapispecificap");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) 31, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":", "Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                 4.1                                                ", (java.lang.CharSequence) "#10.14.3##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ".3410.1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "1.1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("cosx.CP", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35L, (float) 10, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 88, 31L, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 88L + "'", long3 == 88L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Cor", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("OracleCor/Users/sophie/Documents...", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "51.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCor/Users/sophie/Documents..." + "'", str4.equals("OracleCor/Users/sophie/Documents..."));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double[] doubleArray4 = new double[] { 52L, (byte) 100, 10L, (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.5", "mixed mode", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":.AVA/eX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: US is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/                                                                                                   ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                                                                                   " + "'", str2.equals("/                                                                                                   "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                   ", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Mixed mode", (java.lang.CharSequence) "                                                                                                   /", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("tionatform API Specifica PlavaJ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = null;
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray8, strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray11, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray4, strArray11);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence1, (java.lang.CharSequence[]) strArray11);
        int int22 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "OracleCor", (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "tionatformAPISpecificaPlavaJ" + "'", str5.equals("tionatformAPISpecificaPlavaJ"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.4" + "'", str12.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str16.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str20.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                 Java Platform API Specification                                 ", (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        short[] shortArray0 = new short[] {};
        short[] shortArray1 = new short[] {};
        short[][] shortArray2 = new short[][] { shortArray0, shortArray1 };
        short[] shortArray3 = new short[] {};
        short[] shortArray4 = new short[] {};
        short[][] shortArray5 = new short[][] { shortArray3, shortArray4 };
        short[] shortArray6 = new short[] {};
        short[] shortArray7 = new short[] {};
        short[][] shortArray8 = new short[][] { shortArray6, shortArray7 };
        short[] shortArray9 = new short[] {};
        short[] shortArray10 = new short[] {};
        short[][] shortArray11 = new short[][] { shortArray9, shortArray10 };
        short[][][] shortArray12 = new short[][][] { shortArray2, shortArray5, shortArray8, shortArray11 };
        short[] shortArray13 = new short[] {};
        short[] shortArray14 = new short[] {};
        short[][] shortArray15 = new short[][] { shortArray13, shortArray14 };
        short[] shortArray16 = new short[] {};
        short[] shortArray17 = new short[] {};
        short[][] shortArray18 = new short[][] { shortArray16, shortArray17 };
        short[] shortArray19 = new short[] {};
        short[] shortArray20 = new short[] {};
        short[][] shortArray21 = new short[][] { shortArray19, shortArray20 };
        short[] shortArray22 = new short[] {};
        short[] shortArray23 = new short[] {};
        short[][] shortArray24 = new short[][] { shortArray22, shortArray23 };
        short[][][] shortArray25 = new short[][][] { shortArray15, shortArray18, shortArray21, shortArray24 };
        short[] shortArray26 = new short[] {};
        short[] shortArray27 = new short[] {};
        short[][] shortArray28 = new short[][] { shortArray26, shortArray27 };
        short[] shortArray29 = new short[] {};
        short[] shortArray30 = new short[] {};
        short[][] shortArray31 = new short[][] { shortArray29, shortArray30 };
        short[] shortArray32 = new short[] {};
        short[] shortArray33 = new short[] {};
        short[][] shortArray34 = new short[][] { shortArray32, shortArray33 };
        short[] shortArray35 = new short[] {};
        short[] shortArray36 = new short[] {};
        short[][] shortArray37 = new short[][] { shortArray35, shortArray36 };
        short[][][] shortArray38 = new short[][][] { shortArray28, shortArray31, shortArray34, shortArray37 };
        short[] shortArray39 = new short[] {};
        short[] shortArray40 = new short[] {};
        short[][] shortArray41 = new short[][] { shortArray39, shortArray40 };
        short[] shortArray42 = new short[] {};
        short[] shortArray43 = new short[] {};
        short[][] shortArray44 = new short[][] { shortArray42, shortArray43 };
        short[] shortArray45 = new short[] {};
        short[] shortArray46 = new short[] {};
        short[][] shortArray47 = new short[][] { shortArray45, shortArray46 };
        short[] shortArray48 = new short[] {};
        short[] shortArray49 = new short[] {};
        short[][] shortArray50 = new short[][] { shortArray48, shortArray49 };
        short[][][] shortArray51 = new short[][][] { shortArray41, shortArray44, shortArray47, shortArray50 };
        short[][][][] shortArray52 = new short[][][][] { shortArray12, shortArray25, shortArray38, shortArray51 };
        java.lang.String str53 = org.apache.commons.lang3.StringUtils.join(shortArray52);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertNotNull(shortArray38);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray40);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray50);
        org.junit.Assert.assertNotNull(shortArray51);
        org.junit.Assert.assertNotNull(shortArray52);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", (java.lang.CharSequence) "################################################hi!#################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "C", (java.lang.CharSequence) "ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("C");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"C\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        char[] charArray5 = new char[] { ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                1.4                                                 ", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCor/Users/sophie/Documents...", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("tem/Library/Java/Extensions:/usr/lib/java:.", "java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tem/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, (float) (byte) 0, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 7, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                 4.1                                                ", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachine");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCor/Users/sophie/Documents...", (java.lang.CharSequence) "Oraclesun.awt.CGraphicsEnvironmentCorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                 4.1                                                ", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", (java.lang.CharSequence) "", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 63 + "'", int3 == 63);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str10 = javaVersion9.toString();
        boolean boolean11 = javaVersion2.atLeast(javaVersion9);
        java.lang.String str12 = javaVersion2.toString();
        java.lang.String str13 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str17 = javaVersion16.toString();
        boolean boolean18 = javaVersion14.atLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass20 = javaVersion19.getClass();
        boolean boolean21 = javaVersion16.atLeast(javaVersion19);
        java.lang.String str22 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str24 = javaVersion23.toString();
        boolean boolean25 = javaVersion16.atLeast(javaVersion23);
        boolean boolean26 = javaVersion2.atLeast(javaVersion23);
        java.lang.String str27 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.4" + "'", str12.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.4" + "'", str17.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.4" + "'", str22.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0.9" + "'", str24.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.4" + "'", str27.equals("1.4"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.AWT.cgRAPHICSeNVIRONMENT", 2, "0.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "http://java.oracle.com/");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCor/Users/sophie/Documents...", 6, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "utf-8     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("3", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java(TM) SE Runtime Environment", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        long[] longArray6 = new long[] { 0, 'a', 100, (byte) 10, (byte) 1, '#' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi!", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) (byte) 0, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str4.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Platform API Specification", (int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "CHINESa/aJDKa1a.a7a.a0a_a80a.aJDKa/aCONTENTSa/aHOMEa/aJREALMAVIRTUAVAa/aJAVARYa/aJAa/aLIBR", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "tionatformapispecificaplavaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformapispecificaplavaj" + "'", str2.equals("tionatformapispecificaplavaj"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OracleCor", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCor" + "'", str2.equals("OracleCor"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.", "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 1.4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4d + "'", double2 == 1.4d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", "sophie", 35);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporationsun.awt.CGraphicsEnvironmentOracle Cor", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("OracleCor/Users/sophie/Documents..", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                    ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JAVA(TM) SE RUNTIME ENVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr                                      " + "'", str1.equals("chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr                                      "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "en", "#10.14.3##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Virtual Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("noitacificepS IPA mroftalP avaJ", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str2.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                                           mixed mode                                            ", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("cosx.CP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cosx.CP" + "'", str1.equals("cosx.CP"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "           /Users/sophie           ", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "1.7.0_80-b15", "51.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("UTF-8     ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8     " + "'", str2.equals("UTF-8     "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", charSequence2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "noitacificepS IPA mroftalP avaJ", (int) (byte) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!", (int) (short) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ".3410.1", (java.lang.CharSequence) "utf-8     ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Platform API Specification", "1.4################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "11b-08.42", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "11b-08.42" + "'", charSequence2.equals("11b-08.42"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9", (java.lang.CharSequence) "Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 88, (double) 1.4f, (double) 80L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 88.0d + "'", double3 == 88.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi! Java Platform API Specification"));
    }
}

