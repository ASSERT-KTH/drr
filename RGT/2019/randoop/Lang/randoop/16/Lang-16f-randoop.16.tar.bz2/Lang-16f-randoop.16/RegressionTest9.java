import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 86, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "csenvironment1.71.71.71.7agr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str2.equals(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-B15", "sun.lwawt.macosx.CPrinterJob", 72);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                  /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", (java.lang.CharSequence) "noitacificepS IPA mroftalP ava", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ci", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444", 97, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444" + "'", str3.equals("444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3", "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ccj//.os/brv.bomc", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########################################hi!#################################################", "##########################################hi!#################################################", 3007);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "   1.4    ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "   1.4    " + "'", str5.equals("   1.4    "));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", "Java(TM) SE Runtime Environment", " Java Platform API Specification                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7" + "'", str3.equals("71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        double[] doubleArray6 = new double[] { 0L, 1.0f, 1.0f, 100, (byte) 100, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                                                                                                                                                                                                                                                                                                                      0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 459, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("uSERSSOPHIE", "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT", 146);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uSERSSOPHIE" + "'", str3.equals("uSERSSOPHIE"));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                 ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        short[] shortArray6 = new short[] { (short) -1, (short) 10, (short) 1, (short) -1, (short) 1, (byte) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "          1.4##########################.41.01.4##########################          ", (java.lang.CharSequence) "...TRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/K...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" Java HotSpot(TM) 64-Bit Server ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  Java HotSpot(TM) 64-Bit Server  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/STNETNOC/KDJ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "E                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence6, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "######", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4.1", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 8, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("######", "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9", (int) ' ');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "######" + "'", str8.equals("######"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "###################################", "phicsenvironment1.71.71.71.7agr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "                          OracleCor                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          OracleCor                           " + "'", str2.equals("                          OracleCor                           "));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc" + "'", str1.equals("ment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc"));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.4");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(":", "java Virtual Machine Speci");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc", (java.lang.CharSequence) "java.oracle.com");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTnsio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "UTF-8     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     8-ftuaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                                                                                                                                                                                                                                                                                                                      0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("           /Users/sophie           ", "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("46_68x", (double) 124);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 124.0d + "'", double2 == 124.0d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.14.", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.14." + "'", str3.equals("0.14."));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        char[] charArray3 = new char[] { ' ' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "DERS/_V/6V597ZMN4_V31CQ2N2", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("uSERSSOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uSERSSOPHIE" + "'", str1.equals("uSERSSOPHIE"));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("phicsenvironment1.71.71.71.7agr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"phic\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        float[] floatArray6 = new float[] { (-1.0f), (short) 100, 52L, 0, (short) 10, 1L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ...", 94, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ..." + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ..."));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "ccj//.os/brv.bomc", "edomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexim");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.3", "javalpacificepsipamroftanoit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test49");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test50");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1y4#################################################################################################", (java.lang.CharSequence) "8-ftu");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test51");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...i!hi...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test52");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.6d, (double) 105, 88.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6d + "'", double3 == 1.6d);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test53");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speci", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2Xtmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", 3007);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speci" + "'", str3.equals("java virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speciJ4V4(TM)SERUNTIMEENVIRONMENTjava virtual machine speci"));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test54");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("OracleCor444444444", "", " java hotspot(tm) 64-bit server vm ################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor444444444" + "'", str3.equals("OracleCor444444444"));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test55");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "PORATIONASUN.AWT.CGRAPHICSENVIRONMENTAA", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test56");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaOracleCoraaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test57");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("##################", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test58");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph444444444444444444444444444444444444444444444444" + "'", str1.equals("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test59");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" java hotspot(tm) 64-bit server vm ################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " java hotspot(tm) 64-bit server vm ###############################################" + "'", str1.equals(" java hotspot(tm) 64-bit server vm ###############################################"));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test60");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", 3007, "                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              hi!                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test61");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray7, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray10, strArray14);
        java.lang.String[] strArray17 = null;
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray17, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray10, strArray20);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("tionatform API Specifica PlavaJ");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("######", strArray10, strArray24);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray10);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray10);
        int int28 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str15.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.4" + "'", str21.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTF-8" + "'", str22.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "######" + "'", str25.equals("######"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(strArray30);
    }
}

