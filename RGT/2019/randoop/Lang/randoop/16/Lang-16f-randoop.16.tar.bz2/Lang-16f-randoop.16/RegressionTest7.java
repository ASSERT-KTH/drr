import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ar", "7.1", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP", "", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP" + "'", str3.equals("cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("OracleCor/Users/sophie/Documents..", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi" + "'", charSequence2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("phicsenvironment1.71.71.71.7agr", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phicsenvironment1.71.71.71.7agr" + "'", str2.equals("phicsenvironment1.71.71.71.7agr"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!", "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("racle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "RBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHC", (java.lang.CharSequence) "x86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                1.4                                                 ", "java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                1.4                                                 " + "'", str2.equals("                                                1.4                                                 "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JAVAPLATFORMAPISPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "          1.4##########################.41.01.4##########################          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 31, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.71.71.71.7sun.awt.CGrap10.14.3", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "Oracle Corporation1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7Oracle Cor1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                           mixed mode                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                           mixed mode                                            \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 67, (float) 1L, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmode" + "'", str1.equals("Mixedmode"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "edomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexim", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 67, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeusers/sophie1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeusers/sophie1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenv" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modeusers/sophie1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenv"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("noitacificepaSa aIPAa amroftalaPa aava", 0, "8-ftu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepaSa aIPAa amroftalaPa aava" + "'", str3.equals("noitacificepaSa aIPAa amroftalaPa aava"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                    sun.lwawt.macosx.CPrinterJob                                    " + "'", str1.equals("                                    sun.lwawt.macosx.CPrinterJob                                    "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("RBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCRBIL/AJ/YRAVAJ/AVAUTRIVAMLAERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHC", "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.71.71.71.7sun.awt.CGrap10.14.3", (java.lang.CharSequence) "                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, 31L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2", "Oraclesun.awt.CGraphicsEnvironmentCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 52, 0L, (long) 212);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVAPLATFORMAPISPECIFICATION");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", "/var/folders/_v/6v597zmn4_v31cq2n2x", 97);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mixedmode", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 9 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str6.equals("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JAVAPLATFORMAPISPECIFICATION", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UserssophieDocumentsdefects4jtmprun_randoop.pl_95497_1560210540targetclasses:Us24.80-b1", (java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("################################################hi!#################################################", 72);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 144, "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SO" + "'", str3.equals("CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SO"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "!", (java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n", "", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", 146);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http://java.oracle.com/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                              java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7" + "'", charSequence2.equals("c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5", "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 105);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("          ", 0, "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tionatform API Specifica PlavaJ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray6, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray9, strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray2, strArray9);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "racle Corporation", 100, 14);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatformAPISpecificaPlavaJ" + "'", str3.equals("tionatformAPISpecificaPlavaJ"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.4" + "'", str10.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str14.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str18.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/                                                                                                   ", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "0.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("J4v4(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J4v4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3416 + "'", int2 == 3416);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("noitacificepS IPA mroftalP avaJ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str2.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Http://java.oracl", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        short[][][][][][] shortArray0 = new short[][][][][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRORACLE CORCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", "444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("       ...", "CHINES4...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                1.4                                                 ", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                1.4                                                 " + "'", str3.equals("                                                1.4                                                 "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444" + "'", str1.equals("444444444444444444chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr4444444444444444444"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("J4v4(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J4v4(TM)SERuntimeEnvironment" + "'", str1.equals("J4v4(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OracleCor", 18, "4444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor444444444" + "'", str3.equals("OracleCor444444444"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        short[] shortArray1 = new short[] { (short) 10 };
        short[] shortArray3 = new short[] { (short) 10 };
        short[] shortArray5 = new short[] { (short) 10 };
        short[] shortArray7 = new short[] { (short) 10 };
        short[][] shortArray8 = new short[][] { shortArray1, shortArray3, shortArray5, shortArray7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray8);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0.9", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/VAR/FOLDEtionatformapispecificap0210540/target/classes:/Users/sophi...", 35, ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDEtionatformapispecificap0210540/target/classes:/Users/sophi..." + "'", str3.equals("/VAR/FOLDEtionatformapispecificap0210540/target/classes:/Users/sophi..."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR" + "'", str1.equals("/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Http://java.oracle.com/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machin", 463);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machin" + "'", str2.equals("Http://java.oracle.com/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machin"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", ".71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7.71.71.71.7sun.awt.cgraphicsenv######", 3416);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str10 = javaVersion9.toString();
        boolean boolean11 = javaVersion2.atLeast(javaVersion9);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 1, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "###################################################################", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", 146);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "           /Users/sophie           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                ", "HTTP://JAVA.ORACLE.COM/", "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.1", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "/var/folders/_v/6v597zmn4_v31cq2n2x", 88);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sophie" + "'", str6.equals("sophie"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass9 = javaVersion8.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion8.atLeast(javaVersion10);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean14 = javaVersion2.atLeast(javaVersion8);
        java.lang.String str15 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.1" + "'", str11.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.4" + "'", str15.equals("1.4"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 100, (byte) 10 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "", (int) (byte) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr", (int) (byte) 100, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("######################################################################b/javary/J", ".3410.1", "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################################################################b/javary/J" + "'", str3.equals("######################################################################b/javary/J"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n", (java.lang.CharSequence) "0.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::", 459, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Cor", "UTF-8", (int) (short) 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 9, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaautf-8     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ", "                           e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray2, strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "java Virtual Machine Speci", charSequence1, 105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr" + "'", str2.equals("chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "     8-ftu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("tionatformapispecificaplavaj");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!0-b15", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0450120651_79459_ p.poodnar_nur p t  4stcefed stne ucoD eihpos sres  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils5 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray6 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3, systemUtils4, systemUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) systemUtilsArray6, 'a');
        org.junit.Assert.assertNotNull(systemUtilsArray6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("OracleCor/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", 463, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray5 = new java.lang.String[] { "Oracle Corporation", "sun.awt.CGraphicsEnvironment", "Oracle Cor", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Oracle Cor");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', 10, (int) (short) 1);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "           /Users/sophie           ", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Http://java.oracle.com/", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.4", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########################################hi!#################################################", "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/#Library#/#Java#/#Java#Virtual#Machine", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#Library#/#Java#/#Java#Virtual#Machine                       " + "'", str2.equals("/#Library#/#Java#/#Java#Virtual#Machine                       "));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String[] strArray4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray7, strArray11);
        java.lang.String[] strArray14 = null;
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray14, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray7, strArray17);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("tionatform API Specifica PlavaJ");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("######", strArray7, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "n");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str12.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.4" + "'", str18.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTF-8" + "'", str19.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "######" + "'", str22.equals("######"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("noitacificepaSa aIPAa amroftalaPa aava", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepaSa aIPAa amroftalaPa aava" + "'", str2.equals("noitacificepaSa aIPAa amroftalaPa aava"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Oracle Cor", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor" + "'", str2.equals("Oracle Cor"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.4");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corhi!hi!hi!hi!hi!hi!hi!...", strArray2, strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!..." + "'", str4.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!..."));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) ":.AVA/eXTENSIONS:/USR/LIB/JAVARY/jA/eXTENSIONS:/sYSTEM/lIBRAVARY/jA/eXTENSIONS:/nETWORK/lIBRAVARY/jA/eXTENSIONS:/lIBRAVARY/jA/uSERS/SOPHIE/lIBR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph" + "'", str1.equals("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 97, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b11", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9" + "'", str2.equals("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("TIONATFORM api sPECIFICA pLAVAj4444444444444444444444444", "phicsenvironment1.71.71.71.7agr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONATFORM api sPECIFICA pLAVAj4444444444444444444444444" + "'", str2.equals("TIONATFORM api sPECIFICA pLAVAj4444444444444444444444444"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("uS");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4#################################################################################################" + "'", str1.equals("1.4#################################################################################################"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        char[] charArray3 = new char[] { ' ' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!                       Java Platform API Specification                                 ", "tem/Library/Java/Extensions:/usr/lib/java:.", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray2, strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SUN.AWT.cgRAPHICSeNVIRONMENTnhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 212, (long) (byte) 10, (long) 463);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Cor", "UTF-8", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                                                                                                                                                                                                                                                                                                                                                              java hotspot(tm) 64-bit server vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "################################################hi!#################################################", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 144.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("OracleCor", "46_68x", "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor" + "'", str3.equals("OracleCor"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                1.4                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("tionatformapispecificaplavaj", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformapispecificaplavaj                                                                     " + "'", str2.equals("tionatformapispecificaplavaj                                                                     "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "0.", 124, 212);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 78, (float) 463, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 463.0f + "'", float3 == 463.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!", ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("mixed mode", "cosx.cpcosx.cpcosx.cpcosx.cpcosx.cpcosx.cp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNhi!0-bA5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "UserssophieDocumentsdefects4jtmprun_randoop.pl_95497_1560210540targetclasses:Us24.80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Http://java.oracl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hTTP://JAVA.ORACL" + "'", str1.equals("hTTP://JAVA.ORACL"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("porationasun.awt.CGraphicsEnvironmentaa", "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5################################", "/var/folders/_v/6v597zmn4_v31cq2n2x", 62);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("utf-8     ", "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8     " + "'", str2.equals("utf-8     "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OracleCor/Users/sophie/Documents..", 80, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444OracleCor/Users/sophie/Documents.." + "'", str3.equals("4444444444444444444444444444444444444444444444OracleCor/Users/sophie/Documents.."));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("b/javary/J", (float) 146);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 146.0f + "'", float2 == 146.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.AWT.cgRAPHICSeNVIRONMENTnhi!J/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:", 0, "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnhi!J/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnhi!J/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/:"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.oracle.com" + "'", str1.equals("java.oracle.com"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("\nphicsenvironment1.71.71.71.7agr\n", 144);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#", (java.lang.CharSequence) "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 212 + "'", int2 == 212);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "                                                                                      ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", charSequence2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("O##### C##hi!hi!hi!hi!hi!hi!hi!h0.#!hi!hi!hi!hi!hi!hi!hi!hi!", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed mode", (int) '#', 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int[] intArray5 = new int[] { 7, 52, 52, 6, 35 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444444444", "44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.9", (int) (byte) 100, 78);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "                     4.1                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9" + "'", str1.equals("0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.4################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4################################################################################################" + "'", str1.equals("1.4################################################################################################"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavaPla################################################hi!#################################################", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7" + "'", str3.equals("c/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######", "hTTP://JAVA.ORACL");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corhi!hi!hi!hi!hi!hi!hi!...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!..." + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!..."));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 35, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "Java Virtual Machine Specif", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaautf-8     ", (java.lang.CharSequence) "                           e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("     8-ftu", "Java(TM) SE Runtime Environment", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "46_68x", (int) (short) -1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                 4.1                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.1" + "'", str1.equals("4.1"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("JAVA(TM) SE RUNTIME ENVIRONMENT", (int) '#', 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) ".71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                           mixed mode                                            ", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit", 72, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr" + "'", charSequence2.equals("chines/jdk:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr7:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/libr_:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librjdk/contents/home/jrealmavirtuava/javary/ja/li:.ava/extensions:/usr/lib/javary/ja/extensions:/system/libravary/ja/extensions:/network/libravary/ja/extensions:/libravary/ja/users/sophie/librr"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("           /Users/sophie           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, 72L, (long) 62);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ccj//.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ccj//.os/brv.bomc" + "'", str1.equals("ccj//.os/brv.bomc"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.3");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1.4", strArray3, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionatform API Specifica PlavaJ", strArray6, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "SUN.AWT.cgRAPHICSeNVIRONMENTnsio");
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UserssophieDocumentsdefects4jtmprun_randoop.pl_95497_1560210540targetclasses:Us24.80-b1", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str11.equals("tionatform API Specifica PlavaJ"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtu...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "US", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("C", "chines/jdk:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr7:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr_:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librjdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Li:.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librr");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C" + "'", str3.equals("C"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 3420, (long) 459, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "  ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/STNETNOC/KDJ", 34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "Oracle Cor");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 72, 146);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...EALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophi...", (java.lang.CharSequence) "                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2", ".41.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Oracle CorporationOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!sun.awt.CGraphicsEnvironmentOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!Oracle CorOracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Virtual Machine Specification", 88);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "utf-8     #######################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 83);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s" + "'", charSequence2.equals("n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7Java(TM) SE Runtime Environmentn.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraphn.awt.CGraphicsEnvironment1.71.71.71.7s"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.399999976158142d, (-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.399999976158142d + "'", double3 == 1.399999976158142d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM" + "'", charSequence2.equals(" Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("tnemnorivnEscihparGC.twa.nus", "uS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uS" + "'", str2.equals("uS"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "Java Virtual Machine Speci");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3416, (float) 144, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ccj//.os/brv.bomc", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ccj//.os/brv.bomc" + "'", str3.equals("ccj//.os/brv.bomc"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "                                                                                                                                                                                                                                                                                                                                                                                                                                              java hotspot(tm) 64-bit server vm");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str6.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/var/folders/_v/6v597zmn4_v31cq2 Java HotSpot(TM) 64-Bit Server VM /var/folders/_v/6v597zmn4_v31cq2n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("porationasun.awt.CGraphicsEnvironmentaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PORATIONASUN.AWT.CGRAPHICSENVIRONMENTAA" + "'", str1.equals("PORATIONASUN.AWT.CGRAPHICSENVIRONMENTAA"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b1Mixed mode                                   ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.5", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean12 = javaVersion9.atLeast(javaVersion11);
        boolean boolean13 = javaVersion5.atLeast(javaVersion11);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.4#############################################1.4##############################################", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!", "/var/folders/_v/6v597zmn4_v31cq2n2x", 97);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray2, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NE" + "'", str1.equals("NE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", "US", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30, (float) 3416, 31.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 30.0f + "'", float3 == 30.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("CHINES4...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CHINES4..." + "'", str2.equals("CHINES4..."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                               /");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "8", 988, 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR" + "'", str1.equals("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                   ", "       ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals(":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "tionatformapispecificaplavaj4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4################################################hi!#################################################me/jrelMVirtuv/Jvry/J/Libr4444444444444444444", "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!0-b15", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/#Library#/#Java#/#Java#Virtual#Machine                       ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa######################################################################b/javary/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv", (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7" + "'", str1.equals("24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("phicsenvironment1.71.71.71.7agr", ".71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7.71.71.71.7sun.awt.cgraphicsenv######", "                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 28, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ccj/a/.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence6, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM ", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-B15", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 30, (double) 3.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hTTP://JAVA.ORACL", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hTTP://JAVA.ORACL" + "'", str2.equals("hTTP://JAVA.ORACL"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "porationasun.awt.CGraphicsEnvironmentaa", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "cosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CPcosx.CP", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4054 + "'", int2 == 4054);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECI", charSequence1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "SUN.AWT.cgRAPHICSeNVIRONMENT", 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" Java HotSpot(TM) 64-Bit Server VM ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/STNETNOC/KDJ", charSequence1, 3420);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "java Virtual Machine Speci", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int[] intArray5 = new int[] { (-1), ' ', (short) 100, ' ', (byte) 10 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8     " + "'", str2.equals("UTF-8     "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("nts/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nts/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr" + "'", str2.equals("nts/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-b1Mixed mode                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b1Mixed mode                                   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 86, 7.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 86.0f + "'", float3 == 86.0f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("44444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        float[] floatArray6 = new float[] { (-1.0f), (short) 100, 52L, 0, (short) 10, 1L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass9 = floatArray6.getClass();
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("UTF-8", "                                                 4.1                                                ", "en/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7sun.awt.CGraphicsEnv");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Us24.80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "OracleCor/Users/sophie/Documents...", (java.lang.CharSequence) "ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(31, 0, 988);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 988 + "'", int3 == 988);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444", (long) 67);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 444444444444444444L + "'", long2 == 444444444444444444L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Libr ry/J v /Extensions:/Libr ry/J v /Extensions:/Network/Libr ry/J v /Extensions:/System/Libr ry/J v /Extensions:/usr/lib/j v :.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corporation", "          ", "                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0450120651_79459_ p.poodnar_nur p t  4stcefed stne ucoD eihpos sres  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        short[][][][][] shortArray0 = new short[][][][][] {};
        short[][][][][] shortArray1 = new short[][][][][] {};
        short[][][][][] shortArray2 = new short[][][][][] {};
        short[][][][][] shortArray3 = new short[][][][][] {};
        short[][][][][] shortArray4 = new short[][][][][] {};
        short[][][][][] shortArray5 = new short[][][][][] {};
        short[][][][][][] shortArray6 = new short[][][][][][] { shortArray0, shortArray1, shortArray2, shortArray3, shortArray4, shortArray5 };
        short[][][][][] shortArray7 = new short[][][][][] {};
        short[][][][][] shortArray8 = new short[][][][][] {};
        short[][][][][] shortArray9 = new short[][][][][] {};
        short[][][][][] shortArray10 = new short[][][][][] {};
        short[][][][][] shortArray11 = new short[][][][][] {};
        short[][][][][] shortArray12 = new short[][][][][] {};
        short[][][][][][] shortArray13 = new short[][][][][][] { shortArray7, shortArray8, shortArray9, shortArray10, shortArray11, shortArray12 };
        short[][][][][] shortArray14 = new short[][][][][] {};
        short[][][][][] shortArray15 = new short[][][][][] {};
        short[][][][][] shortArray16 = new short[][][][][] {};
        short[][][][][] shortArray17 = new short[][][][][] {};
        short[][][][][] shortArray18 = new short[][][][][] {};
        short[][][][][] shortArray19 = new short[][][][][] {};
        short[][][][][][] shortArray20 = new short[][][][][][] { shortArray14, shortArray15, shortArray16, shortArray17, shortArray18, shortArray19 };
        short[][][][][] shortArray21 = new short[][][][][] {};
        short[][][][][] shortArray22 = new short[][][][][] {};
        short[][][][][] shortArray23 = new short[][][][][] {};
        short[][][][][] shortArray24 = new short[][][][][] {};
        short[][][][][] shortArray25 = new short[][][][][] {};
        short[][][][][] shortArray26 = new short[][][][][] {};
        short[][][][][][] shortArray27 = new short[][][][][][] { shortArray21, shortArray22, shortArray23, shortArray24, shortArray25, shortArray26 };
        short[][][][][] shortArray28 = new short[][][][][] {};
        short[][][][][] shortArray29 = new short[][][][][] {};
        short[][][][][] shortArray30 = new short[][][][][] {};
        short[][][][][] shortArray31 = new short[][][][][] {};
        short[][][][][] shortArray32 = new short[][][][][] {};
        short[][][][][] shortArray33 = new short[][][][][] {};
        short[][][][][][] shortArray34 = new short[][][][][][] { shortArray28, shortArray29, shortArray30, shortArray31, shortArray32, shortArray33 };
        short[][][][][][][] shortArray35 = new short[][][][][][][] { shortArray6, shortArray13, shortArray20, shortArray27, shortArray34 };
        java.lang.String str36 = org.apache.commons.lang3.StringUtils.join(shortArray35);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray35);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("J4v4(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J4V4(TM)SERUNTIMEENVIRONMENT" + "'", str1.equals("J4V4(TM)SERUNTIMEENVIRONMENT"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("A", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBRCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("tionatformapispecificaplavaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javalpacificepsipamroftanoit" + "'", str1.equals("javalpacificepsipamroftanoit"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("          1.4##########################.41.01.4##########################          ", "JAVA VIRTUAL MACHINE SPECI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          1.4##########################.41.01.4##########################          " + "'", str2.equals("          1.4##########################.41.01.4##########################          "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0450120651_79459_ p.poodnar_nur p t  4stcefed stne ucoD eihpos sres  ", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass11 = javaVersion10.getClass();
        boolean boolean12 = javaVersion7.atLeast(javaVersion10);
        java.lang.String str13 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str15 = javaVersion14.toString();
        boolean boolean16 = javaVersion7.atLeast(javaVersion14);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str21 = javaVersion20.toString();
        boolean boolean22 = javaVersion18.atLeast(javaVersion20);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass24 = javaVersion23.getClass();
        boolean boolean25 = javaVersion20.atLeast(javaVersion23);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion27);
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean30 = javaVersion27.atLeast(javaVersion29);
        boolean boolean31 = javaVersion23.atLeast(javaVersion29);
        boolean boolean32 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean34 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion33);
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str36 = javaVersion35.toString();
        boolean boolean37 = javaVersion33.atLeast(javaVersion35);
        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass39 = javaVersion38.getClass();
        boolean boolean40 = javaVersion35.atLeast(javaVersion38);
        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean42 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion41);
        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str44 = javaVersion43.toString();
        boolean boolean45 = javaVersion41.atLeast(javaVersion43);
        org.apache.commons.lang3.JavaVersion javaVersion46 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass47 = javaVersion46.getClass();
        boolean boolean48 = javaVersion43.atLeast(javaVersion46);
        boolean boolean49 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion46);
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean51 = javaVersion46.atLeast(javaVersion50);
        boolean boolean52 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion50);
        boolean boolean53 = javaVersion38.atLeast(javaVersion50);
        org.apache.commons.lang3.JavaVersion javaVersion54 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean55 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion54);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray56 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion7, javaVersion29, javaVersion38, javaVersion54 };
        java.lang.String str57 = org.apache.commons.lang3.StringUtils.join(javaVersionArray56);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.9" + "'", str15.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.4" + "'", str21.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1.4" + "'", str36.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.4" + "'", str44.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + javaVersion46 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion46.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + javaVersion54 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion54.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(javaVersionArray56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1.61.41.50.91.7" + "'", str57.equals("1.61.41.50.91.7"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", "                                                 4.1                                                ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaOracleCoraaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("q2n", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "q2" + "'", str2.equals("q2"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444444", 463);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                            44444444444444444444444444444444444" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                            44444444444444444444444444444444444"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                            44444444444444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "3", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtualMachine", "0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9//java.oracle.com/0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachine" + "'", str2.equals("/Library/Java/JavaVirtualMachine"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0450120651_79459_ p.poodnar_nur p t  4stcefed stne ucoD eihpos sres  ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 8, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4################################################hi!#################################################me/jrelMVirtuv/Jvry/J/Libr4444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4################################################hi!#################################################me/jrelMVirtuv/Jvry/J/Libr4444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.4################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4###############################################################################################" + "'", str1.equals("1.4###############################################################################################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "NOITACIFICEPS IPA MROFTALP AVAJ", "################################################hi!#################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.", "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("Chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                1.4                                                 ", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ar", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Http://java.oracl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracl" + "'", str1.equals("Http://java.oracl"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "       ...", "OracleCor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "71.71.7sun.wt.CGrphicsEnvironment1.71.71.71.71.71.71.71.7" + "'", str2.equals("71.71.7sun.wt.CGrphicsEnvironment1.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.AWT.cgRAPHICSeNVIRONMENT", 80, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENTaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libr", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNhi!0-bA5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "     8-ftu");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444444", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed modeMixed ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("OracleCor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCo" + "'", str1.equals("OracleCo"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.5", "", 56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENTnsio", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                  /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("                  /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc" + "'", str1.equals("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "0450120651_79459_ p.poodnar_nur p t  4stcefed stne ucoD eihpos sres  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bomc", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bom" + "'", str2.equals("1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.71.71.71.71.7sun.awt.cgraphicsenvirccj/a/.os/brv.bom"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "######", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Http://java.oracl", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracl" + "'", str2.equals("Http://java.oracl"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.6", ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str2.equals(":.ava/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus", (java.lang.CharSequence) "                     4.1                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray4 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, ":");
        java.lang.String[] strArray8 = new java.lang.String[] { "Oracle Cor" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, ":");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "1.5", (int) (byte) 10, (int) (byte) 10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence[]) strArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/contents/home/jrealmavirtuava/javary/ja/libroracle corchines/jdk1.7.0_80.jdk/c", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ORACLE CORHI!HI!HI!HI!HI!HI!HI!H0.9!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle Corporation", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle " + "'", str2.equals("Oracle "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LIBR", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        long[] longArray6 = new long[] { 100, 146, 0, 10, 100, 463 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b1Mixed mode                                  ", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  " + "'", str2.equals("1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  1.7.0_80-b1Mixed mode                                  "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        long[] longArray3 = new long[] { 0, 0L, (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 100, (byte) 10 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Http://java.oracl", 105, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################Http://java.oracl############################################" + "'", str3.equals("############################################Http://java.oracl############################################"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode                                                                                                    Mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.71.71.71.7sun.awt.CGrap10.14.3", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.7sun.awt.CGrap10.14.3" + "'", str2.equals("1.71.71.71.7sun.awt.CGrap10.14.3"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str14 = javaVersion13.toString();
        boolean boolean15 = javaVersion11.atLeast(javaVersion13);
        boolean boolean16 = javaVersion9.atLeast(javaVersion13);
        boolean boolean17 = javaVersion2.atLeast(javaVersion13);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.4" + "'", str14.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 100, (byte) 10 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 18.0f, (float) 28L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "           /Users/sophie           ", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", "                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!0-b15", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVOracleCorchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVi", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                        hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "J4v4(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J4v4(TM) SE Runtime Environment" + "'", str2.equals("J4v4(TM) SE Runtime Environment"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1.71.71.71.71.71.71.71.7", (java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("uSERSSOPHIE", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleCor/Users/sophie/Documents..", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrelMVirtuv/Jvry/J/Libr", (java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("   Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.4", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 1.4 " + "'", str2.equals(" 1.4 "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "CHINES/JDK:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR7:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBR_:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRJDK/CONTENTS/HOME/JREALMAVIRTUAVA/JAVARY/JA/LI:.AVA/EXTENSIONS:/USR/LIB/JAVARY/JA/EXTENSIONS:/SYSTEM/LIBRAVARY/JA/EXTENSIONS:/NETWORK/LIBRAVARY/JA/EXTENSIONS:/LIBRAVARY/JA/USERS/SOPHIE/LIBRR", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("noitacificepS IPA mroftalP ava                                                  ", 0, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS IPA mroftalP ava                                                  " + "'", str3.equals("noitacificepS IPA mroftalP ava                                                  "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/LibrOracle Corchines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", 4, 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...i!hi...", 9, "aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...i!hi..." + "'", str3.equals("...i!hi..."));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4.1", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.1" + "'", str2.equals("4.1"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "US", (java.lang.CharSequence) "q2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Mixed mode", (int) (byte) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "boJretnirPC.xsocam.twawl.nus");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("CHINES4...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CHINES4...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA" + "'", str1.equals("AAAAAAAA/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2XAAAAAAAAA"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("NOITACIFICEPS IPA MROFTALP AVAJ", 463, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.71.71.71.7sun.awt.CGrap10.14.3", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("OracleCor/Users/sophie/Documents..", "", "noitacificepS IPA mroftalP ava");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor/Users/sophie/Documents.." + "'", str3.equals("OracleCor/Users/sophie/Documents.."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, (double) 444444444444444444L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.4444444444444442E17d + "'", double3 == 4.4444444444444442E17d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "noitacificepaSa aIPAa amroftalaPa aava");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR", 13, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR" + "'", str3.equals("/VAR11b-08.42sU/:sessalc/tegrat/0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU//VAR"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44444444444444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("uSERSSOPHIE", (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, (int) (byte) 1, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "##########################################hi!#################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4#############################################1.4##############################################", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "J4V4(TM)SERUNTIMEENVIRONMENT", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        float[] floatArray6 = new float[] { (-1.0f), (short) 100, 52L, 0, (short) 10, 1L };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass12 = floatArray6.getClass();
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 5, 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJNOITACIFICEPS IPA MROFTALP AVAJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SUN.AWT.cgRAPHICSeNVIRONMENTnsio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTnsio" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENTnsio"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                    sun.lwawt.macosx.CPrinterJob                                    ", "n.awt.CGraphicsEnvironment1.71.71.71.7sun.awt.CGraph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.lwawt.macosx.CPrinterJob                                    " + "'", str2.equals("                                    sun.lwawt.macosx.CPrinterJob                                    "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.4##########################.41.01.4##########################", "IBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-B15", 212, "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnem" + "'", str3.equals("1.7.0_80-B15tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nustnem"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("       ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       ..." + "'", str1.equals("       ..."));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        long[] longArray6 = new long[] { 0, 'a', 100, (byte) 10, (byte) 1, '#' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.Class<?> wildcardClass9 = longArray6.getClass();
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) ".71.71.71.7sun.awt.cgraphicsenvironment1.71.71.71.7.71.71.71.7sun.awt.cgraphicsenv######", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(":/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: :/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus" + "'", str3.equals("tnemnorivnEscihparGC.twa.nustnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.LWCToolkit", "csenvironment1.71.71.71.7agr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("b/javary/J");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmode" + "'", str1.equals("Mixedmode"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 31, (float) 7L, 1.4f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.4f + "'", float3 == 1.4f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95497_1560210540/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                                                                                                            ::::::::::::::::JAVA(TM) SE RUNTIME ENVIRONMENT::::::::::::::::", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "", (int) (byte) 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("11b-08.42", ":", (int) (short) 100);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("utf-8     ", strArray5, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ers/_v/6v597zmn4_v31cq2n2xaaaaaaaaa", ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM ################################################", strArray9, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "utf-8     " + "'", str10.equals("utf-8     "));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM ################################################" + "'", str14.equals("Java HotSpot(TM) 64-Bit Server VM ################################################"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporation                                                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation                                                                                                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        char[] charArray4 = new char[] { ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Cor", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corhi!hi!hi!hi!hi!hi!hi!...", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("OracleCor444444444", 99, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCor444444444                                                                                 " + "'", str3.equals("OracleCor444444444                                                                                 "));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, (long) 4, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444Oracle Corhi!hi!hi!hi!hi!hi!hi!h0.9!hi!hi!hi!hi!hi!hi!hi!44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7.0_80-B15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (long) 78);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78L + "'", long2 == 78L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        short[] shortArray4 = new short[] { (byte) 1, (byte) 10, (byte) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0450120651_79459_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95497_1560210540/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(124, 463, 78);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78 + "'", int3 == 78);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("OracleCor", "SUN.AWT.cgRAPHICSeNVIRONMENTnsions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.aaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2xaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "3", 3420);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, 0.0d, 4.4444444444444442E17d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("IBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mixedmode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80-b1Mixed mode                                  ", (java.lang.CharSequence) "##########################################hi!#################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /                                                                                               /", (java.lang.CharSequence) "24.80-b111.71.71.71.7sun.awt.CGraphicsEnvironment1.71.71.71.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/uSERS/SOPHIE", "javalpacificepsipamroftanoit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

