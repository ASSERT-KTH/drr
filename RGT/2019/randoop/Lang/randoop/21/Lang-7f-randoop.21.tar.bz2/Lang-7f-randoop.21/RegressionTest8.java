import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "                                 ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4", "x86_6U");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specificati", (java.lang.CharSequence) "                                                                                       /uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0a-1a1a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-1a1a10" + "'", str1.equals("0a-1a1a10"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444444", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG0.0hi!10.0hi!10.0hi!10.0hi!10.0hi!", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#4a4a44" + "'", str15.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nus" + "'", str1.equals("tiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nus"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), (double) 13L, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                               1.3", (java.lang.CharSequence) "0.9                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("v", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "v" + "'", str2.equals("v"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("X86_64");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100a1a10a1a100a100", "###a#a#4", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1a10a1a100a100" + "'", str3.equals("100a1a10a1a100a100"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0487.0/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        ", 600);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!", (int) 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!                               " + "'", str3.equals("                               10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!                               "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) ' ', 1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("32.041001.7.0_80-B14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.0100.032.010.034.00.010.14.310.14.310.14.310.14.310.14.31", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                       ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 187, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("tiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nus", 30, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "camt" + "'", str3.equals("camt"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4a4alM 4#4aVirtuava/Javary/Ja/Lib", 558);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 558 + "'", int2 == 558);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.9                          ", "                          44a4a4042540014 ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".9" + "'", str3.equals(".9"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100#1#-1#1#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("32.04100.04100.04100.04-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.04100.04100.04100.04-1.0" + "'", str1.equals("32.04100.04100.04100.04-1.0"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("32.04100.04100.04100.04-1.0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.04100.04100.04100.04-1.0" + "'", str2.equals("32.04100.04100.04100.04-1.0"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                              51.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa44A4A4#4a", (java.lang.CharSequence) "/users/sophie/users/sophi1.0va/JavaVirtualM 44a4a44", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0aaaaa", (int) (short) 44, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0aaaaa444444444444444444444444444444444444" + "'", str3.equals("1.0aaaaa444444444444444444444444444444444444"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4AAAAA", "0.9", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4a4alM 4#4aVirtuava/Javary/Ja/Libr", (java.lang.CharSequence) "32.041001.7.0_80-b14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4a4alM 4#4aVirtuava/Javary/Ja/Lib");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporation", " 100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 29, (int) (short) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /uSERS/SOPHIE");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG", "          1a0a100           3", 28, 47);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GGGGGGGGGGGGGGGGGGGGGGGGGGGG          1a0a100           3" + "'", str4.equals("GGGGGGGGGGGGGGGGGGGGGGGGGGGG          1a0a100           3"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "    v     ", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "    v     " + "'", charSequence2.equals("    v     "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44A4A4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44A4A4#4" + "'", str1.equals("44A4A4#4"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b1ava/JavaVirtualM 4...", 13, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0", "  /######/######/######/######/###");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng0000cf4n1x2n2qc13v_4nmz79..." + "'", str2.equals("ng0000cf4n1x2n2qc13v_4nmz79..."));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100 1 10 1 100 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100 1 10 1 100 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "100#1#-1#1#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        float[] floatArray2 = new float[] { 100, 87 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0a87.0" + "'", str4.equals("100.0a87.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0a87.0" + "'", str6.equals("100.0a87.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0#87.0" + "'", str8.equals("100.0#87.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 87.0f + "'", float9 == 87.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#87.0" + "'", str12.equals("100.0#87.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa100.0a87.0aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/ u SERS / SOPHIE", "100 10 100 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ u SERS / SOPHIE" + "'", str2.equals("/ u SERS / SOPHIE"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) 28L, (float) 29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 29.0f + "'", float3 == 29.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r", "sun.lwwt.mcosx.lwctoolkit", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r" + "'", str3.equals("ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.LWWT.MCOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("UUUUUUUUU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UUUUUUUUU" + "'", str1.equals("UUUUUUUUU"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4AAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4AAAAA" + "'", str1.equals("4AAAAA"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##################################", "32.0 100.0 100.0 100.0 -1.0", "v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################" + "'", str3.equals("##################################"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("  # a a 4");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa44A4A4#4a", charSequence1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaav", "10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ng0000cfn1x2n2qc13_nmz79560_0s4edof04", 91, "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificatioJava Platform API Specifng0000cfn1x2n2qc13_nmz79560_0s4edof04" + "'", str3.equals("Java Platform API SpecificatioJava Platform API Specifng0000cfn1x2n2qc13_nmz79560_0s4edof04"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "/#######", 27, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA//#######NS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA//#######NS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 44, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "U", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0.04100.0432.0410.0434.040.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("http://java.oracle.com/");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/#######A#AAAAA0.0 100.0 32.0...", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion10.atLeast(javaVersion12);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean16 = javaVersion7.atLeast(javaVersion10);
        boolean boolean17 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        char[] charArray11 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0487.0", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en                                                                                                  ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#4a4a44" + "'", str15.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "en                                                                                                  ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 60, 34);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) 0, (byte) 0, (byte) 1, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100 32 10 1 4 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        char[] charArray10 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                       /uSERS/SOPHIE", charArray10);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "U", charArray10);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.6", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " 4#4a4a44" + "'", str14.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " a#aaaaa4" + "'", str16.equals(" a#aaaaa4"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " ###a#a#4" + "'", str18.equals(" ###a#a#4"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/###############################", "########", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "    v     ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 60, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" ", 4, 1148);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/USERS/SOPHIE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0 87.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "A#AAAAA4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.0aaaaa444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0.0a100.0a32.0a10.0a34.0a0.0", "EIHPOS/SRESU/");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/0u0SERS0/0SOPHIE", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(214, 558, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                       100a52a0                                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                       100a52a0                                                                                                       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100a52a0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 21, "1.7.0_80-B1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B11.7.0_80-B" + "'", str3.equals("1.7.0_80-B11.7.0_80-B"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80", (java.lang.CharSequence) "/users/sophie/users/sophi1.0va/JavaVirtualM 44a4a44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 34L, 1.0d, (double) (short) 44);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.0d + "'", double3 == 44.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "AAAAA4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                        /", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "GGGGGGGGGGGGGGGGGGGGGGGGGGGG          1a0a100           3", (java.lang.CharSequence) "###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4#4a4a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4a4a44" + "'", str1.equals("4#4a4a44"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            sUN.LWWT.MCOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOtcwl.XSOCM.TWWL.NUs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            " + "'", str1.equals("TIKLOOtcwl.XSOCM.TWWL.NUs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("04254001", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04254001" + "'", str2.equals("04254001"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "  # a a 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        float[] floatArray2 = new float[] { 100, 87 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 10, 202);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0a87.0" + "'", str4.equals("100.0a87.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("          1a0a100           ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100a52a0", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 7, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " 4#4a4a44" + "'", str11.equals(" 4#4a4a44"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#100" + "'", str1.equals("1#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#1001#0#100"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Platform API Specification", "sophiesophiesophiesophiesophiesophi/###############################/###############################/###############################/###############################/###############################/##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Library/Java/JavaVirtualM 4#4a4a44aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/ u SERS / SOPHIE", "sun.awt.CGraphicsEnvironment", (int) '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaOaaaaa", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaOaaaaa" + "'", str2.equals("aaaaOaaaaa"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 35, 202);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        float[] floatArray5 = new float[] { 32.0f, 100L, (byte) 100, 100L, (byte) -1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 214, 9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0#100.0#100.0#100.0#-1.0" + "'", str9.equals("32.0#100.0#100.0#100.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.0#100.0#100.0#100.0#-1.0" + "'", str15.equals("32.0#100.0#100.0#100.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0a100.0a100.0a100.0a-1.0" + "'", str17.equals("32.0a100.0a100.0a100.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32.04100.04100.04100.04-1.0" + "'", str19.equals("32.04100.04100.04100.04-1.0"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("...tensions:/Library/Java/JavaVi...", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaa4444444444444444444444444444444444aaaaaaaaa", "en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        ", "1.0aaaaa444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaa4444444444444444444444444444444444aaaaaaaaa" + "'", str3.equals("aaaaaaaaa4444444444444444444444444444444444aaaaaaaaa"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                          44A4A4#4 ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       44A4A4#4 " + "'", str2.equals("                       44A4A4#4 "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie/users/sophie/users/sophie/users10.14.3/Java/JavaVirtualMe4#4a4a44", 52, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        char[] charArray12 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray12, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                       /uSERS/SOPHIE", charArray12);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "U", charArray12);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 1 10 1 100 10", charArray12);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##################################", charArray12);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "phie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " 4#4a4a44" + "'", str16.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " a#aaaaa4" + "'", str18.equals(" a#aaaaa4"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + " ###a#a#4" + "'", str20.equals(" ###a#a#4"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("boJretnirPC.xsocam.twawl.nus", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str2.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10_0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.CharSequence charSequence6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualM 4#4a4a44", '4');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence6, (java.lang.CharSequence[]) strArray9);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie" + "'", str4.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_..", 87, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        char[] charArray8 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(600, (-1), 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("ng0000cfn1x2n2qc13_nmz79560_0s4edof04", " 100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int[] intArray5 = new int[] { (byte) 1, (byte) 1, 2, 2, (short) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', (int) (byte) 1, (int) (short) 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 202, 901);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 202");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 35L, 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, (int) (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (short) 1, (int) (short) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0" + "'", str8.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                          44A4A4#4 ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        double[] doubleArray1 = new double[] { 35 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35.0" + "'", str4.equals("35.0"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a noitaroproc elcaro                                  4aaaaa#a ", 25);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("a4alM 4#4aVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "/Library/Java/JavaVirtualM 4#4a4a44aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                    ", (float) 901);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 901.0f + "'", float2 == 901.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tiklootcwl.xsocm.twwl.nus", (java.lang.CharSequence) "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "100 1 -1 1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("TIKLOOtcwl.XSOCM.TWWL.NUs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.0aaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                  Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API SpecificatioJava Platform API Specifng0000cfn1x2n2qc13_nmz79560_0s4edof04", (java.lang.CharSequence) "4444#4 /Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51687_1560278878/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("04254001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0425400" + "'", str1.equals("0425400"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" ###a#a#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " ###a#a#4" + "'", str1.equals(" ###a#a#4"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                  ne", (java.lang.CharSequence) " a#aaaaa4                                  oracle corporation a#aaaaa4                             v", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        uen        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        SERSen        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        /en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        SOPHIE", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, (double) 901.0f, 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 901.0d + "'", double3 == 901.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.0aaaaa444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaa100.0a87.0aaaaaaaaaaaaaaaaaaaaa", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " ", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/######");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 558, 35);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 100, 31);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 52 0" + "'", str7.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a52a0" + "'", str14.equals("100a52a0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "04254001", (java.lang.CharSequence) "100", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("14141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-414001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-414001" + "'", str1.equals("14141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-4140010 001 01 00114141-414001"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 29, 1);
        long long17 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 52 0" + "'", str7.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 52 0" + "'", str12.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("44A4A4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44A4A4#4" + "'", str1.equals("44A4A4#4"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_6U", (int) (byte) 44, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0" + "'", str4.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0aaaaa", "/uSERS/SOPHIE", 160);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("A#AAAAA4", '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                          44a4a4042540014 ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("v", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "v" + "'", str3.equals("v"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("      ...", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", (java.lang.CharSequence) "/######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4", "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4" + "'", str2.equals(" a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.0 100.0 100.0 100.0 -1.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("SUN.LWAWT.MACOSX.lwctOOLKIT", "v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKITv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rSUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str3.equals("SUN.LWAWT.MACOSX.lwctOOLKITv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rv/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rSUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, (int) (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) 'a', 87);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 0, 4598);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0" + "'", str8.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0", (java.lang.CharSequence) "0.0 100.0 32.0 10.0 34.0 0.0", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0a-1a1a10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("32.0a100.0a100.0a100.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Docu0a-1a1a10_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Docu0a-1a1a10_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("/Users/sophie/Docu0a-1a1a10_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0                                                 ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "/users/sophie/users/sophie/users/sophie/users10.14.3", (int) (byte) 1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("en");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0", strArray9, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10a2a31a10a10a10", (java.lang.CharSequence[]) strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" A#AAAAA4", strArray4, strArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str14.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " A#AAAAA4" + "'", str15.equals(" A#AAAAA4"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str16.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        " + "'", str1.equals("        "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141100414-14141", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaang0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/raaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            sUN.LWWT.MCOSX.lwctOOLKIT", "Java Platform API SpecificatioJava Platform API Specifng0000cfn1x2n2qc13_nmz79560_0s4edof04", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("shshshshshsh", "100 32 10 1 4 100", "############################################# A#AAAAA4##############################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int[] intArray5 = new int[] { (byte) 1, (byte) 1, 2, 2, (short) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 558, (int) (short) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', (int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 1 2 2 1" + "'", str9.equals("1 1 2 2 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#1#2#2#1" + "'", str11.equals("1#1#2#2#1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1a1a2a2a1" + "'", str17.equals("1a1a2a2a1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100#1#10#1#100#100", (java.lang.CharSequence) "44A4A4#4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 0, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#0#100" + "'", str8.equals("1#0#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" a#aaaaa4");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1", 52, "          1a0a100           3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          1a0a100        1          1a0a100         " + "'", str3.equals("          1a0a100        1          1a0a100         "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80-b1ava/JavaVirtualM 4#4a4a4/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1.7.0_80-b1ava/JavaVirtualM 4#4a4a41", (java.lang.CharSequence) "                              51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            sUN.LWWT.MCOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.LWWT.MCOSX.lwctOOLKIT" + "'", str1.equals("sUN.LWWT.MCOSX.lwctOOLKIT"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a52a0" + "'", str9.equals("100a52a0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            sUN.LWWT.MCOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/uSERS/SOPHIE", "                                  Oracle Corporation", (-1));
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 2, (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("          1a0a100        1          1a0a100         ", "a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4                                  oracle corporation a#aaaaa4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          1a0a100        1          1a0a100         " + "'", str2.equals("          1a0a100        1          1a0a100         "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en                                                                                                  ", "          1a0a100           3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          1a0a100        1          1a0a100         ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39 + "'", int2 == 39);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        short[] shortArray4 = new short[] { (short) 0, (short) -1, (short) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a-1a1a10" + "'", str6.equals("0a-1a1a10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15                                                                               ", 0, 202);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15                                                                               " + "'", str3.equals("1.7.0_80-b15                                                                               "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("0 25", strArray1, strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 25" + "'", str4.equals("0 25"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/USERS/SOPHIE/LIBRARY/JAVA//#######NS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA//#######NS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA//#######NS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 0, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "###a#a#4", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("OOOOOOOOO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OOOOOOOOO" + "'", str2.equals("OOOOOOOOO"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        float[] floatArray5 = new float[] { 32.0f, 100L, (byte) 100, 100L, (byte) -1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0#100.0#100.0#100.0#-1.0" + "'", str9.equals("32.0#100.0#100.0#100.0#-1.0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                  ", charSequence1, 214);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 3, 1148);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 52 0" + "'", str6.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10045240" + "'", str8.equals("10045240"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaa44A4A4#4a", "aaaaaaaaaaaaaaaaaaaaaaaaaa44A4A4#4a");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualM 4#4a4a44aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "SUN.LWWT.MCOSX.lwctOOLKIT", "1.6");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        char[] charArray8 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "           100.0#87.0           ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4#4a4a44" + "'", str12.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " a#aaaaa4" + "'", str14.equals(" a#aaaaa4"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                    100", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwwt.mcosx.LWCToolkit", "/ u SERS / SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str2.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 1, (byte) -1, (byte) 1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#1#-1#1#1" + "'", str8.equals("100#1#-1#1#1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "10_0");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (java.lang.CharSequence[]) strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                       /uSERS/SOPHIE", strArray3, strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /v");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie" + "'", str10.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "                                                                                       /uSERS/SOPHIE" + "'", str12.equals("                                                                                       /uSERS/SOPHIE"));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("  ", "###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########", (int) (byte) -1, 901);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########" + "'", str4.equals("###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########Specification API Platform Java###########################################/########"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "EIHPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0487.0/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1", " 4#4a4a44L");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("32.0#100.0#100.0#100.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0#100.0#100.0#100.0#-1.0" + "'", str1.equals("32.0#100.0#100.0#100.0#-1.0"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "AAAAA4", (java.lang.CharSequence) "    /users/sophie/users/sophie/users/sophie/users10.14.3     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sophiesophiesophiesophiesophiesophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophiesophiesophiesophiesophiesophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        int[] intArray5 = new int[] { (byte) 0, 87, 52, 28, 202 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 87 52 28 202" + "'", str7.equals("0 87 52 28 202"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100 1 10 1 100 100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3/jAVA/jAVAvIRTUALmE4#4A4A44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3/jAVA/jAVAvIRTUALmE4#4A4A44" + "'", str1.equals("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3/jAVA/jAVAvIRTUALmE4#4A4A44"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) -1, (double) 13L, 9.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "29.0460.040.0", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1 100 10", "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specificatio", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "hi!", 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(" a#aaaaa4", strArray6, strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                       /uSERS/SOPHIE", strArray6, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            sUN.LWWT.MCOSX.lwctOOLKIT", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " a#aaaaa4" + "'", str12.equals(" a#aaaaa4"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "                                                                                       /uSERS/SOPHIE" + "'", str16.equals("                                                                                       /uSERS/SOPHIE"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str17.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str22.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444#4 /Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51687_1560278878/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a4alM 4#4aVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "                             boJretnirPC.xsocam.twawl.nus                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.310.14.310.14.310.14.310.14.310.0100.032.010.034.00.010.14.310.14.310.14.310.14.310.14.31", "1 100 10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int[] intArray1 = new int[] { 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, (-1));
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 31, 27);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("44A4A4#4", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    44A4A4#4" + "'", str2.equals("                                                    44A4A4#4"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 33, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 97, (int) (short) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) (byte) -1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0" + "'", str4.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4a4alM 4#4aVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("04254");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4254L + "'", long1 == 4254L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.04100.0432.0410.0434.040.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(".9", (float) 2020);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9f + "'", float2 == 0.9f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                       /uSERS/SOPHIE", "10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       /uSERS/SOPHIE" + "'", str2.equals("                                                                                       /uSERS/SOPHIE"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "#######################################################################################", 91);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/44a4a4#4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "UTF-8");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "Java Virtual Machine Specification");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0", strArray3, strArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ', 33, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0" + "'", str8.equals("A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                      /Users/sophie", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "UTF-8");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/#######");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1001.7.0_80-b1 1.7.0_80-b1101.7.0_80-b1 1.7.0_80-b11001.7.0_80-b1 1.7.0_80-b10", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str8.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("O", "44a4a4#4 ", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3/JAVA/JAVAVIRTUALME4#4A4A44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 52, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100.0 87.0", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100.0 87.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100.0 87.0"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("    v     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    v     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 33, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 97, (int) (short) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0" + "'", str4.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        char[] charArray9 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) (short) 100, 97);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4#4a4a44" + "'", str13.equals(" 4#4a4a44"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 202, (long) 600, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 600L + "'", long3 == 600L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#########", "44444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0aaaaa444444444444444444444444444444444444", " A#AAAAA4                        ", "                        /");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0aaaaa                                    " + "'", str3.equals("1.0aaaaa                                    "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/users/sophie/users/sophie/users/sophie/users10.14.3/java/javavirtualme4#4a4a44", "sun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/users/sophie/users/sophie/users10.14.3/java/javavirtualme4#4a4a44" + "'", str2.equals("/users/sophie/users/sophie/users/sophie/users10.14.3/java/javavirtualme4#4a4a44"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ", "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("...tensions:/Library/Java/JavaVi...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 52 0" + "'", str7.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 52 0" + "'", str10.equals("100 52 0"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1148, 0.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1148.0f + "'", float3 == 1148.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "x86_64");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                                 1.3", (java.lang.CharSequence) "44A4A4#4 ", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2, (double) 2.0f, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100 1 10 1 100 100", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1 10 1 100 100" + "'", str2.equals("100 1 10 1 100 100"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnviron", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnviron" + "'", str2.equals("en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnviron"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa A#AAAAA4                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0#87.0", (java.lang.CharSequence) "1.0aaaaa444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        int[] intArray1 = new int[] { 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "32.04100.04100.04100.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.04100.04100.04100.04-1.0" + "'", str2.equals("32.04100.04100.04100.04-1.0"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80-b15", "4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        int[] intArray1 = new int[] { 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) 10, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (short) 100, (int) (short) 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (byte) 44, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', (int) 'a', 87);
        int int23 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0", 8.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0425400", 91, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("GGGGGGGGGGGGGGGGGGGGGGGGGGGG          1a0a100           3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"GGGGGGGGGGGGGGGGGGGGGGGGGGGG          1a0a100           3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 6, (float) 73);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4", "A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4" + "'", str2.equals("a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4 oracle corporation a#aaaaa4"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/ u SERS / SOPHIE/ u SERS / SOPHIE/ u SERS / SOPHIE/ u SERS / SOPHIE/ u SERS / SOPHIE/ u SERS / SOPHIE", charArray7);
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  # a a 4", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Library/Java/JavaVirtualM 4#4a4a44", 31, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/users/sophie/users/sophie/users/sophie/users10.14.3/java/javavirtualme4#4a4a44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 901);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(217L, (long) 13, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 217L + "'", long3 == 217L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 100, 31);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 10, 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 0, 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 52 0" + "'", str7.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10045240" + "'", str14.equals("10045240"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100 52 0" + "'", str20.equals("100 52 0"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaa                                                ", "", "                                 ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4                                  ORCLE CORPORTION A#AAAAA4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaa                                                " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaa                                                "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", "        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "    v     ", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("GGUS", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GGUS" + "'", str9.equals("GGUS"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        long[] longArray3 = new long[] { (byte) 100, '4', 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a52a0" + "'", str8.equals("100a52a0"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a52a0" + "'", str12.equals("100a52a0"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Sun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                              51.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "en                                                                                                  ", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("B", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "B" + "'", str3.equals("B"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Mac OS X", "1 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                            v");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0425400");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.41.432.0#100.0#100.0#100.0#-1.0", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("32.04100.04100.04100.04-1.0", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.", "hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                  ", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "44A4A4#4");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                  " + "'", str7.equals("                                  "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "0#100#10#10#0#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100 1 10 1 100 10", "32.04100.04100.04100.04-1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                               10.0hi!10.0hi!10.0hi!10.0hi!10.0hi!                               ", (java.lang.CharSequence) "4a4alM 4#4aVirtuava/Javary/Ja/Lib");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" 4#4a4a44L", 97, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".40a-1a1a10", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".40a-1a1a10" + "'", str2.equals(".40a-1a1a10"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        short[] shortArray6 = new short[] { (short) 0, (short) 100, (byte) 10, (short) 10, (short) 0, (byte) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 187, (int) (short) 1);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a100a10a10a0a10" + "'", str9.equals("0a100a10a10a0a10"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/0u0SERS0/0SOPHIE", "X86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("A#AAAAA4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A#AAAAA4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        G        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 11, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j" + "'", str1.equals("ions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 7.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  ", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0                                                 ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " ###a#a#4" + "'", str11.equals(" ###a#a#4"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/uSERS/SOPHIE/dOCU0A-1A1A10_51687_1560278878AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("    /users/sophie/users/sophie/users/sophie/users10.14.3     ", "...tensions:/Library/Java/JavaVi...", (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...tensions:/Library/Java/JavaVi...    /users/sophie/users/sophie/users/sophie/users10.14.3     " + "'", str4.equals("...tensions:/Library/Java/JavaVi...    /users/sophie/users/sophie/users/sophie/users10.14.3     "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                       /uSERS/SOPHIE", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa A#AAAAA4                        ", 2020);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE", "ng0000cf4n1x2n2qc13v_4nmz79...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE" + "'", str2.equals("4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4" + "'", str1.equals("A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 60, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "35.0", charSequence1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", (java.lang.CharSequence) "/0u0SERS0/0SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("a#aaaaa4...", "#a#aaaaa4", "0 87 52 28 202");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualM 4#4a4a44aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALm 4#4A4A44AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALm 4#4A4A44AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("44a4alM 4#4aVirtuava/Javary/Ja/Libr", "4a4alM 4#4aVirtuava/Javary/Ja/Libr");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      ", (java.lang.CharSequence) "0.0a0.43a0.01a0.23a0.001a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 202.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 202.0f + "'", float2 == 202.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 44, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("EN        sun.lwwt.mcosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EN       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                       100a52a0                                                                                                       ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1 0 100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("    v     0.0 100.0 32.0 10.0 3 .0 0.0", "1.7.0_80-b14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "    v     0.0 100.0 32.0 10.0 3 .0 0.0" + "'", str4.equals("    v     0.0 100.0 32.0 10.0 3 .0 0.0"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 6, "/en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        uen        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        SERSen        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        /en        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        sun.awt.CGraphicsEnvironmenten        SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(87, (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "                                                                                                1.3", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        float[] floatArray2 = new float[] { 100, 87 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 28, 10);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0a87.0" + "'", str4.equals("100.0a87.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 87.0f + "'", float5 == 87.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 87.0f + "'", float6 == 87.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("rbiL/aJ/yravaJ/avautriVa4#4 Mla4a4", 6, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...J/yravaJ/avautriVa4#4 M..." + "'", str3.equals("...J/yravaJ/avautriVa4#4 M..."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "/users/sophie/users/sophie/users/sophie/users10.14.3/java...", 31, (int) (byte) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ /v");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100a52a0", 1148, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          100a52a0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          100a52a0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa A#AAAAA4                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa A#AAAAA4                        " + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa A#AAAAA4                        "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                 Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4                                  Oracle Corporation A#AAAAA4", (java.lang.CharSequence) "tiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nusX SO caMtiklooTCWL.xsocm.twwl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    v     0.04100.0432.0410.0434.040.0", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("a#aaaaa4  # a a 4", (int) (byte) 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specificatio", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaa100.0a87.0aaaaaaaaaaaaaaaaaaaaa", "24.80-b11", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-B144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("1.7.0_80-B14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10a2a31a10a10a10", "##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ##### ", (int) (byte) 10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("##################################", "/lIBRARY/jAVA/jAVAvIRTUALm 4#4A4A44AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################################" + "'", str2.equals("##################################"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "/USERS/SOPHIE", 1);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "x86_6U");
        java.lang.String[] strArray11 = null;
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray11, strArray13);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...tensions:/Library/Java/JavaVi...", strArray9, strArray13);
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "...tensions:/Library/Java/JavaVi...", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sophie" + "'", str14.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "...tensions:/Library/Java/JavaVi..." + "'", str16.equals("...tensions:/Library/Java/JavaVi..."));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence) "/users/sophie/users/sophie/users/sophie/users10.14.3/java...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/users/sophie/users/sophie/users/sophie/users10.14.3/java...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 11, 73.0f, 9.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                       44A4A4#4 ", "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS10.14.3/JAVA/JAVAVIRTUALME4#4A4A44", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       44A4A4#4 " + "'", str3.equals("                       44A4A4#4 "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE", "    v     0.0 100.0 32.0 10.0 3 .0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE" + "'", str2.equals("4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("##### ", (float) 214);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 214.0f + "'", float2 == 214.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51687_1560278878/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "A#AAAAA0.0 100.0 32.0 10.0 34.0 0.0", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "x86_64");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10045240", 49, "4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE4 u SERS 4 SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 u SERS 4 SOPHIE4 u100452404 u SERS 4 SOPHIE4 u " + "'", str3.equals("4 u SERS 4 SOPHIE4 u100452404 u SERS 4 SOPHIE4 u "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" 4#4a4a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 4#4A4A44" + "'", str1.equals(" 4#4A4A44"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/users/sophie/users/sophi1.0va/JavaVirtualM 44a4a44", "tiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nusx so camtiklootcwl.xsocm.twwl.nus", "                                sophiesophiesophiesophiesophiesophi                                 ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/users/sophie/users/sophi1.0va/JavaVirtualM 44a4a44" + "'", str4.equals("/users/sophie/users/sophi1.0va/JavaVirtualM 44a4a44"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("EN        sun.lwwt.mcosx.CPrinterJob", 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        short[] shortArray6 = new short[] { (short) 0, (short) 100, (byte) 10, (short) 10, (short) 0, (byte) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', (int) ' ', (int) ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 27, 0);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a100a10a10a0a10" + "'", str13.equals("0a100a10a10a0a10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 100 10 10 0 10" + "'", str16.equals("0 100 10 10 0 10"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/######");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaa", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "############################################# A#AAAAA4##############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("rbiL/aJ/yravaJ/avautriVa4#4 Mla4a4", "51.0", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 600L, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0425400aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4" + "'", str1.equals("                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                 1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10#2#31#10#10#10", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Specification API Platform JavaJava Platform API SpecificatioSpecification API Platform JavaJava ", "########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification API Platform JavaJava Platform API SpecificatioSpecification API Platform JavaJava " + "'", str2.equals("Specification API Platform JavaJava Platform API SpecificatioSpecification API Platform JavaJava "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44a4a4#4 ", "");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0a100.0a32.0a10.0a34.0a0.0", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray8, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str11.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 1, (byte) 10, (byte) 1, (byte) 100, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 1 10 1 100 100" + "'", str8.equals("100 1 10 1 100 100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a1a10a1a100a100" + "'", str10.equals("100a1a10a1a100a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 1 10 1 100 100" + "'", str12.equals("100 1 10 1 100 100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a1a10a1a100a100" + "'", str15.equals("100a1a10a1a100a100"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Specification API Platform JavaJava Platform API SpecificatioSpecification API Platform JavaJava ", (java.lang.CharSequence) "1.7.0_80-b144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 558, 2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("35", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        int[] intArray6 = new int[] { (short) 10, 2, 31, (short) 10, (byte) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a2a31a10a10a10" + "'", str10.equals("10a2a31a10a10a10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a2a31a10a10a10" + "'", str12.equals("10a2a31a10a10a10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10#2#31#10#10#10" + "'", str14.equals("10#2#31#10#10#10"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4100.0432.0410.0434.040.0", "a#aaaaa4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4100.0432.0410.0434.040.0" + "'", str2.equals("4100.0432.0410.0434.040.0"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 87.0", "32.0#100.0#100.0#100.0#-1.0");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sUN.LWWT.MCOSX.lwctOOLKIT", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/users/sophie/users/sophie/users/sophie/users10.14.3", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        int[] intArray1 = new int[] { 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) 10, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (short) 100, (int) (short) 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 27, (float) 13L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 27.0f + "'", float3 == 27.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4 Oracle Corporation A#AAAAA4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4" + "'", str1.equals("A#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4OracleCorporationA#AAAAA4"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b1ava/JavaVirtualM 4#4a4a4/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1.7.0_80-b1ava/JavaVirtualM 4#4a4a41", (java.lang.CharSequence) "1.7.0_80-b1ava/JavaVirtualM 4#4a4a4", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Sun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit", 12, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaSun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit" + "'", str4.equals("aaaaaaaaaaaaSun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkitMac OS Xsun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("29.0460.040.0", "/Library/Java/JavaVirtualM 4#4a4a44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("SUN.LWAWT.MACOSX.lwctOOLKIT", "      ...", "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        float[] floatArray6 = new float[] { (byte) 0, (byte) 100, ' ', 10, 34, (short) 0 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 34, (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.04100.0432.0410.0434.040.0" + "'", str12.equals("0.04100.0432.0410.0434.040.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "x86_6U", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "44a4a4#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".9", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r" + "'", str3.equals("v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS Xaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Mac OS Xaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaOaaaaa", "en        ", 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "############################################# A#AAAAA4##############################################", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0                                                 ", 91, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10_0", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10_0" + "'", str2.equals("10_0"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7.0_80-b1ava/JavaVirtualM 4#4a4a4/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1.7.0_80-b1ava/JavaVirtualM 4#4a4a41");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0487.0", "100 10 100 0", "  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0487.0" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0487.0"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4", "shshshshshsh");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4" + "'", str2.equals("                                 Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4                                  Orcle Corportion A#AAAAA4"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                      en        ", (short) 44);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 44 + "'", short2 == (short) 44);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("AAAAA4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAA4" + "'", str2.equals("AAAAA4"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "35", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51687_1560278878aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " a#aaaaa4                    ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "                              51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b" + "'", str2.equals("7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaa4444444444444444444444444444444444aaaaaaaa", (java.lang.CharSequence) "100 1 10 1 100 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        float[] floatArray2 = new float[] { 100, 87 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 0, 2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) ' ', 28);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0a87.0" + "'", str4.equals("100.0a87.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 87.0f + "'", float5 == 87.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 87.0" + "'", str9.equals("100.0 87.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 87.0f + "'", float14 == 87.0f);
    }
}

