import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporatio", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportio" + "'", str2.equals("Orcle Corportio"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaa4444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444aaaaaaaaaa" + "'", str1.equals("4444444444444444444444aaaaaaaaaa"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("!hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   ", 143);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/fo1.7.0_80-b15/var/fol", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folde");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/so#hie/Documents/defects4j/tm#/run_randoo#.#l_95958_1560211149/target/classes:/Users/so#hie/Documents/defects4j/framework/lib/test_generation/generation/randoo#-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179 + "'", int1 == 179);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 31, (double) 9.0f, (double) 143);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 7, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Co                                                                                                                                     ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("t", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t" + "'", str2.equals("t"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("nemnorivnE emitnuR ES )MT(avaJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/j", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/j" + "'", str2.equals("/Users/sophie/Documents/defects4j/j"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.awt.CGraphicsEnvironment", 52, (-1));
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "olkit", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "r/f", (java.lang.CharSequence) "raj.tnerruc-pjeihpos/sresU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.CPrinterJob", "java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java(TM) SE Runtime Environmen" + "'", str2.equals("java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 1, (double) 1.3f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2999999523162842d + "'", double3 == 1.2999999523162842d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" hi! hi!  ", "x86_64", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (java.lang.CharSequence) "                     mixed modi                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("444444ualMachineSpecification444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444ualMachineSpecification444444" + "'", str1.equals("444444ualMachineSpecification444444"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sunwwisxlwctkii", "java virtual machine specificationjava virtual machine specificatiHI!HI!H...java virtual machine specificationjava virtual machine specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunwwisxlwctkii" + "'", str2.equals("sunwwisxlwctkii"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("#########", "aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########" + "'", str2.equals("#########"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" ", "\n                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("p", "java virtual machine specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                        1.4", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        float[] floatArray4 = new float[] { (byte) -1, 1, 48, 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 48.0f + "'", float7 == 48.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r" + "'", str2.equals("r"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Platform API Specification", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                     \n");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("cTIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  rg.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cTIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  rg.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("cTIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  rg.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.Class<?> wildcardClass5 = javaVersion3.getClass();
        java.lang.Class<?> wildcardClass6 = javaVersion3.getClass();
        boolean boolean7 = javaVersion0.atLeast(javaVersion3);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Co                                                                                                                                     ", 8, "  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Co                                                                                                                                     " + "'", str3.equals("Oracle Co                                                                                                                                     "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("44444", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("MacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int[] intArray6 = new int[] { (byte) 100, (byte) 1, 10, 0, (short) -1, (byte) 0 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java virtual machine specificationjava virtual machine specificatiHI!HI!H...java virtual machine specificationjava virtual machine specifica", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4.1                        ", (java.lang.CharSequence) "/vr/folde ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed" + "'", str2.equals("mixed"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80-b15", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4.1       44444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaamixe");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4.1                        ", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "raj.tnerruc-pjeihpos/sresU/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLE cORPORAT", (java.lang.CharSequence) "######################1.5#######################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0000gn/T", "/", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Uss/shi/Lib4y/J4v4/Exnsins:/Lib4y/J4v4/J4v4Viu4M4hins/jdk1.7.0_80.jdk/nns/Hm/j/ib/x:/Lib4y/J4v4/Exnsins:/Nwk/Lib4y/J4v4/Exnsins:/Sysm/Lib4y/J4v4/Exnsins:/us/ib/j4v4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", " Corporat ", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mp/run_ran Corporat urrent.jar" + "'", str3.equals("/mp/run_ran Corporat urrent.jar"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("#", "hie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("44k44w4xs4wwnus", "44k44w4xs4wwnus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (int) (byte) 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35.0f, (double) 10L, (double) 26L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.", "44444", "Environment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       ", "1.r/folde");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4444444444", 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Virtual Machine Specification", 100, 270);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "J Vi.u Mhin Sifi.in");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Use...", "Vi.u Mhin Sifi.in");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("poratio", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tioapor" + "'", str2.equals("tioapor"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "J", (java.lang.CharSequence) "                        1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ndt", (java.lang.CharSequence) "aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi", "                      poratio                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "!hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HI!HI!H...", (java.lang.CharSequence) "noitacificepSenihcaMlautriVava");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaa444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1.7.0_80-b15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence[]) strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "51.0");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray11, strArray16);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", strArray4, strArray11);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str12.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str20.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str21.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nus", "Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("51.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.1", " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation ", 1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation .1" + "'", str4.equals(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation .1"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sunwwisxLWCTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation ", '#');
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "j", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi", (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("... SE Runtime Environment", strArray7, strArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA", (java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.split("r", "", 97);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("nemnorivnE emitnuR ES )MT(avaJ", strArray13, strArray19);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "... SE Runtime Environment" + "'", str14.equals("... SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "nemnorivnE emitnuR ES )MT(avaJ" + "'", str20.equals("nemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Sun.awt.CGraphicsEnvironment", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/javanTacTfTcpSnThcaMlau/TVa/aJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsE" + "'", str2.equals("Sun.awt.CGraphicsE"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "X SO CAM", (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.Class<?> wildcardClass6 = byteArray4.getClass();
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X SO CAM", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tiklooTCWL.xsocm.twwl.nus", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Co", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Co                                       " + "'", str2.equals("Oracle Co                                       "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("...####...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...####..." + "'", str1.equals("...####..."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        char[] charArray6 = new char[] { '#', '4', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophieava(TM) SE Runtime Environment", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "java(TM) SE Runtime Environmen", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/mp/run_ran Corporat urrent.jar", "", 25, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/mp/run_rant.jar" + "'", str4.equals("/mp/run_rant.jar"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("noitacificepSenihcaMlautriVava", "51.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("       ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...####...", 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environmen", "R/f");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environmen" + "'", str2.equals("Java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/mp/run_ran Corporat urrent.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/mp/run_ran Corporat urrent.ja" + "'", str1.equals("/mp/run_ran Corporat urrent.ja"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ndt", "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       ", (int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt" + "'", str4.equals("4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke", (java.lang.CharSequence) "C  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke" + "'", charSequence2.equals("sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("urrent.jar d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "urrent.jar d" + "'", str1.equals("urrent.jar d"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "j", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/mp/run_ran Corporat urrent.jar", 99, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/mp/run_ran Corporat urrent.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/mp/run_ran Corporat urrent.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "t", (java.lang.CharSequence) "###############################hi!                                ###############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi" + "'", str1.equals("/Users/sophi"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle Co                                       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("O...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"O...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) (short) 1, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "p", 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444", (java.lang.CharSequence) "nTacTfTcpSnThcaMlau/TVa/aJ", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "porati", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/D" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/D"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "r/folde", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(27, (int) (short) 10, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80-b1", "v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1" + "'", str2.equals("1.7.0_80-b1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444tnemnorivnE4444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444tnemnorivnE4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion1.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean14 = javaVersion1.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str16 = javaVersion15.toString();
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        boolean boolean18 = javaVersion1.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean21 = javaVersion19.atLeast(javaVersion20);
        boolean boolean22 = javaVersion15.atLeast(javaVersion20);
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion20);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.5" + "'", str16.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa444444444444444444444444444444444444444444", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA", (int) (byte) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "TCWL.xsocam.twawl.nus", (java.lang.CharSequence) "C  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hie/Documents/defects4j/tm#/run_randoo#.#l_95958_1560211149/target/classes:/Users/so#hie/Documents/defects4j/framework/lib/test_generation/gene", (java.lang.CharSequence) " Corporat");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("r", "                        1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r" + "'", str2.equals("r"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.5", "\n", 7);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52L, (double) 3.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/so#hie/Documents/defects4j/tm#/run_randoo#.#l_95958_1560211149/target/classes:/Users/so#hie/Documents/defects4j/framework/lib/test_generation/generation/randoo#-current.jar", (java.lang.CharSequence) "sunwwisxLWaTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 168 + "'", int2 == 168);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("java virtual machine specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("E51.0t");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"E51.0t\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Vi.u Mhin Sifi.in", "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       ", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Vi.u Mhin Sifi.in" + "'", str3.equals("Vi.u Mhin Sifi.in"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence) "P");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", charSequence2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java virtual machine specificationjava virtual machine specificatiHI!HI!H...java virtual machine specificationjava virtual machine specificatio", "N.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle C/vr/foldeOracle Co", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle C/vr/foldeOracle Co" + "'", str3.equals("Oracle C/vr/foldeOracle Co"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "                                  hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...                                  ");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "\n                                               ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporatio", "", (int) (byte) 1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!H...", strArray11, strArray16);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80-b15" + "'", str7.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.7.0_80-b15" + "'", str12.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "HI!HI!H..." + "'", str17.equals("HI!HI!H..."));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("NOITACIFICEPSENIHCAMLAUTRIVAVAJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"NOITACIFICEPSENIHCAMLAUTRIVAVAJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaa aaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!                                ", 125);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                " + "'", str2.equals("hi!                                "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (-1L), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/mp/run_ran Corporat urrent.jar", (java.lang.CharSequence) "java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java HotSpot(TM) 64-Bit Server VM", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("51.0");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', (int) (byte) 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.1.7", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.1.7                                       " + "'", str2.equals("sun.lwawt.1.7                                       "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0000gn/T", "Sun.awt.CGraphicsEnvironment", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sunwwisxLWCTkii1.41.21.41.2", (java.lang.CharSequence) "#########################/var/folde");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("             Corporat              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Corporat" + "'", str1.equals("Corporat"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 142 + "'", int4 == 142);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/var/folde", 0, 168);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folde" + "'", str3.equals("/var/folde"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/ d", charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("J Vi.u Mhin Sifi.in", "10.14.3", "cTIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  rg.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J Vi.u Mhin Sifi.in" + "'", str3.equals("J Vi.u Mhin Sifi.in"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#########################/var/folde");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################/VAR/FOLDE" + "'", str1.equals("#########################/VAR/FOLDE"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "cTIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  rg.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 1 + "'", byte10 == (byte) 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        char[] charArray5 = new char[] { '#', ' ', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/vr/folde/vr/folde/vr/folhi/vr/folde/vr/folde/vr/fol", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/j", (java.lang.CharSequence) "racle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J" + "'", str1.equals("J"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie", 125, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#########################/var/folde", (java.lang.CharSequence) "OracleC1.7", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1.7.0_80-b15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1.41.2", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.41.2" + "'", str7.equals("1.41.2"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ualMachineSpecification", "java(TM) SE Runtime Environmen", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) ".String;class java.io.File");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("j", "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", "mixed mode", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "j" + "'", str4.equals("j"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("44444", "aaaaaaaaaaaaaaaaaaaaaaamixe");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" hi! hi!  ", "sunwwisxLWCTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4.1       ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi" + "'", str3.equals("hi"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi" + "'", str5.equals("hi"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.8" + "'", str4.equals("1.8"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "nemnorivnE emitnuR ES )MT(avaJ", 68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation .1", (java.lang.CharSequence) "Orcle Corportio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("##1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J", "hi!", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.4");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "class java.io.Fileclass org.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, " ##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h##Or#cle Corpor#tion# ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "J" + "'", str6.equals("J"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "J" + "'", str9.equals("J"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(27.0d, (double) 52.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "4.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 143, (double) 3L, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("n.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "porati\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  ", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  " + "'", str2.equals("TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444aaaaaaaaaa", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "                                                                                          10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ".String;class java.io.File", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        char[] charArray5 = new char[] { 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "aaaaaaaaajava(TM) SE Runtime Environmenaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle Co                                       ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Co                                       " + "'", str2.equals("Oracle Co                                       "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "HI!HI!H...");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7", (int) ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("LWCToolkit", strArray4, strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaamixe", "", (int) (short) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("looTCWL.xs", strArray8, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LWCToolkit" + "'", str9.equals("LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "looTCWL.xs" + "'", str14.equals("looTCWL.xs"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "             US            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149", "sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt.macosx.cprinterjob", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/f", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/f                                          " + "'", str2.equals("/var/f                                          "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Co", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Co" + "'", str2.equals("Oracle Co"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaamixe", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion1.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean12 = javaVersion7.atLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("raj.tnerruc-pjeihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-pjeihpos/sresu/" + "'", str1.equals("raj.tnerruc-pjeihpos/sresu/"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ualmachinespecification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.1.7                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 3.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = javaVersion1.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean14 = javaVersion1.atLeast(javaVersion11);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Orcle Corportio");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "TiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nusTiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Environment", (java.lang.CharSequence) "                                                1.4                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...SERuntimeEnvironment", "ualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...SERuntimeEnvironment" + "'", str2.equals("...SERuntimeEnvironment"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation ", (java.lang.CharSequence) "Corporat");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORAT", "/var/folde");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORAT" + "'", str2.equals("ORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORAT"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) ".String;class java.io.File");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS Xixed mode", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS Xixed mode" + "'", str3.equals("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS Xixed mode"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ".0", 99, 9);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Vi.u Mhin Sifi.in");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(") SE Runtime Environmen", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############################hi!                                ###############################", 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaajava(TM) SE Runtime Environmenaaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaajava(TM) SE Runtime Environmenaaaaaaaaaa" + "'", str2.equals("aaaaaaaaajava(TM) SE Runtime Environmenaaaaaaaaaa"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("oracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporat", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Orcle Corportio", "E51.0t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportio" + "'", str2.equals("Orcle Corportio"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                  hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...                                  ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sunwwisxLWCTkii1.41.21.41.2");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" aahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!haaOracle Corporationa ", 51.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4" + "'", str2.equals("1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4Oracle Corporation1.4"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "TCWL.xscm.wwl.nus", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hie/librry/jv/extensions:/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   " + "'", str1.equals("                                   "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("##1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "urrent.jar d", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/so#hie/Documents/defects4j/tm#/run_randoo#.#l_95958_1560211149/target/classes:/Users/so#hie/Documents/defects4j/framework/lib/test_generation/generation/randoo#-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { '#', '4', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444eNVIRONMENT444444444444444444444444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "44k44w4xs4wwnus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "class java.io.Fileclass [Ljava.lang.String;class java.io.File", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "                                  hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...                                  ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS Xixed mode                                               ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "oracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporat", (java.lang.CharSequence) "Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/Http://java.oracle.com/", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ualmachinespecification", (java.lang.CharSequence) "sunwwisxLWCTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "", 97);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1.7.0_80-b15");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray14);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", ' ');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray21);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray25);
        int int27 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence[]) strArray26);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray26, "51.0");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray21, strArray26);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", strArray14, strArray21);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray9, strArray14);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray14);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("TiklooTCWL", strArray3, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str22.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str30.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str31.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "\n" + "'", str32.equals("\n"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TiklooTCWL" + "'", str34.equals("TiklooTCWL"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                               \n", (java.lang.CharSequence) "noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "mixedhi!mixedhi!mixedhi!mixedhi!mixedhi!mixed", (java.lang.CharSequence) "                                              poratio                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("java virtual machine specification", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, (long) ' ', (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "r/f", (java.lang.CharSequence) "TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PORATIO", "class java.io.Fileclass org.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("olkit", "#########################/var/folde");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/vr/folde", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde" + "'", str2.equals("/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1.R/FOLDE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("              hi!", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   ..." + "'", str2.equals("   ..."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("O...", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("s8666(T) E Rx_6m Ex68xmx_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s8666(T) E Rx_6m Ex68xmx_" + "'", str1.equals("s8666(T) E Rx_6m Ex68xmx_"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(125, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.12.14.1iikTCWLxsiwwnus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4.1                        ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444Environment444444444444444444444444444444444444444444444", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.awt.CGraphicsEnvironment", "urrent.ja");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//users/sophie/library/java/extensions:/library/java", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/library/java/extensions:/library/java" + "'", str2.equals("users/sophie/library/java/extensions:/library/java"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 27L, 1.0d, (double) 44444.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                        1.4", 0, "r/f");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        1.4" + "'", str3.equals("                        1.4"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob", "1.1", "oracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporatoracle Corporat");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 50, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".0", (int) (byte) 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    .0    " + "'", str3.equals("    .0    "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("urrent.jar d", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "urrent.jar d" + "'", str2.equals("urrent.jar d"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ualmachinespecification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ualmachinespecification" + "'", str2.equals("ualmachinespecification"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("... SE Runtime Environment", (double) 68);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.0d + "'", double2 == 68.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "Oracle Cor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt...", (java.lang.CharSequence) "Oracle Co                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                " + "'", str2.equals("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "r/f", (java.lang.CharSequence) "ORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORATORACLE CORPORAT", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "nTacTfTcpSnThcaMlau/TVa/aJ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sunwwisxLWCTkii444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("       ...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("racle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcar" + "'", str1.equals("noitaroproC elcar"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                    ", "...SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi! hi!", (java.lang.CharSequence) "hi!  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi! hi!" + "'", charSequence2.equals("hi! hi!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, 44444.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(68, 1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke", 143, "sophieava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophieava(TM) SE Runtime Environmentsophieavsopjava.io.File .String;classsun.lwawt.macosx.LWCToolkesophieava(TM) SE Runtime Environmentsophieav" + "'", str3.equals("sophieava(TM) SE Runtime Environmentsophieavsopjava.io.File .String;classsun.lwawt.macosx.LWCToolkesophieava(TM) SE Runtime Environmentsophieav"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (float) 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 15.0f + "'", float2 == 15.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("raj.tnerruc-pjeihpos/sresU", "/mp/run_ran Corporat urrent.ja", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#", 3, 270);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("J Vi.u Mhin Sifi.in", "1.3", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation ", '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "j", (java.lang.CharSequence[]) strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Oracle Corporatio", (int) (byte) 0, 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi!hi!h...", "SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!h..." + "'", str2.equals("hi!hi!h..."));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sJ", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sJaaaaaaaa" + "'", str3.equals("sJaaaaaaaa"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "tiklooTCWL.xsocm.twwl.nus");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("noitacificepSenihcaMlautriVava");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) 50, (double) 99);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.0d + "'", double3 == 99.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("j", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.awt.CGraphicsEnvironment", 52, (-1));
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":", (int) (byte) 100);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.4", strArray2, strArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.4" + "'", str14.equals("1.4"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", " ", "sun.awt.CGraphicsEnvironment" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray1, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " " + "'", str6.equals(" "));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35, (double) 68, 25.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.0d + "'", double3 == 25.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "TIO  PORATIO  PORATIO  PORATIO  PORATIO  PORATIO  ", (java.lang.CharSequence) "/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar/Users/sophiejp-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(27L, 6L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { '#', '4', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle C/vr/foldeOracle Co", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("java.io.File .String;class", 0, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.io.File .String;class" + "'", str3.equals("java.io.File .String;class"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "nTacTfTcpSnThcaMlau/TVa/aJ", (java.lang.CharSequence) "#########################/VAR/FOLDE", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Environment", 48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (int) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "javavirtualmachinespecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4444444444444444444444aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444aaaaaaaaaa" + "'", str1.equals("4444444444444444444444aaaaaaaaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/mp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/mp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444", 52, "######");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaa444444444444444444444444444444444444444444", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.cprinterjob", (java.lang.CharSequence) "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.R/FOLDE", (java.lang.CharSequence) "Oracle Corporatio", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#########################/var/folde");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################/var/folde" + "'", str1.equals("#########################/var/folde"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA", 179, "urrent.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVAurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jar" + "'", str3.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVAurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jarurrent.jar"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ORACLE4cORPORAT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle4Corporat" + "'", str1.equals("oracle4Corporat"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Cor", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orac..." + "'", str2.equals("Orac..."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                               \n", "p         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" taroproC ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "noitacificepSenihcaMlautriVavaJ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/mp/run_ran Corporat urrent.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" ", (int) (byte) 1, "/var/f");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32.0f, (double) 27, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 27.0d + "'", double3 == 27.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sunwwisxLWCTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21", "LWCToolkit", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sunwwasxa1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21" + "'", str5.equals("sunwwasxa1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.41.2", "#########################/VAR/FOLDE", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sophieava(TM) SE Runtime Environment", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phieava(TM) SE Runtime Environme" + "'", str2.equals("phieava(TM) SE Runtime Environme"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation " + "'", str2.equals(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HI!HI!H...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("X SO CAM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X SO CAM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt", " aahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!haaOracle Corporationa ", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("phieava(TM) SE Runtime Environme", "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt", " Corporat");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phieava(TM) SE Runtime Environme" + "'", str3.equals("phieava(TM) SE Runtime Environme"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str3 = javaVersion2.toString();
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        java.lang.Class<?> wildcardClass5 = javaVersion2.getClass();
        java.lang.String str6 = javaVersion2.toString();
        java.lang.String str7 = javaVersion2.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        float[] floatArray4 = new float[] { (byte) -1, 1, 48, 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 48.0f + "'", float6 == 48.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) ".String;class java.io.File", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "J Vi.u Mhin Sifi.in");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 99, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", (java.lang.CharSequence) "hi!hi!h...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("MAC OS X", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus", 179);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MAC OS X" + "'", str4.equals("MAC OS X"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "mixedhi!mixedhi!mixedhi!mixedhi!mixedhi!mixed", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("tiklooTCWL.xsocm.twwl.nus", " hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation .1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocm.twwl.nus" + "'", str2.equals("tiklooTCWL.xsocm.twwl.nus"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("NOITACIFICEPSENIHCAMLAUTRIVAVAJ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITACIFICEPSENIHCAMLAUTRIVAVAJ" + "'", str2.equals("NOITACIFICEPSENIHCAMLAUTRIVAVAJ"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "p         ", (java.lang.CharSequence) "44k44w4xs4wwnus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sopjava.io.File .String;classsun.lwawt.macosx.LWCToolke is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class java.io.Fileclass [Ljava.lang.String;class java.io.File", "hie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/vrr/fjndt", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sunww4sx4w44k44", "hi!  ", "oracle Corporat");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/vr/f", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           /vr/f           " + "'", str2.equals("           /vr/f           "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sunwwasxa1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21", (int) (byte) 0, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunwwasxa1.41.21.41.21.41.21.41...." + "'", str3.equals("sunwwasxa1.41.21.41.21.41.21.41...."));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "urrent.jar d");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                " + "'", str1.equals("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!a asun.awt.CGraphicsEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#########################/vsU/fords");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 142, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 142 + "'", int3 == 142);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  Java(TM) SE Runtime Environment hi! hi!  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ndt", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaajava(TM) SE Runtime Environmenaaaaaaaaaa", 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/vr/f", "1.r/folde####################1.5#######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("44k44w4xs4wwnus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44K44W4XS4WWNUS" + "'", str1.equals("44K44W4XS4WWNUS"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Environment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Environment" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Environment"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/vr/f");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("oracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporat");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaa", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          aaaaaaaaaaaaaaaaaaaaaaaaaaa           " + "'", str2.equals("          aaaaaaaaaaaaaaaaaaaaaaaaaaa           "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0, "lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("v/a/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/r");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "          aaaaaaaaaaaaaaaaaaaaaaaaaaa           ", (java.lang.CharSequence) "/mp/run_randoop.pl_95958_156021119/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaa", "HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!                                HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/fo1.7.0_80-b15/var/fol", Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.r/folde");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Co                                                                                                                                     ");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 135");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi!                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophiejp-current.jar", 10, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Http://java.oracle.com/", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oracle Corporatio", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", 48, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "sunwwisxLWaTkii1.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21.41.21");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ", "/var/folde");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, " ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "#########");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde", "0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde" + "'", str2.equals("/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde/vr/folde"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95958_1560211149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "noitacificepSenihcaMlautriVava");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/mp/run_ran Corporat urrent.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt", " hi! hi!  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "sunwwisxLWCTkii1.41.21.41.2", 143);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/mp/run_ran Corporat urrent.jaraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Mac OS X", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixedhi!mixedhi!mixedhi!mixedhi!mixedhi!mixed", "p");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.8f + "'", float1 == 1.8f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "r/folde");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("oracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporat", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporat" + "'", str2.equals("acle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporatoracle corporat"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                      poratio                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                      poratio                       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle Corporation", "Jv HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "users/sophie/library/java/extensions:/library/java", (java.lang.CharSequence) " Corporat");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(4.444444444444444E99d, (double) 3L, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sunwwisxLWCTkii1.41.21.41.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sunwwisxLWCTkii1.41.21.41.2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/javanTacTfTcpSnThcaMlau/TVa/aJ", "    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                ", (java.lang.CharSequence) "!ih              ", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("  ", "s8666(T) E Rx_6m Ex68xmx_");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaa aaaaa", (java.lang.CharSequence) "porati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("p         ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi! sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/var/f                                          ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaa444444444444444444444444444444444444444444", "en", (int) (short) 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 270, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                 hi!", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("class java.io.Fileclass org.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class java.io.Fileclass org.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class java.io.Fileclass org.apache.commons.lang3.JavaVersionclass [Fclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h##Or#cle Corpor#tion# ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("poratio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "poratio" + "'", str1.equals("poratio"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("   ...", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaa4444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa4444444444444444444444" + "'", str1.equals("aaaaaaaaaa4444444444444444444444"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "oracle Corporat", 143, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.41.2", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa" + "'", str1.equals("aaaaaaaaaa"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt", 125, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt" + "'", str3.equals("4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       1.71.71.71.71.71.71.71.71tiklooTCWL.xsocam.twawl.nus4.1       dt"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hOracle Corporation .1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(143, 26, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        char[] charArray8 = new char[] { 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("tiklooTCWL.xsocm.twwl.nus", 35, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" hi! hi!  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

