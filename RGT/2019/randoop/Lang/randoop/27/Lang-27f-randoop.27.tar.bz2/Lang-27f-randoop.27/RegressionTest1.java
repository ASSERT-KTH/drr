import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(".310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolX SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLX SO CAM" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLX SO CAM"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("HI!", "aa...", "10.14.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("\n", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#Java Platform API Specification", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#Java Platform API Specification" + "'", str2.equals("#Java Platform API Specification"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ne", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ne" + "'", str2.equals("ne"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "sun.lwawt.macosx.LWCToolki", 10, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str4.equals("10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lsun.l");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_64", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.LWWT.MCOSX.LWCTOOLKIT", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWWT.MCOSX.LWCTOOLKIT" + "'", str3.equals("SUN.LWWT.MCOSX.LWCTOOLKIT"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_ME;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "SUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lsun.l", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lsun.l" + "'", str2.equals("sun.lsun.l"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VM", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HotSpot(TM) 64-Bit Server V" + "'", str2.equals("HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwwt.mcosx.LWCToolkit", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("\n", strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sun.awt.CGraphicsEnvironment", (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtual..." + "'", str3.equals("/Library/Java/JavaVirtual..."));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 28, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("X SO caM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "sun.lsun.l");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "x86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6                                                                                                                                                                                                                    " + "'", str1.equals("X86_6                                                                                                                                                                                                                    "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("51.0", ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolX SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_2000;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", "10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "hi!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    " + "'", str3.equals("/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(25, 217, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 217 + "'", int3 == 217);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Oracle Corporation", "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Java(TM) SE Runtime Environment", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "edomdexim");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("US", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######1.7" + "'", str3.equals("#######1.7"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hie", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                       hie" + "'", str2.equals("                                                                                                                                                                       hie"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", ":");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ne", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("edom dexim");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, 0.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolk", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sunJlwwtJmcosxJLWCToolkit", 9, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunJlwwtJmcosxJLWCToolkit" + "'", str3.equals("sunJlwwtJmcosxJLWCToolkit"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    ", (java.lang.CharSequence) "hie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ne", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ne" + "'", charSequence2.equals("ne"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", "en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolk", "X86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolk" + "'", str2.equals("sun.lwawt.macosx.LWCToolk"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("MV revreS tiB-46 )MT(topStoH avaJ", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str2.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985", "", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Corporation", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("x86_6                                                                                                                                                                                                                    ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("51.0", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwwt.mcosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwwt.mcosx.LWCToolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", "neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100L, (double) 51.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("ne", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("51.0", "HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "X86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_PATH;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 9, "edom dexim");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "edom d1.7" + "'", str3.equals("edom d1.7"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), 0L, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sophie", "hi!       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "HotSpot(TM) 64-Bit Server V", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("X86_6                                                                                                                                                                                                                    ", (int) (short) -1, "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6                                                                                                                                                                                                                    " + "'", str3.equals("X86_6                                                                                                                                                                                                                    "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolk", "sun.lwwt.mcosx.LWCToolkit", (int) '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "hi!");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray6, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie", (java.lang.Object[]) strArray11);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "sunJlwwtJmcosxJLWCToolkit", 0, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("aa...", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed mode", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("en", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "...O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen", "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.7    " + "'", str2.equals("   1.7    "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#######1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 1, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_7;
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) 5, (long) 15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lsun.l", "x86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("x86_64", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("JavaHotSpot(TM)64-BitServerVM", "http://java.oracle.com/", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#######1.7", "ne");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.LWCToolk", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToolkawt.masun.lw" + "'", str2.equals("cosx.LWCToolkawt.masun.lw"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1", "HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 25, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X SO caM", ".310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Mac OS X", "", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) 'a', "SUN.LWAWT.MACOSX.LWCTOOLX SO CAM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSXSUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSX." + "'", str3.equals("SUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSXSUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSX."));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("24.80-b11", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7", "SUN.LWWT.MCOSX.LWCTOOLKIT", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str1.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, 0L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "sun.lsun.l", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("cosx.LWCToolkawt.masun.lw", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.LWCToolkawt.masun.lw" + "'", str3.equals("cosx.LWCToolkawt.masun.lw"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("edom d1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", "edom d1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VM", "HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java" + "'", str2.equals("Java"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("X86_6                                                                                                                                                                                                                    ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                                                                                 "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("   1.7    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '4', ' ', '4', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\n", "JavaHotSpot(TM)64-BitServerVM", "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(":", (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("51.0", "cosx.LWCToolkawt.masun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lsun.l");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lsun.l" + "'", str3.equals("sun.lsun.l"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 28, 0L, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java", 2, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va" + "'", str3.equals("va"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "\n");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray1, strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.0" + "'", str5.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hie", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("X86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6                                                                                                                                                                                                                    " + "'", str1.equals("X86_6                                                                                                                                                                                                                    "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAHOTSPOT(TM)64-BITSERVERVM" + "'", str1.equals("JAVAHOTSPOT(TM)64-BITSERVERVM"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("edomdexim", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophie", 11, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("X SO caM", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("ne", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "   1.7    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine Specification", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#Java Platform API Specification" + "'", str1.equals("#Java Platform API Specification"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "edom d1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Edom d1.7" + "'", str1.equals("Edom d1.7"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "...O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "US", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lsun.l", "va");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("va", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va" + "'", str2.equals("va"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http://java.oracle.com/", (int) (short) 1, "MV revreS tiB-46 )MT(topStoH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 1 + "'", short0.equals((short) 1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.LWCToolX SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolX SO caM" + "'", str1.equals("sun.lwawt.macosx.LWCToolX SO caM"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "neaaaaa..." + "'", str2.equals("neaaaaa..."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sun.lwawt.macos .CPrinterJob", "1.7", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#######1.7", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######1.7" + "'", str2.equals("#######1.7"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkitaaJava Platform API SpecificationaJava Platform API Specificationa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, (double) 11, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("SUN.LWAWT.MACOSX.LWCTOOLX SO CAM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.LWCTOOLX SO CAM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        char[] charArray7 = new char[] { '#', '#', '4', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SUN.LWWT.MCOSX.LWCTOOLKIT", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                                                                 ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        float float0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION_FLOAT;
//        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.7f + "'", float0 == 1.7f);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("   1.7    ", "sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64", (java.lang.CharSequence) "neaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed mode");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) 0, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_6                                                                                                                                                                                                                    ", "", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6                                                                                                                                                                                                                    " + "'", str3.equals("x86_6                                                                                                                                                                                                                    "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MV revreS tiB-46 )MT(topStoH", 25, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV revreS tiB-46 )MT(topStoH" + "'", str3.equals("MV revreS tiB-46 )MT(topStoH"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("   1.7    ", "mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.lwawt.macosx.LWCToolkitaaJava Platform API SpecificationaJava Platform API Specificationa", "neaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwwt.mcosx.lwctoolkit" + "'", str1.equals("sun.lwwt.mcosx.lwctoolkit"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophie", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 0.0f, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", 8, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JaHI!Jav" + "'", str3.equals("JaHI!Jav"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Java Virtual Machine Specification", "ne");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("va", "x86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) (-1), (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen", "sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, (long) 1, (long) 25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("http://java.oracle.com/", "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80-b15", "edomdexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sophie", ".310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "va");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("24.80-b11", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     24.80-b11                      " + "'", str2.equals("                     24.80-b11                      "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64", "", 2, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64" + "'", str4.equals("x8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 28L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("   1.7    ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("...O", 69, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...O" + "'", str3.equals("...O"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("...O", "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str2.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("SUN.LWAWT.MACOSX.LWCTOOLX SO CAM", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "x86_64");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("SUN.LWWT.MCOSX.LWCTOOLKIT", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JAVAHOTSPOT(TM)64-BITSERVERVM", "sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!", "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAHOTSPOT(TM)64-BITSERVERVM" + "'", str3.equals("JAVAHOTSPOT(TM)64-BITSERVERVM"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 14, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                                 ", (int) (short) -1, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                 " + "'", str3.equals("                                                                                                                                                                                                                 "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/..." + "'", str1.equals("/Users/..."));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 170, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########################################################################################################################################################################" + "'", str3.equals("##########################################################################################################################################################################"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi!", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(14, 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLK" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLK"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("cosx.LWCToolkawt.masun.lw", "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("edom dexim", "sun.lwwt.mcosx.LWCToolkit", "...O");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("neaaaaa...", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "neaaaaa..." + "'", str2.equals("neaaaaa..."));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", (-1), "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("#######1.7", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("SUN.LWAWT.MACOSX.LWCTOOLX SO CAM", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("10.14.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("edom dexim", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom dexim" + "'", str2.equals("edom dexim"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("en", "sun.lsun.l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lsun.l", 0, 170);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lsun.l" + "'", str4.equals("sun.lsun.l"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                                                                                                                                                                 ", "/U!er!/!phe/br ry/J v /Ee ! !:/br ry/J v /Ee ! !:/Ne r/br ry/J v /Ee !    ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtual...", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("sun.awt.CGraphicsEnvironment", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolX SO caM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolX SO caM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!" + "'", str2.equals("sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sunJlwwtJmcosxJLWCToolkit");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWWT.MCOSX.LWCTOOLKIT", "...O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mixed mode", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification", "hi!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) 69, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("edom d1.7", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, 1L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        char[] charArray8 = new char[] { '4', ' ', '4', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKITHI!HI!JAVA PLATFORM API SPECIFICATIONHI!JAVA PLATFORM API SPECIFICATIONHI!" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLKITHI!HI!JAVA PLATFORM API SPECIFICATIONHI!JAVA PLATFORM API SPECIFICATIONHI!"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 217, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 0, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("   1.7    ", "/", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKITHI!HI!JAVA PLATFORM API SPECIFICATIONHI!JAVA PLATFORM API SPECIFICATIONHI!", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT", "Java", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("...O", "Java Platform API Specification", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hotspot(tm) 64-bit server vm", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hotspot(tm) 64-bit server vm" + "'", str2.equals("hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("ne", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkitaaJava Platform API SpecificationaJava Platform API Specificationa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        short[] shortArray4 = new short[] { (short) 1, (byte) 100, (byte) 0, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwwt.mcosx.lwctoolkit", "Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aa...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolk", "sun.lwwt.mcosx.LWCToolkit", (int) '#');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "hi!");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray7, strArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie", (java.lang.Object[]) strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.concatWith("/", (java.lang.Object[]) strArray12);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Oracle Corporation" + "'", str13.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwawt.macos .CPrinterJob", "neaaaaa...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.String[] strArray7 = new java.lang.String[] { "10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "SUN.LWWT.MCOSX.LWCTOOLKIT", "x86_64", "SUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSXSUN.LWAWT.MACOSX.LWCTOOLX SO CAMSUN.LWAWT.MACOSX.", "JAVAHOTSPOT(TM)64-BITSERVERVM", "x8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64" };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "edom d1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("JavaHotSpot(TM)64-BitServerVM", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java(TM) SE Runtime Environment", "/Users/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(".310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 10, 69);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.1" + "'", str3.equals("0.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.1"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.1" + "'", str2.equals("0.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.1"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("edom d1.7", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "edom d1.7" + "'", str3.equals("edom d1.7"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "sun.lwawt.macosx.LWCToolkitSUN.LWWT.MCOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "Java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                                                       hie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "x86_6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0.equals(1.0f));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aa...", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa..." + "'", str2.equals("aa..."));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("edomdexim", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edomdexim" + "'", str2.equals("edomdexim"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("UTF-8", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("edomdexim", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sophie", (int) (short) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", "JaHI!Jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", 97, "x8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8" + "'", str3.equals("mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64" + "'", str2.equals("86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_64"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("#Java Platform API Specification", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatform API Specifica Plava#J" + "'", str2.equals("tionatform API Specifica Plava#J"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("tionatform API Specifica Plava#J", "/Users/...", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolk", "sun.lwwt.mcosx.LWCToolkit", (int) '#');
        java.lang.String[] strArray10 = new java.lang.String[] { "sun.lwawt.macosx.LWCToolkit", "", "Java Platform API Specification", "Java Platform API Specification", "" };
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10sun.lwawt.macosx.LWCToolki14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification" + "'", str13.equals("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API Specification"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str15.equals("sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "10.14.3", 15, 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.3" + "'", str4.equals("10.14.3"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen" + "'", str2.equals("en...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen...Oen"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("##########################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 170, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("x86_64", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/...", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("en");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Users/...", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HotSpot(TM) 64-Bit Server V", "MV revreS tiB-46 )MT(topStoH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MV revreS tiB-46 )MT(topStoH" + "'", str2.equals("MV revreS tiB-46 )MT(topStoH"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLX SO CAM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.LWCToolkit", "hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.LWCToolX SO caM", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolX SO caM" + "'", str2.equals("sun.lwawt.macosx.LWCToolX SO caM"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.lwawt.macosx.LWCToolk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolk" + "'", str1.equals("sun.lwawt.macosx.LWCToolk"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("   1.7    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   1.7    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine Specification", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!", 14, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("cosx.LWCToolkawt.masun.lw", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToolkawt.masun.lw" + "'", str2.equals("cosx.LWCToolkawt.masun.lw"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hie", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie" + "'", str2.equals("hie"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("#######1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("HotSpot(TM) 64-Bit Server VM", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (int) (short) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("Java HotSpot(TM) 64-Bit Server VM", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sunJlwwtJmcosxJLWCToolkit", (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("tionatform API Specifica Plava#J", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolk", "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolk" + "'", str2.equals("sun.lwawt.macosx.LWCToolk"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (-1), 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkitaaJava Platform API SpecificationaJava Platform API Specificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitaaJavaPlatformAPISpecificationaJavaPlatformAPISpecificationa" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitaaJavaPlatformAPISpecificationaJavaPlatformAPISpecificationa"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macos .CPrinterJob", "\n", (int) (short) 100, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macos .CPrinterJob\n" + "'", str4.equals("sun.lwawt.macos .CPrinterJob\n"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "/Users/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "sophie", "Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("X86_6                                                                                                                                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_6                                                                                                                                                                                                                    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "va");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("x86_6", "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6" + "'", str2.equals("x86_6"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macos .CPrinterJob\n");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironmen" + "'", str1.equals("Sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("cosx.LWCToolkawt.masun.lw", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("##########################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", "##########################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolX SO caM", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("MV revreS tiB-46 )MT(topStoH avaJ", "sun.lwawt.macosx.LWCToolkithi!hi!Java Platform API Specificationhi!Java Platform API Specificationhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "x86_6", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("va");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VA" + "'", str1.equals("VA"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '#', "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("Documents/defects4j/tmp/run_randoop.pl_11391_1560229985/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 100, "MV revreS tiB-46 )MT(topStoH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV revreS tiB-46 )MT(topStoHMV re/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("MV revreS tiB-46 )MT(topStoHMV re/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8" + "'", str1.equals("Mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("X86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 3, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".lwawt.ma" + "'", str3.equals(".lwawt.ma"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", "Mixed modex8.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x86_641.7x8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "JAVAHOTSPOT(TM)64-BITSERVERVM", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 15, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-b15", 9, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lsun.l");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("US", 5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("\n", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "VA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sun.awt.CGraphicsEnvironmen", "sun.lwawt.macosx.LWCToolkitaaJavaPlatformAPISpecificationaJavaPlatformAPISpecificationa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVAHOTSPOT(TM)64-BITSERVERVM", "JaHI!Jav", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAHOTSPOT(TM)64-BITSERVERVM" + "'", str3.equals("JAVAHOTSPOT(TM)64-BITSERVERVM"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "sun.lwawt.macosx.LWCToolkit/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaJava Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sun.lwawt.macosx.LWCToolX SO caM", "sun.lwawt.macosx.LWCToolX SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '#', (float) 11, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", "sun.lwawt.macosx.LWCToolkitJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("va");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VA" + "'", str1.equals("VA"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("JAVAHOTSPOT(TM)64-BITSERVERVM", "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '#', '#', '4', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SUN.LWWT.MCOSX.LWCTOOLKIT", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("1.7", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985", 2, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11391_1560229985aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("edom dexim", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("cosx.LWCToolkawt.masun.lw", "MV revreS tiB-46 )MT(topStoH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Edom d1.7", 3, "x86_6                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Edom d1.7" + "'", str3.equals("Edom d1.7"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/...", "Sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java", "hi!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 170 + "'", int1 == 170);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

