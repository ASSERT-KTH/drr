import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4444a4#4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444a4#4#4" + "'", str1.equals("4444a4#4#4"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                               100 -1 -1", 2, 84);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                             .80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".80-b11" + "'", str1.equals(".80-b11"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sophie", "104.0#-1.0#1.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100" + "'", charSequence2.equals("84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "4.80-B11.80-B11.80-B11.80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 10, 1);
        java.lang.Class<?> wildcardClass19 = byteArray6.getClass();
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "aaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("       10.14.31 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.31" + "'", str1.equals("10.14.31"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10.0 10.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0a-1a-1a100a100a10", (java.lang.CharSequence) "US", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 9, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "nt.jar", "041484-");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 574 + "'", int2 == 574);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31, (float) 1, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1 -1" + "'", str1.equals("100 -1 -1"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit", (java.lang.CharSequence) "10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 9, (short) (byte) 9, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 9 + "'", short3 == (short) 9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4a4aa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a4aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("# # a 4 4", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 4 a 4 4" + "'", str3.equals("4 4 a 4 4"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14", "1.7.-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.71.71.4#4#a###");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.4#4#a###" + "'", str1.equals("1.71.71.4#4#a###"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', (int) (short) 1, 0);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(".slaB..", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".slaB.." + "'", str2.equals(".slaB.."));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444a4#4#4", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, (float) 15, (float) 574);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 574.0f + "'", float3 == 574.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "100.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 26, 576);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 26");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "       10.14.31 ", (java.lang.CharSequence) "13.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a10a-1a18a32a10084a10a-1a18a32a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String[] strArray3 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "            hi!", (java.lang.CharSequence) "10 1 8 -1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#######4 4 a # #", "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10#0#100#0#100#100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("444414#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444414#" + "'", str1.equals("444414#"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0#-1#100#0#1", "10a1a...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#-1#100#0#1" + "'", str2.equals("#-1#100#0#1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a" + "'", str3.equals("8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 97, (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Jv(TM) E Runtime Environment", "en4 4  # #  4 4  # #  4 4  #1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("erJob", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0#-1#-1#100#100#10", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48", "                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48" + "'", str2.equals("001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.2", "444414#4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("010a0a100a0a100a10010a0a100a0a10", "  1.7.0_80", "                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "010a0a100a0a100a10010a0a100a0a10" + "'", str3.equals("010a0a100a0a100a10010a0a100a0a10"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("001a23a1a1a01a4", (int) (short) 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001a23a1a1a01a4" + "'", str2.equals("001a23a1a1a01a4"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        java.lang.String[] strArray2 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 52, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80-b15" + "'", str7.equals("1.7.0_80-b15"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.0 10.0 10.0 -1.0", "4 4 a # #", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100", 143, "844104-14184324100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100" + "'", str3.equals("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("###", " 4 4 # #  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###" + "'", str2.equals("###"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "               1.71.71.4#4#a###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("84a10a-1a18a32a100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4 4 a # #  ", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4 a # #  " + "'", str2.equals("4 4 a # #  "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10 1 8 -1", (java.lang.CharSequence) "4444a4#4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.4", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "8.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                       /Users/sophie", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       /Users/sophie" + "'", str2.equals("                                                                                       /Users/sophie"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java HotSpot(TM) 64-Bit Server VM", "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("2.80-B11", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.80-B11" + "'", str2.equals("2.80-B11"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "0 -1 1 100 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) '#', (int) (short) 1);
        try {
            long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4#4#a#####", "84 10 -1 18 32 100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "84#10#-1#18#...", "4 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("2.80-B11", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.80-B11" + "'", str2.equals("2.80-B11"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "44a##");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 10 + "'", byte1 == (byte) 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################" + "'", str2.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("###############...", "100.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############..." + "'", str2.equals("###############..."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10 1 8 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(84, 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":ptth", (java.lang.CharSequence) "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "erJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 0, (int) (byte) 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 13.0f + "'", float4 == 13.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 13.0f + "'", float5 == 13.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 13.0f + "'", float6 == 13.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 13.0f + "'", float11 == 13.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("SOPHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHI" + "'", str1.equals("SOPHI"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "844104-14184324100", (java.lang.CharSequence) "9.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4.80-B11.80-B11.80-B11.80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.14.3", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  ", "844104-14184324100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server V", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VavaJ"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.14.31", "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", 16, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str4.equals("10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   " + "'", str2.equals("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', (int) (byte) 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 10" + "'", str6.equals("100 10"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 5, (-1));
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("13.0", (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie", 84.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 84.0f + "'", float2 == 84.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1192, (float) 97L, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1192.0f + "'", float3 == 1192.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 2, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "451.0451.0a51.0#51.0#", (java.lang.CharSequence) "1.71.71.", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "...aa1a1aa01a4a", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "...aa1a1aa01a4a" + "'", charSequence2.equals("...aa1a1aa01a4a"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a31.0a10.0" + "'", str7.equals("10.0a31.0a10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 31.0f + "'", float8 == 31.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        char[] charArray9 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.9", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a10", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#4#a##### " + "'", str11.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4a4aaa#a#a " + "'", str14.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', 0);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 13.0f + "'", float8 == 13.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 13.0f + "'", float9 == 13.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 13.0f + "'", float10 == 13.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 13.0f + "'", float11 == 13.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 13.0f + "'", float12 == 13.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0", 9, "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.04a4aaa" + "'", str3.equals("1.04a4aaa"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "     ", (java.lang.CharSequence) " 0_80 ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("001a23a100 101a1100 10a01a4100 10", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100410", (int) (short) 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100410 + "'", int2 == 100410);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("en4 4  # #  4 4  # #  4 4  #1.7", "#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en4 4  # #  4 4  # #  4 4  #1.7" + "'", str2.equals("en4 4  # #  4 4  # #  4 4  #1.7"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#a4aaa aaa ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "4#4#a#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.0#31.0#10.0#5.0#84.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 -1 1 100 0", (java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0 -1 1 100 0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", "#a4aaa aaa ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        " + "'", str3.equals("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        "));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 1, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.14." + "'", str3.equals("0.14."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        long[] longArray2 = new long[] { '4', (short) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) '4', 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 32, 0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("        ", "     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "9.", (java.lang.CharSequence) "0a-1a-1a100a100a10", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("04-14-141004100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04-14-141004100410" + "'", str1.equals("04-14-141004100410"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) (byte) 10, (int) (short) -1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', (int) (byte) 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "4a4aaa#a#a", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("J4v4 HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en", (java.lang.CharSequence) "041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 212 + "'", int2 == 212);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.71.71.4#4#####", "0a-1a100a0a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.4#4#####" + "'", str2.equals("1.71.71.4#4#####"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...aa1a1aa01a4a", 31.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                               en", "####                            ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 26, (float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) ":ptth");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 104);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4444a4#4#4", "100.0 -1.0 15.0 -1.0 8.0 6.0", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "        ", (java.lang.CharSequence) "001a23a1a1a01a4", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", "boJretnirPC.xsoc m.tw wl.nus", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#-1#100#0#1", (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(":");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "# # a 4 4", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#4#a##### ", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4a4aaa#a#a " + "'", str19.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4#4#a#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#a#####" + "'", str1.equals("4#4#a#####"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.04a4aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.04a4aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 0, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "001a23a#1a1#a01a4#", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", "en");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", "");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long19 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10 1 8 -1" + "'", str17.equals("10 1 8 -1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.0 31.0 10.0", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 31.0 10.0" + "'", str2.equals("10.0 31.0 10.0"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                       /                                                                       " + "'", str2.equals("                                                                       /                                                                       "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("t", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 t                                                  " + "'", str2.equals("                                                 t                                                  "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 15, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10 1 8 -1" + "'", str17.equals("10 1 8 -1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("844104-14184324100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"844104-14184324100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999" + "'", str1.equals("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 9, (short) 9);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 9 + "'", short3 == (short) 9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence3, (java.lang.CharSequence[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "10.0 10.0 10.0 -1.0");
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence1, (java.lang.CharSequence[]) strArray6);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80-b15" + "'", str7.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80-b15" + "'", str11.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7.0_80-b15" + "'", str14.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0.14.", "0a-1a-1a100a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.14." + "'", str2.equals("0.14."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", charSequence1, 576);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("9", (float) 25);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "# #  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4 4  # #  4 4  # #  4 4  #1.7", "4#4#a#####");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  ", ' ');
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 12 vs 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.Class<?> wildcardClass15 = byteArray6.getClass();
        byte[] byteArray18 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray18, '4');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(byteArray18, 'a', 8, (int) (short) 1);
        byte byte25 = org.apache.commons.lang3.math.NumberUtils.min(byteArray18);
        byte byte26 = org.apache.commons.lang3.math.NumberUtils.min(byteArray18);
        java.lang.Class<?> wildcardClass27 = byteArray18.getClass();
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        java.lang.Class<?> wildcardClass30 = strArray29.getClass();
        java.lang.String[] strArray34 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray34);
        int int36 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray34);
        java.lang.String[] strArray38 = org.apache.commons.lang3.StringUtils.stripAll(strArray34, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.stripAll(strArray38);
        boolean boolean40 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence[]) strArray39);
        java.lang.Class<?> wildcardClass41 = strArray39.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray42 = new java.lang.reflect.GenericDeclaration[] { wildcardClass15, wildcardClass27, wildcardClass30, wildcardClass41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray42);
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) genericDeclarationArray42, "");
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100410" + "'", str20.equals("100410"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + byte25 + "' != '" + (byte) 10 + "'", byte25 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte26 + "' != '" + (byte) 10 + "'", byte26 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1.7.0_80-b15" + "'", str35.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(genericDeclarationArray42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str43.equals("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str45.equals("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(15, 18, 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 92 + "'", int3 == 92);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaa" + "'", str1.equals("Aaaaa"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 10, 1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 16, 9);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (java.lang.CharSequence) "104041004041004100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("########################################################################################################", "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########################################################################################################" + "'", str2.equals("########################################################################################################"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 29, 100410);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', 0);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 8, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4a4aaa#a#a", (java.lang.CharSequence) "                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100" + "'", str1.equals("84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444414#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444414#4" + "'", str1.equals("444414#4"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("a10a-1a18a32a10084a10a-1a18a32a1", "10#0#1...", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "001a23a#1a1#a01a4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("#################################################################################################", " 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                ", (int) (short) 1, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               4#4#a##### 444444444444444444444444444444444444444444444444444444" + "'", str3.equals("                               4#4#a##### 444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Jv(TM) E Runtime Environment", 26, 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "451.0451.0a51.0#51.0#", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (short) 1, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 143, (int) ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 0, 2);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "84 10 -1 18 32 100" + "'", str10.equals("84 10 -1 18 32 100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "84#10" + "'", str20.equals("84#10"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("9", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        int[] intArray1 = new int[] { 92 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "92" + "'", str3.equals("92"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "104.0#-1.0#1.0", "1.0############################################################################################################################################", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.013.41.013.41.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.013.41.013.41.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.71.71.4#4#a###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("               1.71.71.4#4#a###", 7, " HotSpot(TM) 64-Bit Server VavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               1.71.71.4#4#a###" + "'", str3.equals("               1.71.71.4#4#a###"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100 10", (java.lang.CharSequence) "10.14");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HTTP://JAVA.ORACLE.COM", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLE.COM" + "'", str2.equals("CLE.COM"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie", "41484-1", "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie" + "'", str3.equals("mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#A#####" + "'", str1.equals("4#4#A#####"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "8.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "8.0a10.0", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####" + "'", str1.equals("####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Jv(TM) E Runtime Environment", (java.lang.CharSequence) "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lw", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4 4 a # #  ", (java.lang.CharSequence) "0 a - 1 a 100 a 0 a 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "041484-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100.0#-1.0#15.0#-1.0#8.0#6.0", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#-1.0#15.0#-1.0#8.0#6.0  " + "'", str2.equals("100.0#-1.0#15.0#-1.0#8.0#6.0  "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "13.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "001a23a1a1a01a4", (java.lang.CharSequence) "# # a 4 4", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                       /                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4a4aaa#a#a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) (short) 0, (float) 104L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi" + "'", str1.equals("sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "0", "9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("####");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# #  ", "0#-1#100#0#1");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", (int) (byte) 10, 5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("01");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.71.71.", (java.lang.CharSequence) "4#4#a#####   ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 -1.0 15.0 -1.0 8.0 6.0" + "'", str1.equals("100.0 -1.0 15.0 -1.0 8.0 6.0"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("52#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52#1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String[] strArray1 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1041484-1", (int) 'a', 31);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80-b15" + "'", str7.equals("1.7.0_80-b15"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (java.lang.CharSequence) "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7.0_80", "24.80-b11", 212);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str2.equals("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10#0#100#0#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4.80-B11.80-B11.80-B11.80", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.80-B11.80-B11.80-B11.80" + "'", str2.equals("4.80-B11.80-B11.80-B11.80"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, (double) 32L, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 104.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "#a4aaa aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("wl.nus m.tw boJretnirPC.xsoc");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_80-b15", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("444414#", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444414#                         " + "'", str2.equals("444414#                         "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "10.14.310.14.310.1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("444414#                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444414#                         " + "'", str1.equals("444414#                         "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4a4aaa#a#a", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                 t                                                  ", "erJob", "10.14.3en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 t                                                  " + "'", str3.equals("                                                 t                                                  "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2.80-B11", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "4444a4#4#4 ", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("84#10#-1#18#32#1", "4444a4#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "84#10#-1#18#32#1" + "'", str2.equals("84#10#-1#18#32#1"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 10, 1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 100, 32);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 1192, 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#", (java.lang.CharSequence) "mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) (-1L), (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0############################################################################################################################################", "Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4 4 a # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4 4 a # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.0############################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie", (int) (short) 10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(".slaB..", "mixed mode", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed mode.slaB.." + "'", str4.equals("mixed mode.slaB.."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lw", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("# # a 4 4", 10, "10 1 8 -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "# # a 4 41" + "'", str3.equals("# # a 4 41"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("92");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "92" + "'", str1.equals("92"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4#4#A#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#A#####" + "'", str1.equals("4#4#A#####"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931" + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", (java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4#4#a#####   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("444414#4", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(".80-B11", "", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 1192);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".80-B11" + "'", str4.equals(".80-B11"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0410.0410.04-1.0", (java.lang.CharSequence) "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0", "4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.71.71.4#4#a###", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.4#4#a###" + "'", str2.equals("1.71.71.4#4#a###"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "444414#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 10, 1);
        java.lang.Class<?> wildcardClass19 = byteArray6.getClass();
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10a0a100a0a100a100" + "'", str21.equals("10a0a100a0a100a100"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 4 + "'", short2 == (short) 4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("41484-1", "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "41484-1" + "'", str2.equals("41484-1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("wl.nus m.tw boJretnirPC.xsoc");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: wl.nus m.tw boJretnirPC.xsoc is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 30, 104);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13.0" + "'", str4.equals("13.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".80-b11", "8.0410.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100.0 -1.0 15.0 -1.0 8.0 6.0", 9, 2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "SOPHI");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ".80-b11" + "'", str8.equals(".80-b11"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("t");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444a4#4#4", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("04-14-141004100410", "mixed mode.slaB..", "nt jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 0, 104);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 10" + "'", str6.equals("100 10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10" + "'", str9.equals("100a10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a10" + "'", str11.equals("100a10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 10" + "'", str13.equals("100 10"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2, (double) 143L, (double) 84L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 143.0d + "'", double3 == 143.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a                  1a1                  a01a4                  ", "                                                                                               100 -1 -1", 4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray7);
        java.lang.Class<?> wildcardClass11 = strArray7.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str9.equals("sun.lwwt.mcosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", "sun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                  ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, (int) (short) 9, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("2.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.80-B11" + "'", str1.equals("2.80-B11"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray14 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray14, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 10", charArray14);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray14);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray14);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4#4#a##### " + "'", str16.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "####       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100 10", 13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.2", "4444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "04-14-141004100410", (java.lang.CharSequence) "0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("x86_64", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":ptth", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "CLE.COM", (int) (byte) 1, 102);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("13.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"13.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0", (int) (byte) 9, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0/Libra" + "'", str3.equals("1.0/Libra"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwwt.mcosx.LWCToolkit", "4#4#a#####   0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str2.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("451.0451.0a51.0#51.0#");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#-1#100#0#1", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;", "0 -1 100 0 1", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sophie", "hi!");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".80-b11", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) 9);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", (java.lang.CharSequence) "10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444444444", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0#31.0#10.0#5.0#84.0", "010a0a100a0a100a10010a0a100a0a10", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("erJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"erJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.4", (long) 574);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 574L + "'", long2 == 574L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":ptth", (java.lang.CharSequence) "9.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("erJob");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0", 84, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8" + "'", str1.equals("A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.14.", "UTF-8", "001a23a100 101a1100 10a01a4100 10", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.14." + "'", str4.equals("0.14."));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        char[] charArray4 = new char[] { 'a', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 -1 -1", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 11, 4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 3, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "84 10 -1 18 32 100" + "'", str11.equals("84 10 -1 18 32 100"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("010a0a100a0a100a10010a0a100a0a10", "44444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass11 = byteArray2.getClass();
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 97, (int) (short) 10);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.04a4aaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.044" + "'", str2.equals("1.044"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "10.0 10.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.0 10.0 10.0 -1.0" + "'", charSequence2.equals("10.0 10.0 10.0 -1.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 6, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1001.6-11.6-1", "CLE.COM", 212);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("4 4 a # #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 a # #" + "'", str1.equals("4 4 a # #"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1041484-1" + "'", str14.equals("1041484-1"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "4.80-B11.80-B11.80-B11.80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "84#10#-1#18#32#100", (java.lang.CharSequence) "0 -1 100 0 1", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b11", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("       0.0431.0410.045.0484.0", "10#0#100#0#100#100", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a##", (java.lang.CharSequence) "4#4#a#####   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0 a - 1 a 100 a 0 a 1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("8.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8.0410.0" + "'", str1.equals("8.0410.0"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "84 10 -1 18 32 100", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################" + "'", str2.equals("################"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", (int) (byte) 1, "0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str3.equals("10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9", '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n", 19, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n                  " + "'", str3.equals("\n                  "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("erJob", 9, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erJobaaaa" + "'", str3.equals("erJobaaaa"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0a31.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a31.0a10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie" + "'", str2.equals("mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("\n                  ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("erJob", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erJob" + "'", str2.equals("erJob"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("# # a 4 41");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# # a 4 41" + "'", str1.equals("# # a 4 41"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0a31.0a10.0", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.044", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.044" + "'", str2.equals("1.044"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray14 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray14, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 10", charArray14);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray14);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray14);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4#4#a##### " + "'", str16.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str2 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = javaVersion8.atLeast(javaVersion10);
        boolean boolean12 = javaVersion7.atLeast(javaVersion10);
        boolean boolean13 = javaVersion1.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion14 = null;
        try {
            boolean boolean15 = javaVersion1.atLeast(javaVersion14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("11b-08.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".80-b11" + "'", str1.equals(".80-b11"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1192, 97.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1.equals(4.0f));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.14." + "'", str1.equals("0.14."));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (int) '4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (int) (byte) 9, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(84L, (long) (byte) 9, (long) (short) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 84L + "'", long3 == 84L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 18, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 15, (int) (short) 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', (int) (byte) 100, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "84a10a-1a18a32a100" + "'", str20.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  1.7.0_80", "10 1 8 -1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str3 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion4.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str12 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        boolean boolean15 = javaVersion11.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean17 = javaVersion13.atLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean19 = javaVersion13.atLeast(javaVersion18);
        boolean boolean20 = javaVersion9.atLeast(javaVersion13);
        boolean boolean21 = javaVersion0.atLeast(javaVersion13);
        java.lang.String str22 = javaVersion13.toString();
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.9" + "'", str12.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0.9" + "'", str22.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 10" + "'", str6.equals("100 10"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...aa1a1aa01a4a", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", 576);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100 -1 -1", (int) '#', 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("# #  ", "boJretnirPC.xsoc m.tw wl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# #  " + "'", str2.equals("# #  "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444444440a-1a100a0a1", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               en", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray11);
        java.lang.Class<?> wildcardClass19 = charArray11.getClass();
        short[] shortArray25 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(shortArray25, 'a');
        java.lang.Class<?> wildcardClass28 = shortArray25.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray29 = new java.lang.reflect.AnnotatedElement[] { wildcardClass19, wildcardClass28 };
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray29);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) annotatedElementArray29, ' ', 19, 11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0a-1a100a0a1" + "'", str27.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(annotatedElementArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "class [Cclass [S" + "'", str30.equals("class [Cclass [S"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 9, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a31.0a10.0" + "'", str7.equals("10.0a31.0a10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 31.0 10.0" + "'", str10.equals("10.0 31.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0431.0410.0" + "'", str12.equals("10.0431.0410.0"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "04-14-141004100410", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" 4 4 # #  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4 4 # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.5", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa1.5aaaaaaaa" + "'", str3.equals("aaaaaaa1.5aaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4#4#a##### " + "'", str12.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("boJretnirPC.xsoc m.tw wl.nus", "...aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsoc m.tw wl.nus" + "'", str2.equals("boJretnirPC.xsoc m.tw wl.nus"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "001a23aa1a1aa01a4a", 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "001a23aa1a1aa01a4a" + "'", str4.equals("001a23aa1a1aa01a4a"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0#-1#100#0#1", (java.lang.CharSequence) "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mode", 13, "4a4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4mixed mode4a" + "'", str3.equals("4mixed mode4a"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a100a0a1", "\n", 5);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0a-1a100a0a1" + "'", str4.equals("0a-1a100a0a1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a-1a100a0a1" + "'", str6.equals("0a-1a100a0a1"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a" + "'", str2.equals("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaa", "10.0431.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 6, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 9, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkit", "            hi!", "451.0451.0a51.0#51.0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n                  ", (java.lang.CharSequence) "4.80-B11.80-B11.80-B11.80", 1192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#4#a#####", "erJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("010a0a100a0a100a10010a0a100a0a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01a0a001a0a01001a001a0a001a0a010" + "'", str1.equals("01a0a001a0a01001a001a0a001a0a010"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1" + "'", str2.equals(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#a4aaa aaa", (java.lang.CharSequence) "                                                                       /                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.71.71.4#4#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4 4 a # #", (java.lang.CharSequence) "####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("# #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# #" + "'", str1.equals("# #"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1", "104.0#-1.0#1.0", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 104, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 2.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4a4aaa#a#a ", 84);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a4aaa#a#a " + "'", str2.equals("4a4aaa#a#a "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        char[] charArray10 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', (-1), (int) (byte) -1);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4#4#a##### " + "'", str12.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a a - a a aaa a a a a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                 t                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "t" + "'", str1.equals("t"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.14.31");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               en", "", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".80-b11", "8.0410.0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "100.0 -1.0 15.0 -1.0 8.0 6.0", 9, 2);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444440a-1a100a0a1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444a4#4#4 ", 35, "100a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a10100a104444a4#4#4 100a10100a10" + "'", str3.equals("100a10100a104444a4#4#4 100a10100a10"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, 92L, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1041484-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ", 18);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str12.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a31.0a10.0" + "'", str7.equals("10.0a31.0a10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 31.0 10.0" + "'", str10.equals("10.0 31.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0431.0410.0" + "'", str12.equals("10.0431.0410.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 31.0f + "'", float13 == 31.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("8.0a10.0", (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 4, 35.0f, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("001a23a1a1a01a4", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "                                                 t                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(143L, (long) 26, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 143L + "'", long3 == 143L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "  84#10  ", (java.lang.CharSequence) "10.0 31.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "8.0a10.0", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("01a0a001a0a01001a001a0a001a0a010", "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str5 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        boolean boolean11 = javaVersion1.atLeast(javaVersion9);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str13 = javaVersion9.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.5" + "'", str13.equals("1.5"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10 0 100 0 100 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.0f, 7.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###############...", (java.lang.CharSequence) "001a23a100 101a1100 10a01a4100 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("noitacificepS IPA mroftalP avaJ", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str2.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "       10.14.31 ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4 4  # #  4 4  # #  4 4  #1.7", "4#4#a#####");
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(".80-B11", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "001a23a1a1a01a4" + "'", str6.equals("001a23a1a1a01a4"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "4a4aaa#a#a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", charArray11);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', 32, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4444a4#4#4 " + "'", str19.equals("4444a4#4#4 "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "boJretnirPC.xsoc m.tw wl.nus", (java.lang.CharSequence) "aaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "       10.14.31 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence) "10.0410.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", "4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str2.equals("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############...", (java.lang.CharSequence) "100#-1#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("en4 4  # #  4 4  # #  4 4  #1.7", "sun.lwawt.macosx.LWCToolkit", "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en4 4  # #  4 4  # #  4 4  #1.7" + "'", str3.equals("en4 4  # #  4 4  # #  4 4  #1.7"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                    ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', 0);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 25, 6);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 13.0f + "'", float8 == 13.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 13.0f + "'", float9 == 13.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a-1a100a0a");
        org.junit.Assert.assertNotNull(strArray1);
    }
}

