import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####" + "'", str1.equals("####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str10 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean13 = javaVersion9.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean15 = javaVersion11.atLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean17 = javaVersion11.atLeast(javaVersion16);
        boolean boolean18 = javaVersion7.atLeast(javaVersion11);
        java.lang.String str19 = javaVersion7.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7" + "'", str19.equals("1.7"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:", "", 31);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "###", (int) (short) 4, 84);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.9                                ", (java.lang.CharSequence) "Aaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, 100L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "13.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444a4#4#4 #4444a4#4#4  4444a4#4#4 #4444a4#4#4  4444a4#4#4  4444a4#4#4 ", "mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie", 1192);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", "HTTP://JAVA.ORACLE.COM", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "sun.lw", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("100 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1 -1" + "'", str1.equals("100 -1 -1"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophi", "en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" 0_80 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "8.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10#0#1...", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1041484-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041484-1" + "'", str1.equals("1041484-1"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("001a23a#1a1#a01a4#", "10.0a31.0a10.0", "1041484-1", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "001a23a#1a1#a01a4#" + "'", str4.equals("001a23a#1a1#a01a4#"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                    ", "4 4 a # #  ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VavaJ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10#0#1...", (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#0#1..." + "'", str2.equals("10#0#1..."));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100a10", (java.lang.CharSequence) "4a4aaa#a#a ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("104.0#-1.0#1.0", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104.0#-1.0#1.0" + "'", str2.equals("104.0#-1.0#1.0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("8.0a10.0", "10#0#1...", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("####       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ####        is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 18, (int) (byte) 10);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10 1 8 -1" + "'", str16.equals("10 1 8 -1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10#1#8#-1" + "'", str18.equals("10#1#8#-1"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("100.0 -1.0 15.0 -1.0 8.0 6.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00.0 -1.0 15.0 -1.0 8.0 6.0" + "'", str2.equals("00.0 -1.0 15.0 -1.0 8.0 6.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "01a0a001a0a01001a001a0a001a0a010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#-1#100#0#1" + "'", str10.equals("0#-1#100#0#1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4 4  # #  4 4  # #  4 4  #1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', (int) ' ', (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!hi!hi!hi!hi!hi!hi!hi!hi!h", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "104.0#-1.0#1.0" + "'", str1.equals("104.0#-1.0#1.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en", (java.lang.CharSequence) "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..." + "'", str2.equals("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..."));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4444a4#4#4 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 576, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ", 18);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str13.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("9.0", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9.0" + "'", str2.equals("9.0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("444414#", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "2.80-B11", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("4a4aa", "###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4a4aa" + "'", str2.equals("4a4aa"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4a4aaa#a#a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a4aaa#a#a" + "'", str1.equals("4a4aaa#a#a"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #" + "'", str1.equals("4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) ' ', 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84a10a-1a18a32a100", "51.0", 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("", "4 4 a # #  ");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4", strArray15, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("  1.7.0_80", strArray11, strArray18);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray18);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010", strArray2, strArray18);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ":");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "84a10a-1a18a32a100" + "'", str12.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "  1.7.0_80" + "'", str20.equals("  1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010" + "'", str22.equals("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Java: :Platform: :API: :Specification" + "'", str24.equals("Java: :Platform: :API: :Specification"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        char[] charArray8 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4#4#a##### ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#4#a##### " + "'", str10.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4 4 a # #  " + "'", str13.equals("4 4 a # #  "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1001.6-11.6-1", "10a0a100a0a100a100", 11);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0410.0410.04-1.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 4, (short) 100, (short) 9);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (int) '#', 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("001a23aa1a1aa01a4a", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001a23aa1a1aa01a4a" + "'", str3.equals("001a23aa1a1aa01a4a"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("84#10#-1#18#...", "104041004041004100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(212, 4, 100410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass11 = byteArray2.getClass();
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 a # #" + "'", str1.equals("4 a # #"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "                  ");
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "001a23a1a1a01a4" + "'", str6.equals("001a23a1a1a01a4"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "001a23a                  1a1                  a01a4                  " + "'", str9.equals("001a23a                  1a1                  a01a4                  "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 143 + "'", int10 == 143);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "84a10a-1a18a32a100", (java.lang.CharSequence) "# #", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 13.0f + "'", float4 == 13.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 13.0f + "'", float5 == 13.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 13.0f + "'", float6 == 13.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 13.0f + "'", float7 == 13.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("http://java.oracle.com", "1.04a4aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com" + "'", str2.equals("http://java.oracle.com"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #4 4 a # #", 26);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("t");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("84 10 -1 18 32 100", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0.0", " 4 4 # #  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                  ", "444414#                         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#######4 4 a # #", (float) 143);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 143.0f + "'", float2 == 143.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str5 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        boolean boolean11 = javaVersion1.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass12 = javaVersion1.getClass();
        java.lang.String str13 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.9" + "'", str13.equals("0.9"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "            hi!", (java.lang.CharSequence) "11b-08.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                               100 -1 -1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("               1.71.71.4#4#a###", "UTF-8", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10#0#1...", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#0#1..." + "'", str2.equals("10#0#1..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "8.0a10.0", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", "# # a 4 41");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..." + "'", str2.equals("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..."));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaa", "########################################################################################################", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("001a23a1a1a01a4", "Aaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001a23a1a1a01a4" + "'", str2.equals("001a23a1a1a01a4"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100", (java.lang.CharSequence) "4#4#a##### ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100" + "'", charSequence2.equals("84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray0 = new org.apache.commons.lang3.JavaVersion[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(javaVersionArray0);
        org.junit.Assert.assertNotNull(javaVersionArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8" + "'", charSequence2.equals("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "a a - a a aaa a a a a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "# #  ", (java.lang.CharSequence) "0.14.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0.9                                Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "8.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("sophi", "0 a - 1 a 100 a 0 a 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("SOPHI");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", (java.lang.CharSequence) "       10.14.31 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80", "04-14-141004100410", "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "            hi!", (java.lang.CharSequence) " ", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "84 10 -1 18 32 100" + "'", str10.equals("84 10 -1 18 32 100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa", " 10.14.31 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9L, (float) (short) 0, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        double[] doubleArray3 = new double[] { 104.0d, (-1), 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 104.0d + "'", double5 == 104.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit", (java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 143, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10 1 8 -1" + "'", str17.equals("10 1 8 -1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " 0_80 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                  ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4a4aaa#a#a ", (java.lang.CharSequence) "41484-1", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.2", "0.14.", 212);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.2" + "'", str3.equals("1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.2"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                ", "10a0a100a0a100a100", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("104.0#-1.0#1.0", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 574, 5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(3.0f, (float) 97, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# #  ", "0#-1#100#0#1");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("SOPHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHI" + "'", str1.equals("SOPHI"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/Ja", (java.lang.CharSequence) "101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("9.", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################", 576);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0a-1a100a0a", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0a-1a100a0a" + "'", charSequence2.equals("0a-1a100a0a"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaa", (java.lang.CharSequence) "mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray12 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 10", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4#4#a##### " + "'", str14.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#a4aaa aaa ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4 4  # #  4 4  # #  4 4  #1.7", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "92", (java.lang.CharSequence) "4a4aaa#a#a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("###############...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############..." + "'", str1.equals("###############..."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Libra", (int) (short) 9, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libraaaa" + "'", str3.equals("/Libraaaa"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "9.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4A4AAA#A#A AAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("4A4AAA#A#A AAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "Jv(TM) E Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.6", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6d + "'", double2 == 1.6d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.0 10.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 10.0 10.0 -1.0" + "'", str1.equals("10.0 10.0 10.0 -1.0"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("104041004041004100", "", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 576, 80);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#-1#100#0#1" + "'", str10.equals("0#-1#100#0#1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4#4#a#####", "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Libra", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#################################################################################################", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#################################################################################################" + "'", str6.equals("#################################################################################################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10 0 100 0 100 100", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 100" + "'", str2.equals("10 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 100"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi", "4 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4#4#a#####   ", (int) (short) 4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 2, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "acle Corporation" + "'", str3.equals("acle Corporation"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("http:");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(32.0f, (float) 32L, 1.1f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("001a23a100 101a1100 10a01a4100 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"01a23a100 101a1100 10a01a4100 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10 1 8 -1" + "'", str17.equals("10 1 8 -1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10#1#8#-1" + "'", str20.equals("10#1#8#-1"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10a1a8a-1" + "'", str22.equals("10a1a8a-1"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.0/Libra");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 100410, 92);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a10a-1a18a32a10084a10a-1a18a32a1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100 -1 -1", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100..." + "'", str2.equals("100..."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4444a4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444a4#4" + "'", str1.equals("4444a4#4"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0 -1 1 100 0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_8", 'a');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "                                             .80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "01", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("###############...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0#-1#-1#100#100#10" + "'", str14.equals("0#-1#-1#100#100#10"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("               1.71.71.4#4#a###", "451.0451.0a51.0#51.0#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "451.0451.0a51.0#51.0#" + "'", str2.equals("451.0451.0a51.0#51.0#"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("84#10#-1#18#32#100", "041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-", "                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "84#10#-1#18#32#100" + "'", str3.equals("84#10#-1#18#32#100"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "104.0#-1.0#1.0", (java.lang.CharSequence) "acle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("84a10a-1a18a32a100", (short) (byte) 9);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 9 + "'", short2 == (short) 9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444414#", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0#-1#-1#100#100#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("nt.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NT.JAR" + "'", str1.equals("NT.JAR"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 . 14 . 3" + "'", str4.equals("10 . 14 . 3"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", "10a1a8a-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 574, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0410.0" + "'", str5.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100a10100a104444a4#4#4 100a10100a10", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/", "", (int) (byte) 1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "001a23a                  1a1                  a01a4                  ", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48", (int) (short) -1, "                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48" + "'", str3.equals("001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0 a - 1 a 100 a 0 a 1", "84 10 -1 18 32 100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(3.0f, (float) 9, 2.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "US", (java.lang.CharSequence) "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a-1a100a0a", 143, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0a-1a100a0a1", "J4v4 HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:", (java.lang.CharSequence) "0.9                                Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(".80-b11", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1", "001a23a100 101a1100 10a01a4100 10", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a" + "'", str3.equals(".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a100a0a1", "\n", 5);
        java.lang.String[] strArray8 = new java.lang.String[] { "sophie" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "041484-", (java.lang.CharSequence[]) strArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#0#100#0#100#100", (java.lang.CharSequence) "100...", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 -1 1 100 0", 143);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.71.71.", (java.lang.CharSequence) "  84#10  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                    ", (java.lang.CharSequence) "                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "t");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.", 102);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", 8, "10a0a100a0a100a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a" + "'", str3.equals("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_8", "4 4 a 4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7", "10.0 31.0 10.0", "444414#4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7" + "'", str3.equals("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0_80", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a-1a100a100a10", "Java: :Platform: :API: :Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SOPHI", (java.lang.CharSequence) "44444444444444444440a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com", (java.lang.CharSequence) "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0", (java.lang.CharSequence) "001a23a100 101a1100 10a01a4100 10", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444444", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 44444444444444444444444444444444444" + "'", str2.equals("                                                                 44444444444444444444444444444444444"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10a1a...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.0 31.0 10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils5 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4, numberUtils5 };
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils11 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils12 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray13 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils7, numberUtils8, numberUtils9, numberUtils10, numberUtils11, numberUtils12 };
        org.apache.commons.lang3.math.NumberUtils numberUtils14 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils17 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils18 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils19 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray20 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils14, numberUtils15, numberUtils16, numberUtils17, numberUtils18, numberUtils19 };
        org.apache.commons.lang3.math.NumberUtils numberUtils21 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils22 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils23 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils24 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils25 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils26 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray27 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils21, numberUtils22, numberUtils23, numberUtils24, numberUtils25, numberUtils26 };
        org.apache.commons.lang3.math.NumberUtils numberUtils28 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils29 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils30 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils31 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils32 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils33 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray34 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils28, numberUtils29, numberUtils30, numberUtils31, numberUtils32, numberUtils33 };
        org.apache.commons.lang3.math.NumberUtils numberUtils35 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils36 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils37 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils38 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils39 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils40 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray41 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils35, numberUtils36, numberUtils37, numberUtils38, numberUtils39, numberUtils40 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray42 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray6, numberUtilsArray13, numberUtilsArray20, numberUtilsArray27, numberUtilsArray34, numberUtilsArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray42);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray13);
        org.junit.Assert.assertNotNull(numberUtilsArray20);
        org.junit.Assert.assertNotNull(numberUtilsArray27);
        org.junit.Assert.assertNotNull(numberUtilsArray34);
        org.junit.Assert.assertNotNull(numberUtilsArray41);
        org.junit.Assert.assertNotNull(numberUtilsArray42);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#4#a#####", "1.7.0_80", 8);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, ":");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#4#a#####" + "'", str6.equals("4#4#a#####"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                     ", 32, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                     " + "'", str3.equals("                                                                                                     "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4 4 a # #", (java.lang.CharSequence) "4A4AAA#A#A AAAAAAAAAAAAAAAAAAAAA", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10#0#1...", "001a23a81a1-a01a48");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        byte[][] byteArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        char[] charArray9 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#4#a##### " + "'", str11.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4#4#a##### " + "'", str16.equals("4#4#a##### "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#######4 4 a # #", 9, "001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48001#23#81#1-#01#48");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######4 4 a # #" + "'", str3.equals("#######4 4 a # #"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 104L, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          " + "'", str1.equals("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          "));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10a1a8a-1", "84#10#-1#18#32#100", "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84a10a-1a18a32a100", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "84a10a-1a18a32a100" + "'", str6.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Libra");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931################" + "'", str3.equals("###############/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931################"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        short[] shortArray0 = new short[] {};
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4#4#A#####", (java.lang.CharSequence) "10 1 8 -1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0431.0410.045.0484.0", "9.0", "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0431.0410.045.0484.0" + "'", str4.equals("0.0431.0410.045.0484.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.14.3", "0.0431.0410.045.0484.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray13 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray13, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 10", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "84#10#-1#18#32#1", charArray13);
        try {
            java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray13, '4', 7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4#4#a##### " + "'", str15.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "# # a 4 41");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("41484-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "41484-1" + "'", str1.equals("41484-1"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 6L, (float) (byte) 100, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0############################################################################################################################################", "51.0", 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 4, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, (int) (short) 4, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Use\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("###", 100410);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###" + "'", str2.equals("###"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "4 a # #");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################" + "'", str2.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SOPHI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("44444444444444444440a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444440a-1a100a0a1" + "'", str1.equals("44444444444444444440a-1a100a0a1"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("               1.71.71.4#4#a###");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "erJobaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a##", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass11 = byteArray2.getClass();
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 10 + "'", byte12 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1041484-1" + "'", str17.equals("1041484-1"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   " + "'", str2.equals("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "444414#", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "444414#" + "'", charSequence2.equals("444414#"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                                                 t                                                  ", 4, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                 t                                                  " + "'", str4.equals("                                                 t                                                  "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8L, (float) (byte) 1, (float) 84L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                ", "1041484-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                " + "'", str2.equals("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...aa1a1aa01a4a", "#######4 4 a # #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...aa1a1aa01a4a" + "'", str2.equals("...aa1a1aa01a4a"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        char[] charArray13 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray13, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "        ", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray13);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray13, 'a', 7, 2);
        int int25 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", charArray13);
        boolean boolean26 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4#4#a##### " + "'", str15.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("J#v# HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J#v# HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a a - a a aaa a a a a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.9d, 0.0d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a" + "'", str1.equals(".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10.0410.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0410.0410.04-1.0" + "'", str1.equals("10.0410.0410.04-1.0"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 10", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100", charArray11);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', (int) '4', 102);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("####                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####" + "'", str1.equals("####"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "########################################################################################################", 11, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("# #", 32, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                             # #" + "'", str3.equals("                             # #"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 9, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("...aa1a1aa01a4a", (byte) 9);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 9 + "'", byte2 == (byte) 9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.71.71.", (java.lang.CharSequence) "4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("9.0", 11, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.0431.0410.0", 9, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0431.0410.0" + "'", str3.equals("10.0431.0410.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444", 100, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("####                            ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100 10" + "'", str6.equals("100 10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10" + "'", str9.equals("100a10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a10" + "'", str11.equals("100a10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 10" + "'", str13.equals("100 10"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                  ", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 102);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("9.", "Jv(TM) E Runtime Environment");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 30, (-1));
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lw");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lw\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6", 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.-b15");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0 -1 100 0 1", "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1 100 0 1" + "'", str2.equals("0 -1 100 0 1"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1041484-1", "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041484-1" + "'", str2.equals("1041484-1"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean10 = javaVersion5.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "...aa1a1aa01a4a", (java.lang.CharSequence) "0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        char[] charArray9 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 8, (int) (short) 0);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "041484-", charArray9);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#4#a##### " + "'", str11.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4a4aaa#a#a " + "'", str14.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4444a4#4#4 " + "'", str21.equals("4444a4#4#4 "));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 9 + "'", byte3 == (byte) 9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10#0#1...", (java.lang.CharSequence) "0a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10 1 8 -1", (int) 'a', 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 1 8 -1" + "'", str3.equals("10 1 8 -1"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 97, 16);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                               ", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               " + "'", str2.equals("               "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444a4#4#4", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4", "HTTP://JAVA.ORACLE.COM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        short[] shortArray5 = new short[] { (byte) 10, (byte) 100, (byte) -1, (short) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) ' ', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 104, 5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        char[] charArray10 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.0 31.0 10.0", charArray10);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 19, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4#4#a##### " + "'", str12.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("844104-14184324100", "", "aaaaaaa1.5aaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "844104-14184324100" + "'", str3.equals("844104-14184324100"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, (long) 35, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("en4 4  # #  4 4  # #  4 4  #1.7", "0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_8", "1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.20.14.1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        char[] charArray8 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#4#a##### " + "'", str10.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class [Cclass [S");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "# # a 4 4", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#4#a##### ", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "               1.71.71.4#4#a###", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4a4aaa#a#a " + "'", str19.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " 0_80 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".80-b11", "8.0410.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "100.0 -1.0 15.0 -1.0 8.0 6.0", 9, 2);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#a4aaa aaa ", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#a4aaa aaa " + "'", str10.equals("#a4aaa aaa "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7."));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0410.0" + "'", str5.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8.0410.0" + "'", str8.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8.0 10.0" + "'", str10.equals("8.0 10.0"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 84, 0);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a0a100a0a100a100" + "'", str13.equals("10a0a100a0a100a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "0.0#31.0#10.0#5.0#84.0", (int) (short) 9);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mode.slaB..");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam.twawl.nus");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10.14.31", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0", "10a0a100a0a100a100", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "#a4aaa aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.310.14.310.1", 212, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#4#a##### ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.CharSequence[] charSequenceArray9 = new java.lang.CharSequence[] { "1.7", ":", "10.14.3", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "hi!", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" };
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequenceArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray9);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/", charSequenceArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10.0410.0410.04-1.0", charSequenceArray9);
        org.junit.Assert.assertNotNull(charSequenceArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 84 + "'", int10 == 84);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 1 8 -1", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("BOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bojretnirpc.xsocam.twawl.nus" + "'", str1.equals("bojretnirpc.xsocam.twawl.nus"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0a31.0a10.0", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        double[] doubleArray4 = new double[] { 10.0d, 10.0f, 10L, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 10.0 10.0 -1.0" + "'", str6.equals("10.0 10.0 10.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0a10.0a10.0a-1.0" + "'", str8.equals("10.0a10.0a10.0a-1.0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("# # a 4 41");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# # a 4 41" + "'", str1.equals("# # a 4 41"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1041484-1", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041484-11041484-11041484-11041484-11041484-11041484-11041484-1" + "'", str2.equals("1041484-11041484-11041484-11041484-11041484-11041484-11041484-1"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#a4aaa aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4aaa aaa" + "'", str1.equals("#a4aaa aaa"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaa1.5aaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0.9                                Mac OS X", 0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9                                Mac OS X" + "'", str3.equals("0.9                                Mac OS X"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.71.71.4#4#####", (java.lang.CharSequence) "mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("001a23a1a1a01a4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"01a23a1a1a01a4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", (java.lang.CharSequence) "#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 13, (int) (short) 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!", 9, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!enenen" + "'", str3.equals("hi!enenen"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0410.0" + "'", str5.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8.0 10.0" + "'", str8.equals("8.0 10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8.0a10.0" + "'", str10.equals("8.0a10.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4#4#a#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#a#####" + "'", str1.equals("4#4#a#####"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84#10#-1#18#32#100", "# #  ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str7.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        double[] doubleArray4 = new double[] { 4L, 35, 10.0f, 104.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4.0 35.0 10.0 104.0" + "'", str6.equals("4.0 35.0 10.0 104.0"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4a4aaa#a#a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en4 4  # #  4 4  # #  4 4  #1.7", "aaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", (int) (byte) 9, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...            ..." + "'", str3.equals("...            ..."));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com" + "'", str1.equals("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "     ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "52#1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a", "aaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a" + "'", str3.equals(".ecccccccccccccccccccccccAcccccccccccccccccccccaO.a"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10a0a100a0a100a100", 104);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      10a0a100a0a100a100" + "'", str2.equals("                                                                                      10a0a100a0a100a100"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("101010101010101010101010101010101010", "4#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4#4#A#####");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("bojretnirpc.xsocam.twawl.nus", "00.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0/Libra", (java.lang.CharSequence) "#a4aaa aaa ", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "1.7.0_80", 2);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "8.0 10.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("52#1", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#1" + "'", str2.equals("52#1"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####", "10.0431.0410.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("####       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####       " + "'", str1.equals("####       "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1001.6-11.6-1", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", (java.lang.CharSequence) "001a23a#1a1#a01a4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("100410", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100410" + "'", str2.equals("100410"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10a1a8a-1", "84#10#-1#18#32#100", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a8a-1" + "'", str3.equals("10a1a8a-1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a0a100a0a100a100" + "'", str13.equals("10a0a100a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        char[] charArray10 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 8, (int) (short) 0);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a##", charArray10);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com", charArray10);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", charArray10);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', (int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4#4#a##### " + "'", str12.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4a4aaa#a#a " + "'", str15.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("nt.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nt.jar" + "'", str1.equals("nt.jar"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "1041484-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "     ", (java.lang.CharSequence) "1001.6-11.6-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 84.0f, (-1.0d), (double) (short) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 84.0d + "'", double3 == 84.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("84a10a-1a18a32a100", "100#-1#-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 104, (double) 31, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 104.0d + "'", double3 == 104.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa", "8.0a10.0", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a8.0a10.0a" + "'", str3.equals("4a8.0a10.0a"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("01a0a001a0a01001a001a0a001a0a010");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 9, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 9 + "'", byte3 == (byte) 9);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 4444444444444444444444444444444444444444444444444444444444444444444444444#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10a1a8a-1" + "'", str14.equals("10a1a8a-1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("boJretnirPC.xsoc m.tw wl.nus", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) ' ', (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                 t                                                  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "a##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1192, 16, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("moc.elcaro.avaj//:ptth");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"moc.elcaro.avaj//:ptth\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0a-1a100a0a1", "84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100", "...            ...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1041484-11041484-11041484-11041484-11041484-11041484-11041484-1", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1" + "'", str2.equals("1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SOPHI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4 4 a # #  ", "13.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 92, 143L, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        float[] floatArray5 = new float[] { 35L, 97.0f, (-1L), 1.1f, 576 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 576.0f + "'", float6 == 576.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1001.6-11.6-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80", 15);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "9", (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("444414#                         ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        long[] longArray3 = new long[] { 100L, (-1), (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 -1 -1" + "'", str5.equals("100 -1 -1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "01a0a001a0a01001a001a0a001a0a010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " 4 a # #  ", (java.lang.CharSequence) "                                                                                                      ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6, (double) 100410, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0#-1.0#15.0#-1.0#8.0#6.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#4#a##### ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (java.lang.CharSequence) "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("# #", "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# #" + "'", str2.equals("# #"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("010a0a100a0a100a10010a0a100a0a10", 92, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class [Cclass [S", (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(".");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#4#a#####   0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9", "44444444444444444444444444444444", 143);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SOPHI", "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.14");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14" + "'", str1.equals("10.14"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((-1L), (long) 102, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 102L + "'", long3 == 102L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                               4#4#a##### 444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http://java.oracle.com", "52#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com" + "'", str2.equals("http://java.oracle.com"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "# # a 4 4", (java.lang.CharSequence) "10#0#1...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7", (java.lang.CharSequence) "", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en4 4  # #  4 4  # #  4 4  #1.7", (java.lang.CharSequence) "1.71.71.4#4#a###", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("92");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 92.0f + "'", float1 == 92.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "451.0451.0a51.0#51.0#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4#4#a#####   ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 32, 7);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "4 4 a # #  ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a-1a100a0a1");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "4a4aaa#a#a ", 100, (int) '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("1.0############################################################################################################################################", strArray4, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "en4 4  # #  4 4  # #  4 4  #1.7", (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0############################################################################################################################################" + "'", str12.equals("1.0############################################################################################################################################"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                          ", "            hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", (java.lang.CharSequence) "...aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(19, 15, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44a##", (java.lang.CharSequence) "0#-1#100#0#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                      10a0a100a0a100a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      10a0a100a0a100a100" + "'", str1.equals("                                                                                      10a0a100a0a100a100"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "acle Corporation", (java.lang.CharSequence) "100...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1192.0f, 2.0f, (float) 92);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1192.0f + "'", float3 == 1192.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", (java.lang.CharSequence) "aaaaaaaaa", 102);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.Class<?> wildcardClass10 = strArray4.getClass();
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80-b15" + "'", str9.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####       ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ", 100410, (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" HotSpot(TM) 64-Bit Server VavaJ", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VavaJ"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(92L, (long) 35, (long) 576);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " 10.14.31 ", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.0a31.0a10.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a31.0a10.0" + "'", str2.equals("10.0a31.0a10.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) 100, (short) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 31, 574);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#################################################################################################", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        char[] charArray13 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray13, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4#4#a##### " + "'", str15.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "2.80-B11", (java.lang.CharSequence) "10a0a100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "4#4#a##### ", (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("...            ...", "100.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 8, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkit", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "1.7.0_80", 2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.0", (int) (byte) 100, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84a10a-1a18a32a100", "51.0", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("", "4 4 a # #  ");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4", strArray9, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("  1.7.0_80", strArray5, strArray12);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  ", ' ');
        java.lang.Class<?> wildcardClass18 = strArray17.getClass();
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "10");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        int int23 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray17);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("84 10 -1 18 32 100", strArray5, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "84a10a-1a18a32a100" + "'", str6.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "  1.7.0_80" + "'", str14.equals("  1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "101010101010101010101010101010101010" + "'", str20.equals("101010101010101010101010101010101010"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          " + "'", str22.equals("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          "));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a", (java.lang.CharSequence) "10 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 100", 104);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "84#10", (java.lang.CharSequence) "mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie", (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("52#1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "001a23a#1a1#a01a4#", (java.lang.CharSequence) "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("001a23a#1a1#a01a4#", (float) 45);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 45.0f + "'", float2 == 45.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("8.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"8.0#10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0", "0a-1a-1a100a100a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0" + "'", str2.equals("####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.Class<?> wildcardClass15 = byteArray6.getClass();
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10#0#100#0#100#100" + "'", str18.equals("10#0#100#0#100#100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10 0 100 0 100 100" + "'", str20.equals("10 0 100 0 100 100"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.0 10.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("8.0410.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

