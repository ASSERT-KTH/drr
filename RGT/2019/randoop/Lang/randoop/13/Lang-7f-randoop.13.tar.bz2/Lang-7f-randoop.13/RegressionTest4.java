import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Oracle Corporation", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.71.71.", "#######4 4 a # #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71." + "'", str2.equals("1.71.71."));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, 5L, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#######4 4 a # #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...aa1a1aa01a4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...aa1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "1.71.71.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("41484-1", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "41484-1" + "'", str3.equals("41484-1"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", "####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", (java.lang.CharSequence) "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4#4#a##### ", "4444a4#4#4 ", "0a-1a100a0a", (int) (short) 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4#4#a##### " + "'", str4.equals("4#4#a##### "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10#0#100#0#100#100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.310.14.310.1", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4#4#a##### ", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a-1a100a0a1");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4a4aaa#a#a ", 100, (int) '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0 a - 1 a 100 a 0 a 1" + "'", str10.equals("0 a - 1 a 100 a 0 a 1"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444440a-1a100a0a1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String[] strArray3 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                    ", 5, (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", "UTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-" + "'", str2.equals("UTF-"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("http:", (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.9     ", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9     " + "'", str3.equals("0.9     "));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.Class<?> wildcardClass15 = byteArray6.getClass();
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (short) -1, 45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "104041004041004100" + "'", str18.equals("104041004041004100"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str8 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.3" + "'", str8.equals("1.3"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("a10a-1a18a32a10084a10a-1a18a32a1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Library/Java/Ja", (java.lang.CharSequence) "                                                                                               100 -1 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4.80-B11.80-B11.80-B11.80", (java.lang.CharSequence) "0.9     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4#4#a#####", "01#001#001#1-#1-#0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4a4aaa#a#a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a4aaa#a#a " + "'", str1.equals("4a4aaa#a#a "));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 9, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 9 + "'", byte3 == (byte) 9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10#0#100#0#100#100", "0#-1#100#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#a4aaa aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4aaa aaa" + "'", str1.equals("#a4aaa aaa"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ", 18);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0#-1#-1#100#100#10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (short) 9, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double[] doubleArray4 = new double[] { 4L, 1.1f, 100.0d, 8.0d };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("en4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en44##44##44#1.7" + "'", str1.equals("en44##44##44#1.7"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10 1 8 -1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4a4aaa#a#a ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("  1.7.0_80", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  1.7.0_80" + "'", str2.equals("  1.7.0_80"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '#', (int) (short) 10, (int) (byte) 9);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("100 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1 -1" + "'", str1.equals("100 -1 -1"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "       10.14.31 ", (java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(9L, (long) 31, (long) 45);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100", "J4v4 HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("J4v4 HotSpot(TM) 64-Bit Server VM", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   " + "'", str2.equals("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.9");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.9f + "'", float1 == 0.9f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 9, (double) 13.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "  1.7.0_80", (java.lang.CharSequence) "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".80-B11", (long) 143);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 143L + "'", long2 == 143L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 26, (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.310.14.310.1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("####", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####" + "'", str2.equals("####"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "  1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7" + "'", str1.equals("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71." + "'", str1.equals("1.71.71."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "4444a4#4#4 ");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "84a10a-1a18a32a100");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####       ", (java.lang.CharSequence) "101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(16, 29, 1192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100", 6, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100" + "'", str3.equals("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4a4aaa#a#a " + "'", str20.equals("4a4aaa#a#a "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "4444a4#4#4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 1, (-1));
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a4aaa#a#a ", "24.80-B11", 11);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("9.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("2.80-B11", "Mac OS X", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.80-B11" + "'", str3.equals("2.80-B11"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  ", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10.14.3");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "###", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str5.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.", (int) 'a', "0#-1#100#0#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#" + "'", str3.equals("1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 104);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.71.71.4#4#a###", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a-1a100a0a", "84#10#-1#18#32#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-B11", "0 a - 1 a 100 a 0 a 1", "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("erJob", "####       ", "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erJob" + "'", str3.equals("erJob"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) (byte) 10, (int) (short) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4#4#a#####   ", "100.0#-1.0#15.0#-1.0#8.0#6.0", "10a0a100a0a100a100", 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4#4#a#####   " + "'", str4.equals("4#4#a#####   "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0.9     ", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9     " + "'", str2.equals("0.9     "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4#4#a##### ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SOPHI", "9.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 143 + "'", int3 == 143);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.31", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..." + "'", str1.equals("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ..."));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4 4 a # #  4 4 a # #  4 4 a #1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0a-1a100a0a1", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a100a0a1" + "'", str2.equals("0a-1a100a0a1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", (java.lang.CharSequence) "sophi", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1001.6-11.6-1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "001a23a1a1a01a4", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "84a10a-1a18a32a100" + "'", str12.equals("84a10a-1a18a32a100"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4444a4#4#4", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444a4#4" + "'", str2.equals("4444a4#4"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 15.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 15.0f + "'", float3 == 15.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) (short) 0, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwwt.mcosx.LWCToolkit", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str2.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0 a - 1 a 100 a 0 a 1", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", (int) (byte) 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(7.0f, 2.0f, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", (int) (short) 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               " + "'", str2.equals("                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(".80-b11", "84#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".80-b11" + "'", str2.equals(".80-b11"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10#0#100#0#100#100", "10#0#100#0#100#100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0#-1#-1#100#100#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        short[] shortArray5 = new short[] { (byte) 10, (byte) 100, (byte) -1, (short) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) ' ', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 104, 5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 576, (int) (byte) -1);
        short short18 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 100 + "'", short18 == (short) 100);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "104041004041004100", (java.lang.CharSequence) "4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" 4 a # #  ", (long) (short) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.71.71.4#4#####", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.4#4#####" + "'", str2.equals("1.71.71.4#4#####"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#" + "'", str3.equals("1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        " + "'", str2.equals("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        "));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "24.80-B11", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("# #", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100 10", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444a4#4#4 #4444a4#4#4  4444a4#4#4 #4444a4#4#4  4444a4#4#4  4444a4#4#4 ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("            hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("010a0a100a0a100a10010a0a100a0a10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "010a0a100a0a100a10010a0a100a0a10" + "'", str2.equals("010a0a100a0a100a10010a0a100a0a10"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "41484-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("###");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("84#10#-1#18#32#1", 143, 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "84#10#-1#18#..." + "'", str3.equals("84#10#-1#18#..."));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0a-1a-1a100a100a10", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a-1a100a100a10" + "'", str2.equals("0a-1a-1a100a100a10"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, 35L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4444a4#4#4", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.14", "0_80", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14" + "'", str3.equals("10.14"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: J4v4 HotSpot(TM) 64-Bit Server VM                                                                    is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) 3, 9L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int[] intArray4 = new int[] { 97, 26, (short) -1, 100 };
        int[] intArray9 = new int[] { 97, 26, (short) -1, 100 };
        int[][] intArray10 = new int[][] { intArray4, intArray9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray10, "", 52, 5);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.4", "J#v# HotSpot(TM) 64-Bit Server VM", "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", (java.lang.CharSequence) "                                             .80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.2", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "4444a4#4#4 ", "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("nt.jar", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nt.jar" + "'", str2.equals("nt.jar"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "13.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("041484-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "041484-" + "'", str1.equals("041484-"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("010a0a100a0a100a10010a0a100a0a10", 576, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "8.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Jv(TM) E Runtime Environment", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0a31.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a31.0a10.0" + "'", str1.equals("10.0a31.0a10.0"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0#-1#-1#100#100#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" 4 a # #  ", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4 4 # #  " + "'", str3.equals(" 4 4 # #  "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0_80", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", "0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (java.lang.CharSequence) "0a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " ", (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.3", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(".", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 1, 84L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 84L + "'", long3 == 84L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444", "10a1a8a-1", "4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", "/Libra");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/Ja", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"USaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" ", 84, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa" + "'", str3.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0a-1a100a0a1", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a100a0a1" + "'", str2.equals("0a-1a100a0a1"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.71.71.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 576, "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84a10a-1a18a32a100", "51.0", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam.twawl.nus");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray4, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a', 7, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/Ja", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/Ja" + "'", str2.equals("/Library/Java/Ja"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "# #  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("J#v# HotSpot(TM) 64-Bit Server VM", 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1041484-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) 104L, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("en44##44##44#1.7", "4444a4#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", "       10.14.31 ", (int) (byte) 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 18, 0L, (long) 25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("wl.nus m.tw boJretnirPC.xsoc", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "wl.nus m.tw boJretnirPC.xsoc" + "'", str3.equals("wl.nus m.tw boJretnirPC.xsoc"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 35, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a31.0a10.0" + "'", str7.equals("10.0a31.0a10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a-1a100a0a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", "", (int) (byte) 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.3" + "'", str4.equals("10.14.3"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, 0L, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".80-B11", "84 10 -1 18 32 100", "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".slaB.." + "'", str3.equals(".slaB.."));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3L, (double) 16, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 9, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "24.80-B11");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "0#-1#100#0#1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lw", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("8.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8.0410.0" + "'", str1.equals("8.0410.0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en44##44##44#1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("9.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4a4aaa#a#a ", (java.lang.CharSequence) "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', 'a', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", charArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#a4aaa aaa " + "'", str11.equals("#a4aaa aaa "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "# # a 4 4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1", "                  ", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10 1 8 -1", (java.lang.CharSequence) "100.0 -1.0 15.0 -1.0 8.0 6.0", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.30.9", (java.lang.CharSequence) "11b-08.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0_80", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 0_80 " + "'", str2.equals(" 0_80 "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) (byte) 1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10", "4 4 a # #  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("nt jar", ":ptth");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam.twawl.nus");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) ' ', 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                    ", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(".80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.71.71.4#4#a###", 31, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               1.71.71.4#4#a###" + "'", str3.equals("               1.71.71.4#4#a###"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 8.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "http:", (java.lang.CharSequence) "84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(8.0f, 97.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("####", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####                            " + "'", str2.equals("####                            "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("001a23a                  1a1                  a01a4                  ", "1.7", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001a23a                  1a1                  a01a4                  " + "'", str3.equals("001a23a                  1a1                  a01a4                  "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "2.80-B11", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("nt.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nt.jar" + "'", str2.equals("nt.jar"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1041484-1", "10#0#100#0#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041484-1" + "'", str2.equals("1041484-1"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "4", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 102 + "'", int3 == 102);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 -1 100 0 1" + "'", str13.equals("0 -1 100 0 1"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 'a', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("451.0451.0a51.0#51.0#", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, (float) 0, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1001.6-11.6-1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 0, (int) (byte) 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10a1a8a-1" + "'", str17.equals("10a1a8a-1"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "001a23a                  1a1                  a01a4                  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        " + "'", str1.equals("        "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4#4#a##### ", (java.lang.CharSequence) "100#-1#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############..." + "'", str2.equals("###############..."));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                ", "                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                " + "'", str2.equals("                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444                                "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "9.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("boJretnirPC.xsoc m.tw wl.nus", 35, ".80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "boJretnirPC.xsoc m.tw wl.nus.80-b11" + "'", str3.equals("boJretnirPC.xsoc m.tw wl.nus.80-b11"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":ptth", (-1), "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":ptth" + "'", str3.equals(":ptth"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0" + "'", str3.equals("0.0"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       0.0431.0410.045.0484.0", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 18, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "84#10#-1#18#32#100" + "'", str16.equals("84#10#-1#18#32#100"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1041484-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4 4 a # #", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4 a # #" + "'", str2.equals("4 4 a # #"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("####       ", "4.80-B11.80-B11.80-B11.80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####       " + "'", str2.equals("####       "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "       10.14.31 ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444a4#4", "aaaaaaaaa", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444414#4" + "'", str3.equals("444414#4"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.71.71.4#4#a###", "100.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.4#4#a###" + "'", str2.equals("1.71.71.4#4#a###"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("            hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"            hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a100a0a1", "\n", 5);
        java.lang.String[] strArray6 = new java.lang.String[] { "sophie" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", 2, 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa", "10.14.3", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" 10.14.31 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 10.14.31 " + "'", str1.equals(" 10.14.31 "));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.-b15" + "'", str1.equals("1.7.-b15"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double[] doubleArray4 = new double[] { 32.0d, (byte) 100, 8.0f, 0.0d };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100.0#-1.0#15.0#-1.0#8.0#6.0", "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", "1001.6-11.6-1", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0#-1.0#15.0#-1.0#8.0#6.0" + "'", str4.equals("100.0#-1.0#15.0#-1.0#8.0#6.0"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 84, 10);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "# #  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3, 0.9f, (float) 18L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.9f + "'", float3 == 0.9f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.4", "boJretnirPC.xsocam.twawl.nus", "                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0 -1 100 0 1", "84 10 -1 18 32 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1 100 0 1" + "'", str2.equals("0 -1 100 0 1"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("041484-", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-" + "'", str2.equals("041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-041484-"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", charSequenceArray1);
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#################################################################################################", 29, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################" + "'", str3.equals("#################################################################################################"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("9.0", "4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444", "####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9.0" + "'", str3.equals("9.0"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str1.equals("4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "9.", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                ", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.71.71.4#4#####", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####" + "'", str2.equals("1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                    ", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "     ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a" + "'", str1.equals("8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" ", 0, "844104-14184324100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10a1a...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1a...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("9.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("#a4aaa aaa", "###############...", 100, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###############..." + "'", str4.equals("###############..."));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("J#v# HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime Environment", 0, "J4v4 HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(45, 4, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 45 + "'", int3 == 45);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4 4 a # #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44a##" + "'", str1.equals("44a##"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("11b-08.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11b-08." + "'", str1.equals("11b-08."));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", "9.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 102, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                      " + "'", str3.equals("                                                                                                      "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:", (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "010a0a100a0a100a10010a0a100a0a10", 2, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100", (java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str7 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean10 = javaVersion6.atLeast(javaVersion8);
        boolean boolean11 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str13 = javaVersion12.toString();
        boolean boolean14 = javaVersion5.atLeast(javaVersion12);
        boolean boolean15 = javaVersion2.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com" + "'", str1.equals("http://java.oracle.com"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.Enum<org.apache.commons.lang3.JavaVersion>[] javaVersionEnumArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(javaVersionEnumArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', (int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(".80-b11", (double) 576);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 576.0d + "'", double2 == 576.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.2", 104);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        long[] longArray2 = new long[] { '4', (short) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52#1" + "'", str6.equals("52#1"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("844104-14184324100", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "844104-14184324100" + "'", str2.equals("844104-14184324100"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-1a100a0a1" + "'", str1.equals("0a-1a100a0a1"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1", "aaaaaaaaaaa", "en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("8.0 10.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 a # #  " + "'", str1.equals("4 4 a # #  "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                     " + "'", str1.equals("                                                                                                     "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        char[] charArray9 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.9", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "t", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#4#a##### " + "'", str11.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4a4aaa#a#a " + "'", str14.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.0", "", 45);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0a-1a-1a100a100a10", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("01", "84a10a-1a18a32a100", "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#a4aaa aaa ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("04-14-141004100410");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1", 16, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0 -1 100 0 1", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("010a0a100a0a100a10010a0a100a0a10", "a10a-1a18a32a10084a10a-1a18a32a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "010a0a100a0a100a10010a0a100a0a10" + "'", str2.equals("010a0a100a0a100a10010a0a100a0a10"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.9                                ", "Mac OS X", (int) (short) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9                                Mac OS X" + "'", str4.equals("0.9                                Mac OS X"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10a1a8a-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a8a-1" + "'", str2.equals("10a1a8a-1"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10#0#100#0#100#100", "####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#0#100#0#100#100" + "'", str2.equals("10#0#100#0#100#100"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "1.71.71.4#4#a###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", (java.lang.CharSequence) "#a4aaa aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 18, 0);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "boJretnirPC.xsoc m.tw wl.nus.80-b11", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "boJretnirPC.xsoc m.tw wl.nus", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0#10.0" + "'", str5.equals("8.0#10.0"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444a4#4#4 #4444a4#4#4  4444a4#4#4 #4444a4#4#4  4444a4#4#4  4444a4#4#4 ", "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa", "100410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444a4#4#4 #4444a4#4#4  4444a4#4#4 #4444a4#4#4  4444a4#4#4  4444a4#4#4 " + "'", str3.equals("4444a4#4#4 #4444a4#4#4  4444a4#4#4 #4444a4#4#4  4444a4#4#4  4444a4#4#4 "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a100a0a1", "\n", 5);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) 576, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                             .80-b11", "en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en", "001a23a100 101a1100 10a01a4100 10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str2 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str7 = javaVersion0.toString();
        java.lang.String str8 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", (java.lang.CharSequence) "aaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "001a23aa1a1aa01a4a" + "'", str5.equals("001a23aa1a1aa01a4a"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "001a23a#1a1#a01a4#" + "'", str7.equals("001a23a#1a1#a01a4#"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10a1a...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1a..." + "'", str1.equals("10a1a..."));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0a-1a-1a100a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                               hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("451.0451.0a51.0#51.0#", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "451.0451.0a51.0#51.0#" + "'", str2.equals("451.0451.0a51.0#51.0#"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a" + "'", str1.equals("1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#######4 4 a # #", 576);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######4 4 a # #" + "'", str2.equals("#######4 4 a # #"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 9, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion1.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###############...", (java.lang.CharSequence) "Oracle Corporation", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("104041004041004100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "104041004041004100" + "'", str1.equals("104041004041004100"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, (float) 102, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("13.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "100.0 -1.0 15.0 -1.0 8.0 6.0", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100.0 -1.0 15.0 -1.0 8.0 6.0" + "'", charSequence2.equals("100.0 -1.0 15.0 -1.0 8.0 6.0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (float) 7L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("a##", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa", "#a4aaa aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "a10a-1a18a32a10084a10a-1a18a32a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0_80", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0a-1a-1a100a100a10", 0, " 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a-1a-1a100a100a10" + "'", str3.equals("0a-1a-1a100a100a10"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("001a23a#1a1#a01a4#", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001a23a#1a1#a01a4#" + "'", str2.equals("001a23a#1a1#a01a4#"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("84a10a-1a18a32a100", "10.0 10.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "84a10a-1a18a32a100" + "'", str2.equals("84a10a-1a18a32a100"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4#4#a##### ", "0 -1 100 0 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4#a##### " + "'", str2.equals("4#4#a##### "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("104.0#-1.0#1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100", (java.lang.CharSequence) ".80-B11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("###");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###" + "'", str1.equals("###"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0 a - 1 a 100 a 0 a 1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", "Aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a a - a a aaa a a a a" + "'", str3.equals("a a - a a aaa a a a a"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "101010101010101010101010101010101010" + "'", str1.equals("101010101010101010101010101010101010"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        char[] charArray11 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4#4#a##### " + "'", str13.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4444a4#4#4 " + "'", str19.equals("4444a4#4#4 "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "101010101010101010101010101010101010", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010" + "'", str3.equals("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("041484-", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "041484-" + "'", str3.equals("041484-"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM" + "'", str1.equals("HTTP://JAVA.ORACLE.COM"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.0a31.0a10.0a5.0a84.0", ":", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "a##", "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com", "104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com" + "'", str2.equals("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "####", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie", (java.lang.CharSequence) "sun.lw", 104);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("nt jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("boJretnirPC.xsoc m.tw wl.nus", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test444");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10#0#100#0#100#100", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#0#1..." + "'", str2.equals("10#0#1..."));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################################################################" + "'", str1.equals("#################################################################################################"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("001a23aa1a1aa01a4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0_80", "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ".slaB..", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4#4#a#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("a a - a a aaa a a a a", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '4', 'a', '4', '4', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "1.7.0_80", 2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4 4  # #  4 4  # #  4 4  #1.7", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a10" + "'", str1.equals("100a10"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0#-1#-1#100#100#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#-1#-1#100#100#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8, "#a4aaa aaa ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophi");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0.9", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("########################################################################################################", "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########################################################################################################" + "'", str2.equals("########################################################################################################"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "moc.elcaro.avaj//:ptth" + "'", str1.equals("moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophi", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.", 18);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "041484-", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaaaa" + "'", str8.equals("aaaaa"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                               100 -1 -1", "/Library/Java/Ja", "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                               100 -1 -1" + "'", str4.equals("                                                                                               100 -1 -1"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        float[] floatArray1 = new float[] { 13 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 13.0f + "'", float4 == 13.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 13.0f + "'", float5 == 13.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Libra", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(143L, 35L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("84a10a-1a18a32a100", 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "4", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        char[] charArray8 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 8, (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "001a23a                  1a1                  a01a4                  ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#4#a##### " + "'", str10.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4a4aaa#a#a " + "'", str13.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4#4#a##### " + "'", str19.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" ");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray5, strArray13);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, " 4 a # #  ", 18, 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80-b15" + "'", str6.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80-b15" + "'", str10.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "en" + "'", str15.equals("en"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str1.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("01", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01" + "'", str2.equals("01"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 4 4 # #  ", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "               /Users/sophie", (int) (byte) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4a4aaa#a#a", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("844104-14184324100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "844104-14184324100" + "'", str1.equals("844104-14184324100"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("9.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9." + "'", str1.equals("9."));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a4aa", "# #", 102);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "10.0 31.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "9.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("001a23a81a1-a01a48");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

