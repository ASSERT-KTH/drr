import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", " 10.14.31 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                             .80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             .80-B11" + "'", str1.equals("                                             .80-B11"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10a0a100a0a100a100" + "'", str16.equals("10a0a100a0a100a100"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "01a0a001a0a01001a001a0a001a0a010", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("J#v# HotSpot(TM) 64-Bit Server VM", "", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.310.14.310.1", 5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("84a10a-1a18a32a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "84a10a-1a18a32a100" + "'", str1.equals("84a10a-1a18a32a100"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.14.31", "                          ", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 18L, (double) 84.0f, (double) 102L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 102.0d + "'", double3 == 102.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        short[] shortArray1 = new short[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 80, 29);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", 9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '#', (int) 'a', (int) (short) 4);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#######4 4 a # #", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "       10.14.31 ");
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "001a23a1a1a01a4" + "'", str10.equals("001a23a1a1a01a4"));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("       0.0431.0410.045.0484.0", "1.013.41.013.41.01");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                             .80-B11", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "44444444444444444440a-1a100a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048" + "'", str1.equals("#10#-1#18#32#1004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#10004-848414#10#-1#18#32#100048"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("nt.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nt.jar" + "'", str1.equals("nt.jar"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10 0 100 0 100 100" + "'", str15.equals("10 0 100 0 100 100"));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4.80-B11.80-B11.80-B11.80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4.80-B11.80-B11.80-B11.80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0 10.0 10.0 -1.0", 212);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 10.0 10.0 -1.0                                                                                                                                                                                                 " + "'", str2.equals("10.0 10.0 10.0 -1.0                                                                                                                                                                                                 "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", (java.lang.CharSequence) "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaa1.5aaaaaaaa", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   aaaaaaa1.5aaaaaaaa    " + "'", str2.equals("   aaaaaaa1.5aaaaaaaa    "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("84#10#-1#18#32#1", "101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "84#10#-1#18#32#" + "'", str2.equals("84#10#-1#18#32#"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("# # a 4 41");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "4a8.0a10.0a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0_80", " HotSpot(TM) 64-Bit Server VavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9" + "'", str1.equals("9"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                     ", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                     " + "'", str3.equals("                                                                                                     "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("13.0", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.0" + "'", str2.equals("13.0"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a31.0a10.0a5.0a84.0" + "'", str1.equals("0.0a31.0a10.0a5.0a84.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 0 100 0 100 100", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) 'a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93//Users/sophie/DocumUTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaa1.5aaaaaaaa", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.14.3en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en" + "'", str2.equals("10.14.3en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', (int) (short) 1, 0);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0#-1#-1#100#100#10" + "'", str17.equals("0#-1#-1#100#100#10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0a-1a-1a100a100a10" + "'", str19.equals("0a-1a-1a100a100a10"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "84#10#-1#18#32#100" + "'", str12.equals("84#10#-1#18#32#100"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 143, (int) ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 0, 2);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "84 10 -1 18 32 100" + "'", str10.equals("84 10 -1 18 32 100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "84#10" + "'", str20.equals("84#10"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "84a10a-1a18a32a100" + "'", str22.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "84#10#-1#18#32#100" + "'", str24.equals("84#10#-1#18#32#100"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie", 9, "101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1sophie10" + "'", str3.equals("1sophie10"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "844104-14184324100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.044", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.044" + "'", charSequence2.equals("1.044"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "erJobaaaa", 8, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("nt.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444a4#4#4", "#a4aaa aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444a4#4#4" + "'", str2.equals("4444a4#4#4"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "      mixed mode.slaB..      ", (java.lang.CharSequence) "10.14.310.14.310.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444a4#4#4 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a-1a100a0a1", (java.lang.CharSequence) "8.0410.0", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                     ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0 -1 1 100 0", "01#001#001#1-#1-#0", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1 1 100 0" + "'", str3.equals("0 -1 1 100 0"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/Ja", (java.lang.CharSequence) "CLE.COM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 4, 102, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 102 + "'", int3 == 102);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("boJretnirPC.xsocam.twawl.nus", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus" + "'", str2.equals("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', (double) 1.7f, (double) 80);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "# #");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "104041004041004100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HTTP://JAVA.ORACLE.COM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 19);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("4#4#A#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#A#####" + "'", str1.equals("4#4#A#####"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "51.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "001a23aa1a1aa01a4a" + "'", str5.equals("001a23aa1a1aa01a4a"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "SOPHI", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", "                                                                                    ", (int) ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.-b15", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("  84#10  ", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931" + "'", str13.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                               ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                               " + "'", str2.equals("                                                                                                                                               "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "844104-14184324100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100410", 212, "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U100410" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U100410"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mixedmode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) '4', (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10#0#100#0#100#100", "", "8.0 10.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java(TM) SE Runtime Environment", "     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100#10", 97, "CLE.COM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#10CLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COM" + "'", str3.equals("100#10CLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COMCLE.COM"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###a#4#4.17.17.1", (java.lang.CharSequence) "100410", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7", "hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7" + "'", str3.equals("1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7hi!hi!hi!hi!hi!hi!hi!hi!hi!h1.7"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("###############/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_1560277931################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0#-1#100#0#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0 10.0 10.0 -1.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.2", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!enenen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!enenen\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".", "1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 16, 0);
        int int18 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "84 10 -1 18 32 100" + "'", str11.equals("84 10 -1 18 32 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "844104-14184324100" + "'", str13.equals("844104-14184324100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4 4 a # #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 a # #" + "'", str1.equals("4 4 a # #"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, (float) 100410, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100410.0f + "'", float3 == 100410.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100#-1#-1100#-1#-1100#-1#-1100#", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#-1#-1100#-1#-1100#-1#-..." + "'", str2.equals("100#-1#-1100#-1#-1100#-1#-..."));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        char[] charArray14 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray14, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray14);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM", charArray14);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       10.14.31 ", charArray14);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                     ", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4#4#a##### " + "'", str16.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", (java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.4 4 a # #  4 4 a # #  4 4 a #1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444a4#4", "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444a4#4" + "'", str2.equals("4444a4#4"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0#-1#100#0#1", "aaaaaaa1.5aaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#-1#100#0#1" + "'", str2.equals("0#-1#100#0#1"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444a4#4#4aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", "A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        " + "'", str2.equals("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("# # a 4 4", "9.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# # a 4 4" + "'", str2.equals("# # a 4 4"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "# #", (java.lang.CharSequence) "84#10#-1#18#32#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-B11", "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/", " 4 4 # #  ", "10 . 14 . 3", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http:", "10.14.31");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 83, (float) '#', (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 83.0f + "'", float3 == 83.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7.1", 576);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;", ".", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("101010101010101010101010101010101010", "boJretnirPC.xsocam.twawl.nus");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " 10.14.31 ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10.14");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14" + "'", str1.equals("10.14"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5, (double) 45, (double) 574);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "2.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4a4aaa#a#a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.2", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMach...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("baaaa", "24.80-b11", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("7.1", "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.1" + "'", str3.equals("7.1"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String[] strArray2 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U100410");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1" + "'", str1.equals(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####                            ", (java.lang.CharSequence) "52#1", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44a##", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str6 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = javaVersion7.atLeast(javaVersion10);
        boolean boolean12 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100.0#-1.0#15.0#-1.0#8.0#6.0  ", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0#-1.0#15.0#-1.0#8.0#6.0  " + "'", str3.equals("100.0#-1.0#15.0#-1.0#8.0#6.0  "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                               ", "24.80-B1124.80-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0 -1 100 0 1", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 31.0f + "'", float5 == 31.0f);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/", "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4#4#a##### ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4#a#####" + "'", str1.equals("4#4#a#####"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                               4#4#a##### 444444444444444444444444444444444444444444444444444444", "1.0/Libra");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi" + "'", str3.equals("sophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophisophi"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 18, (int) (byte) 10);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("# #  ", "0#-1#100#0#1");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("4 4 a # #  ", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4a4aaa#a#" + "'", str9.equals("4a4aaa#a#"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "sophi");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#######4 4 a # #", "####       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4 a # #" + "'", str2.equals("4 4 a # #"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("J4v4 HotSpot(TM) 64-Bit Server VM", 104, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100a10100a104444a4#4#4 100a10100a10", 576, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.0############################################################################################################################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 143 + "'", int4 == 143);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("wl.nus m.tw boJretnirPC.xsoc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "wl.nus m.tw boJretnirPC.xsoc" + "'", str1.equals("wl.nus m.tw boJretnirPC.xsoc"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                               4#4#a##### 444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "\n                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a-1a100a0a1");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "4a4aaa#a#a ", 100, (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "001a23a81a1-a01a48", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "mixed mode/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdka.7.0_a0.jdk/contents/home/jre/users/sophie");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 92, 16);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4444a4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444a4#4" + "'", str1.equals("4444a4#4"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "84#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#10084#10#-1#18#32#100", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 572 + "'", int2 == 572);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                             .80-B11", "                                                    ", 9, 84);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                             " + "'", str4.equals("                                                             "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        char[] charArray12 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray12);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4#4#a##### " + "'", str14.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0#-1#100#0#1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#-1#100#0#1" + "'", str2.equals("0#-1#100#0#1"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "04-14-141004100410" + "'", str13.equals("04-14-141004100410"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4#4#a#####   0.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.90.9");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence) "          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#-1#100#0#1" + "'", str10.equals("0#-1#100#0#1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a100a0a1" + "'", str12.equals("0a-1a100a0a1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.71.71.4#4#a###", 143, ".");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...............................................................1.71.71.4#4#a###................................................................" + "'", str3.equals("...............................................................1.71.71.4#4#a###................................................................"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        double[] doubleArray5 = new double[] { 0.0d, 31, (short) 10, 5, 84.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 102, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0#31.0#10.0#5.0#84.0" + "'", str8.equals("0.0#31.0#10.0#5.0#84.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "nt jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1041484-1", (java.lang.CharSequence) "1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 4, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.013.41.013.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.013.41.013.41.01" + "'", str1.equals("1.013.41.013.41.01"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        double[] doubleArray5 = new double[] { 0.0d, 31, (short) 10, 5, 84.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) (short) 0, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 102, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', 100, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1", (java.lang.CharSequence) "1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("11b-08.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a", 35, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/", "/Libra");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("010a0a100a0a100a10010a0a100a0a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaa", 8, "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0aaaaa00" + "'", str3.equals("0aaaaa00"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "10.0 10.0 10.0 -1.0");
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "0.9     ");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80-b15" + "'", str6.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7.0_80-b15" + "'", str10.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80-b15" + "'", str13.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80-b15" + "'", str16.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80-b15" + "'", str18.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7.0_80-b15" + "'", str19.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.7.0_80-b15" + "'", str21.equals("1.7.0_80-b15"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (byte) 100, (short) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.Class<?> wildcardClass8 = shortArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 574, 3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a-1a100a0a1" + "'", str7.equals("0a-1a100a0a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#-1#100#0#1" + "'", str10.equals("0#-1#100#0#1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100 -1 -1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(84L, (long) 7, (long) 45);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 84L + "'", long3 == 84L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "a##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1041484-11041484-11041484-11041484-11041484-11041484-11041484-1", "8.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "41484-11041484-11041484-11041484-11041484-11041484-11041484-" + "'", str2.equals("41484-11041484-11041484-11041484-11041484-11041484-11041484-"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "4 4 a # #  ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444a4#4#4", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # ...", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444414#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444414#" + "'", str1.equals("444414#"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4#4#a##### ", "###", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#4#a##### " + "'", str3.equals("4#4#a##### "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", "", 102);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("          ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("en44##44##44#1.7", "                                                                                               en", (int) '#', 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "en44##44##                                                                                               en" + "'", str4.equals("en44##44##                                                                                               en"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0 -1 1 100 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####     9.0####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "t", (int) (short) 10, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8" + "'", str1.equals("A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/A23A8A-AA8"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4" + "'", str2.equals("# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4# # a 4 4"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("8.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "8.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "########################################################################################################", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4 a # #", "erJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 a # #" + "'", str2.equals("4 a # #"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("84a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a10084a10a-1a18a32a100", "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84a10a-1a18a32a100", "51.0", 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam.twawl.nus");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray9, strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####0.9     ####", 3, (int) (byte) 0);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("1.04a4aaa", strArray9, strArray16);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_8", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java Virtual Machine Specification" + "'", str13.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.04a4aaa" + "'", str23.equals("1.04a4aaa"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.7.0_8" + "'", str24.equals("1.7.0_8"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31.0f, 8.0d, (double) 104L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 104.0d + "'", double3 == 104.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "001a23aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100...", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.9                                Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.14.", (java.lang.CharSequence) "4a8.0a10.0a", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "84a10a-1a18a32a100");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4 4  # #  4 4  # #  4 4  #1.7", strArray5, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "92");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("          ", strArray1, strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4 4  # #  4 4  # #  4 4  #1.7" + "'", str9.equals("4 4  # #  4 4  # #  4 4  #1.7"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "          " + "'", str12.equals("          "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4a8.0a10.0a", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("####                            ", "4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####                            " + "'", str2.equals("####                            "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.30.9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("#a4aaa aaa ", "", "10.14.3en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#a4aaa aaa " + "'", str3.equals("#a4aaa aaa "));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.", (java.lang.CharSequence) ".80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("01", "a a - a a aaa a a a a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4#4#4##### 444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "010a0a100a0a100a10010a0a100a0a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        long[] longArray2 = new long[] { '4', (short) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) '4', 0);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("baaaa", 97, "4 4 a # #  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 baaaa4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 " + "'", str3.equals("4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 baaaa4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("001a23a                  1a1                  a01a4                  ", 100410, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...   a01a4                  " + "'", str3.equals("...   a01a4                  "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("            hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        char[] charArray9 = new char[] { '#', '4', 'a', ' ', 'a', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en44##44##44#1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Aaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("8.0a10.0", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8.0a10.0" + "'", str3.equals("8.0a10.0"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0" + "'", str1.equals("####       ####       ####       ####       ####       ####       ####       ####     104.0#-1.0#1.0"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        float[] floatArray3 = new float[] { 10.0f, 31, 10 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ");
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        byte[] byteArray12 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray12, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray12, 'a', 8, (int) (short) 1);
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.min(byteArray12);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray12);
        java.lang.Class<?> wildcardClass21 = byteArray12.getClass();
        byte[] byteArray28 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join(byteArray28, 'a', 100, 0);
        java.lang.String str36 = org.apache.commons.lang3.StringUtils.join(byteArray28, ' ', 0, 1);
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.join(byteArray28, 'a', (int) (short) 10, 1);
        java.lang.Class<?> wildcardClass41 = byteArray28.getClass();
        byte[] byteArray44 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str46 = org.apache.commons.lang3.StringUtils.join(byteArray44, '4');
        java.lang.String str50 = org.apache.commons.lang3.StringUtils.join(byteArray44, 'a', 8, (int) (short) 1);
        byte byte51 = org.apache.commons.lang3.math.NumberUtils.min(byteArray44);
        byte byte52 = org.apache.commons.lang3.math.NumberUtils.min(byteArray44);
        java.lang.Class<?> wildcardClass53 = byteArray44.getClass();
        java.lang.String[] strArray55 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        java.lang.Class<?> wildcardClass56 = strArray55.getClass();
        java.lang.reflect.Type[] typeArray57 = new java.lang.reflect.Type[] { wildcardClass6, wildcardClass9, wildcardClass21, wildcardClass41, wildcardClass53, wildcardClass56 };
        java.lang.String str58 = org.apache.commons.lang3.StringUtils.join(typeArray57);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 31.0f + "'", float4 == 31.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 31.0f + "'", float5 == 31.0f);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100410" + "'", str14.equals("100410"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 10 + "'", byte19 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 10 + "'", byte20 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "100410" + "'", str46.equals("100410"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + byte51 + "' != '" + (byte) 10 + "'", byte51 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte52 + "' != '" + (byte) 10 + "'", byte52 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(typeArray57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "class [Fclass [Ljava.lang.String;class [Bclass [Bclass [Bclass [Ljava.lang.String;" + "'", str58.equals("class [Fclass [Ljava.lang.String;class [Bclass [Bclass [Bclass [Ljava.lang.String;"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "J4v4 HotSpot(TM) 64-Bit Server VM                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10a1a8a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1a8a-1" + "'", str1.equals("10a1a8a-1"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1" + "'", str1.equals("1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4mixed mode4a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "24.80-B11" + "'", charSequence2.equals("24.80-B11"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1041484-11041484-11041484-11041484-11041484-11041484-11041484-1", 7, (int) (short) 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 574L, 92.0f, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 574.0f + "'", float3 == 574.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 9);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 9 + "'", byte3 == (byte) 9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 18, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) '#', 5);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 0, 0);
        int int25 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int26 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "84#10#-1#18#32#100" + "'", str16.equals("84#10#-1#18#32#100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0 31.0 10.0", (int) (short) 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 31.0 10.0" + "'", str3.equals("10.0 31.0 10.0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "erJobaaaa", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "04-14-141004100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.7.-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.-b15" + "'", str1.equals("1.7.-b15"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("moc.elcaro.avaj//", 26, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0.9 3.0 9.0 25.0 13.0", 100410, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("9.", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9.                 " + "'", str2.equals("9.                 "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XM Mac OS XMac OS XMac OS XMac OS XMac OS XMa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.", "1.7.0_80a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a0a10a-1a100a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) 100, (short) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 -1 1 100 0" + "'", str9.equals("0 -1 1 100 0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#-1#1#100#0" + "'", str11.equals("0#-1#1#100#0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 277 + "'", int2 == 277);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "4 4 a # #  4 4 a # #  4 4 a #1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        char[] charArray12 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "        ", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie", charArray12);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray12, '4', 29, (int) (short) -1);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsoc m.tw wl.nus.80-b11", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4#4#a##### " + "'", str14.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444", "100410");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.310.14.310.1", (java.lang.CharSequence) "4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                               ", (long) 29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4#4#a#####   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 4#4#a#####    is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                             .80-b11", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "  1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", "", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str3.equals("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("00.0 -1.0 15.0 -1.0 8.0 6.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "# #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1" + "'", str1.equals("1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                             .80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "10a0a100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa", 18, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("4a4aaa#a#aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "44444444444444444440a-1a100a0a1", (java.lang.CharSequence) "10 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 10010 0 100 0 100 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###", "     ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###" + "'", str3.equals("###"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("41484-11041484-11041484-11041484-11041484-11041484-11041484-", "001a23a                  1a1                  a01a4                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "41484-11041484-11041484-11041484-11041484-11041484-11041484-" + "'", str2.equals("41484-11041484-11041484-11041484-11041484-11041484-11041484-"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0.0431.0410.045.0484.0", 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1" + "'", str2.equals("10 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1100.0#-1.0#15.0#-1.0#8.0#6.010 1 8 -1"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10.0a10.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a10.0a10.0a-1.0" + "'", str1.equals("10.0a10.0a10.0a-1.0"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Libra");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRA" + "'", str1.equals("/lIBRA"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "01", (java.lang.CharSequence) "4a4aaa#a#a");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "01" + "'", charSequence2.equals("01"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444a4#4#4aaaaaaaaaaaaaaa", "en", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Jv(TM) E Runtime Environment", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0431.0410.045.0484.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("84#10#-1#18#32#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "84#10#-1#18#32#" + "'", str1.equals("84#10#-1#18#32#"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4#4#a##### 444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1041484-11041484-11041484-11041484-11041484-11041484-11041484-1", (java.lang.CharSequence) "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com", 574);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 220 + "'", int3 == 220);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0#-1.0#15.0#-1.0#8.0#6.0  ", "/Libraaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Bclass [Bclass [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "   aaaaaaa1.5aaaaaaaa    ", (java.lang.CharSequence) "Jv(TM) E Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa", "                                                                 44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####       ", "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.com", (int) (byte) 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.310.14.310.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "451.0451.0a51.0#51.0#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("       10.14.31 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0a31.0a10.0a5.0a84.0", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        long[] longArray2 = new long[] { '4', (short) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) '4', 0);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 2, (int) (byte) 1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("9", "24.80-B1124.80-", "8aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_593_56277938aa-a8a32a");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "# #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#10#-1#100#0#", "001a23a                  1a1                  a01a4                  ", "0.9     ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en", "4444a4#4#4 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en" + "'", str2.equals("en/enuenSenEenRenSen/enSenOenPenHenIenEen/endenOenCenUenMenEenNenTenSen/enDenEenFenEenCenTenSen4enJen/enTenMenPen/enRenUenNen_enRenAenNenDenOenOenPen.enPenLen_en5en0en9en3en1en_en1en5en6en0en2en7en7en9en3en1en"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.013.41.013.41.01", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        short[] shortArray5 = new short[] { (byte) 10, (byte) 100, (byte) -1, (short) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) ' ', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 104, 5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 29, 2);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 100 + "'", short16 == (short) 100);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.0#31.0#10.0#5.0#84.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#31.0#10.0#5.0#84.0" + "'", str2.equals("0.0#31.0#10.0#5.0#84.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java HotSpot(TM) 64-Bit Server V", "/lIBRA", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V/lIBRAJava HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4 4 a # #  4 4 a # #  4 4 a #1.7", 15, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 4 a # #  4 4 a # #  4 4 a #1.7" + "'", str3.equals("4 4 a # #  4 4 a # #  4 4 a #1.7"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a##", (java.lang.CharSequence) "100.0#-1.0#15.0#-1.0#8.0#6.0  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  " + "'", str3.equals("sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 16, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0410.0" + "'", str5.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8.0 10.0" + "'", str8.equals("8.0 10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("J#v# HotSpot(TM) 64-Bit Server VM", "844104-14184324100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v# HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("J#v# HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        char[] charArray7 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) (byte) 9, 2);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4#4#a##### " + "'", str9.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4a4aaa#a#a " + "'", str12.equals("4a4aaa#a#a "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\n                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) " 4 a # #  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 13, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############" + "'", str3.equals("#############"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4a4aaa#a#a", "1.7.0_8", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80", "...            ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.013.41.013.41.01aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("1.013.41.013.41.01aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.04a4aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.04a4aaa" + "'", str1.equals("1.04a4aaa"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0.0a31.0a10.0a5.0a84.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####                            ", "44444444444444444444444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1041484-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#################################################################################################", 0, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####" + "'", str3.equals("####"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4mixed mode4a", "acle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4mixed mode4a" + "'", str2.equals("4mixed mode4a"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7. is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4 4 a # #", "#################################################################################################", 29, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#################################################################################################" + "'", str4.equals("#################################################################################################"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4 4 a # #", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4 a # #" + "'", str2.equals("4 4 a # #"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 83);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                   " + "'", str2.equals("                                                                                   "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal[] bigDecimalArray6 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray6);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimalArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999" + "'", str7.equals("1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999" + "'", str8.equals("1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        char[] charArray8 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4 4 a # #  4 4 a # #  4 4 a #1.7", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#4#a##### " + "'", str10.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4#4#a##### " + "'", str14.equals("4#4#a##### "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0.9 3.0 9.0 25.0 13.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: USaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.0431.0410.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", 32, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str3.equals("4#4#A#####                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "nt.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 100, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 10, 1);
        java.lang.Class<?> wildcardClass19 = byteArray6.getClass();
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10#0#100#0#100#100" + "'", str22.equals("10#0#100#0#100#100"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                               4#4#a##### 444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray2);
        org.junit.Assert.assertNotNull(classArray1);
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("nt jar", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nt jar" + "'", str2.equals("nt jar"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("001a23a81a1-a01a48", "UTF-8", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 100, (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "001a23aa1a1aa01a4a" + "'", str5.equals("001a23aa1a1aa01a4a"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        long[] longArray3 = new long[] { 100L, (-1), (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 -1 -1" + "'", str5.equals("100 -1 -1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 -1 -1" + "'", str7.equals("100 -1 -1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8" + "'", str1.equals("a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa83977265_395_LP.POODNAR_NUR/PMT/JSTCEFED/STNEMUCOD/EIHPOS/SRESU/a23a8a-aa8"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Aaaaa", (double) 19L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.0d + "'", double2 == 19.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("041484-", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "018-" + "'", str2.equals("018-"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Libraaaa", "####", "10.0a10.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libraaaa" + "'", str3.equals("/Libraaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        long[] longArray3 = new long[] { 100L, (-1), (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 15, 2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100 -1 -1" + "'", str5.equals("100 -1 -1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("########################################################################################################", "", "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                                                                               4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########################################################################################################" + "'", str3.equals("########################################################################################################"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44##44##44#1.7" + "'", str1.equals("44##44##44#1.7"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("41484-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "41484-1" + "'", str1.equals("41484-1"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) 9, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 1, ".80-B11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "." + "'", str3.equals("."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a-1a-1a100a100a10" + "'", str13.equals("0a-1a-1a100a100a10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0a-1a-1a100a100a10" + "'", str16.equals("0a-1a-1a100a100a10"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("###0.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###0.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0" + "'", str1.equals("###0.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0#5.0#84.00.0#31.0#10.0"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "               /Users/sophie", (java.lang.CharSequence) "4a8.0a10.0a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4.80-B11.80-B11.80-B11.80", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.80-B11.80-B11.80-B11.80 " + "'", str2.equals("4.80-B11.80-B11.80-B11.80 "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.9 3.0 9.0 25.0 13.0", "4 4 a # #", "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9a3.0a9.0a25.0a13.0" + "'", str3.equals("0.9a3.0a9.0a25.0a13.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4.80-B11.80-B11.80-B11.80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.80-B11.80-B11.80-B11.8" + "'", str1.equals("4.80-B11.80-B11.80-B11.8"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aa#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa" + "'", str1.equals("aa"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          " + "'", str2.equals("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          "));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Aaaaa", "", "###");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 10, (short) (byte) 9);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44a##", "84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100041484-84#10#-1#18#32#100", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Libra");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "0 a - 1 a 100 a 0 a 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("x86_64", "84#10#-1#18#32#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6" + "'", str2.equals("x86_6"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        short[][] shortArray0 = new short[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "41484-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        long[] longArray4 = new long[] { (short) 10, (short) 1, 8, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 100, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1041484-1" + "'", str10.equals("1041484-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a1a8a-1" + "'", str12.equals("10a1a8a-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        short[] shortArray6 = new short[] { (short) 0, (byte) -1, (short) -1, (byte) 100, (byte) 100, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-141004100410" + "'", str8.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "04-14-141004100410" + "'", str10.equals("04-14-141004100410"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0 -1 -1 100 100 10" + "'", str12.equals("0 -1 -1 100 100 10"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "0a-1a-1a100a100a10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0a-1a-1a100a100a10" + "'", charSequence2.equals("0a-1a-1a100a100a10"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("001a23a#1a1#a01a4#", "00.0 -1.0 15.0 -1.0 8.0 6.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        short[] shortArray5 = new short[] { (byte) 10, (byte) 100, (byte) -1, (short) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) ' ', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 576, 0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "100#-1#-1");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "NT.JAR");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 baaaa4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 baaaa4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 " + "'", str1.equals("4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 baaaa4 4 a # #  4 4 a # #  4 4 a # #  4 4 a # #  4 "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4#4#a##### 4444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4#4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("104.0#-1.0#1.0", "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie                    /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ", "10.14.sun.lwawt.macosx.CPrinterJob####       ####       ####       ####       ####       ####       ####  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "104.0#-1.0#1.0" + "'", str3.equals("104.0#-1.0#1.0"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("...aa1a1aa01a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...AA1A1AA01A4A" + "'", str1.equals("...AA1A1AA01A4A"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#############", "1.044", "erJobaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############" + "'", str3.equals("#############"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("\n                  ", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n                  " + "'", str3.equals("\n                  "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java HotSpot(TM) 64-Bit Server V", "10.0410.0410.04-1.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          " + "'", str2.equals("          /Library/Java/JavaVirtualMachines/jdk1.7._8.jdk/Contents/Home/jre/Users/sophie          "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaa1.5aaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "8.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 5, "4#4#A#####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        long[] longArray2 = new long[] { '4', (short) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52#1" + "'", str7.equals("52#1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7.-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("84a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50931_156027793184a10a-1a18a32a100", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
        java.math.BigDecimal[] bigDecimalArray6 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Number[]) bigDecimalArray6);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimalArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999" + "'", str7.equals("1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999" + "'", str8.equals("1.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.0999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991.099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10a1a8a-1", "mixedmode/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("BOJRETNIRPC.XSOCAM.TWAWL.NUS", "1sophie10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str2.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   aaaaaaa1.5aaaaaaaa    ", (java.lang.CharSequence) "001a23aa1a1aa01a4a", 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("               ", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "               " + "'", str4.equals("               "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100410);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) (short) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("84 10 -1 18 32 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "84 10 -1 18 32 100" + "'", str1.equals("84 10 -1 18 32 100"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "####################################################################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100 10#####################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("erJobaaaa", "1.30.9");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/", "", (int) (byte) 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1", strArray4, strArray7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#', (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1" + "'", str8.equals(".3aaaaaaaaaaaaaaaaaaaaaaa4Aaaaaaaaaaaaaaaaaaaaaa10.1"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("9.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9.0" + "'", str1.equals("9.0"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444", "4444a4#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100#10" + "'", str6.equals("100#10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10" + "'", str9.equals("100a10"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10a1a...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa4a4aaa#a#a aaaa4#4#a#####4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa4a4aaa#a#a aaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa4a4aaa#a#a aaaa4#4#a#####4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa4a4aaa#a#a aaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str2.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a a - a a aaa a a a a", 31, 84);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.7.0_8", "4 4  # #  4 4  # #  4 4  #1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4mixed mode4a", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4mixed mode4a" + "'", str3.equals("4mixed mode4a"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        ", "boJretnirPC.xsoc m.tw wl.nus.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        " + "'", str2.equals("                                                       4a4aaa#a#a aaaaaaaaaaaaaaaaaaaaa                                                        "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0.9     ", (java.lang.CharSequence) "451.0451.0a51.0#51.0#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 8, (int) (short) 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100410" + "'", str4.equals("100410"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 7, 143);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "84a10a-1a18a32a100" + "'", str10.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "84 10 -1 18 32 100" + "'", str12.equals("84 10 -1 18 32 100"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.013.41.013.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.013.41.013.41.01" + "'", str1.equals("1.013.41.013.41.01"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("04-14-141004100410", 45, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "100...             ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "01", (int) (short) -1, 574);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"boJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nusboJretnirPC.xsocam.twawl.nus\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "24.80-B1124.80-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("104041004041004100", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104041004041004100                                                                               " + "'", str2.equals("104041004041004100                                                                               "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10#0#1...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#0#1..." + "'", str1.equals("10#0#1..."));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                      10a0a100a0a100a100", 220);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                10a0a100a0a100a100                                                          " + "'", str2.equals("                                                                                                                                                10a0a100a0a100a100                                                          "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("04-14-141004100410", "04-14-141004100410", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "10.0 31.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444", "001a23aa1a1aa01a4a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(".80-b11", "0 -1 100 0 1", "", 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".80-b11" + "'", str4.equals(".80-b11"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        double[] doubleArray2 = new double[] { 8, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8.0410.0" + "'", str5.equals("8.0410.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.013.41.013.41.01", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("          /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:           /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie           is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                               4#4#a##### 444444444444444444444444444444444444444444444444444444", "100 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "9.                 ", (java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        double[] doubleArray4 = new double[] { 10.0d, 10.0f, 10L, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 10.0 10.0 -1.0" + "'", str6.equals("10.0 10.0 10.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0410.0410.04-1.0" + "'", str8.equals("10.0410.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a10.0a10.0a-1.0" + "'", str11.equals("10.0a10.0a10.0a-1.0"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("        ", "#############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1", "en44##44##44#1.7", "                             # #", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1" + "'", str4.equals("/Library/Java/Jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.310.14.310.1"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10#1#8#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "010a0a100a0a100a10010a0a100a0a1", (java.lang.CharSequence) "84 10 -1 18 32 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        boolean boolean11 = javaVersion6.atLeast(javaVersion9);
        boolean boolean12 = javaVersion3.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str14 = javaVersion13.toString();
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        boolean boolean17 = javaVersion13.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean19 = javaVersion15.atLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean21 = javaVersion15.atLeast(javaVersion20);
        boolean boolean22 = javaVersion3.atLeast(javaVersion15);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.9" + "'", str14.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####", 80, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####" + "'", str3.equals("1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####1.71.71.4#4#####"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        char[] charArray12 = new char[] { '4', '4', 'a', '#', '#', ' ' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50931_1560277931", charArray12);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray12, '4', (-1), (int) (byte) -1);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray12);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray12);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.6", charArray12);
        java.lang.Class<?> wildcardClass25 = charArray12.getClass();
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4#4#a##### " + "'", str14.equals("4#4#a##### "));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10 0 100 0 100 100", "bojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode.slaB..", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode.slaB.." + "'", str2.equals("mixed mode.slaB.."));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.14.310.14.310.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.1" + "'", str1.equals("10.14.310.14.310.1"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0a-1a100a0a1", "100.0#-1.0#15.0#-1.0#8.0#6.0  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a100a0a1" + "'", str2.equals("0a-1a100a0a1"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100...", (java.lang.CharSequence) "1.7.0_80-b15", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        int[] intArray6 = new int[] { 84, 10, (-1), 18, ' ', 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', (int) '4', 35);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "84a10a-1a18a32a100" + "'", str8.equals("84a10a-1a18a32a100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:4#4#a##### http:");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("84#10#-1#18#32#100", "# #  ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0a31.0a10.0a5.0a84.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "4a4aaa#a#a ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "sun.lwawt.macosx.CPrinterJob");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-B1124.80-", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 30 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("class [Fclass [Ljava.lang.String;class [Bclass [Bclass [Bclass [Ljava.lang.String;", 29, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4444a4#4#4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444a4#4#4" + "'", str1.equals("4444a4#4#4"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', 'a', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '#', 11, 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10a0a100a0a100a100", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" HotSpot(TM) 64-Bit Server VavaJ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4A4AAA#A#A AAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0_80", "1041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-11041484-1", "24.80-b11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                             .80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44a##", (int) 'a', 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "41484-11041484-11041484-11041484-11041484-11041484-11041484-", (java.lang.CharSequence) "101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0_80");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/runsrandoopUplsir93/s/i6r2ss93/", "", (int) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "boJretnirPC.xsoc m.tw wl.nus.80-b11", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 11L, 0.0f, 574.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ", 18);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String[] strArray3 = new java.lang.String[] { "1.7.0_80-b15" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0431.0410.045.0484.0", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "                                                                                   ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sususususususususususususususususususus" + "'", str1.equals("sususususususususususususususususususus"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1sophie10", 100410);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

