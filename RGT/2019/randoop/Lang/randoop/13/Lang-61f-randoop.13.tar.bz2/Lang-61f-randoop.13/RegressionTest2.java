import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher6 = strTokenizer5.getTrimmerMatcher();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strMatcher6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('a');
        boolean boolean6 = strTokenizer5.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer5.setEmptyTokenAsNull(false);
        int int9 = strTokenizer8.nextIndex();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer3.setQuoteChar('a');
        java.util.List list10 = strTokenizer3.getTokenList();
        java.lang.String str11 = strTokenizer3.getContent();
        char[] charArray12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setDelimiterChar('a');
        try {
            strTokenizer3.set((java.lang.Object) strTokenizer13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: set() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        boolean boolean7 = strBuilder5.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.trim();
        java.lang.StringBuffer stringBuffer10 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.append(stringBuffer10, (int) (byte) 10, 1);
        char[] charArray15 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray15, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer21.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer32.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer32.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer41.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher37, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer51.setTrimmerMatcher(strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer62.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer71.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher67, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer57.setDelimiterMatcher(strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher46, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher26, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray15);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder13.insert(0, charArray15);
        char[] charArray83 = strBuilder5.getChars(charArray15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer(charArray83, ' ');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strTokenizer81);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(charArray83);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strBuilder4.asTokenizer();
        java.lang.String str6 = strTokenizer5.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer5.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setQuoteChar('a');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.setEmptyTokenAsNull(true);
        char[] charArray8 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer3.reset(charArray8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setEmptyTokenAsNull(false);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(" ");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        char[] charArray0 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer(charArray0, '#', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder6.trim();
        java.lang.StringBuffer stringBuffer8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.append(stringBuffer8, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer21.setTrimmerMatcher(strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer32.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer32.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer41.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher37, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer27.setDelimiterMatcher(strMatcher46);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder17.replaceAll(strMatcher46, "");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder15.replace(strMatcher46, "hi!", (int) (short) 0, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer5.setTrimmerMatcher(strMatcher46);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer5.getQuoteMatcher();
        boolean boolean58 = strTokenizer5.hasNext();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append(true);
        char[] charArray25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray25, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.reset("");
        java.lang.String[] strArray31 = strTokenizer28.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder22.appendWithSeparators((java.lang.Object[]) strArray31, "");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.deleteCharAt((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.deleteFirst('#');
        int int17 = strBuilder15.indexOf("StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.append(0);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder15.append((long) 6);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.appendWithSeparators(objArray22, "f32.0alse                                                                                            ");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("1.0aaaaaaaa32");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder2.trim();
        java.lang.StringBuffer stringBuffer4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append(stringBuffer4, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append((float) 1);
        int int12 = strBuilder9.lastIndexOf('a', (int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder14.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(false);
        char[] charArray24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer21.reset(charArray24);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) strTokenizer21, (int) (byte) -1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.replaceFirst("1.0aaaaaaaa32", "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder31.deleteFirst(strMatcher40);
        int int43 = strBuilder1.indexOf(strMatcher40, 3);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.trim();
        java.lang.StringBuffer stringBuffer10 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.append(stringBuffer10, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer17.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer17.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer17.setTrimmerMatcher(strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer28.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer37.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher33, strMatcher42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer23.setDelimiterMatcher(strMatcher42);
        int int45 = strBuilder13.indexOf(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder13.appendFixedWidthPadRight((int) (byte) 1, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder13.replaceAll(' ', 'a');
        char[] charArray54 = new char[] { 'a' };
        char[] charArray55 = strBuilder13.getChars(charArray54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, "");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder1.insert((int) (short) 10, charArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(charArray55);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        java.lang.String str5 = strBuilder3.rightString((int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder3.replaceFirst("1.0", "1.0");
        int int11 = strBuilder3.indexOf("class org.apache.commons.lang.te", 151);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer17.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder13.appendWithSeparators((java.util.Iterator) strTokenizer17, "hi!");
        boolean boolean23 = strBuilder13.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder13.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder29.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer33 = strBuilder29.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder13.append(stringBuffer33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(true);
        boolean boolean43 = strTokenizer42.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer42.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder34.replaceAll(strMatcher44, "");
        char[] charArray47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setQuoteChar('a');
        boolean boolean53 = strTokenizer52.hasNext();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder46.appendFixedWidthPadLeft((java.lang.Object) boolean53, 32, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer60.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder56.replaceFirst(strMatcher63, "");
        int int66 = strBuilder3.indexOf(strMatcher63);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(stringBuffer33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        try {
            java.lang.String str33 = strBuilder0.substring(1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setQuoteChar('a');
        boolean boolean6 = strTokenizer5.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer5.setIgnoreEmptyTokens(false);
        java.lang.String str9 = strTokenizer5.getContent();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer15.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher20, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer34.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer45.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher50, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer40.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher29, strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.replace(strMatcher29, "", 0, (int) (byte) 100, (int) (byte) 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.reset("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer72.setIgnoredChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher78 = strTokenizer77.getIgnoredMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer77.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer72.setIgnoredMatcher(strMatcher79);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder1.deleteFirst(strMatcher79);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strBuilder81);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer("1.0", "1.0");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer10.setTrimmerMatcher(strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer21.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer30.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer30.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher26, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer16.setDelimiterMatcher(strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder6.replaceAll(strMatcher35, "");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder39.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.insert((int) (byte) 0, (double) 1L);
        char[] charArray44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer45.getDelimiterMatcher();
        int int50 = strBuilder40.indexOf(strMatcher48, (int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer4.setQuoteMatcher(strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("class org.apache.commons.lang.text.StrTokenizer#", strMatcher1, strMatcher48);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer51);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.lang.StringBuffer stringBuffer38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder5.append(stringBuffer38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder40.trim();
        java.lang.StringBuffer stringBuffer42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.append(stringBuffer42, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer49.setTrimmerMatcher(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer60.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher65, strMatcher74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer55.setDelimiterMatcher(strMatcher74);
        int int77 = strBuilder45.indexOf(strMatcher74);
        java.lang.StringBuffer stringBuffer78 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder45.append(stringBuffer78);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder45.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder81.ensureCapacity((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder81.replaceAll('#', 'a');
        boolean boolean87 = strBuilder39.equals(strBuilder81);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder39.ensureCapacity((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder89.setNullText("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder89.append((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder93.append((float) 151);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder98 = strBuilder95.insert((int) (byte) -1, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(strBuilder95);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        boolean boolean7 = strBuilder5.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder44.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.insert((int) (byte) 0, (double) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder9.append(strBuilder48);
        char[] charArray55 = new char[] { ' ', '4', ' ', '4', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray55, ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder49.appendWithSeparators((java.util.Iterator) strTokenizer61, "");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(strBuilder63);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder9.replace(strMatcher40, "hi!", (int) (short) 0, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder9.reverse();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer53.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder9.replaceAll(strMatcher54, "StrTokenizer[]");
        boolean boolean58 = strBuilder56.startsWith("1.0");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.deleteFirst('#');
        char[] charArray16 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        char[] charArray23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.reset(charArray23);
        java.lang.String str25 = strTokenizer24.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer24.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder1.replaceAll(strMatcher28, "1.01.0");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        int int28 = strBuilder0.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder0.setLength(3);
        java.util.Iterator iterator31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.appendWithSeparators(iterator31, "");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 32 + "'", int28 == 32);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.reset("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer4.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = strTokenizer4.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertNotNull(strMatcher7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder0.deleteFirst("");
        char[] charArray10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setQuoteChar('a');
        boolean boolean16 = strTokenizer13.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder0.appendWithSeparators((java.util.Iterator) strTokenizer13, "0.0");
        char[] charArray19 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder26.trim();
        java.lang.StringBuffer stringBuffer28 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.append(stringBuffer28, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer32 = strBuilder27.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder27.replaceAll("", "hi!");
        char[] charArray36 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher39);
        char[] charArray41 = strBuilder35.getChars(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer25.reset(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer48.setEmptyTokenAsNull(true);
        char[] charArray53 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer48.reset(charArray53);
        int int57 = strTokenizer48.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer62.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer71.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher67, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer48.setTrimmerMatcher(strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher76);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder18.append(charArray36);
        int int82 = strBuilder81.length();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(stringBuffer32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder0.deleteFirst("");
        int int12 = strBuilder0.indexOf('#', 100);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.append("hi!");
        java.io.Writer writer34 = strBuilder33.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.minimizeCapacity();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder33.insert((int) '.', (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 46");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(writer34);
        org.junit.Assert.assertNotNull(strBuilder35);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", '#');
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append((int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft((int) (short) 1, (int) (byte) 10, 'a');
        int int16 = strBuilder13.lastIndexOf('4', (int) '#');
        boolean boolean18 = strBuilder13.contains('a');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        char[] charArray5 = new char[] { ' ', '4', ' ', '4', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer10.reset();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        java.lang.String str11 = strBuilder7.rightString(100);
        boolean boolean12 = strBuilder7.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder7.append(0.0f);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer17.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder14.replaceAll(strMatcher18, "");
        java.lang.String str22 = strBuilder20.leftString(100);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.append(1L);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.00.0" + "'", str22.equals("1.00.0"));
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        char[] charArray0 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer(charArray0, '#', '#');
        boolean boolean6 = strTokenizer5.hasNext();
        java.lang.Object obj7 = strTokenizer5.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer5.reset("StrTokenizer[not tokenized yet]####");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(strTokenizer9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setEmptyTokenAsNull(true);
        boolean boolean18 = strTokenizer17.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer17.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.replaceAll(strMatcher19, "");
        char[] charArray22 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer28.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer39.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer48.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher44, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer58.setTrimmerMatcher(strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer78.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher74, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer64.setDelimiterMatcher(strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher53, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher33, strMatcher83);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder1.replaceAll(strMatcher83, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder1.appendPadding(1, '#');
        char char94 = strBuilder92.charAt((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder92.setNullText("0hi!a");
        boolean boolean97 = strBuilder92.isEmpty();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertTrue("'" + char94 + "' != '" + '#' + "'", char94 == '#');
        org.junit.Assert.assertNotNull(strBuilder96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder5.appendFixedWidthPadRight((int) (byte) 1, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder5.replaceAll(' ', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder45.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.ensureCapacity(0);
        java.lang.StringBuffer stringBuffer52 = strBuilder51.toStringBuffer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder5.append(stringBuffer52, 151, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(stringBuffer52);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        char[] charArray7 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer13.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer33.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher29, strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer43.setTrimmerMatcher(strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer63.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher59, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer49.setDelimiterMatcher(strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher38, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher18, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray7);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder5.insert(0, charArray7);
        char[] charArray76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder5.insert(0, charArray76);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.deleteFirst('#');
        int int17 = strBuilder15.indexOf("StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.append(0);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder20.trim();
        java.lang.StringBuffer stringBuffer22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.append(stringBuffer22, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.setNullText("");
        java.lang.String str31 = strBuilder27.rightString(100);
        boolean boolean32 = strBuilder27.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder27.replaceAll("StrTokenizer[]", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder27.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder27.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder27.append("");
        boolean boolean41 = strBuilder19.equals(strBuilder40);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder19.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.setNewLineText("1.0hi!a");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.0" + "'", str31.equals("1.0"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setEmptyTokenAsNull(true);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.replaceAll(strMatcher32, "");
        char[] charArray35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(true);
        int int41 = strTokenizer38.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder22.append((java.lang.Object) strTokenizer38);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder44.appendWithSeparators((java.util.Iterator) strTokenizer48, "hi!");
        boolean boolean54 = strBuilder44.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder44.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder44.deleteFirst('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer62.setEmptyTokenAsNull(true);
        char[] charArray67 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray67, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer62.reset(charArray67);
        int int71 = strTokenizer62.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer76.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer76.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer76.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer85.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer85.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher90 = strTokenizer85.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher81, strMatcher90);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer62.setTrimmerMatcher(strMatcher90);
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder44.deleteAll(strMatcher90);
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder22.replaceAll(strMatcher90, "f32.0alse                                                                                            ");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(charArray67);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strMatcher90);
        org.junit.Assert.assertNotNull(strTokenizer92);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(strBuilder95);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(false);
        int int6 = strTokenizer3.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.trim();
        java.lang.StringBuffer stringBuffer9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.append(stringBuffer9, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer16.setTrimmerMatcher(strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer27.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer27.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer36.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher32, strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer22.setDelimiterMatcher(strMatcher41);
        int int44 = strBuilder12.indexOf(strMatcher41);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder12.appendFixedWidthPadRight((int) (byte) 1, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder12.replaceAll(' ', 'a');
        char[] charArray53 = new char[] { 'a' };
        char[] charArray54 = strBuilder12.getChars(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray53, "StrTokenizer[]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer3.reset(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer57);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.lang.StringBuffer stringBuffer38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder5.append(stringBuffer38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder40.trim();
        java.lang.StringBuffer stringBuffer42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.append(stringBuffer42, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer49.setTrimmerMatcher(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer60.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher65, strMatcher74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer55.setDelimiterMatcher(strMatcher74);
        int int77 = strBuilder45.indexOf(strMatcher74);
        java.lang.StringBuffer stringBuffer78 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder45.append(stringBuffer78);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder45.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder81.ensureCapacity((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder81.replaceAll('#', 'a');
        boolean boolean87 = strBuilder39.equals(strBuilder81);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder39.ensureCapacity((int) (byte) 10);
        boolean boolean91 = strBuilder89.contains('a');
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder89.replaceFirst('4', '4');
        boolean boolean95 = strBuilder94.isEmpty();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setDelimiterMatcher(strMatcher6);
        java.lang.Object obj8 = strTokenizer5.clone();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        int int4 = strBuilder0.indexOf('#', (int) (short) 100);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder0.insert(151, "1.0hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 151");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        boolean boolean7 = strBuilder5.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder44.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.insert((int) (byte) 0, (double) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder9.append(strBuilder48);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.append(10L);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("1.0aaaaaaaa32");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder2.trim();
        java.lang.StringBuffer stringBuffer4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.append(stringBuffer4, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer11.setTrimmerMatcher(strMatcher16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer22.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer22.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer31.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer31.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer17.setDelimiterMatcher(strMatcher36);
        int int39 = strBuilder7.indexOf(strMatcher36);
        java.lang.StringBuffer stringBuffer40 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder7.append(stringBuffer40);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder7.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.ensureCapacity((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder43.replaceAll('#', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder43.appendFixedWidthPadLeft((int) (short) 100, (int) (short) -1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder53.trim();
        java.lang.StringBuffer stringBuffer55 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder54.append(stringBuffer55, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer59 = strBuilder54.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder54.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder62.replace((int) (byte) 0, (int) (short) 100, "class org.apache.commons.lang.text.StrTokenizer");
        java.lang.StringBuffer stringBuffer67 = strBuilder62.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder43.append(stringBuffer67);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder43.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder69.append(0.0f);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder1.append(strBuilder71, 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: length must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(stringBuffer59);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.ensureCapacity((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendFixedWidthPadRight(0, 0, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(false);
        java.lang.String[] strArray46 = strTokenizer43.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder35.appendWithSeparators((java.lang.Object[]) strArray46, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.insert(0, (long) (byte) 100);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder48.insert((int) (short) -1, ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        char[] charArray7 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray7, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer13.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer33.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher29, strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer43.setTrimmerMatcher(strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer63.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher59, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer49.setDelimiterMatcher(strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher38, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray7, strMatcher18, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray7);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder5.insert(0, charArray7);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder74.replaceAll('4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder74.insert(0, "class org.apache.commons.lang.text.StrTokenizer");
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder74.deleteFirst("hi!1.0");
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder82.deleteFirst("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer89.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = strTokenizer89.setEmptyTokenAsNull(true);
        java.lang.String str94 = strTokenizer89.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer96 = strTokenizer89.setDelimiterChar('#');
        int int97 = strTokenizer89.size();
        java.lang.String[] strArray98 = strTokenizer89.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder99 = strBuilder84.insert(10, (java.lang.Object) strTokenizer89);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertNotNull(strTokenizer93);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertNotNull(strTokenizer96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertNotNull(strArray98);
        org.junit.Assert.assertNotNull(strBuilder99);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder5.replace(strMatcher14, "1.0", (int) (short) 1, 3, (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.deleteFirst("class org.apache.commons.lang.text.StrTokenizer#");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.io.Writer writer38 = strBuilder5.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer42.setTrimmerMatcher(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.trim();
        java.lang.StringBuffer stringBuffer51 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.append(stringBuffer51, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer55 = strBuilder50.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder50.replaceAll("", "hi!");
        char[] charArray59 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher62);
        char[] charArray64 = strBuilder58.getChars(charArray59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer42.reset(charArray64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray64);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder5.append(charArray64, 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder5.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder70.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder70.replaceFirst('a', 'a');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(writer38);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(stringBuffer55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder74);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strBuilder0.asTokenizer();
        boolean boolean10 = strBuilder0.contains("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.trim();
        java.lang.StringBuffer stringBuffer13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append(stringBuffer13, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer17 = strBuilder12.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.replaceAll("", "hi!");
        char[] charArray21 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher24);
        char[] charArray26 = strBuilder20.getChars(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setDelimiterMatcher(strMatcher34);
        java.lang.String str36 = strTokenizer35.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer42.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer51.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher47, strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer61.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer61.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher66 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer61.setTrimmerMatcher(strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer72.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer72.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher77 = strTokenizer72.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer81.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer81.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer81.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher77, strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer67.setDelimiterMatcher(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher56, strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer35.setQuoteMatcher(strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer27.setDelimiterMatcher(strMatcher56);
        int int93 = strBuilder0.lastIndexOf(strMatcher56, 1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(stringBuffer17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strMatcher77);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.setLength(151);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder0.insert((int) (byte) 100, true);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        java.lang.StringBuffer stringBuffer5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.append(stringBuffer5, (int) (short) 10, (-1));
        boolean boolean10 = strBuilder4.startsWith("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.trim();
        java.lang.StringBuffer stringBuffer13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append(stringBuffer13, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer17 = strBuilder12.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setEmptyTokenAsNull(true);
        boolean boolean29 = strTokenizer28.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder12.replaceAll(strMatcher30, "");
        boolean boolean33 = strBuilder4.equals(strBuilder32);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.clear();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(true);
        java.lang.Class<?> wildcardClass43 = strTokenizer38.getClass();
        java.lang.Object obj44 = strTokenizer38.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher45 = strTokenizer38.getIgnoredMatcher();
        int int46 = strBuilder34.indexOf(strMatcher45);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(stringBuffer17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(strMatcher45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        char[] charArray1 = strBuilder0.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder2.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder3.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.append((int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((long) (-1));
        int int15 = strBuilder11.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.trim();
        java.lang.StringBuffer stringBuffer18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.append(stringBuffer18, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.setNullText("");
        java.lang.String str27 = strBuilder23.rightString(100);
        boolean boolean28 = strBuilder23.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.replaceAll("StrTokenizer[]", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder23.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder23.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder23.append("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer40.getTrimmerMatcher();
        int int42 = strBuilder23.indexOf(strMatcher41);
        int int43 = strBuilder11.indexOf(strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray1, strMatcher41);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.0" + "'", str27.equals("1.0"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.append("hi!");
        java.io.Writer writer34 = strBuilder33.asWriter();
        java.lang.String str35 = strBuilder33.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder33.deleteFirst("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder37.reverse();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(writer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder38);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.ensureCapacity((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.appendFixedWidthPadRight(0, 0, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(false);
        java.lang.String[] strArray46 = strTokenizer43.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder35.appendWithSeparators((java.lang.Object[]) strArray46, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.insert(0, (long) (byte) 100);
        try {
            java.lang.String str54 = strBuilder51.substring((int) ' ', 151);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        int int10 = strBuilder7.lastIndexOf('a', (int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder7.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(false);
        char[] charArray22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer19.reset(charArray22);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strTokenizer19, (int) (byte) -1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder15.minimizeCapacity();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.append("");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        java.lang.StringBuffer stringBuffer5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.append(stringBuffer5, (int) (short) 10, (-1));
        boolean boolean10 = strBuilder4.startsWith("");
        int int13 = strBuilder4.lastIndexOf("hi!", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder4.appendFixedWidthPadLeft((java.lang.Object) (-1), (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.deleteFirst('.');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer25.setTrimmerMatcher(strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer36.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer45.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher41, strMatcher50);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer31.setDelimiterMatcher(strMatcher50);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder21.replaceAll(strMatcher50, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setIgnoreEmptyTokens(false);
        boolean boolean63 = strTokenizer62.isEmptyTokenAsNull();
        java.lang.Class<?> wildcardClass64 = strTokenizer62.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder21.append((java.lang.Object) wildcardClass64);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder65.replaceFirst('#', ' ');
        java.lang.String str70 = strBuilder65.rightString(100);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strBuilder65.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder4.append((java.lang.Object) strTokenizer71);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "class org.apache.commons.lang.text.StrTokenizer" + "'", str70.equals("class org.apache.commons.lang.text.StrTokenizer"));
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strBuilder72);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer11.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer11.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder0.deleteFirst(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder0.append("hi!");
        java.io.Writer writer34 = strBuilder33.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder35.trim();
        java.lang.StringBuffer stringBuffer37 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.append(stringBuffer37, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer44.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer44.setTrimmerMatcher(strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer55.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer55.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer64.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher69 = strTokenizer64.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher60, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer50.setDelimiterMatcher(strMatcher69);
        int int72 = strBuilder40.indexOf(strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder40.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder33.appendFixedWidthPadLeft((java.lang.Object) strBuilder40, (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder76.append((float) (-1));
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(writer34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strMatcher69);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strBuilder0.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.ensureCapacity(3);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder0.replaceFirst('#', '#');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder0.append("1.0aaaaaaaa32", 47, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setEmptyTokenAsNull(true);
        boolean boolean18 = strTokenizer17.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer17.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.replaceAll(strMatcher19, "");
        char[] charArray22 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer28.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer39.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer48.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher44, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer58.setTrimmerMatcher(strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer78.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher74, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer64.setDelimiterMatcher(strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher53, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher33, strMatcher83);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder1.replaceAll(strMatcher83, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder1.appendPadding(1, '#');
        char char94 = strBuilder92.charAt((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder96 = strBuilder92.setNullText("0hi!a");
        boolean boolean98 = strBuilder92.contains("0.0");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertTrue("'" + char94 + "' != '" + '#' + "'", char94 == '#');
        org.junit.Assert.assertNotNull(strBuilder96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer5.setTrimmerMatcher(strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer16.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer25.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher21, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer11.setDelimiterMatcher(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder1.replaceAll(strMatcher30, "");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder34.reverse();
        int int36 = strBuilder35.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer41.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer50.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer50.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher55);
        int int57 = strTokenizer56.size();
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder35.appendWithSeparators((java.util.Iterator) strTokenizer56, "");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder60.trim();
        java.lang.StringBuffer stringBuffer62 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder61.append(stringBuffer62, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder65.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder59.append((java.lang.Object) strBuilder67);
        char[] charArray70 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray70, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder59.insert(0, charArray70);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder75.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder76.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder73.insert((int) (short) 1, (java.lang.Object) strBuilder79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer84.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher87 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer86.setDelimiterMatcher(strMatcher87);
        boolean boolean89 = strTokenizer88.isIgnoreEmptyTokens();
        java.util.List list90 = strTokenizer88.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher91 = strTokenizer88.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder73.replaceAll(strMatcher91, "1.0hi!");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(charArray70);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertNotNull(strMatcher91);
        org.junit.Assert.assertNotNull(strBuilder93);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer15.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher20, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer34.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer45.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher50, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer40.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher29, strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.replace(strMatcher29, "", 0, (int) (byte) 100, (int) (byte) 0);
        java.lang.String str69 = strBuilder1.rightString((int) (short) 10);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "" + "'", str69.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setQuoteChar('a');
        java.lang.String str6 = strTokenizer5.getContent();
        java.lang.Object obj7 = strTokenizer5.clone();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setEmptyTokenAsNull(true);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.replaceAll(strMatcher32, "");
        int int36 = strBuilder22.indexOf("class org.apache.commons.lang.text.StrTokenizer");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder38.appendWithSeparators((java.util.Iterator) strTokenizer42, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer42.setIgnoredChar('4');
        char[] charArray49 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer48.reset(charArray49);
        java.util.List list55 = strTokenizer48.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder22.appendWithSeparators((java.util.Collection) list55, "");
        boolean boolean58 = strBuilder22.isEmpty();
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        java.lang.String str11 = strBuilder7.rightString(100);
        boolean boolean12 = strBuilder7.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder7.replaceAll("StrTokenizer[]", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteCharAt(0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setDelimiterMatcher(strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer26.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder28.trim();
        boolean boolean31 = strBuilder29.startsWith("");
        char[] charArray34 = strBuilder29.toCharArray(0, (int) 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer38.setTrimmerMatcher(strMatcher43);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder45.trim();
        java.lang.StringBuffer stringBuffer47 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder46.append(stringBuffer47, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer51 = strBuilder46.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder46.replaceAll("", "hi!");
        char[] charArray55 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher58 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer(charArray55, strMatcher58);
        char[] charArray60 = strBuilder54.getChars(charArray55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer38.reset(charArray60);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer38.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer66.setEmptyTokenAsNull(true);
        char[] charArray71 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray71, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer66.reset(charArray71);
        int int75 = strTokenizer66.previousIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer66.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher62, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer26.reset(charArray34);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder17.insert((int) '4', charArray34, 32, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 52");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(stringBuffer51);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer78);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        java.lang.String str5 = strBuilder3.rightString((int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder3.replaceFirst("1.0", "1.0");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder9.trim();
        java.lang.StringBuffer stringBuffer11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.append(stringBuffer11, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer18.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer18.setTrimmerMatcher(strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer38.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher34, strMatcher43);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer24.setDelimiterMatcher(strMatcher43);
        int int46 = strBuilder14.indexOf(strMatcher43);
        java.lang.StringBuffer stringBuffer47 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder14.append(stringBuffer47);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder50.append((int) '4');
        boolean boolean53 = strBuilder3.equalsIgnoreCase(strBuilder52);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder3.appendFixedWidthPadLeft((int) (byte) 10, 151, 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder57);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        boolean boolean3 = strBuilder1.startsWith("");
        char[] charArray6 = strBuilder1.toCharArray(0, (int) 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer10.setTrimmerMatcher(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder17.trim();
        java.lang.StringBuffer stringBuffer19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.append(stringBuffer19, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer23 = strBuilder18.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder18.replaceAll("", "hi!");
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher30);
        char[] charArray32 = strBuilder26.getChars(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer10.reset(charArray32);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer10.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(true);
        char[] charArray43 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer38.reset(charArray43);
        int int47 = strTokenizer38.previousIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer38.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray6, strMatcher34, strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray6, 'a', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(stringBuffer23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertNotNull(strTokenizer53);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setQuoteChar('a');
        boolean boolean6 = strTokenizer5.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer8.getQuoteMatcher();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strMatcher9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.replaceAll('a', '#');
        int int29 = strBuilder23.lastIndexOf("hi!", (int) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer34.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer43.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer43.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder23.deleteFirst(strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder23.appendFixedWidthPadRight((int) (byte) 100, (int) (short) -1, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder23.deleteFirst("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setDelimiterMatcher(strMatcher63);
        boolean boolean65 = strTokenizer64.isIgnoreEmptyTokens();
        java.util.List list66 = strTokenizer64.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder23.appendWithSeparators((java.util.Collection) list66, "");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder1.append(strBuilder68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.setDelimiterMatcher(strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer77.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder68.appendWithSeparators((java.util.Iterator) strTokenizer77, "StrTokenizer[not tokenized yet]");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(list66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strBuilder80);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setEmptyTokenAsNull(true);
        boolean boolean18 = strTokenizer17.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer17.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.replaceAll(strMatcher19, "");
        int int23 = strBuilder21.lastIndexOf("1.00.0");
        int int26 = strBuilder21.lastIndexOf('a', 3);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        java.lang.StringBuffer stringBuffer5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.append(stringBuffer5, (int) (short) 10, (-1));
        boolean boolean10 = strBuilder4.startsWith("");
        int int13 = strBuilder4.lastIndexOf("hi!", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder4.appendFixedWidthPadLeft((java.lang.Object) (-1), (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append('#');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.setEmptyTokenAsNull(true);
        java.lang.String str8 = strTokenizer3.nextToken();
        java.lang.String str9 = strTokenizer3.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer15.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher20, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer34.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer45.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher50, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer40.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher29, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer3.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder64.trim();
        java.lang.StringBuffer stringBuffer66 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder65.append(stringBuffer66, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer70 = strBuilder65.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder65.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder65.replaceAll("StrTokenizer[]", "StrTokenizer[not tokenized yet]");
        try {
            strTokenizer3.add((java.lang.Object) strBuilder65);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(stringBuffer70);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder76);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        boolean boolean7 = strBuilder5.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((float) (byte) 1);
        char[] charArray10 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder17.trim();
        java.lang.StringBuffer stringBuffer19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.append(stringBuffer19, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer23 = strBuilder18.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder18.replaceAll("", "hi!");
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher30);
        char[] charArray32 = strBuilder26.getChars(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer16.reset(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer39.setEmptyTokenAsNull(true);
        char[] charArray44 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray44, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer39.reset(charArray44);
        int int48 = strTokenizer39.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer53.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer62.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer62.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher58, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer39.setTrimmerMatcher(strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher67);
        int int72 = strBuilder5.indexOf(strMatcher67);
        try {
            java.lang.String str75 = strBuilder5.substring(5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(stringBuffer23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        char[] charArray10 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher13);
        char[] charArray15 = strBuilder9.getChars(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.replaceAll("1.00.0", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoreEmptyTokens(false);
        int int25 = strTokenizer22.previousIndex();
        java.lang.String str26 = strTokenizer22.toString();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer22.setQuoteChar('4');
        java.lang.String str29 = strTokenizer22.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer22.getIgnoredMatcher();
        boolean boolean31 = strBuilder18.contains(strMatcher30);
        java.lang.String str34 = strBuilder18.midString(100, (int) (short) 1);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str26.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str29.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        java.lang.String str11 = strBuilder7.rightString(100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder7.appendFixedWidthPadLeft(0, (int) (byte) 10, 'a');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertNotNull(strBuilder15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        java.lang.String str11 = strBuilder7.rightString(100);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder12.trim();
        java.lang.StringBuffer stringBuffer14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.append(stringBuffer14, (int) (byte) 10, 1);
        boolean boolean19 = strBuilder17.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder20.trim();
        java.lang.StringBuffer stringBuffer22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.append(stringBuffer22, (int) (byte) 10, 1);
        char[] charArray27 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer33.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer44.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer44.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer53.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher49, strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer63.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher68 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer63.setTrimmerMatcher(strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer74.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer74.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer74.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer83.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer83.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher88 = strTokenizer83.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher79, strMatcher88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer69.setDelimiterMatcher(strMatcher88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher58, strMatcher88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher38, strMatcher88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray27);
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder25.insert(0, charArray27);
        char[] charArray95 = strBuilder17.getChars(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer96 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray27);
        org.apache.commons.lang.text.StrBuilder strBuilder97 = strBuilder7.append(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer98 = new org.apache.commons.lang.text.StrTokenizer(charArray27);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strMatcher88);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strTokenizer93);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertNotNull(charArray95);
        org.junit.Assert.assertNotNull(strTokenizer96);
        org.junit.Assert.assertNotNull(strBuilder97);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.io.Writer writer38 = strBuilder5.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer42.setTrimmerMatcher(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.trim();
        java.lang.StringBuffer stringBuffer51 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.append(stringBuffer51, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer55 = strBuilder50.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder50.replaceAll("", "hi!");
        char[] charArray59 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher62);
        char[] charArray64 = strBuilder58.getChars(charArray59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer42.reset(charArray64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray64);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder5.append(charArray64, 0, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray64, "1.0");
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer71.getQuoteMatcher();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(writer38);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(stringBuffer55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strMatcher72);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder0.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder0.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.replaceFirst(' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.trim();
        java.lang.StringBuffer stringBuffer13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append(stringBuffer13, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer26.setTrimmerMatcher(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer37.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer46.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher51 = strTokenizer46.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher42, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer32.setDelimiterMatcher(strMatcher51);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder22.replaceAll(strMatcher51, "");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder20.replace(strMatcher51, "hi!", (int) (short) 0, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder20.append(1.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder63.trim();
        java.lang.StringBuffer stringBuffer65 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder64.append(stringBuffer65, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer69 = strBuilder64.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder64.replaceAll("", "hi!");
        char[] charArray73 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer(charArray73, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray73, strMatcher76);
        char[] charArray78 = strBuilder72.getChars(charArray73);
        char[] charArray79 = strBuilder20.getChars(charArray73);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder10.append(charArray79);
        char[] charArray82 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray82);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer83.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer83.getDelimiterMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher87 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher86, strMatcher87);
        int int89 = strBuilder10.indexOf(strMatcher86);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strMatcher51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(stringBuffer69);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertNotNull(charArray78);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder0.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append("");
        int int13 = strBuilder11.indexOf("StrTokenizer[hi!]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.lang.StringBuffer stringBuffer38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder5.append(stringBuffer38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder40.trim();
        java.lang.StringBuffer stringBuffer42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.append(stringBuffer42, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer49.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer49.setTrimmerMatcher(strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer60.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher65, strMatcher74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer55.setDelimiterMatcher(strMatcher74);
        int int77 = strBuilder45.indexOf(strMatcher74);
        java.lang.StringBuffer stringBuffer78 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder45.append(stringBuffer78);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder45.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder81.ensureCapacity((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder81.replaceAll('#', 'a');
        boolean boolean87 = strBuilder39.equals(strBuilder81);
        int int90 = strBuilder39.lastIndexOf("StrTokenizer[]", 10);
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder39.replaceAll(' ', 'a');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertNotNull(strBuilder93);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        char[] charArray5 = new char[] { ' ', '4', ' ', '4', '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setQuoteChar(' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        java.lang.StringBuffer stringBuffer5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder4.append(stringBuffer5, (int) (short) 10, (-1));
        boolean boolean10 = strBuilder4.startsWith("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.trim();
        java.lang.StringBuffer stringBuffer13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append(stringBuffer13, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer17 = strBuilder12.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setEmptyTokenAsNull(true);
        boolean boolean29 = strTokenizer28.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder12.replaceAll(strMatcher30, "");
        boolean boolean33 = strBuilder4.equals(strBuilder32);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder4.clear();
        boolean boolean35 = strBuilder4.isEmpty();
        int int38 = strBuilder4.indexOf("hi!1.0", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder4.clear();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(stringBuffer17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setEmptyTokenAsNull(true);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.replaceAll(strMatcher32, "");
        char[] charArray35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setQuoteChar('a');
        boolean boolean41 = strTokenizer40.hasNext();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder34.appendFixedWidthPadLeft((java.lang.Object) boolean41, 32, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher51 = strTokenizer48.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder44.replaceFirst(strMatcher51, "");
        boolean boolean55 = strBuilder44.contains("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder44.minimizeCapacity();
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strMatcher51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.lang.StringBuffer stringBuffer38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder5.append(stringBuffer38);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.setCharAt((int) (byte) 0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.replaceAll('4', '#');
        char[] charArray50 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray50, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.reset("");
        java.lang.String[] strArray56 = strTokenizer53.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder46.appendWithSeparators((java.lang.Object[]) strArray56, "1.0aaaaaaaa32");
        int int61 = strBuilder58.lastIndexOf(' ', (int) 'a');
        try {
            char char63 = strBuilder58.charAt((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 35");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setEmptyTokenAsNull(true);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.replaceAll(strMatcher32, "");
        char[] charArray35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(true);
        int int41 = strTokenizer38.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder22.append((java.lang.Object) strTokenizer38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer46.setEmptyTokenAsNull(true);
        char[] charArray51 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer46.reset(charArray51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray51);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder22.append((java.lang.Object) strTokenizer55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer55.setDelimiterString("class org.apache.commons.lang.te");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer58);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder9.replace(strMatcher40, "hi!", (int) (short) 0, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.append("hi!1.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer56.setEmptyTokenAsNull(true);
        char[] charArray61 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray61, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer56.reset(charArray61);
        int int65 = strTokenizer56.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer70.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = strTokenizer70.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = strTokenizer79.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer79.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher84 = strTokenizer79.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher75, strMatcher84);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer56.setTrimmerMatcher(strMatcher84);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher84);
        int int89 = strBuilder51.indexOf(strMatcher84, (int) (byte) 100);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strMatcher75);
        org.junit.Assert.assertNotNull(strTokenizer81);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertNotNull(strMatcher84);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        java.lang.String str5 = strBuilder3.rightString((int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder3.replaceFirst("1.0", "1.0");
        int int11 = strBuilder3.indexOf("class org.apache.commons.lang.te", 151);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.trim();
        java.lang.StringBuffer stringBuffer15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.append(stringBuffer15, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer22.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer22.setTrimmerMatcher(strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer33.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer42.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher38, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer28.setDelimiterMatcher(strMatcher47);
        int int50 = strBuilder18.indexOf(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder18.appendFixedWidthPadRight((int) (byte) 1, 0, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(false);
        char[] charArray61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.reset(charArray61);
        java.lang.String str63 = strTokenizer62.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer62.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher66 = strTokenizer65.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder18.deleteAll(strMatcher66);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer("1.00.0", strMatcher66);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder3.deleteFirst(strMatcher66);
        java.io.Writer writer70 = strBuilder3.asWriter();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strMatcher66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(writer70);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        boolean boolean7 = strBuilder5.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder44.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder45.insert((int) (byte) 0, (double) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder9.append(strBuilder48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.setDelimiterMatcher(strMatcher56);
        boolean boolean58 = strTokenizer57.isIgnoreEmptyTokens();
        java.util.List list59 = strTokenizer57.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer57.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder48.replace(strMatcher60, "class org.apache.commons.lang.text.StrTokenizer", 0, (int) (byte) 100, (int) (byte) 10);
        char[] charArray66 = strBuilder48.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray66);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertNotNull(strTokenizer67);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.insert(0, (float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append((int) (short) -1);
        int int7 = strBuilder6.size();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.insert((-1), (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strTokenizer2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer15.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer24.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher20, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer34.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer45.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer45.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer54.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer54.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher50, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer40.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher29, strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.replace(strMatcher29, "", 0, (int) (byte) 100, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder67.deleteFirst('a');
        boolean boolean71 = strBuilder67.contains("class org.apache.commons.lang.te");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer15.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer15.setTrimmerMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer26.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer35.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer21.setDelimiterMatcher(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.replaceAll(strMatcher40, "");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder44.reverse();
        int int46 = strBuilder45.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer51.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer51.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = strTokenizer60.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher56, strMatcher65);
        int int67 = strTokenizer66.size();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder45.appendWithSeparators((java.util.Iterator) strTokenizer66, "");
        boolean boolean70 = strBuilder7.equalsIgnoreCase(strBuilder45);
        int int73 = strBuilder7.lastIndexOf(' ', (int) ' ');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strMatcher65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer5.setTrimmerMatcher(strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer16.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer16.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer25.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher21, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer11.setDelimiterMatcher(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder1.replaceAll(strMatcher30, "");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder34.reverse();
        int int36 = strBuilder35.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer41.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer41.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer50.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer50.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher55);
        int int57 = strTokenizer56.size();
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder35.appendWithSeparators((java.util.Iterator) strTokenizer56, "");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder60.trim();
        java.lang.StringBuffer stringBuffer62 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder61.append(stringBuffer62, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder65.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder59.append((java.lang.Object) strBuilder67);
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder67.appendFixedWidthPadRight((int) ' ', (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder67.replaceFirst("StrTokenizer[hi!]", " 4 4#");
        java.lang.String str77 = strBuilder75.leftString((int) (short) 10);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "1.032aaaaa" + "'", str77.equals("1.032aaaaa"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer6 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer13.setEmptyTokenAsNull(true);
        boolean boolean18 = strTokenizer17.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer17.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.replaceAll(strMatcher19, "");
        char[] charArray22 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer28.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer28.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer39.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer39.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer48.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer48.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher44, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer58.setTrimmerMatcher(strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer69.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer69.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer78.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer78.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher74, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer64.setDelimiterMatcher(strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher53, strMatcher83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher33, strMatcher83);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder1.replaceAll(strMatcher83, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder1.appendPadding(1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder1.replaceAll("hi!", "hi!");
        int int97 = strBuilder1.indexOf("hi!1.0");
        org.apache.commons.lang.text.StrBuilder strBuilder98 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder99 = strBuilder1.append(strBuilder98);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(stringBuffer6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(strBuilder95);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1) + "'", int97 == (-1));
        org.junit.Assert.assertNotNull(strBuilder99);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder1.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll('a', '#');
        java.lang.StringBuffer stringBuffer21 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(stringBuffer21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer26.setEmptyTokenAsNull(true);
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher32 = strTokenizer30.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder22.replaceAll(strMatcher32, "");
        char[] charArray35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoreEmptyTokens(true);
        int int41 = strTokenizer38.previousIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder22.append((java.lang.Object) strTokenizer38);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder22.setLength((int) (byte) 1);
        char[] charArray45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setDelimiterChar('a');
        int int49 = strTokenizer46.size();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder22.appendWithSeparators((java.util.Iterator) strTokenizer46, "class org.apache.commons.lang.text.StrTokenizer");
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(strBuilder51);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer5, "hi!");
        boolean boolean11 = strBuilder1.contains("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.deleteFirst('#');
        int int17 = strBuilder15.indexOf("StrTokenizer[]");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.append(0);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.append('4');
        java.lang.StringBuffer stringBuffer22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append(stringBuffer22);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoredChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder25.appendWithSeparators((java.util.Iterator) strTokenizer29, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer29.setIgnoredChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher36 = strTokenizer35.getDelimiterMatcher();
        int int38 = strBuilder21.indexOf(strMatcher36, (-1));
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strMatcher36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer9.setTrimmerMatcher(strMatcher14);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer20.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer20.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer29.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer29.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher25, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer15.setDelimiterMatcher(strMatcher34);
        int int37 = strBuilder5.indexOf(strMatcher34);
        java.io.Writer writer38 = strBuilder5.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer42.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer42.setTrimmerMatcher(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.trim();
        java.lang.StringBuffer stringBuffer51 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder50.append(stringBuffer51, (int) (byte) 10, 1);
        java.lang.StringBuffer stringBuffer55 = strBuilder50.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder50.replaceAll("", "hi!");
        char[] charArray59 = new char[] {};
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray59, strMatcher62);
        char[] charArray64 = strBuilder58.getChars(charArray59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer42.reset(charArray64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray64);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder5.append(charArray64, 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder5.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder70.appendNull();
        boolean boolean73 = strBuilder70.endsWith(" ");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder70.appendPadding((int) (byte) 0, ' ');
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(writer38);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(stringBuffer55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(strBuilder76);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.replaceFirst("StrTokenizer[not tokenized yet]####", "class org.apache.commons.lang.text.StrTokenizer#");
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder0.replaceAll('a', '#');
        int int6 = strBuilder0.lastIndexOf("hi!", (int) (short) 1);
        java.io.Reader reader7 = strBuilder0.asReader();
        java.util.Collection collection8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.appendWithSeparators(collection8, "hi!");
        int int11 = strBuilder0.length();
        char[] charArray12 = strBuilder0.toCharArray();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder7.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder10.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        int int10 = strBuilder7.lastIndexOf('a', (int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder7.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(false);
        char[] charArray22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer19.reset(charArray22);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strTokenizer19, (int) (byte) -1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.replaceFirst("1.0aaaaaaaa32", "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer33.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder29.deleteFirst(strMatcher38);
        int int42 = strBuilder39.indexOf("hi!1.0", 0);
        java.lang.String str44 = strBuilder39.rightString(10);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder45.trim();
        java.lang.StringBuffer stringBuffer47 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder46.append(stringBuffer47, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder50.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder52.setNullText("");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer60.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher65 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer60.setTrimmerMatcher(strMatcher65);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer71.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer71.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer80.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher85 = strTokenizer80.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher76, strMatcher85);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer66.setDelimiterMatcher(strMatcher85);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder56.replaceAll(strMatcher85, "");
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder54.replace(strMatcher85, "hi!", (int) (short) 0, (int) (byte) 0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder39.deleteAll(strMatcher85);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.0hi!a" + "'", str44.equals("1.0hi!a"));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strMatcher85);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertNotNull(strBuilder95);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder1 = strBuilder0.trim();
        java.lang.StringBuffer stringBuffer2 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(stringBuffer2, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.setNullText("");
        java.lang.String str11 = strBuilder7.rightString(100);
        boolean boolean12 = strBuilder7.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder7.replaceAll("StrTokenizer[]", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.insert(0, (float) (short) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strBuilder18.asTokenizer();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strBuilder18.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder21.trim();
        java.lang.StringBuffer stringBuffer23 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.append(stringBuffer23, (int) (byte) 10, 1);
        boolean boolean28 = strBuilder26.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer36.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer36.setTrimmerMatcher(strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer47.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer47.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("", '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer56.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher61 = strTokenizer56.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher52, strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer42.setDelimiterMatcher(strMatcher61);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder32.replaceAll(strMatcher61, "");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder65.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder66.insert((int) (byte) 0, (double) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder30.append(strBuilder69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer74.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher77 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer76.setDelimiterMatcher(strMatcher77);
        boolean boolean79 = strTokenizer78.isIgnoreEmptyTokens();
        java.util.List list80 = strTokenizer78.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer78.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder69.replace(strMatcher81, "class org.apache.commons.lang.text.StrTokenizer", 0, (int) (byte) 100, (int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer20.setIgnoredMatcher(strMatcher81);
        org.junit.Assert.assertNotNull(strBuilder1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strMatcher61);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strTokenizer87);
    }
}

