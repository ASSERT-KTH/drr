import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str3.equals("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                                     ", "Mc OS XaMc OS XaMc OS sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("im", "..");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uVlV PVif/r API JbcvfvcViv/" + "'", str1.equals("uVlV PVif/r API JbcvfvcViv/"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("uVlV PVif/r API JbcvfvcViv/", "/mo", "amixed mode2a.80-b112a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uVlV PVifar API JbcvfvcViva" + "'", str3.equals("uVlV PVifar API JbcvfvcViva"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "N", "Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" c");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                    2#.80...", 125);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Cor", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor" + "'", str2.equals("Oracle Cor"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b1124          24.80-b1124");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124          24.80-b1124" + "'", str1.equals("24.80-b1124          24.80-b1124"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 149, 328);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 328 + "'", int3 == 328);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  " + "'", str2.equals("                                         e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                \n\n\n                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Mac Oa X", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", (int) (byte) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                " + "'", str3.equals("               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ne                                                                                               ne                                                                       ", "", "mixednenemode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ne                                                                                               ne                                                                       " + "'", str3.equals("ne                                                                                               ne                                                                       "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "MIXED MOD                                                                                           ", (java.lang.CharSequence) "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str1.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mc OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed mod", "x so Cm", 0, 244);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x so Cm" + "'", str4.equals("x so Cm"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HTTP://JA", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        short[] shortArray2 = new short[] { (short) 0, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0, 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl..." + "'", str3.equals("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl..."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(21, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n\n\n");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("lib/java:.", "                               ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray2, strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str6.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("om/", 172);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 172 + "'", int2 == 172);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uVlVPVif/rAPIJbcvfvcViv/" + "'", str1.equals("uVlVPVif/rAPIJbcvfvcViv/"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("24.80...", "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("MIXEDMODE", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80...", '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 100);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("x86_6                                                                                               ", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "uVlVPVif/rAPIJbcvfvcViv/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", 28, "                     edom dexim                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str3.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#######", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mixedne nemode                                      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("M  c O   X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M  c O   X" + "'", str1.equals("M  c O   X"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                         e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "awt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "                                                                                               eN");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification", "HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "MC OS X");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "MC OS X");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "mac mac ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(97.0f, (float) 100, 125.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 125.0f + "'", float3 == 125.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/", (int) (short) -1, "Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/" + "'", str3.equals("RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        char[] charArray11 = new char[] { '#', '4', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MC OS X", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("SophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" MC OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe", 334);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                   11b-08.42", "/Users/sophie/Librar1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Librar1.7.0_80-b15" + "'", str2.equals("/Users/sophie/Librar1.7.0_80-b15"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80...", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("Mc OS X", strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "    ..");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "10.14.3");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "210.14.380" + "'", str8.equals("210.14.380"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("x86_6                           Oracle Corporation                                                ", "ar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mac Oa X", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "4444444444444444444444444444444444444444444444444:", (int) ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HTTP://JA", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 328);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("XSOc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xsoc" + "'", str1.equals("xsoc"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java(TM)UTF-8                              SEUTF-8                              RuntimeUTF-8                              Environment", "aaaaHTTP://JAV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("xSOcM", "lib/java:.", "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xSOcM" + "'", str3.equals("xSOcM"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 1, (long) (byte) 1, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("MIXED MOD", 149, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MODaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("MIXED MODaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("JavatPlatformtAPItSpncificatioe", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen", 159);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("BOjRETNIRpc.XSOCAM.TWAWL.NUS", "mv revres tib-46 )mt(topstoh avaj", 51);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("User r");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "mixed m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed m" + "'", str2.equals("mixed m"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "BOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUS", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int[] intArray5 = new int[] { '#', (byte) -1, (byte) 1, 1, (short) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("mv revres tib-46 )mt(topstoh avaj", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod" + "'", str1.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Ne", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.LWAWT.MACOSX.cpRINTERjOB", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                               US", "Mc O X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               US" + "'", str2.equals("                                                                                               US"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaHTTP://JAV", "ar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaHTTP://JAV" + "'", str2.equals("aaaaHTTP://JAV"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X", "Mac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLE CORPORATION", 328, "X OS Mc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McXORACLE CORPORATIONX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX" + "'", str3.equals("X OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McXORACLE CORPORATIONX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.cpRINTERjO");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjO" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjO"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "                                                                    2#.80...", (int) (byte) 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Mac OS X", (int) (short) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray15 = null;
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray14, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray9, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str16.equals("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str17.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str18.equals("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                            ", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-b11                                24.80-b11                                24.80-b11", "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "24.80...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 172L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("mv revres tib-46 )mt(topstoh avaj", "eDOM DEXIM", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                noitaroproC elcarO                           6_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                noitaroproC elcarO                           6_68x" + "'", str1.equals("                                                noitaroproC elcarO                           6_68x"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java(TM)SERuntimeEnvironment                        ", "n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)SERuntimeEnvironment                        " + "'", str2.equals("Java(TM)SERuntimeEnvironment                        "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja", (java.lang.CharSequence) " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("amixed mode2a.80-b112a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "amixed mode2a.80-b112a" + "'", str2.equals("amixed mode2a.80-b112a"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.LWAWT.MACOSX.cpRINTERj", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERj" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERj"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("x86_6", 76);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("amixed mode2a.80-b112a", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("x86_64", (java.lang.Object[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X SO cM", '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 33 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str4.equals("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("x so cm MC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x so cm MC OS X" + "'", str1.equals("x so cm MC OS X"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.cpRINTERjO");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                               ", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mc O X" + "'", str4.equals("Mc O X"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Mac Oa X" + "'", str6.equals("Mac Oa X"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjO" + "'", str11.equals("SUN.LWAWT.MACOSX.cpRINTERjO"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("VAJ//:PTTH");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar" + "'", str2.equals("/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                noitaroproC elcarO                           6_68x", "RENTJAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                noitaroproC elcarO                           6_68x" + "'", str2.equals("                                                noitaroproC elcarO                           6_68x"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b1124          24.80-b1124", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                \n\n\n                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 328, (long) 6, 334L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 334L + "'", long3 == 334L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" MC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MC OS X" + "'", str1.equals("MC OS X"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + "'", str2.equals("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "aaaaHTTP://JAV", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("MIXED MODaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "m");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 142 + "'", int1 == 142);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("11b-08.42", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("r/folders/_v/6v597zmn4_v31", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 0, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ne                                                                                               ", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("xSOcM", "/Users/sophie/Librar1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xSOcM" + "'", str2.equals("xSOcM"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc", "24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("ne                                                                                              ", "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 170, 97);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 28, (int) (byte) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "McOSX" + "'", str4.equals("McOSX"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X" + "'", str14.equals("McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Ne                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Ne\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x" + "'", str2.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("e24.80-b1124", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                                    mixedmode", 33, 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                            " + "'", str3.equals("                                                                            "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   ", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   " + "'", str3.equals("uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "rentjar", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("1.7.0_80-b15", "/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) 34, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                               US                                                ", "Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                     edom dexim                     ", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     edom dexim                     " + "'", str2.equals("                     edom dexim                     "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "UTF-8                              ");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("ne", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", "uVlV PVif/r API JbcvfvcViv/e", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str3.equals("/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("VAJ//:PTTH", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VAJ//:PTTH" + "'", str2.equals("VAJ//:PTTH"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "24.80-b11");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("24.80-b1124          24.80-b1124", strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "##############################################1.7.0_80##############################################", 6, 2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str8.equals("Java(TM)SERuntimeEnvironment"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("ne                                                                                               ne", "r/folders/_v/6v597zmn4_v31", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Exten..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten.." + "'", str1.equals("/Users/sophie/Library/Java/Exten.."));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 87);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedjv hotspot(tm) 64-bit server vm jv hotspot(tm) 64-bit server vmmode" + "'", str2.equals("mixedjv hotspot(tm) 64-bit server vm jv hotspot(tm) 64-bit server vmmode"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "/User //r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Exten..", "sun.lwawt.macosx.CPrinterJob", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("  ", "Ne                                                                                              ", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixedne nemode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "/Librry/Jv/JvVirtulMchines/jdk1....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...", "x so CmJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIF");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                            ", "/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        char[] charArray9 = new char[] { '#', '4', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("hi!", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "#############################################3.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 328);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                           sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("                                                                                                                                                           sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "User r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.cprinterjob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwawt.macosx.cprinterjob is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "sophie", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ne                                                                                               ne", "210.14.380", (int) 'a');
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        double[] doubleArray1 = new double[] { 2 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod" + "'", str2.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("HTTP://JAV", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                _64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM)SERuntimeEnvironment", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                        /vr/folders/_v/6v597zmn4_v31");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        char[] charArray9 = new char[] { '#', '4', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray9);
        java.lang.Class<?> wildcardClass12 = charArray9.getClass();
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mc OS XaMc OS XaMc OS sophie", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("######################24.80...######################", 76, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                \n\n\n                                                 ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                \n\n\n                                                 " + "'", str2.equals("                                                \n\n\n                                                 "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                    2#.80...", "uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 100, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("eDOM DEXIM", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 334L, 0.0d, (double) 98);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("2#.80..");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "uVlV PVif/r API JbcvfvcViv/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uVlV PVif/r API JbcvfvcViv/" + "'", str1.equals("uVlV PVif/r API JbcvfvcViv/"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("#SE#Runtime#", "MIXED MODaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "X OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McXORACLE CORPORATIONX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX OS McX", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ne", "/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ne" + "'", str3.equals("ne"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr", "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_", 87);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    ...", 125, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 172, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 149, (double) (short) 0, (double) 8.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 149.0d + "'", double3 == 149.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#######", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentxJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 197 + "'", int2 == 197);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixedmode                       ", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA", 172, 96);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixedmode                       MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA" + "'", str4.equals("mixedmode                       MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("awt.macosx.CPrinterJob", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "awt.macosx.CPrinterJob" + "'", str2.equals("awt.macosx.CPrinterJob"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EDOM DEXIM" + "'", str1.equals("EDOM DEXIM"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) 'a', 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_6", "/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ", "/Users/sophie/Librar1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                            ", (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("java Virtual Machine Specificatio", "Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("ne                                                                                               ", "mixedmod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN", ":", 97, 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr:" + "'", str4.equals("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr:"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ", 96, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c " + "'", str3.equals(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "mv revres tib-46 )mt(topstoh avaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mv revres tib-46 )mt(topstoh avaj" + "'", str1.equals("Mv revres tib-46 )mt(topstoh avaj"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif", "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif" + "'", str2.equals("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Ne                                                                                              ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "ne                                                                                               ne");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JavaPlatformAPISpecification", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "uVlV PVif/r API JbcvfvcViv/e", 244);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptth" + "'", str4.equals("sophaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptth"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...#...", 54, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444...#..." + "'", str3.equals("44444444444444444444444444444444444444444444444...#..."));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Mc O X", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O X" + "'", str2.equals("Mc O X"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray8);
        java.lang.Class<?> wildcardClass11 = charArray8.getClass();
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Ne", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixedmode", "..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("lib/java:.", "nere/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR                                                                                               ", "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ZMN4_V31CQ2N2X1N4FC0000GN/t/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixedne nemode                                      ", "Ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVAhOTsPOT(tm)64-bITsERVERvm" + "'", str1.equals("jAVAhOTsPOT(tm)64-bITsERVERvm"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "M  c O   X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/sers", "UTF-8                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/sers" + "'", str2.equals("/sers"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b15", "e", "/mo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("MIXED MOD", "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                 ...", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac", "JavaPlatformAPISpecification", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#############################################3.41.01", "...MIXED MODEnvironment", 76);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 23, (long) 8, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl...", "Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA" + "'", str1.equals("/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4mixed mode24.80-b1124", "1.7", 0, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("\n\n\nn", "XSOcM", (int) (short) 1, 76);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\nXSOcM" + "'", str4.equals("\nXSOcM"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + "'", str2.equals("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, (float) 4, (float) 50L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Librar1.7.0_80-b15", "e                                                   ", 244);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM)#SE#Runtime#Environment" + "'", str5.equals("Java(TM)#SE#Runtime#Environment"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("rentjar", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rentjar" + "'", str3.equals("rentjar"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("om /", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("N", "ar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N" + "'", str2.equals("N"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("S", "mixedmode                       ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("##############################################1.7.0_80##############################################", "210.14.380", 192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("rentjar", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                               eN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("MIXED MOD                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MOD                                                                                           " + "'", str1.equals("MIXED MOD                                                                                           "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("amixed mode2a.80-b112a", "", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("e                                                   ", "    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                _64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("  ", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) 8, (double) 142);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(".14.3", 23, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                     edom dexim                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom dexim" + "'", str1.equals("edom dexim"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        char[] charArray13 = new char[] { '#', '4', 'a', ' ', '4' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "li", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ne", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...MIXED MODEnvironment", "l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...MIXED MODEnvironment" + "'", str2.equals("...MIXED MODEnvironment"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("http://java.oracle.com/", "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ", 10, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  a.oracle.com/" + "'", str4.equals("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  a.oracle.com/"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.cprinterjob", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        sun.lwawt.macosx.cprinterjob" + "'", str2.equals("                        sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie                                            en", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sop" + "'", str2.equals("/Users/sophie/Users/sop"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        char[] charArray11 = new char[] { '#', '4', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray11);
        java.lang.Class<?> wildcardClass15 = charArray11.getClass();
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", charArray11);
        java.lang.Class<?> wildcardClass17 = charArray11.getClass();
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ORACLE CORPORATION", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixedjv hotspot(tm) 64-bit server vm jv hotspot(tm) 64-bit server vmmode", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                                 ...", 50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X" + "'", str3.equals("M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MAC OS X", "mixedmode", "                                                \n\n\n                                                 ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("    ", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("X SO c", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mixedne                                                                                               ne                                                                                              mode", 192, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod" + "'", str1.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "c");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                       1.7.0_80-b15", "#SE#Runtime#", "mixedne nemod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       1.7.0_80-b15" + "'", str3.equals("                       1.7.0_80-b15"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                     edom dexim                     ", "nere/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR                                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", "Mac OS ", 18, 125);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/uSER //R/uSER //RMac OS " + "'", str4.equals("/uSER //R/uSER //RMac OS "));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8                              ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("aaaaaaaarentj4rrentj4", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n\n\nS");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "sophaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptthaj:ptth", 4, 76);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java(TM)4SE4Runtime4Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)4SE4Runtime4Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X" + "'", str4.equals("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("eDOM DEXIM", 0, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eDOM DEXIM" + "'", str3.equals("eDOM DEXIM"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA", "/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", "...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ne                                                                                               ne                                                                       ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/vr/folsers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("ne                                                                                               ne                                                                       ", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 99 + "'", int5 == 99);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        float[] floatArray2 = new float[] { 8, 32 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 32.0f + "'", float4 == 32.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 8.0f + "'", float6 == 8.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", 33, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                       1.7.0_80-b15", "X SO cM", "               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 100, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "/sers");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/sers" + "'", str2.equals("/sers"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("c", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", "IM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR" + "'", str2.equals("Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("User r", 50, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("MAC OS ", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MACOS" + "'", str3.equals("MACOS"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                        sun.lwawt.macosx.cprinterjob", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "mixednenemode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "McOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("MACOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACOS" + "'", str1.equals("MACOS"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("S", "uVlV PVifar API JbcvfvcViva", ":");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Ne                                                                                               ", ' ');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Users/sop", "11b-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("    ...", "McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", 0, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64x86_64x86_64x86_64x86_64" + "'", str3.equals("x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ne                                                                                               ne");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ne                                                                                               ne\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("MC", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MC" + "'", str2.equals("MC"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/" + "'", str2.equals("http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("e                                                  ", "lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e                                                  " + "'", str2.equals("e                                                  "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...", 197);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac..." + "'", str2.equals("...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac..."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                         e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray10);
        java.lang.Class<?> wildcardClass14 = charArray10.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b1124          24.80-b1124aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Users/sop", "sun.lwawt.macosx.cprinterjob", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sop" + "'", str3.equals("/Users/sophie/Users/sop"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "mac mac ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ent.jar" + "'", str2.equals("ent.jar"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("xSOcM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xSOcM" + "'", str1.equals("xSOcM"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", "http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java(TM)SERuntimeEnvironment                        ", "1.7.0_80-b15", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("n", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                        /vr/folders/_v/6v597zmn4_v31");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                        /vr/folders/_v/6v597zmn4_v31\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("######################24.80...######################", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################24.80...######################" + "'", str2.equals("######################24.80...######################"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mcOSX", "_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("rentj4r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rentj4r" + "'", str2.equals("rentj4r"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", "Java(TM)#SE#Runtime#Environment", 3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("m", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "m" + "'", str7.equals("m"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API Sp", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API Sp" + "'", str2.equals("Java Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API Sp"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.Object[] objArray0 = new java.lang.Object[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "im");
        org.junit.Assert.assertNotNull(objArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("JavaHotSpot(TM)64-BitServerVM", "\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MC", "                                               US                                                ", "JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("ZMN4_V31CQ2N2X1N4FC0000GN/t/", "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "sun.awt.CGraphicsEnvironment", 334);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ", "######x so cm MC OS X#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  " + "'", str2.equals("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 35, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray12);
        java.lang.Class<?> wildcardClass16 = charArray12.getClass();
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("MAC OS X", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("MACOS", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MACOS" + "'", str2.equals("MACOS"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 142, (long) 87, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########", "x so cm MC OS X", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                \n\n\n                                                 ", "11B-08.42");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Ne                                                                                              ", " c");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ne                                                                                              " + "'", str2.equals("Ne                                                                                              "));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", "ent.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     Java(TM)SERuntimeEnvironment                        " + "'", str2.equals("                     Java(TM)SERuntimeEnvironment                        "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 2, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Ne                                                                                              ", "/Users/sophie/Library/Java/Exten...                                                              ", "X SO c");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ne                                                                                              " + "'", str3.equals("Ne                                                                                              "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "ne");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "java hotspot(tm) 64-bit server vm");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedne nemode" + "'", str3.equals("mixedne nemode"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode" + "'", str6.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("x so cm", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " so cm" + "'", str2.equals(" so cm"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Ne                                                                                               ", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ne" + "'", str3.equals("Ne"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/4se", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixedne                                                                                               ne                                                                                              mode", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", "http://java.oracle.com/", "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str4.equals("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ne                                                                                              ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ne                                                                                              " + "'", str2.equals("ne                                                                                              "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                            aaaaHTTP://JAV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VAJ//:PTTHaaaa                                                                                                                                                            " + "'", str1.equals("VAJ//:PTTHaaaa                                                                                                                                                            "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                               ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", "                                                                                                                                                            aaaaHTTP://JAV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("mixedne nemod", "e                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedne nemod" + "'", str2.equals("mixedne nemod"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "eDOM DEXIM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("jAVAhOTsPOT(tm)64-bITsERVERvm", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("ent.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ent.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Java Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API Sp", "                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1", strArray4);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str8.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + ":" + "'", str16.equals(":"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("r/folders/_v/6v597zmn4_v31", "                               ", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("24.80-b1124          24.80-b1124", "mixed m", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124" + "'", str3.equals("24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124mixed m24.80-b1124          24.80-b1124"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("e                                                   ", 99, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixedne nemod", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 170, (double) 142, (double) 12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("Mac OS X", (java.lang.Object[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 32, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("n", "RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen", "om/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X" + "'", str2.equals("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                            ", "S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                            " + "'", str2.equals("                                                                            "));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("en", "Orcle Corportion", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("edom dexim", "Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444", 10, "ne                                                                                               ne                                                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444" + "'", str3.equals("24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica", "24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-8                              ", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                               eN", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixedne                                                                                               ne                                                                                              mode", "51.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 100, 52);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("  ", "x86_6", "", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  " + "'", str4.equals("  "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JavaVirtualMachineSpecification", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 50, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 5.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NE                                                                                              " + "'", str1.equals("NE                                                                                              "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SUN.LWAWT.MACOSX.cpRINTERjOB", 328);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Librry/Jv/JvVirtulMchines/jdk1....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRRY/JV/JVVIRTULMCHINES/JDK1...." + "'", str1.equals("/LIBRRY/JV/JVVIRTULMCHINES/JDK1...."));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Librry/Jv/JvVirtulMchines/jdk1....", "EDOM DEXIM", (int) (short) 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("mixedmod", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mc OS Xa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mc OS X" + "'", str1.equals("Mc OS X"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#######", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi!", "mixedne nemode                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        char[] charArray11 = new char[] { '#', '4', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "            10.14.3#############################################            ", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                       ", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 328, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 328 + "'", int3 == 328);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/jasun.lwawt.macosx.cprinterjob" + "'", str1.equals("/users/sophie/library/jasun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11                                24.80-b11                                24.80-b11", 149, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                      24.80-b11" + "'", str3.equals("...                      24.80-b11"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "MC OS X");
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 96, 50);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("OaclaCan", "", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}

