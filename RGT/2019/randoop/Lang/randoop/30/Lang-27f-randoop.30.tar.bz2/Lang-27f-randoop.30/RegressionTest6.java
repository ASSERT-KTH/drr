import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x so cm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x so cm" + "'", str1.equals("x so cm"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/User //r", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", (java.lang.CharSequence) "                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 159 + "'", int2 == 159);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("VAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTH", "Ne");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("\n\n\n", "mv revres tib-46 )mt(topstoh avaj", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa", (int) (byte) 1, "EN");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa" + "'", str3.equals("Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("l", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JavatPlatformtAPItSpncificatioe", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MIXEDMODE", "mcOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X", 4);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.Object[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac Oa X", (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) 159, 98.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R" + "'", str2.equals("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mixedmod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mixedmod is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n\n\nS", "mixedne nemode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\nS" + "'", str2.equals("\n\n\nS"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("HTTP://JAV", "Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA...", "MC OS X", "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..." + "'", str3.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..."));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("aaaaaaaa", "MAC MAC ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaa" + "'", str2.equals("aaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80..." + "'", str1.equals("24.80..."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("xSOcM", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xSOcM" + "'", str2.equals("xSOcM"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("MAC OS X", "2#.80..", "rentjar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS X" + "'", str3.equals("MAC OS X"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixedne nemode", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedne nemode" + "'", str2.equals("mixedne nemode"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/User//r", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/User//r" + "'", str2.equals("/User//r"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/", 98.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 98.0f + "'", float2 == 98.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "10.14.3#############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "2Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "2Java(TM) SE Runtime Environment" + "'", charSequence2.equals("2Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                ", 21, "                                                noitaroproC elcarO                           6_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24.80...444444444444444444444444444", "Oracle Cor", "                                                                                               US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80...444444444444444444444444444" + "'", str3.equals("24.80...444444444444444444444444444"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "mixedne nemode", 5);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "mixedne nemode                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java HotSpot(TM) 64-Bit Server VM", 3, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("#############################################3.41.01", "24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/", "im");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("MAC MAC ", "mv revres tib-46 )mt(topstoh avaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC MAC " + "'", str2.equals("MAC MAC "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", "/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("m");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "######################24.80...######################");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "sun.awt.CGraphicsEnvironment");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mo");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("http:ecom/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java(HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", 32, 334);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str4.equals("Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 100, "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA" + "'", str3.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle Corporation", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("11B-08.42");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x so cm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x so cm\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 172, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "uVlV PVif/r API JbcvfvcViv/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 54, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "######################24.80...######################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "10.14.3#############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3#############################################" + "'", str1.equals("10.14.3#############################################"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Corporation", 14, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("Mac OS X", (java.lang.Object[]) strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("  ", strArray4);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                               US                                                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("10.14.3#############################################", "2Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                                /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaarentj4rrentj4", "JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT", "X SO CAM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaarentj4rrentj4" + "'", str3.equals("aaaaaaaarentj4rrentj4"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.7f, 6.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", "Java Platform API Sp", "mixedmod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                noitaroproC elcarO                           6_68x");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("X SO CAM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n", " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/User//r", 14, "x86_6                                                                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6 /User//r" + "'", str3.equals("x86_6 /User//r"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#############################################3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#############################################3.41.01" + "'", str1.equals("#############################################3.41.01"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/vr/folders/_v/6v597zmn4_v31", (int) (byte) -1, 159);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/vr/folders/_v/6v597zmn4_v31" + "'", str3.equals("/vr/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("aaaaHTTP://JAV", "/User //r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        double[] doubleArray3 = new double[] { (byte) 100, 244, 2.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(97.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("r/folders/_v/6v597zmn4_v31", "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31" + "'", str2.equals("r/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "McOSX" + "'", str4.equals("McOSX"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java(TM)#SE#Runtime#Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaHTTP://JAV", 170, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                            aaaaHTTP://JAV" + "'", str3.equals("                                                                                                                                                            aaaaHTTP://JAV"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Exten...", "RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM)#SE#Runtime#Environment", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)#SE#Runtime#Environment" + "'", str3.equals("Java(TM)#SE#Runtime#Environment"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80...444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 0, (long) 50, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 50L + "'", long3 == 50L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 2, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("li");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"li\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaOaclaCan");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaOaclaCan" + "'", str1.equals("aaOaclaCan"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ", "                                                                                                                    mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixedmod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar", "\n\n\nS", 30);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar" + "'", str4.equals("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 0, "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n" + "'", str2.equals("\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", (int) (byte) 0, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mv revres tib-46 )mt(topstoh avaj");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("N");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"N\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("11B-08.42");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11B-08.42" + "'", str1.equals("11B-08.42"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM)4SE4Runtime4Environment", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str2.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 4, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80...444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444" + "'", str2.equals("24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                \n\n\n                                                 ", "MIXED MOD");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("######################24.80...######################", "li");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################24.80...######################" + "'", str2.equals("######################24.80...######################"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java(TM)#SE#Runtime#Environment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen", "2Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                               US                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80...444444444444444444444444444", "java Virtual Machine Specificatio", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8.0f, 100.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporationaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportion" + "'", str2.equals("Orcle Corportion"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" c", "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", 172, 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " c/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str4.equals(" c/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/vr/folders/_v/6v597zmn4_v31", "Mac Oa X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "x so cm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "c");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str3.equals("Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                            ", "x so cm", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("X SO c", "x86_6 /User//r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 6, "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jUTF-8" + "'", str3.equals("jUTF-8"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 54, (float) 100L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "24.80-b11");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                               US                                                ", strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("##############################################1.7.0_80##############################################", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "##############################################1.7.0_80##############################################" + "'", str13.equals("##############################################1.7.0_80##############################################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                     edom dexim                     ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("li");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3#############################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#Environment", 87, "Oracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#Environment" + "'", str3.equals("Java(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#Environment"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaa", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac Oa X", 170, "/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF" + "'", str3.equals("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "", "SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja", "                                                                                                                    mixedmode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("mv revres tib-46 )mt(topstoh avaj", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                   11b-08.42", "mixedne nemod", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   11b-08.42" + "'", str3.equals("                   11b-08.42"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("BOjRETNIRpc.XSOCAM.TWAWL.NUS", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("IM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IM" + "'", str1.equals("IM"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                        /vr/folders/_v/6v597zmn4_v31", "x so cm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        /vr/folders/_v/6v597zmn4_v31" + "'", str2.equals("                                                                        /vr/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("http://jav", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/User //r/User //r/User //r/User //r/User //r/User //r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/User //r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " MC OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                               US                                                ", 51, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               US                                                " + "'", str3.equals("                                               US                                                "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 125, (float) 334);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "/4se");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str2.equals("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", "MIXED MOD");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode" + "'", str2.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#Environment", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("r/folders/_v/6v597zmn4_v31");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r/folders/_v/6v597zmn4_v31" + "'", str1.equals("r/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X", 35, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JavaVirtualMachineSpecification", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  " + "'", str2.equals("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HTTP://JAV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VAJ//:PTTH" + "'", str1.equals("VAJ//:PTTH"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("rentj4r", "sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) (short) 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "                                                                                                 ", "                                                                                                                    mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str3.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "######x so cm MC OS X#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", "24.80-b1124          24.80-b1124");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                            aaaaHTTP://JAV", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                               ", "xSOcM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str1.equals("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN" + "'", str1.equals("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JavatPlatformtAPItSpncificatioe");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, (int) '#', 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "MC OS X");
        java.lang.Class<?> wildcardClass13 = strArray12.getClass();
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                               US", strArray7, strArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ", strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                                                                                               US" + "'", str14.equals("                                                                                               US"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("jUTF-8", 6, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 170, 32.0f, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("######################24.80...######################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######################24.80...######################" + "'", str1.equals("######################24.80...######################"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(".14.3", "                                ", "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".14.3" + "'", str3.equals(".14.3"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                noitaroproC elcarO                           6_68x", "java hotspot(tm) 64-bit server vm", "x86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                noitaroproC elcarO                           6_68x" + "'", str3.equals("                                                noitaroproC elcarO                           6_68x"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        char[] charArray13 = new char[] { '#', '4', 'a', ' ', '4' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("mixed mo", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny("X SO cM", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "######x so cm MC OS X#######", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("e                                                  ", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  " + "'", str2.equals("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaa", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "11B-08.42");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/", "24.80...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/" + "'", str2.equals("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Mc OS X", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X OS Mc" + "'", str2.equals("X OS Mc"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("MAC MAC ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MAC MAC \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("JavatPlatformtAPItSpncificatioe");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "x86_6");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Orcle Corportion", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Orcle Corportion" + "'", str2.equals("Orcle Corportion"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 18, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "jUTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("JavaVirtualMachineSpecification", "/Users/sophie/Library/Java/Exten...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixedmode", "ne                                                                                              ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def" + "'", str1.equals("mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar" + "'", str3.equals("/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "######################24.80...######################");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sun.awt.CGraphicsEnvironment");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "          " + "'", str5.equals("          "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("OaclaCan");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica" + "'", str1.equals("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mc OS X", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b1124          24.80-b1124", 149, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124          24.80-b1124aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("24.80-b1124          24.80-b1124aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mixednenemode", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                     ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 ..." + "'", str2.equals("                                                                                                 ..."));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc" + "'", str1.equals("XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R" + "'", str2.equals("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "MIXED MOD");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441", "HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("24.80-b11                                24.80-b11                                24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                                24.80-b11                                24.80-b11" + "'", str2.equals("24.80-b11                                24.80-b11                                24.80-b11"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "...#...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Mc O X", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X" + "'", str2.equals("Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) 5, (float) 334L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 334.0f + "'", float3 == 334.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "l");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("10.14.3#############################################", "Mc OS Xa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("rentj4r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rentj4r" + "'", str1.equals("rentj4r"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("v", "                                                                                                 ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("rentj4r", "X OS Mc", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("MAC MAC ", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "M  c O   X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("mixedmod", "mixedmod", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS " + "'", str1.equals("Mac OS "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa", "\n\n\nS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MAC OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ', 50, 244);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", strArray3, strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str6.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                    mixedmode", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                    mixedmode" + "'", str3.equals("                                                                                                                    mixedmode"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("om/", "24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 50, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "HTTP://JA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("l", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "l" + "'", str2.equals("l"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 32, "mixedne                                                                                               ne                                                                                              mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 170, (long) 23, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("li", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "li" + "'", str3.equals("li"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 192, (float) (short) 100, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Librar1.7.0_80-b15", "SUN.LWAWT.MACOSX.cpRINTERj", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, (long) 97, (long) 192);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("MIXEDMODE", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMODE" + "'", str2.equals("MIXEDMODE"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_6 /User//r", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6 /User//r                                     " + "'", str2.equals("x86_6 /User//r                                     "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ar", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("ne", "jUTF-8", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "XSOcM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("11B-08.42");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 244);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7", 30, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/sers");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/sers" + "'", str1.equals("/sers"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MAC OS X", "\n", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("en", "aaaaHTTP://JAV", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("SUN.LWAWT.MACOSX.cpRINTERj", 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("x86_6", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 50, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b1124          24.80-b1124");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               en", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) '4');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "rentj4r");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("HTTP://JAV", strArray2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 13 vs 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("MAC OS X", "2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "US");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7", 3, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str2.equals("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", " c/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, (long) 159, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 159L + "'", long3 == 159L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("N", "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ne                                                                                               ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nere/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR                                                                                               " + "'", str3.equals("nere/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR                                                                                               "));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM" + "'", str3.equals("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", "/User //r/User //r/User //r/User //r/User //r/User //r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/User //r/User //r/User //r/User //r/User //r/User //r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/User //r/User //r/User //r/User //r/User //r/User //r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(98);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("OaclaCan", "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("uVlV PVif/r API JbcvfvcViv/", 334);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("uVlV PVif/r API JbcvfvcViv/                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 172);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MIXED MOD                                                                                           ", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", "c");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "24.80-b1124mixed mode24.80-b1124", (int) '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, (long) 54, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten...                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten...                                                              " + "'", str1.equals("/Users/sophie/Library/Java/Exten...                                                              "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("RENTJAR");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v" + "'", str2.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", "#SE#Runtime#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("MIXED MOD", 98, " c");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MOD c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c " + "'", str3.equals("MIXED MOD c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("mixedmode                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("hi!", "x so cm MC OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("mixedne nemode", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X", 3);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("uVlV PVif/r API JbcvfvcViv/e", "MIXED MOD", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        long[] longArray3 = new long[] { 0L, (-1), '#' };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("UTF-8                              ", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str5.equals("Java(TM)SERuntimeEnvironment"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java(TM)UTF-8                              SEUTF-8                              RuntimeUTF-8                              Environment" + "'", str6.equals("Java(TM)UTF-8                              SEUTF-8                              RuntimeUTF-8                              Environment"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/vr/folsers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac", "N", 149);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("mixed mode", "x86_6", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS" + "'", str2.equals("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 30, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar", (double) 87);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 87.0d + "'", double2 == 87.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "\n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ne                                                                                              ", (java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/", "jUTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ar", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ar" + "'", str3.equals("ar"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7.0_80", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10.14.3#############################################", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            10.14.3#############################################            " + "'", str2.equals("            10.14.3#############################################            "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten...                                                              ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ne", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80...", "\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80..." + "'", str2.equals("24.80..."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("lib/java:.", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/sers");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                \n\n\n                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            " + "'", str2.equals("                            "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (int) '#', "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED" + "'", str3.equals("/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie                                            en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mcOSX", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#######", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                noitaroproC elcarO                           6_68x", (java.lang.CharSequence) "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)SERuntimeEnvironment                       ava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        JavaJ" + "'", str2.equals("(TM)SERuntimeEnvironment                       ava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        JavaJ"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "Java(TM)#SE#Runtime#Environment", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 328 + "'", int2 == 328);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Exten...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten.." + "'", str1.equals("/Users/sophie/Library/Java/Exten.."));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                               ", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (double) 172L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 172.0d + "'", double2 == 172.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("RENTJAR", "1.7.0_80-b15", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("UTF-8", "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "li", "/4se");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaarentj4rrentj4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("#############################################3.41.01", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_6 /User//r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6 /User//r" + "'", str1.equals("x86_6 /User//r"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 172);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("\n\n\nn", strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "OaclaCan", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentxJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("MIXED MOD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MOD" + "'", str1.equals("MIXED MOD"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JavatPlatformtAPItSpncificatioe", "2#.80..", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        short[] shortArray3 = new short[] { (byte) 0, (short) 1, (byte) 100 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("SophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Oracle Corporationaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporationaaaaaaaaaaaaaa" + "'", str1.equals("Oracle Corporationaaaaaaaaaaaaaa"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                                                                                                                                                            aaaaHTTP://JAV", "Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachineSpecification" + "'", str3.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt..." + "'", str2.equals("...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt..."));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/User //r", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", (int) ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "User r" + "'", str4.equals("User r"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "10.14.3#############################################", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MC OS X");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("uVlV PVif/r API JbcvfvcViv/e", strArray3, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "uVlV PVif/r API JbcvfvcViv/e" + "'", str13.equals("uVlV PVif/r API JbcvfvcViv/e"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixedmode                       ", "..", 159);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("om /", "hi!", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ORACLUTF-8", "xSOcM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "rentjar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("VAJ//:PTTH", "                                                                                                 ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VAJ//:PTTH" + "'", str2.equals("VAJ//:PTTH"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("lib/java:.", (int) (byte) 0, "x so cm MC OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "lib/java:." + "'", str3.equals("lib/java:."));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                               US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                    mixedmode", (java.lang.CharSequence) "######################24.80...######################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("24.80-b11                                24.80-b11                                24.80-b11", " MC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                                24.80-b11                                24.80-b11" + "'", str2.equals("24.80-b11                                24.80-b11                                24.80-b11"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/", 33, 334);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                        /vr/folders/_v/6v597zmn4_v31", 97, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                        /vr/folders/_v/6v597zmn4_v31" + "'", str3.equals("                                                                        /vr/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                _64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("                                _64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n", "                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "24.80-b1124mixed mode24.80-b1124", 192);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "24.80-b11");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray7);
        java.lang.Class<?> wildcardClass10 = strArray7.getClass();
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("ORACLE CORPORATION", strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str8.equals("Java(TM)SERuntimeEnvironment"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "XSOcM", 125);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X SO cM", "                                ");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac Oa X", '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe" + "'", str9.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "n", "JavatPlatformtAPItSpncificatioe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "mixedmode                       ", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "mcOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("e24.80-b1124");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e24.80-b1124" + "'", str1.equals("e24.80-b1124"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", "x86_6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) 159, (float) 54);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaOaclaCan");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment", 159, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...MIXED MODEnvironment" + "'", str3.equals("...MIXED MODEnvironment"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj" + "'", str1.equals("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X SO CAM", "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("11B-08.42", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-8                              ", 21, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("entjar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "entjar" + "'", str1.equals("entjar"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("e24.80-b1124", (int) '4', 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eDOM DEXIM" + "'", str1.equals("eDOM DEXIM"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "XSOc");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("VAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTH");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("MAC MAC ", "x so CmJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIF");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr" + "'", str1.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("nere/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR                                                                                               ", "XSOcM", 14);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("amixed mode2a.80-b112a", 73, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", "  ", "amixed mode2a.80-b112a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x" + "'", str3.equals("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "re/u..." + "'", str2.equals("re/u..."));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("re/u...", "aaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS " + "'", str1.equals("MAC OS "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x so Cm", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mo", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "x so Cm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str1.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "xSOcM");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Mc OS X");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("X OS Mc", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X OS Mc" + "'", str3.equals("X OS Mc"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("            10.14.3#############################################            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        double[] doubleArray1 = new double[] { (-1) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/4se");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4se" + "'", str1.equals("/4se"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                                                                                                                                                     ", "24.80...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################24.80...######################", 'a');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "BOjRETNIRpc.XSOCAM.TWAWL.NUS", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x so Cm", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        java.lang.Class<?> wildcardClass12 = charArray10.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("jUTF-8", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" ", 159);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("jUTF-8", "mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar", "2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar" + "'", str2.equals("/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#SE#Runtime#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaa", 149);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 149 + "'", int2 == 149);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("l", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "XSOc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100L, (double) 76, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("l");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"l\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

