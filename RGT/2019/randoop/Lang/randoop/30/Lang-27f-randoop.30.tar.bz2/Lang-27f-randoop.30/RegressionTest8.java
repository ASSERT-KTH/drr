import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("X SO cM", "Java Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API SpJava Platform API Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                noitaroproC elcarO                           6_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6                           Oracle Corporation                                                " + "'", str1.equals("x86_6                           Oracle Corporation                                                "));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("l", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "l                                 " + "'", str2.equals("l                                 "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("          ", "/Users/sophie/Librar1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                 ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Oracle Cor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "amixed mode2a.80-b112a", 149);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 0, 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str4.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj" + "'", str1.equals("oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 96, (double) 'a', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "x so cm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       1.7.0_80-b15", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                               ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                       1.7.0_80-b15" + "'", str4.equals("                       1.7.0_80-b15"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "..", (java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 170L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 170.0d + "'", double2 == 170.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaN" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaN"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4mixed mode24.80-b1124", "XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                          "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("VAJ//:PTTH", "24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7.0_80", 3);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".14.3" + "'", str4.equals(".14.3"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        char[] charArray11 = new char[] { '#', '4', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray11);
        java.lang.Class<?> wildcardClass15 = charArray11.getClass();
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", charArray11);
        java.lang.Class<?> wildcardClass17 = charArray11.getClass();
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ORACLE CORPORATION", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERj", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                       1.7.0_80-b15", "x so cm MC OS X", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "\nXSOcM", "x86_6 /User//r                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUAL ACHINE6/JDK1.7.0_80.JDK/C_NTENT6/H_ E/JRE/LIB/END_R6ED" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUAL ACHINE6/JDK1.7.0_80.JDK/C_NTENT6/H_ E/JRE/LIB/END_R6ED"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ne", "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("mac mac ", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "mac mac mac mac " + "'", str5.equals("mac mac mac mac "));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X", "mcOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JavaPlatformAPISpecification", "2#.80..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("...#...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...#..." + "'", str1.equals("...#..."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3#############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java Virtual Machine Specificatio", "x so cm");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("S", "x86_6 /User//r                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixedne                                                                                               ne                                                                                              mode", "######################24.80...######################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/LIBRRY/JV/JVVIRTULMCHINES/JDK1....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....1KDJ/SENIHCMLUTRIVVJ/VJ/YRRBIL/" + "'", str1.equals("....1KDJ/SENIHCMLUTRIVVJ/VJ/YRRBIL/"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 28, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(125.0f, (float) 'a', 8.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 125.0f + "'", float3 == 125.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        char[] charArray9 = new char[] { '#', '4', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        java.lang.Class<?> wildcardClass11 = charArray9.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("24.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...44444444444444444444444444424.80...444444444444444444444444444", "x86_6                           Oracle Corporation                                                ", 52);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie                                            en", "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                               US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("jAVA hOTsPOT(tm) 64-bIT sERVER vm", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mc OS X", "##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 51, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("lib/java:.", "Mc OS Xa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                                                                                                                                                                             ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMamc os x" + "'", str1.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMamc os x"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                            ", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                            " + "'", str2.equals("                                                                            "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Oracle Corporation");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.Class<?> wildcardClass8 = strArray6.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification", "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ", "\nXSOcM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", "", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM" + "'", str3.equals("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("mixedmod", "SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod" + "'", str2.equals("mixedmod"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MC OS X");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("mixed mode");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "Oracle Corporation");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specificatio", strArray3, strArray9);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 2, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Java Virtual Machine Specificatio" + "'", str12.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "mixedmode                       ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ":" + "'", str7.equals(":"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str9.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("e                                                   ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        short[] shortArray5 = new short[] { (byte) 100, (byte) -1, (short) 1, (byte) 10, (byte) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X", "m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X" + "'", str2.equals("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMC OS X"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("44444444444444444444444444444444444444444444444...#...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444...#..." + "'", str2.equals("44444444444444444444444444444444444444444444444...#..."));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment                        ", (java.lang.CharSequence) "ne                                                                                               ne");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/User //r", "UTF-8                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/User //r" + "'", str2.equals("/User //r"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_6                                                                                               ", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str7.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("\n\n\nS", "/4se");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\nS" + "'", str2.equals("\n\n\nS"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                       ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("OaclaCan");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6                           Oracle Corporation                                                ", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MAC OS X", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "EN", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mc O X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                                                                            ", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("e", 149);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMamc os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMamcosx" + "'", str1.equals("MacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSXMamcosx"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("...#...", (int) (short) -1, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...#..." + "'", str3.equals("...#..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("MIXED MOD c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c ", "Oracle CorporationaaaaaaaaaaaaaaOracMc OS XaMc OS XaMc OS sophieOracle CorporationaaaaaaaaaaaaaaOrac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED MOD c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c " + "'", str2.equals("MIXED MOD c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c c "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Ne                                                                                               ", "Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment", "aaaaaaaarentj4rrentj4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Nt                                                                                               " + "'", str3.equals("Nt                                                                                               "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        char[] charArray7 = new char[] { ' ', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                     edom dexim                     ", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specificatio", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "im", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21 + "'", int9 == 21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("x so cm MC OS X", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x so cm MC OS X" + "'", str2.equals("x so cm MC OS X"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                               US", 28, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                               US" + "'", str3.equals("                                                                                               US"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("MIXED MOD                                                                                           ", "ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "mixedne nemode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                noitaroproC elcarO                           6_68x", "/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("x so cm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x so cm" + "'", str1.equals("x so cm"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mac mac ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac mac" + "'", str1.equals("mac mac"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Exten..", 244, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                  /Users/sophie/Library/Java/Exten.." + "'", str3.equals("                                                                                                                                                                                                                  /Users/sophie/Library/Java/Exten.."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Mac OS ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MAC MAC ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac mac " + "'", str1.equals("mac mac "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("x so CmJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIFICATIOJAVA vIRTUAL mACHINE sPECIF", "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        double[] doubleArray3 = new double[] { 0, (-1L), (-1.0f) };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj" + "'", str3.equals("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        float[] floatArray1 = new float[] { 'a' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80...", "Java HotSpot(TM) 64-Bit Server VM");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("(TM)SERuntimeEnvironment                       ava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        JavaJ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("MAC MAC ", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "X SO cM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x SO cM" + "'", str1.equals("x SO cM"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporationaaaaaaaaaaaaaa", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("x86_6                           Oracle Corporation                                                ", "Java(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#EnvironmentJava(TM)#SE#Runtime#Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        float[] floatArray1 = new float[] { 'a' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("\n", "                                                \n\n\n                                                 ", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("mixedmode                       MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA", "sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, 192, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 33, (long) 197, (long) 76);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 197L + "'", long3 == 197L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ent.jar", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "uVlV PVif/r API JbcvfvcViv/", 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("jAVAhOTsPOT(tm)64-bITsERVERvm", "                       ", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                       " + "'", str4.equals("                       "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass10 = byteArray6.getClass();
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                noitaroproC elcarO                           6_68x", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitaroproCaelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaa6_68x" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitaroproCaelcarOaaaaaaaaaaaaaaaaaaaaaaaaaaa6_68x"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("MAC MAC ", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "BOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUSBOjRETNIRpc.XSOCAM.TWAWL.NUS", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 12, (float) 172L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 172.0f + "'", float3 == 172.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) 47, (float) 159L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X" + "'", str1.equals("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("    ...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixedmode                       ", 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444mixedmode                       4444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444mixedmode                       4444444444444444444444444444444444"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("amixed mode2a.80-b112a", "                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaN", "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        char[] charArray13 = new char[] { '#', '4', 'a', ' ', '4' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "li", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "User r", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mac mac", 98, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac mac                                                                                           " + "'", str3.equals("mac mac                                                                                           "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ne", "4mixed mode24.80-b112");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ne" + "'", str2.equals("ne"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Environmentaaaaaaaaaaaa" + "'", str2.equals("Environmentaaaaaaaaaaaa"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ne", "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("Mc OS XaMc OS XaMc OS sophie", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("2#.80..");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#.80.." + "'", str2.equals("2#.80.."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Dmf4m665623342gDmf4fmwgg-" + "'", str4.equals("Dmf4m665623342gDmf4fmwgg-"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "rentjar", (java.lang.CharSequence) "                                       /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                     Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", (-1), "/mo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj" + "'", str3.equals("oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", "m");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF", "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, (long) 98, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("l", "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "l" + "'", str3.equals("l"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "11b-08.42", "ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X", "Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X" + "'", str2.equals("McJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       OSJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       X"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                            aaaaHTTP://JAV", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                            aaaaHTTP://JAV" + "'", str2.equals("                                                                                                                                                            aaaaHTTP://JAV"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R", "/Users/sophie/Librar1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("51.0", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("om/");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "om/" + "'", str2.equals("om/"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "omJava(TM) SE Runtime Environment/" + "'", str4.equals("omJava(TM) SE Runtime Environment/"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/", 328, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("re/u...", "/Users/sophie/Documents/defects j/tmp/run randoop.pl 11    15 02303 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "re/u..." + "'", str2.equals("re/u..."));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "24.80...444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 197L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("v", 149, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("omJava(TM) SE Runtime Environment/", (int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mJava(TM) SE" + "'", str3.equals("mJava(TM) SE"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("McOSX", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Mc OS XaMc OS XaMc OS sophie", "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS XaMc OS XaMc OS sophie" + "'", str3.equals("Mc OS XaMc OS XaMc OS sophie"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment" + "'", str1.equals("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\nXSOcM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                ", "X OS Mc");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("MIXEDMODE", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMODE " + "'", str2.equals("MIXEDMODE "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("MAC OS ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS " + "'", str2.equals("MAC OS "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                   11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", "                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa", "aaaaHTTP://JAV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mac mac mac mac ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC MAC MAC MAC " + "'", str1.equals("MAC MAC MAC MAC "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("######x so cm MC OS X#######", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######x so cm MC OS X#######" + "'", str2.equals("######x so cm MC OS X#######"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt...", "X SO cM", "e                                                   ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", strArray3, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str6.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mc4OS4X" + "'", str8.equals("Mc4OS4X"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x so cm MC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x so cm MC OS X" + "'", str1.equals("x so cm MC OS X"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("Mac OS X", (java.lang.Object[]) strArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA" + "'", str2.equals("/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " c", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        int[] intArray6 = new int[] { (short) 100, 30, (short) 10, 170, 4, '4' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 170 + "'", int8 == 170);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 170 + "'", int9 == 170);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JavaPlatformAPISpecification", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("im", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "im###############################################################################################" + "'", str3.equals("im###############################################################################################"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                            aaaaHTTP://JAV", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                            aaaaHTTP://JAV" + "'", str2.equals("                                                                                                                                                            aaaaHTTP://JAV"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) 100, (long) 197);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 197L + "'", long3 == 197L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("VAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTH", "24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        float[] floatArray5 = new float[] { 334, 1, 97L, 149, 125.0f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X", 3);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        long[] longArray3 = new long[] { 7, (byte) 10, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.Class<?> wildcardClass7 = longArray3.getClass();
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("McOSX", "/uSER //R/uSER //RMac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McOSX" + "'", str2.equals("McOSX"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("24.80-b1124          24.80-b1124aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X", 21, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X" + "'", str3.equals("M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("lib/java:.", strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + "'", str2.equals("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "uVlV PVif/r API JbcvfvcViv/e", (java.lang.CharSequence) "x so Cm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32L, (double) 1, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                 ...", "/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R/uSER //R");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Oracle Corporationaaaaaaaaaaaaaa", "4mixed mode24.80-b112", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 64-Bit Server VM", 197, 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Dmf4m665623342gDmf4fmwgg-", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Dmf4m665623342gDmf4fmwgg-" + "'", str3.equals("Dmf4m665623342gDmf4fmwgg-"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 197, 32.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("EDOM DEXIM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                                                                                           sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("SUN.LWAWT.MACOSX.cpRINTERjO", 35, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X", "11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                       ", "11B-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification", 244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244 + "'", int2 == 244);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Mc O X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mc O X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str3.equals("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("McOSX", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McOSX" + "'", str2.equals("McOSX"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("                     edom dexim                     ", "mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "x86_64");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str5.equals("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str6.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mv revres tib-46 )mt(topstoh avaj", "/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://jav", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac Oa X/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF" + "'", str1.equals("MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        int[] intArray5 = new int[] { '#', (byte) -1, (byte) 1, 1, (short) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("JavaPlatformAPISpecification", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA" + "'", str2.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAMAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("mixedne                                                                                               ne                                                                                              mode", "mixedjv hotspot(tm) 64-bit server vm jv hotspot(tm) 64-bit server vmmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc", (java.lang.CharSequence) "            10.14.3#############################################            ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc" + "'", charSequence2.equals("XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http:ecom/", "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:ecom/" + "'", str2.equals("http:ecom/"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Exten...", (int) 'a', 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..." + "'", str2.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..."));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "x86_6");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4', 149, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.14.3" + "'", str10.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str11.equals("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "uVlV PVifar API JbcvfvcViva", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  e                                                  ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray2, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n" + "'", str8.equals("\n"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    ...             /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("N");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 197, "e                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e                                                   e                                               ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("e                                                   e                                               ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("X SO cM", " c");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO cM" + "'", str2.equals("X SO cM"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe", "/4se", 159, 170);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt/4sevaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe" + "'", str4.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt/4sevaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Exten..." + "'", str2.equals("/Users/sophie/Library/Java/Exten..."));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", "mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode" + "'", str2.equals("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str2.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                               US", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               US" + "'", str2.equals("                                                                                               US"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("eDOM DEXIM", 47, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eDOM DEXIM" + "'", str3.equals("eDOM DEXIM"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM)SERuntimeEnvironment                        ", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", 51);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", "java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/User//r", "mac mac mac mac ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HTTP://JAre/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("IM", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        long[] longArray3 = new long[] { 0L, (-1), '#' };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        int[] intArray6 = new int[] { (short) 100, 30, (short) 10, 170, 4, '4' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 170 + "'", int8 == 170);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("##############################################1.7.0_80##############################################", "Oracle Cor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################1.7.0_80##############################################" + "'", str2.equals("##############################################1.7.0_80##############################################"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_6                           Oracle Corporation                                                ", "Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6                           Oracle Corporation                                                " + "'", str2.equals("x86_6                           Oracle Corporation                                                "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", "51.0", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sophi");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTF-8" + "'", str5.equals("UTF-8"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4:4", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4:4" + "'", str2.equals("4:4"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        char[] charArray7 = new char[] { ' ', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                     edom dexim                     ", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21 + "'", int9 == 21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("M  c O   X", "Mc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS Xa", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("XSOcM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "l");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 197L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("BOjRETNIRpc.XSOCAM.TWAWL.NUS", 32, "uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BOjRETNIRpc.XSOCAM.TWAWL.NUSuVlV" + "'", str3.equals("BOjRETNIRpc.XSOCAM.TWAWL.NUSuVlV"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/sers");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/ser" + "'", str1.equals("/ser"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("re/u...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "re/u..." + "'", str1.equals("re/u..."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x" + "'", str2.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mac mac mac mac ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT", "2#.80...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("re/u...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"re/u...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/vr/folders/_v/6v597zmn4_v31", "li");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("JavaVirtualMachineSpecification", "                                                                                                 ", 98);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def", "Mac OS ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lib/java:." + "'", str2.equals("lib/java:."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/", "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("edom dexim", 172);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom dexim                                                                                                                                                                  " + "'", str2.equals("edom dexim                                                                                                                                                                  "));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Exten...", "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", 172);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWAWT.MACOSX.cpRINTERjOB", 149, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("BOjRETNIRpc.XSOCAM.TWAWL.NUS");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("2#.80..", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BO2#.80..j2#.80..RETNIR2#.80..pc2#.80...2#.80..XSOCAM2#.80...2#.80..TWAWL2#.80...2#.80..NUS" + "'", str3.equals("BO2#.80..j2#.80..RETNIR2#.80..pc2#.80...2#.80..XSOCAM2#.80...2#.80..TWAWL2#.80...2#.80..NUS"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("ne                                                                                              ", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def", "4:4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("e                                                  ", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e                                                  " + "'", str2.equals("e                                                  "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mod", 7, (int) (byte) 1);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("JavaVirtualMachineSpecification", strArray3);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "                                                                                                                                                     ");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str6.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4:4", "/User //r/User //r/User //r/User //r/User //r/User //r");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl...", "uVlV PVif/r API JbcvfvcViv/e", "x86_6                                                                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "soph   mDo xm nts d    ts4j tmp  xn_ andoop.p6_11686_1560230342 ta g t  6..." + "'", str3.equals("soph   mDo xm nts d    ts4j tmp  xn_ andoop.p6_11686_1560230342 ta g t  6..."));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment", 1, 54);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment" + "'", str4.equals("/Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_6                           Oracle Corporation                                                ", "vaj//:ptth", 2);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("MIXED MOD", strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification11B-08.42Java Virtual Machine Specification"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten...                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", "", " c/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR" + "'", str4.equals("re/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr", "(TM)SERuntimeEnvironment                       ava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        JavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("######x so cm MC OS X#######", "e                                                   e                                               ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e                                                   e                                               ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("e                                                   e                                               ne44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixedne nemode                                      ", 33, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixedne nemode                                      " + "'", str3.equals("mixedne nemode                                      "));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrEN", 170, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "rentjar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Librx86_64ry/Jx86_64vx86_64/Jx86_64vx86_64Virtux86_64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("soph   mDo xm nts d    ts4j tmp  xn_ andoop.p6_11686_1560230342 ta g t  6...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "e                                                   ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        double[] doubleArray3 = new double[] { 0, (-1L), (-1.0f) };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.Class<?> wildcardClass8 = doubleArray3.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "uVlV PVif/r API JbcvfvcViv/e", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode", "/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "x so cm MC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JavaVirtualMachineSpecification", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                \n\n\n                                                 ", "XSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOcXSOc");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_6                                                                                               ", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("######################24.80...######################", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 29, (long) 5, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mv revres tib-46 )mt(topstoh avaj", 0, "                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mv revres tib-46 )mt(topstoh avaj" + "'", str3.equals("mv revres tib-46 )mt(topstoh avaj"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("2#.80..", "                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#.80.." + "'", str2.equals("2#.80.."));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  a.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "xSOcM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(" c/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixedne nemode", "uVlV PVif/r API JbcvfvcViv/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaHTTP://JAV", 172, "VAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaHTTP://JAVVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PT" + "'", str3.equals("aaaaHTTP://JAVVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PT"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mo", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str2.equals("Java(HTTP://JAre/uSERS/SOPHIE/dOhie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/vr/folders/_v/6v597zmn4_v31");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/vr/folders/_v/6v597zmn4_v31" + "'", str1.equals("/vr/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/vr/folsers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt...", "", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                    2#.80...", "IM", "ne");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                    2#.80..." + "'", str3.equals("                                                                    2#.80..."));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c ", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt/4sevaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c " + "'", str2.equals(" c c c c c c c c c c c c c c c c c c c c c c c com/ c c c c c c c c c c c c c c c c c c c c c c c c "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("amixed mode2a.80-b112a", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        int[] intArray3 = new int[] { 10, 32, ' ' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ne", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "mixedne nemode", 5);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("edom dexim", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 23, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str3.equals("sOPHIEIMdOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_11686_1560230342/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "NE                                                                                              ", "Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentxJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mod", "/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "mixedmode                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (-1), "                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("MIXEDMODE", "##############################################1.7.0_80##############################################", 334);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("/Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/4SERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 246 + "'", int2 == 246);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Ne                                                                                               ", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ne                                                                                               " + "'", str2.equals("Ne                                                                                               "));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("M                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/c O                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ X", "/uSER //R/uSER //RMac OS ", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ZMN4_V31CQ2N2X1N4FC0000GN/t/", "4mixed mode24.80-b112");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java(TM)SERuntimeEnvironment", 244);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ne");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "24.80-b11", 0, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixedne nemode" + "'", str4.equals("mixedne nemode"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "mixed mode" + "'", str13.equals("mixed mode"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mAC oA x/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/def");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 170, 97);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "    ..");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "McOSX" + "'", str4.equals("McOSX"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "McOSX" + "'", str9.equals("McOSX"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(149, 35, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2#.80..", "                                                                                                 ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("    ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Java(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentxJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironmentJava(TM)SERuntimeEnvironment", "            10.14.3#############################################            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("mac mac mac mac ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "chines/jdk1.7.0_80.jdk/Contents/Home/jre/alMaVirtuava/Javary/Ja                                /Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Mc OS X", "xsoc", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4444444444444444444444444444444444mixedmode                       4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 32, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("omJava(TM) SE Runtime Environment/", "mixed m");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("x so Cm", "x SO cM", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 54, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 54.0d + "'", double3 == 54.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("x so cm", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cm" + "'", str2.equals("x so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cmx so cm"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.14.3#############################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Mc OS X");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 170, 97);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "McOSX" + "'", str8.equals("McOSX"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "1.7", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("aaaaaaa", "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mixed mo", "#SE#Runtime#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mo" + "'", str2.equals("mixed mo"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 7, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", (int) (short) 0, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/JaSUN.LWAWT." + "'", str3.equals("/Users/sophie/Library/JaSUN.LWAWT."));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "4444444444444444444444444444444444444444444444444:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("RENTJAR", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne                                                                                               " + "'", str1.equals("ne                                                                                               "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", "4444444444444444444444444444444444mixedmode                       4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("\n\n\nS", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', 3.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl...", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl..." + "'", str2.equals("mDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/cl..."));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("aaaaaaa", "######x so cm MC OS X#######", 328);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "24.80-b1124          24.80-b1124");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                       ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                          ", 50, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                \n\n\n                                                 ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 159);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF" + "'", str1.equals("MAC OA X/USERS/SOPHIE/DOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEF"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/User //r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/User //r" + "'", str1.equals("/User //r"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "\nXSOcM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        int[] intArray5 = new int[] { '#', (byte) -1, (byte) 1, 1, (short) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                     edom dexim                     ", 100);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ", 334);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 334 + "'", int2 == 334);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("mixedmode", "vaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H.14.3/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str2.equals("/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixedmode", "", 142);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("...MIXED MODEnvironment", " MC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                        sun.lwawt.macosx.cprinterjob", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str2.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Mc4OS4X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        char[] charArray9 = new char[] { ' ', 'a', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Java Virtual Machine SpecificatioJava Virtual Machine SpecificatioJava Virtual Machine Specifica  ", "http://jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("JavaHotSpot(TM)64-BitServerVM", "...                      24.80-b11", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SophieimDocuments/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/ser");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#SE#Runtime#", "24.80-b11                                24.80-b11                                24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ne                                                                                               ne                                                                       ", (java.lang.CharSequence) "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ne                                                                                               ne                                                                       " + "'", charSequence2.equals("ne                                                                                               ne                                                                       "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Environmentaaaaaaaaaaaa", 10, "44444444444444444444444444444444444444444444444...#...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Environmentaaaaaaaaaaaa" + "'", str3.equals("Environmentaaaaaaaaaaaa"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("mixedmode", "##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########", 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "l");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                       ", "BOjRETNIRpc.XSOCAM.TWAWL.NUSuVlV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("jAVAhOTsPOT(tm)64-bITsERVERvm", "            10.14.3#############################################            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("X SO c", "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                        /vr/folders/_v/6v597zmn4_v31", "10.14.3", "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                        /vr/folders/_v/6v597zmn4_v31" + "'", str4.equals("                                                                        /vr/folders/_v/6v597zmn4_v31"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Mc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O XMc O X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ent.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ent.jar" + "'", str1.equals("ent.jar"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########", 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/4se", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4se" + "'", str2.equals("/4se"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("X SO cM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("l                                 ", 97, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "l                                 ###############################################################" + "'", str3.equals("l                                 ###############################################################"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        float[] floatArray2 = new float[] { 8, 32 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 8.0f + "'", float4 == 8.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 8.0f + "'", float6 == 8.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 32.0f + "'", float7 == 32.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str1.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("e");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 47);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaHTTP://JAVVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaHTTP://JAVVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PT" + "'", str1.equals("aaaaHTTP://JAVVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PTTHVAJ//:PT"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("MIXEDMODE ", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMODE " + "'", str2.equals("MIXEDMODE "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("xsoc", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xsoc" + "'", str2.equals("xsoc"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 98, (double) 125, (double) 149);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 149.0d + "'", double3 == 149.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-b1124mixed mode24.80-b1124", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124mixed mode24.80-b1124" + "'", str2.equals("24.80-b1124mixed mode24.80-b1124"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                   11b-08.42");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"M c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS XM c OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("EN", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(" MC OS X", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie/library/jasun.lwawt.macosx.cprinterjob", "\n", "/Users/sophie/Library/JaSUN.LWAWT.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/library/jasun.lwawt.macosx.cprinterjob" + "'", str3.equals("/users/sophie/library/jasun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaarentj4rrentj4", 3, 328);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaarentj4rrentj4" + "'", str3.equals("aaaaaaaarentj4rrentj4"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mc4OS4X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "                                ");
        java.lang.String[] strArray10 = new java.lang.String[] { "Oracle Corporation", "", "1.7.0_80", "1.7.0_80", "10.14.3" };
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "10.14.3#############################################");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM)SERuntimeEnvironment", strArray10, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray10);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str14.equals("Java(TM)SERuntimeEnvironment"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specification", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4mixed mode24.80-b112", "x86_6                                                                                               ", "                                _64lMx86_64chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4mixed mode24.80-b112" + "'", str3.equals("4mixed mode24.80-b112"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("RENTJAR", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt/4sevaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                                                                                                     ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                     " + "'", str2.equals("                                                                                                                                                     "));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "mixednenemode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "2Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("l                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/uSER //R/uSER //RMac OS ", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_6 /User//r                                     ", "##########/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6 /User//r                                     " + "'", str2.equals("x86_6 /User//r                                     "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ne", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342                ", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixedne nemode                                      ", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "X SO CAM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str1.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", "http:ecom/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("xsoc", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/User //r/User //r/User //r/User //r/User //r/User //r", "e24.80-b1124", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               en", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }
}

