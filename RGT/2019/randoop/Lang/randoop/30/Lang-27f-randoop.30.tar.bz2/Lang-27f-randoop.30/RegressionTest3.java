import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mixedne                                                                                               ne                                                                                              mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("om/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "om/" + "'", str2.equals("om/"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 14, (double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                               US", "", "lib/java:.", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                               US" + "'", str4.equals("                                                                                               US"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                               ", "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ne");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("######################24.80...######################", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HTTP://JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JA" + "'", str1.equals("HTTP://JA"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mixed mo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mo\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("java hotspot(tm) 64-bit server vm", "Mac Oa X", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("im", "EN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                ", 100, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/" + "'", str3.equals("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, (double) 'a', (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("edom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom dexim" + "'", str1.equals("edom dexim"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("entjar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "entjar" + "'", str2.equals("entjar"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporationaaaaaaaaaaaaaa", 1, "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationaaaaaaaaaaaaaa" + "'", str3.equals("Oracle Corporationaaaaaaaaaaaaaa"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, (double) (short) 10, (double) 170);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80...", "24.80-b1124          24.80-b1124");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80..." + "'", str2.equals("24.80..."));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("HTTP://JAV");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 6, (float) (-1), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/User //r", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/User //r/User //r/User //r/User //r/User //r/User //r" + "'", str2.equals("/User //r/User //r/User //r/User //r/User //r/User //r"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 100L, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str1.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Mc O X", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O X" + "'", str2.equals("Mc O X"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "HTTP://JAV");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 7, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac..." + "'", str3.equals("...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac..."));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 125, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b1124          24.80-b1124", "li");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "X SO cM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO cM" + "'", str2.equals("X SO cM"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.3", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("lib/java:.", "                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/User //r/User //r/User //r/User //r/User //r/User //r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/User //r/User //r/User //r/User //r/User //r/User //r" + "'", str1.equals("/User //r/User //r/User //r/User //r/User //r/User //r"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "24.80-b11                                24.80-b11                                24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("Java(TM) SE Runtime Environment", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("McOSX", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McOSX" + "'", str2.equals("McOSX"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("edom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EDOM DEXIM" + "'", str1.equals("EDOM DEXIM"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("en", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("MIXEDMODE", "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine Specification", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str2.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Platform API Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 0, (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                               US                                                ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ..." + "'", str2.equals("    ..."));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "rentj4r");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(21, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("http://java.oracle.com/", "sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporationaaaaaaaaaaaaaa", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OaclaCan" + "'", str4.equals("OaclaCan"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", "Java Platform API Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Exten..." + "'", str2.equals("/Users/sophie/Library/Java/Exten..."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("HTTP://JA", (int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("11b-08.42", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11b-08.42" + "'", str2.equals("11b-08.42"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                               en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_6                           Oracle Corporation                                                ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str2.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 98 + "'", int1 == 98);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 8, "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC MAC " + "'", str3.equals("MAC MAC "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 10L, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4mixed mode24.80-b1124", (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM)SERuntimeEnvironment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str2.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM)#SE#Runtime#Environment", (java.lang.CharSequence) "x so cm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "2#.80...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http:ecom/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "om/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("uVlV PVif/r API JbcvfvcViv/", "\n\n\n", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                               US                                                ", "                                                /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif", "x86_6                                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       " + "'", str3.equals("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("rentjar", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rentjar" + "'", str2.equals("rentjar"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "rentjar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "uVlV PVif/r API JbcvfvcViv/e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("entjar", 125, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 14, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               eN" + "'", str1.equals("                                                                                               eN"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HTTP://JAV", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MIXED MOD                                                                                           ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) (short) 1, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("li", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "MIXED MOD                                                                                           ", "\n\n\n");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        char[] charArray10 = new char[] { '#', '4', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "amixed mode2a.80-b112a", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/" + "'", str1.equals("RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "######################24.80...######################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       " + "'", str1.equals("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) 97L, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mixed mo", 28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("im", "24.80-b1124mixed mode24.80-b1124", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java Virtual Machine Specificatio", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Virtual Machine Specificatio" + "'", str2.equals("java Virtual Machine Specificatio"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED" + "'", str2.equals("/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 4, "                     edom dexim                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("US");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "", "McOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/User//r");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "SUN.LWAWT.MACOSX.cpRINTERjOB", "", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str4.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("UTF-8                              ", "SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", (int) (short) 10, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str4.equals("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3#############################################", "x86_6                                                                                               ", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("vaj//:ptth", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaj//:ptth" + "'", str2.equals("vaj//:ptth"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("OaclaCan", "\n\n\nS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OaclaCan" + "'", str2.equals("OaclaCan"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 97L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str3.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "\n\n\nS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n\n\nS" + "'", str1.equals("\n\n\nS"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "XSOcM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xSOcM" + "'", str1.equals("xSOcM"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64" + "'", str2.equals("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.7f, (float) 125, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 125.0f + "'", float3 == 125.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("24.80-b11                                24.80-b11                                24.80-b11", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixed mode", ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String[] strArray6 = new java.lang.String[] { "Oracle Corporation", "", "1.7.0_80", "1.7.0_80", "10.14.3" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "10.14.3#############################################");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM)SERuntimeEnvironment", strArray6, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "http:ecom/", (int) (byte) 100, 2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str10.equals("Java(TM)SERuntimeEnvironment"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("11b-08.42");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, 0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                               en", "x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               en" + "'", str2.equals("                                                                                               en"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("v", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "v" + "'", str2.equals("v"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 0, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                                               US", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 35, "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       1.7.0_80-b15" + "'", str3.equals("                       1.7.0_80-b15"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                               eN", "Java Platform API Sp", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "x86_6                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6                                                                                               " + "'", str1.equals("x86_6                                                                                               "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("\n", "ne                                                                                               ne                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("UTF-8                              ", "Ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BOjRETNIRpc.XSOCAM.TWAWL.NUS" + "'", str1.equals("BOjRETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", 100, "entjar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj" + "'", str3.equals("Oracle Corporationentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentjarentj"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java(TM)SERuntimeEnvironment", "Java Virtual Machine Specification", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str3.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/", "24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("ne                                                                                              ", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                       1.7.0_80-b15", "mixed mode", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       1.7.0_80-b15" + "'", str3.equals("                       1.7.0_80-b15"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("EDOM DEXIM", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EDOM DEXIM" + "'", str2.equals("EDOM DEXIM"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://jav", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MC OS X");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", "1.7");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("uVlV PVif/r API JbcvfvcViv/e", strArray3, strArray11);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', 2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "uVlV PVif/r API JbcvfvcViv/e" + "'", str13.equals("uVlV PVif/r API JbcvfvcViv/e"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("X SO CAM", "Java Platform API Sp", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 98);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "", (int) ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "MIXED MOD");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment" + "'", str5.equals("Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4mixed mode24.80-b112" + "'", str1.equals("4mixed mode24.80-b112"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("24.80-b11                                24.80-b11                                24.80-b11", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("EDOM DEXIM", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "/User //r/User //r/User //r/User //r/User //r/User //r", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.cpRINTERjOB", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MIXEDMODE", "24.80-b11                                24.80-b11                                24.80-b11", "hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/4se", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe" + "'", str4.equals("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4mixed mode24.80-b112", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "/Users/sophie/Library/Java/Exten...", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("lib/java:.", "                               ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "lib/java:." + "'", str4.equals("lib/java:."));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Mac OS X", "24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    ...", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".." + "'", str2.equals(".."));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("######################24.80...######################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"######################24.80...######################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("rentjar", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mc O X/VAR/FOLDERS/_V/6V597ZMN4_", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_" + "'", str2.equals("Mc O X/VAR/FOLDERS/_V/6V597ZMN4_"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java(TM)SERuntimeEnvironment", "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                       1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                       1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11                                24.80-b11                                24.80-b11", "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                                24.80-b11                                24.80-b11" + "'", str2.equals("24.80-b11                                24.80-b11                                24.80-b11"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                               ", "1.7.0_80", "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               " + "'", str3.equals("                               "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa" + "'", str3.equals("aaaaaaa"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("im", "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "im" + "'", str2.equals("im"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defectsj/tmp/run_randooppl_686_5622/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-currentjar", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("SUN.LWAWT.MACOSX.cpRINTERj", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ne                                                                                               ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", 32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("MAC MAC ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac mac " + "'", str1.equals("mac mac "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("11B-08.42", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".14.3", "4mixed mode24.80-b112", "om/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("en");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("BOjRETNIRpc.XSOCAM.TWAWL.NUS", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS" + "'", str2.equals("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("entjar", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "entjar" + "'", str2.equals("entjar"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                               en", "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80-b15", "11b-08.42", "x86_6                           Oracle Corporation                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\n\n\n", "", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("51.0", 0, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "SUN.LWAWT.MACOSX.cpRINTERj", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Librar1.7.0_80-b15", "X SO CAM");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) 98, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                                                               US", "X SO CAM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/4se", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str4.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MAC MAC ", "RAJVAJ//:PTTHTNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/2VAJ//:PTTH2VAJ//:PTTH65VAJ//:PTTH_686VAJ//:PTTH_LPVAJ//:PTTHPOODNAR_NUR/PMT/JVAJ//:PTTHSTCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Sp", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Sp" + "'", str3.equals("Java Platform API Sp"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mac mac ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC MAC " + "'", str1.equals("MAC MAC "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                               US                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MIXED MOD                                                                                           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Corporationaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "11B-08.42", 14, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 100, (float) 52L, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str3.equals("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("MIXED MOD                                                                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "11b-08.42", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", 28, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document" + "'", str3.equals("Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("MC OS X", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("ne                                                                                              ", "mixed mode", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("######################24.80...######################", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################24.80...######################" + "'", str3.equals("######################24.80...######################"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Mc O X/VAR/FOLDERS/_V/6V597ZMN4_", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_" + "'", str2.equals("Mc O X/VAR/FOLDERS/_V/6V597ZMN4_"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/" + "'", str2.equals("                                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("n", "en", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar" + "'", str2.equals("/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HTTP://JAV", "/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" MC OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("\n\n\n", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "\n\n\nS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "/Users/sophie/Library/JaSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ", "mixed m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        " + "'", str2.equals("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.concat(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ".14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Platform API Specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mac mac ", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac mac " + "'", str2.equals("mac mac "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT" + "'", str1.equals("JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "######################24.80...######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " MC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("x86_6", "HTTP://JAV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        char[] charArray8 = new char[] { '#', '4', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        java.lang.Class<?> wildcardClass10 = charArray8.getClass();
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("MIXED MOD", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "hi!un_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("amixed mode2a.80-b112a", "MC OS X", "/User //r");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ne                                                                                              " + "'", str1.equals("Ne                                                                                              "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("EN", "amixed mode2a.80-b112a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("X SO CAM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO CAM" + "'", str2.equals("X SO CAM"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java Virtual Machine Specificatio", "im");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("\n\n\nS", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "om/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "li", "vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("11B-08.42", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MIXED MOD");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ne                                                                                               ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("mac mac ", "\n\n\nS", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 10, "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLUTF-8" + "'", str3.equals("ORACLUTF-8"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("11b-08.42", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11b-08.42" + "'", str3.equals("11b-08.42"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("im", "/Users/sophie/Library/Java/Exten...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "im" + "'", str2.equals("im"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Librry/Jv/JvVirtulMchines/jdk1....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java(TM)SERuntimeEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)SERuntimeEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "2#.80...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defectshttp://java.oracle.com/j/tmp/run_randoophttp://java.oracle.com/pl_http://java.oracle.com/686_http://java.oracle.com/56http://java.oracle.com/2http://java.oracle.com/2/target/classes:/Users/sophie/Documents/defectshttp://java.oracle.com/j/framework/lib/test_generation/generation/randoop-currenthttp://java.oracle.com/jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment" + "'", str2.equals("Java(TM)/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarSE/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarRuntime/Users/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/Users/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjarEnvironment"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) 28, (float) 125);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 125.0f + "'", float3 == 125.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("SUN.LWAWT.MACOSX.cpRINTERj", "\n\n\nS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("x86_6                           Oracle Corporation                                                ", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("X SO cM", "XSOcM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sophi", "aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                               en", "X SO cM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               en" + "'", str2.equals("                                                                                               en"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("UTF-8                              ", "Mc O X/VAR/FOLDERS/_V/6V597ZMN4_", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("xSOcM", "UTF-8                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xSOcM" + "'", str2.equals("xSOcM"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("\n", "24.80-b11", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n" + "'", str3.equals("\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n24.80-b11\n"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("entjar", "          ", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "entjar" + "'", str3.equals("entjar"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/TMP/RUN_RANDOOPHTTP://JAVPL_HTTP://JAV686_HTTP://JAV56HTTP://JAV2HTTP://JAV2/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTSHTTP://JAVJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENTHTTP://JAVJAR", 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 149 + "'", int3 == 149);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                       1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, 149, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 149 + "'", int3 == 149);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/4se", "EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Ne                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS" + "'", str2.equals("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double[] doubleArray1 = new double[] { (-1) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        char[] charArray12 = new char[] { '#', '4', 'a', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_6", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "li", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/4sers/sophie/Documents/defectshttp://javj/tmp/run_randoophttp://javpl_http://jav686_http://jav56http://jav2http://jav2/target/classes:/4sers/sophie/Documents/defectshttp://javj/framework/lib/test_generation/generation/randoop-currenthttp://javjar", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specificatio", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Exten...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten..." + "'", str1.equals("/Users/sophie/Library/Java/Exten..."));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8                              ", 0, "om/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8                              " + "'", str3.equals("UTF-8                              "));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-b1124mixed mode24.80-b1124");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sophievaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("rentjar", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", 35, "aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x" + "'", str3.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######" + "'", str3.equals("#######"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MIXED MOD                                                                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MIXED MOD                                                                                           \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("          ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                     edom dexim                     ", "51.0", (int) (short) 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("edom dexim");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("x86_6                                                                                               ", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("BOjRETNIRpc.XSOCAM.TWAWL.NUS", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BOjRETNIRpc.XSOCAM.TWAWL.NUS" + "'", str2.equals("BOjRETNIRpc.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("om/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/mo" + "'", str1.equals("/mo"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "10.14.3#############################################");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mc OS X", "aaaaHTTP://JAV", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double[] doubleArray3 = new double[] { 0, (-1L), (-1.0f) };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("mixedne nemode", "aaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 76 + "'", int1 == 76);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", 32, "24.80-b11                                24.80-b11                                24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2Java(TM) SE Runtime Environment" + "'", str3.equals("2Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("          ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MC OS X");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                               en", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("lib/java:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM", 14, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM" + "'", str3.equals("X SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cMX SO cM"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("4mixed mode24.80-b1124", "Oracle Corporationaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("2Java(TM) SE Runtime Environment", "1.7.0_80-b15", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2Java(TM) SE Runtime Environment" + "'", str3.equals("2Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 1, 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/" + "'", str3.equals("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                               US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "mixedmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Mc O X", "10.14.3#############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Exten...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten..." + "'", str1.equals("/Users/sophie/Library/Java/Exten..."));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "/Librry/Jv/JvVirtulMchines/jdk1....", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80", "4mixed mode24.80-b112", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "                                                                                                                    mixedmode", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("rentj4r", "UTF-8", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Document");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java(TM)MIXED MODSEMIXED MODRuntimeMIXED MODEnvironment", "ne");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mc OS X", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS Xa" + "'", str3.equals("Mc OS Xa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(32.0d, (double) 21, (double) 149);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.0d + "'", double3 == 21.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("http:ecom/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: http:ecom/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("XSOcM", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("xSOcM", "XSOcM", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("UTF-8", "", (int) (byte) 0, 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("xSOcM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", 0, 149);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..." + "'", str3.equals("MAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmA..."));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        ", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mod", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("entjar", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "entjar" + "'", str2.equals("entjar"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ne                                                                                               ne                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne                                                                                               ne" + "'", str1.equals("ne                                                                                               ne"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ne" + "'", str1.equals("Ne"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("uVlV PVif/r API JbcvfvcViv/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("McOSX", " MC OS X", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("2Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ", "", "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "OaclaCan");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "mixedjava hotspot(tm) 64-bit server vm java hotspot(tm) 64-bit server vmmode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/Library/Java/Exten...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Exten..." + "'", str1.equals("/Users/sophie/Library/Java/Exten..."));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "aaaaaaa", "X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 0, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/User //r/User //r/User //r/User //r/User //r/User //r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("                                                \n\n\n                                                 ", "4mixed mode24.80-b1124", 149);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7.0_80-b15", "#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("rentjar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RENTJAR" + "'", str1.equals("RENTJAR"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        xJava(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                         Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                        Java(TM)SERuntimeEnvironment                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 334 + "'", int2 == 334);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Ne", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaNe"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Ne                                                                                               ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mc OS Xa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("X SO c", 4, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "rentjar", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA(TM)MIXED MODSEMIXED MODRUNTIMEMIXED MODENVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaa", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "                                                /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("2430320651_68611_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.3#############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#############################################3.41.01" + "'", str1.equals("#############################################3.41.01"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                /VR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "ORACLUTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.CPrinterJob", "rentj4r", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/sers/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaa", "Java(TM)SERuntimeEnvironment                        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                               eN", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               eN" + "'", str2.equals("                                                                                               eN"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "MC OS X");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                               en", "entjar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                               US                                                ", 76, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               US                                                " + "'", str3.equals("                                               US                                                "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "RENTJAR", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                        BOjRETNIRpc.XSOCAM.TWAWL.NUS", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                ", "/X SO cava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X SO c", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("UTF-8", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("EN");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("X SO cM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO cM" + "'", str1.equals("X SO cM"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("vaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", 35, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt..." + "'", str3.equals("...:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptt..."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "uVlV PVif/r API JbcvfvcViv/", 52, 21);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("mixednenemode", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                               en", (int) (byte) 100, 125);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                               en" + "'", str3.equals("                                                                                               en"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mixedmode", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode                       " + "'", str2.equals("mixedmode                       "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("JavaPlatformAPISpecification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("e", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e                                                   " + "'", str3.equals("e                                                   "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("rentjar");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("                                               US                                                ", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X SO cMjava Virtual Machine Specificatiojava Virtual Machine Specificatiojava Virtual Machine Specif", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif" + "'", str3.equals("XaSOacMjavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecificatiojavaaVirtualaMachineaSpecif"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double[] doubleArray5 = new double[] { 8.0d, 4, 10.0d, (byte) -1, 35L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "10.14.3");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar" + "'", str5.equals("/Users/sophie/Documents/defects j/tmp/run_randoop pl_ 686_ 56 2 2/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current jar"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie/Documents/defects4j/tmp/run_randoop.pl_11686_1560230342/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "entjar");
        org.junit.Assert.assertNotNull(strArray2);
    }
}

