import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        java.lang.String str7 = strBuilder1.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int18 = strBuilder12.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder12.append(strBuilder19, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceFirst(strMatcher23, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.append((float) 1);
        int int29 = strBuilder27.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.replaceAll("", "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.replace(3, (int) (short) 100, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strBuilder32, 104, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder39.reverse();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder40);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(10.0d);
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher8);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(true);
        boolean boolean18 = strTokenizer15.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer15.setDelimiterChar('#');
        java.lang.String[] strArray21 = strTokenizer20.getTokenArray();
        java.lang.Object obj22 = strTokenizer20.next();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer20.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer9.setIgnoredMatcher(strMatcher23);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(true);
        boolean boolean35 = strTokenizer32.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer32.setDelimiterChar('#');
        java.lang.String[] strArray38 = strTokenizer37.getTokenArray();
        java.lang.Object obj39 = strTokenizer37.next();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer37.getIgnoredMatcher();
        int int42 = strBuilder26.lastIndexOf(strMatcher40, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher23, strMatcher40);
        int int45 = strBuilder5.lastIndexOf(strMatcher23, 3);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder5.append("10.0", (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + obj39 + "' != '" + "hi!" + "'", obj39.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer1.setIgnoredChar(' ');
        boolean boolean6 = strTokenizer1.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer1.setQuoteChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setIgnoreEmptyTokens(true);
        boolean boolean17 = strTokenizer14.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer14.setDelimiterChar('#');
        java.lang.String[] strArray20 = strTokenizer19.getTokenArray();
        java.lang.Object obj21 = strTokenizer19.next();
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer19.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer19.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(true);
        boolean boolean35 = strTokenizer32.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer32.setDelimiterChar('#');
        java.lang.String[] strArray38 = strTokenizer37.getTokenArray();
        java.lang.Object obj39 = strTokenizer37.next();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer37.getIgnoredMatcher();
        int int42 = strBuilder26.lastIndexOf(strMatcher40, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer19.setTrimmerMatcher(strMatcher40);
        java.lang.Class<?> wildcardClass44 = strMatcher40.getClass();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer8.setDelimiterMatcher(strMatcher40);
        java.lang.String str46 = strTokenizer45.nextToken();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + "hi!" + "'", obj21.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + obj39 + "' != '" + "hi!" + "'", obj39.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNull(str46);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        boolean boolean14 = strTokenizer11.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setDelimiterChar('#');
        java.lang.String[] strArray17 = strTokenizer16.getTokenArray();
        java.lang.Object obj18 = strTokenizer16.next();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.append((java.lang.Object) strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst(' ');
        java.lang.String str24 = strBuilder21.getNullText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + "hi!" + "'", obj18.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int20 = strBuilder17.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder17.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int30 = strBuilder27.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.deleteAll("hi!");
        boolean boolean34 = strBuilder32.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int40 = strBuilder37.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer41 = strBuilder37.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder17.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder15.append(strBuilder43);
        char[] charArray45 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.append(charArray45);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.ensureCapacity(0);
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer52.setEmptyTokenAsNull(false);
        int int57 = strTokenizer52.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer52.setQuoteChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer52.reset("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder46.appendWithSeparators((java.util.Iterator) strTokenizer52, "hi!");
        java.io.Reader reader64 = strBuilder46.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder46.replaceFirst(' ', '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(reader64);
        org.junit.Assert.assertNotNull(strBuilder67);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        boolean boolean68 = strBuilder66.contains("4a  ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        boolean boolean8 = strTokenizer5.isIgnoreEmptyTokens();
        java.lang.String str9 = strTokenizer5.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher10 = strTokenizer5.getDelimiterMatcher();
        boolean boolean11 = strTokenizer5.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str9.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strMatcher10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!##4a", "1.0");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int17 = strBuilder12.length();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.deleteAll(strMatcher18);
        int int21 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append((float) 1L);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder22.insert((int) (short) 1, (long) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.append(56);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.io.Writer writer18 = strBuilder17.asWriter();
        java.lang.String str21 = strBuilder17.midString((int) 'a', (int) (short) 100);
        try {
            char[] charArray24 = strBuilder17.toCharArray(3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(writer18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int17 = strBuilder12.length();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.deleteAll(strMatcher18);
        int int21 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.replaceFirst('4', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int30 = strBuilder27.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.deleteAll("hi!");
        boolean boolean34 = strBuilder32.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int40 = strBuilder37.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer41 = strBuilder37.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder42.append(0.0f);
        int int45 = strBuilder42.capacity();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        int int48 = strBuilder42.indexOf(strMatcher46, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder42.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder1.append(strBuilder49);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder1.delete(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder50);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        int int17 = strBuilder14.lastIndexOf('a', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.setNullText("hi!");
        int int24 = strBuilder21.lastIndexOf("#4#", (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.insert(0, (float) 4);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int32 = strBuilder29.lastIndexOf("", (int) 'a');
        int int33 = strBuilder29.size();
        int int35 = strBuilder29.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder29.append(strBuilder36, (int) (short) 1, (int) '#');
        int int41 = strBuilder29.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder29.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher47, strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.setIgnoreEmptyTokens(true);
        boolean boolean54 = strTokenizer51.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder45.appendWithSeparators((java.util.Iterator) strTokenizer51, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer51.setQuoteChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder27.appendWithSeparators((java.util.Iterator) strTokenizer58, "false ");
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("", 'a', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder27.appendWithSeparators((java.util.Iterator) strTokenizer68, "");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strBuilder70);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int5 = strBuilder2.lastIndexOf("", (int) 'a');
        int int6 = strBuilder2.size();
        int int8 = strBuilder2.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder2.append(strBuilder9, (int) (short) 1, (int) '#');
        int int14 = strBuilder2.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder2.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int23 = strBuilder20.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder20.deleteAll("hi!");
        boolean boolean27 = strBuilder25.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.clear();
        boolean boolean29 = strBuilder18.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strBuilder25.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.append(strBuilder25);
        java.lang.String str33 = strBuilder31.leftString(0);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.appendFixedWidthPadLeft(100, (int) (short) 10, ' ');
        java.lang.String str38 = strBuilder37.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "       100" + "'", str38.equals("       100"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int22 = strBuilder19.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.append(strBuilder19);
        boolean boolean27 = strBuilder19.startsWith("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder19.append('4');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.deleteAll("35");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder17.deleteCharAt((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendFixedWidthPadRight((int) (short) 100, (int) (byte) 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.appendFixedWidthPadRight((java.lang.Object) 1, (int) 'a', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder34.appendPadding(0, 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int72 = strBuilder69.lastIndexOf("", (int) 'a');
        int int73 = strBuilder69.size();
        int int75 = strBuilder69.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder69.append(strBuilder76, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder79.replaceFirst(strMatcher80, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder79.delete((int) (short) 0, 100);
        boolean boolean87 = strBuilder85.contains("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) "#4#", (int) '4', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder67.appendPadding((int) (short) 100, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer94 = strBuilder67.asTokenizer();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(strTokenizer94);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder11.deleteAll("hi!");
        boolean boolean18 = strBuilder16.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer25 = strBuilder21.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.append(stringBuffer25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder1.append(stringBuffer25);
        java.lang.StringBuffer stringBuffer28 = strBuilder27.toStringBuffer();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.reset("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int42 = strBuilder39.lastIndexOf("", (int) 'a');
        int int43 = strBuilder39.size();
        int int45 = strBuilder39.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder39.append(strBuilder46, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.replaceFirst(strMatcher50, "hi!");
        char[] charArray53 = strBuilder52.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer33.reset(charArray53);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder27.insert((int) (byte) 0, charArray53);
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder27.deleteAll(strMatcher57);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder27.appendPadding(100, 'e');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(stringBuffer28);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
//        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
//        int int5 = strBuilder1.size();
//        int int6 = strBuilder1.length();
//        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
//        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
//        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
//        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
//        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
//        java.lang.Object obj20 = strTokenizer18.next();
//        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
//        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
//        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
//        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
//        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
//        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
//        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
//        java.lang.Object obj38 = strTokenizer36.next();
//        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
//        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
//        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
//        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
//        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
//        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
//        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
//        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
//        java.lang.Object obj57 = strTokenizer55.next();
//        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
//        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
//        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
//        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.append("hi!");
//        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.appendNewLine();
//        int int70 = strBuilder1.lastIndexOf('a', (int) (byte) 100);
//        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder1.insert(52, "");
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(strTokenizer13);
//        org.junit.Assert.assertNotNull(strTokenizer15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(strTokenizer18);
//        org.junit.Assert.assertNotNull(strArray19);
//        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
//        org.junit.Assert.assertNotNull(strMatcher21);
//        org.junit.Assert.assertNotNull(strTokenizer23);
//        org.junit.Assert.assertNotNull(strTokenizer31);
//        org.junit.Assert.assertNotNull(strTokenizer33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(strTokenizer36);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
//        org.junit.Assert.assertNotNull(strMatcher39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(strTokenizer42);
//        org.junit.Assert.assertNotNull(strTokenizer50);
//        org.junit.Assert.assertNotNull(strTokenizer52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(strTokenizer55);
//        org.junit.Assert.assertNotNull(strArray56);
//        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
//        org.junit.Assert.assertNotNull(strMatcher58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(strBuilder64);
//        org.junit.Assert.assertNotNull(strBuilder66);
//        org.junit.Assert.assertNotNull(strBuilder67);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 85 + "'", int70 == 85);
//        org.junit.Assert.assertNotNull(strBuilder73);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int5 = strBuilder2.lastIndexOf("", (int) 'a');
        char[] charArray11 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher13);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder2.appendWithSeparators((java.util.Iterator) strTokenizer14, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append("#4#");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strBuilder18.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.ensureCapacity(1);
        char[] charArray27 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoredMatcher(strMatcher32);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer31.getQuoteMatcher();
        boolean boolean35 = strBuilder21.contains(strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("4a  ", strMatcher34);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder18.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder18.deleteAll("hi!");
        boolean boolean25 = strBuilder23.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.clear();
        int int28 = strBuilder26.indexOf("#4#");
        java.io.Writer writer29 = strBuilder26.asWriter();
        char[] charArray36 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder26.insert(0, charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer41.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int49 = strBuilder46.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.deleteAll("hi!");
        boolean boolean53 = strBuilder51.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder51.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher60, strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        boolean boolean67 = strTokenizer64.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer64.setDelimiterChar('#');
        java.lang.String[] strArray70 = strTokenizer69.getTokenArray();
        java.lang.Object obj71 = strTokenizer69.next();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer69.getIgnoredMatcher();
        int int74 = strBuilder58.lastIndexOf(strMatcher72, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder51.replaceAll(strMatcher72, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer44.setQuoteMatcher(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder9.deleteAll(strMatcher72);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder9.insert(1, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertTrue("'" + obj71 + "' != '" + "hi!" + "'", obj71.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.setEmptyTokenAsNull(false);
        int int8 = strTokenizer7.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer7.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer7.setDelimiterChar('e');
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strMatcher9);
        org.junit.Assert.assertNotNull(strTokenizer11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder64.append((long) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder69.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder70.append("StrTokenizer[not tokenized yet]", (int) (byte) 1, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder74.appendPadding(0, '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int6 = strBuilder4.indexOf('#');
        boolean boolean8 = strBuilder4.endsWith("");
        char[] charArray9 = strBuilder4.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray9);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder2.append(charArray9, 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: Invalid startIndex: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(strTokenizer10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        java.lang.String str10 = strBuilder8.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder12.indexOf('#');
        boolean boolean15 = strBuilder8.equals(strBuilder12);
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher17, strMatcher18);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        boolean boolean24 = strTokenizer21.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer21.setDelimiterChar('#');
        java.lang.String[] strArray27 = strTokenizer26.getTokenArray();
        java.lang.Object obj28 = strTokenizer26.next();
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer26.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer26.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(true);
        boolean boolean42 = strTokenizer39.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer39.setDelimiterChar('#');
        java.lang.String[] strArray45 = strTokenizer44.getTokenArray();
        java.lang.Object obj46 = strTokenizer44.next();
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        int int49 = strBuilder33.lastIndexOf(strMatcher47, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer26.setTrimmerMatcher(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder12.deleteAll(strMatcher47);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder12.appendNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj54 = strTokenizer53.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer53.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int61 = strBuilder58.lastIndexOf("", (int) 'a');
        char[] charArray67 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = new org.apache.commons.lang.text.StrTokenizer(charArray67);
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray67, strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder58.appendWithSeparators((java.util.Iterator) strTokenizer70, "#4#");
        org.apache.commons.lang.text.StrMatcher strMatcher73 = strTokenizer70.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer53.setIgnoredMatcher(strMatcher73);
        java.util.List list75 = strTokenizer74.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder52.appendWithSeparators((java.util.Collection) list75, "44444444444444444444444444444497");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + "hi!" + "'", obj28.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + "hi!" + "'", obj46.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(charArray67);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strMatcher73);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.insert(0, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder6.trim();
        java.lang.String str16 = strBuilder15.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.append('4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.setLength(100);
        java.util.Collection collection26 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder9.appendWithSeparators(collection26, "");
        java.lang.String str29 = strBuilder28.getNullText();
        java.io.Reader reader30 = strBuilder28.asReader();
        char[] charArray36 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder28.append(charArray36, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: Invalid startIndex: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(reader30);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer43);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder11.deleteAll("hi!");
        boolean boolean18 = strBuilder16.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer25 = strBuilder21.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.append(stringBuffer25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder1.append(stringBuffer25);
        java.lang.StringBuffer stringBuffer28 = strBuilder27.toStringBuffer();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.reset("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int42 = strBuilder39.lastIndexOf("", (int) 'a');
        int int43 = strBuilder39.size();
        int int45 = strBuilder39.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder39.append(strBuilder46, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.replaceFirst(strMatcher50, "hi!");
        char[] charArray53 = strBuilder52.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer33.reset(charArray53);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder27.insert((int) (byte) 0, charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray53, "#4# a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray53);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(stringBuffer28);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer59);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.appendNewLine();
        java.lang.String str13 = strBuilder11.getNewLineText();
        java.lang.String str14 = strBuilder11.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder11.replace(0, 56, "1");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\n" + "'", str14.equals("\n"));
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.append(false);
        boolean boolean5 = strBuilder1.equalsIgnoreCase(strBuilder2);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int10 = strBuilder7.lastIndexOf("", (int) 'a');
        int int11 = strBuilder7.size();
        int int13 = strBuilder7.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.append(strBuilder14, (int) (short) 1, (int) '#');
        int int19 = strBuilder7.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder7.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str26 = strBuilder7.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder7.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder2.append(strBuilder28);
        int int32 = strBuilder2.lastIndexOf('4', (int) (short) 10);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strBuilder14.asTokenizer();
        int int16 = strBuilder14.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.ensureCapacity((int) ' ');
        int int21 = strBuilder18.indexOf('a', 6);
        try {
            char[] charArray24 = strBuilder18.toCharArray((int) 'e', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        int int20 = strBuilder17.lastIndexOf('#', (int) (short) 10);
        boolean boolean22 = strBuilder17.contains("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int28 = strBuilder25.lastIndexOf("", (int) 'a');
        int int29 = strBuilder25.size();
        int int31 = strBuilder25.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder25.append(strBuilder32, (int) (short) 1, (int) '#');
        int int37 = strBuilder25.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder25.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int46 = strBuilder43.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder43.deleteAll("hi!");
        boolean boolean50 = strBuilder48.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.clear();
        boolean boolean52 = strBuilder41.equalsIgnoreCase(strBuilder48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strBuilder48.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder23.append(strBuilder48);
        java.lang.String str55 = strBuilder23.toString();
        boolean boolean56 = strBuilder17.equalsIgnoreCase(strBuilder23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strBuilder17.asTokenizer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder17.insert((int) (byte) 10, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(strTokenizer57);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder6.appendFixedWidthPadRight((int) (short) 10, (int) (byte) -1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder6.append((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder6.setNullText("h!100#################################################################################################14");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder6.append(100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(104);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int6 = strBuilder3.lastIndexOf("", (int) 'a');
        int int7 = strBuilder3.size();
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder3.deleteAll(strMatcher9);
        int int12 = strBuilder3.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int17 = strBuilder14.lastIndexOf("", (int) 'a');
        int int18 = strBuilder14.size();
        int int19 = strBuilder14.length();
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder14.deleteAll(strMatcher20);
        int int23 = strBuilder14.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder3.append((java.lang.Object) "");
        int int26 = strBuilder3.lastIndexOf("#4#");
        java.io.Writer writer27 = strBuilder3.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder1.append(strBuilder3);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder3.insert((int) (byte) 0, (double) (short) 100);
        int int33 = strBuilder31.indexOf('4');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.reverse();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(writer27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(10.0d);
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher8);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(true);
        boolean boolean18 = strTokenizer15.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer15.setDelimiterChar('#');
        java.lang.String[] strArray21 = strTokenizer20.getTokenArray();
        java.lang.Object obj22 = strTokenizer20.next();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer20.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer9.setIgnoredMatcher(strMatcher23);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(true);
        boolean boolean35 = strTokenizer32.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer32.setDelimiterChar('#');
        java.lang.String[] strArray38 = strTokenizer37.getTokenArray();
        java.lang.Object obj39 = strTokenizer37.next();
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer37.getIgnoredMatcher();
        int int42 = strBuilder26.lastIndexOf(strMatcher40, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher23, strMatcher40);
        int int45 = strBuilder5.lastIndexOf(strMatcher23, 3);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder5.insert(3, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + obj39 + "' != '" + "hi!" + "'", obj39.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        int int3 = strBuilder0.lastIndexOf(strMatcher1, 100);
        java.lang.String str5 = strBuilder0.rightString((int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 100, 'a');
        java.lang.String str12 = strBuilder0.substring(2, 3);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder0.append('a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(strBuilder14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder18.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder18.deleteAll("hi!");
        boolean boolean25 = strBuilder23.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.clear();
        int int28 = strBuilder26.indexOf("#4#");
        java.io.Writer writer29 = strBuilder26.asWriter();
        char[] charArray36 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder26.insert(0, charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer41.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int49 = strBuilder46.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.deleteAll("hi!");
        boolean boolean53 = strBuilder51.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder51.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher60, strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        boolean boolean67 = strTokenizer64.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer64.setDelimiterChar('#');
        java.lang.String[] strArray70 = strTokenizer69.getTokenArray();
        java.lang.Object obj71 = strTokenizer69.next();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer69.getIgnoredMatcher();
        int int74 = strBuilder58.lastIndexOf(strMatcher72, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder51.replaceAll(strMatcher72, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer44.setQuoteMatcher(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder9.deleteAll(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder78.setLength(2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertTrue("'" + obj71 + "' != '" + "hi!" + "'", obj71.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strBuilder80);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((int) (short) 0, (int) (short) 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.insert((int) (byte) 0, (double) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int13 = strBuilder10.lastIndexOf("", (int) 'a');
        int int14 = strBuilder10.size();
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder10.append(strBuilder17, (int) (short) 1, (int) '#');
        int int22 = strBuilder10.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder10.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int31 = strBuilder28.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder10.append(strBuilder28);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strBuilder10, 32, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder10.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder10.insert(0, (double) 1.0f);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder42);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        boolean boolean8 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int13 = strBuilder10.lastIndexOf("", (int) 'a');
        int int14 = strBuilder10.size();
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder10.append(strBuilder17, (int) (short) 1, (int) '#');
        int int22 = strBuilder10.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder10.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int31 = strBuilder28.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder10.append(strBuilder28);
        char[] charArray35 = strBuilder10.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int41 = strBuilder38.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher44, strMatcher45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        boolean boolean51 = strTokenizer48.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer48.setDelimiterChar('#');
        java.lang.String[] strArray54 = strTokenizer53.getTokenArray();
        java.lang.Object obj55 = strTokenizer53.next();
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer53.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder38.append((java.lang.Object) strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int64 = strBuilder61.lastIndexOf("", (int) 'a');
        char[] charArray70 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray70);
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer(charArray70, strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder61.appendWithSeparators((java.util.Iterator) strTokenizer73, "#4#");
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer73.getIgnoredMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher77 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher76, strMatcher77);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer(charArray35, strMatcher56, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer7.setIgnoredMatcher(strMatcher56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + "hi!" + "'", obj55.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(charArray70);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strTokenizer80);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(false);
        int int5 = strBuilder2.lastIndexOf(' ', (int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.ensureCapacity((int) (byte) -1);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strBuilder7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer24.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int32 = strBuilder29.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder29.deleteAll("hi!");
        boolean boolean36 = strBuilder34.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoreEmptyTokens(true);
        boolean boolean50 = strTokenizer47.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer47.setDelimiterChar('#');
        java.lang.String[] strArray53 = strTokenizer52.getTokenArray();
        java.lang.Object obj54 = strTokenizer52.next();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer52.getIgnoredMatcher();
        int int57 = strBuilder41.lastIndexOf(strMatcher55, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder34.replaceAll(strMatcher55, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer27.setQuoteMatcher(strMatcher55);
        boolean boolean61 = strTokenizer27.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer27.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer27.setIgnoredChar('a');
        java.lang.String str65 = strTokenizer27.getContent();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + "hi!" + "'", obj54.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "#4# a" + "'", str65.equals("#4# a"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        int int20 = strBuilder17.lastIndexOf('#', (int) (short) 10);
        boolean boolean22 = strBuilder17.contains("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        int int28 = strBuilder24.size();
        int int30 = strBuilder24.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder24.append(strBuilder31, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder34.replaceFirst(strMatcher35, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.append((float) 1);
        int int41 = strBuilder39.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append(false);
        boolean boolean47 = strBuilder43.equalsIgnoreCase(strBuilder44);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int52 = strBuilder49.lastIndexOf("", (int) 'a');
        int int53 = strBuilder49.size();
        int int55 = strBuilder49.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder49.append(strBuilder56, (int) (short) 1, (int) '#');
        int int61 = strBuilder49.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder49.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str68 = strBuilder49.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder49.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder44.append(strBuilder70);
        char[] charArray77 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer(charArray77);
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray77, strMatcher79);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder70.append(charArray77);
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder39.append(charArray77);
        char[] charArray83 = strBuilder82.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder17.append(charArray83);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer(charArray83, "hi!");
        boolean boolean87 = strTokenizer86.hasNext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(charArray77);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(charArray83);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        java.lang.String str10 = strBuilder8.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.appendFixedWidthPadRight((int) (short) 100, 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int20 = strBuilder18.indexOf('#');
        boolean boolean22 = strBuilder18.endsWith("");
        char[] charArray23 = strBuilder18.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray23);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int31 = strBuilder28.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.deleteAll("hi!");
        boolean boolean35 = strBuilder33.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.appendFixedWidthPadLeft(1, 1, '4');
        boolean boolean42 = strBuilder40.startsWith("hi!");
        char[] charArray43 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray43);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer44.setIgnoredChar(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder40.appendWithSeparators((java.util.Iterator) strTokenizer48, "");
        org.apache.commons.lang.text.StrMatcher strMatcher51 = strTokenizer48.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int56 = strBuilder53.lastIndexOf("", (int) 'a');
        int int57 = strBuilder53.size();
        int int59 = strBuilder53.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder53.append(strBuilder60, (int) (short) 1, (int) '#');
        int int65 = strBuilder53.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder53.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher71 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.setIgnoreEmptyTokens(true);
        boolean boolean78 = strTokenizer75.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer75.setDelimiterChar('#');
        java.lang.String[] strArray81 = strTokenizer80.getTokenArray();
        java.lang.Object obj82 = strTokenizer80.next();
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer80.getIgnoredMatcher();
        int int85 = strBuilder69.indexOf(strMatcher83, (int) '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer48.setTrimmerMatcher(strMatcher83);
        org.apache.commons.lang.text.StrMatcher strMatcher87 = strTokenizer48.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer26.setTrimmerMatcher(strMatcher87);
        int int89 = strBuilder16.lastIndexOf(strMatcher87);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strMatcher51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertTrue("'" + obj82 + "' != '" + "hi!" + "'", obj82.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertNotNull(strMatcher87);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder6.appendFixedWidthPadRight((int) (short) 10, (int) (byte) -1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder6.append((int) '4');
        boolean boolean19 = strBuilder6.startsWith("#4# a#4#org.apache.commons.lang.text.StrMatcher$NoMa");
        java.lang.String str20 = strBuilder6.getNewLineText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append(100.0f);
        boolean boolean19 = strBuilder15.startsWith("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.deleteAll("hi!");
        boolean boolean28 = strBuilder26.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder26.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int39 = strBuilder36.lastIndexOf("", (int) 'a');
        int int40 = strBuilder36.size();
        int int42 = strBuilder36.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder26.append(strBuilder36);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder15.append((java.lang.Object) strBuilder43);
        boolean boolean46 = strBuilder15.startsWith("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.setLength(100);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder27.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder27.replaceAll(' ', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder27.delete(4, 104);
        boolean boolean39 = strBuilder27.endsWith("hi!");
        java.io.Writer writer40 = strBuilder27.asWriter();
        boolean boolean41 = strBuilder9.equals((java.lang.Object) writer40);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder9.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder9.insert(0, (long) ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(writer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder45);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.ensureCapacity((int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.minimizeCapacity();
        int int14 = strBuilder10.capacity();
        java.io.Reader reader15 = strBuilder10.asReader();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(reader15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        int int17 = strBuilder14.lastIndexOf('a', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        int int28 = strBuilder24.size();
        int int30 = strBuilder24.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder24.append(strBuilder31, (int) (short) 1, (int) '#');
        int int36 = strBuilder24.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder24.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int45 = strBuilder42.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder42.deleteAll("hi!");
        boolean boolean49 = strBuilder47.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder47.clear();
        boolean boolean51 = strBuilder40.equalsIgnoreCase(strBuilder47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strBuilder47.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder22.append(strBuilder47);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.replaceAll("hi!", "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.replaceFirst("", "");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder56.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder21.append((java.lang.Object) strBuilder60);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder60.append((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder63);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        int int19 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.appendPadding(0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.deleteFirst('e');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.replace((int) (byte) 1, 7, "4  a#");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        java.util.List list2 = strTokenizer1.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer1.setQuoteChar('a');
        boolean boolean5 = strTokenizer4.hasNext();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder67.insert((int) (byte) 100, true);
        java.lang.String str71 = strBuilder70.getNewLineText();
        char[] charArray74 = strBuilder70.toCharArray((int) (short) 1, 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(charArray74);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        java.lang.String str19 = strBuilder18.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.reverse();
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setEmptyTokenAsNull(false);
        int int29 = strTokenizer24.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer24.setQuoteChar(' ');
        boolean boolean32 = strTokenizer24.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer24.setDelimiterChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder20.appendWithSeparators((java.util.Iterator) strTokenizer34, " ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.0" + "'", str19.equals("0.0"));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strBuilder36);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        int int3 = strBuilder0.lastIndexOf(strMatcher1, 100);
        java.lang.String str5 = strBuilder0.rightString((int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder0.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strBuilder9.asTokenizer();
        java.util.List list11 = strTokenizer10.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.reset("h!100#################################################################################################14");
        java.lang.String str14 = strTokenizer10.getContent();
        try {
            java.lang.Object obj15 = strTokenizer10.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "h!100#################################################################################################14" + "'", str14.equals("h!100#################################################################################################14"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer23.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int34 = strBuilder32.indexOf('#');
        boolean boolean36 = strBuilder32.endsWith("");
        char[] charArray37 = strBuilder32.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray37, ' ', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer23.reset(charArray37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray37, 'e');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer42);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer1.setIgnoredChar(' ');
        boolean boolean6 = strTokenizer1.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer1.setQuoteChar('4');
        java.util.List list9 = strTokenizer1.getTokenList();
        java.lang.Class<?> wildcardClass10 = strTokenizer1.getClass();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer1.setDelimiterChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setDelimiterChar('#');
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        int int20 = strBuilder16.size();
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.append((double) (byte) 100);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.deleteFirst(strMatcher26);
        boolean boolean29 = strBuilder25.endsWith("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj1 = strTokenizer0.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer0.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrMatcher strMatcher4 = strTokenizer3.getTrimmerMatcher();
        try {
            java.lang.Object obj5 = strTokenizer3.next();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strMatcher4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.append(false);
        boolean boolean5 = strBuilder1.equalsIgnoreCase(strBuilder2);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int10 = strBuilder7.lastIndexOf("", (int) 'a');
        int int11 = strBuilder7.size();
        int int13 = strBuilder7.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.append(strBuilder14, (int) (short) 1, (int) '#');
        int int19 = strBuilder7.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder7.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str26 = strBuilder7.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder7.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder2.append(strBuilder28);
        java.lang.String str32 = strBuilder29.midString((int) '#', 0);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder29.replaceFirst("0hi!", "");
        java.lang.String str36 = strBuilder35.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int41 = strBuilder38.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder38.deleteAll("hi!");
        boolean boolean45 = strBuilder43.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder43.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder48.appendNewLine();
        java.lang.String str50 = strBuilder48.getNewLineText();
        boolean boolean51 = strBuilder35.equals((java.lang.Object) strBuilder48);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder48.deleteFirst("0.0");
        char[] charArray54 = strBuilder48.toCharArray();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "false " + "'", str36.equals("false "));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(charArray54);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer23.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int34 = strBuilder32.indexOf('#');
        boolean boolean36 = strBuilder32.endsWith("");
        char[] charArray37 = strBuilder32.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray37, ' ', ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer23.reset(charArray37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer42.reset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer43);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int22 = strBuilder19.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.append(strBuilder19);
        char[] charArray26 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder1.deleteAll(strMatcher27);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder1.delete(3, (int) '#');
        java.lang.String str32 = strBuilder31.getNullText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        int int17 = strBuilder14.lastIndexOf('a', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.setNullText("hi!");
        int int24 = strBuilder21.lastIndexOf("#4#", (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.insert(0, (float) 4);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder27.insert(0, (float) 7);
        int int31 = strBuilder30.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder30.deleteAll("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        boolean boolean8 = strTokenizer5.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer5.setDelimiterChar('#');
        java.lang.String[] strArray11 = strTokenizer10.getTokenArray();
        java.lang.Object obj12 = strTokenizer10.next();
        org.apache.commons.lang.text.StrMatcher strMatcher13 = strTokenizer10.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer10.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer23.setDelimiterChar('#');
        java.lang.String[] strArray29 = strTokenizer28.getTokenArray();
        java.lang.Object obj30 = strTokenizer28.next();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer28.getIgnoredMatcher();
        int int33 = strBuilder17.lastIndexOf(strMatcher31, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer10.setTrimmerMatcher(strMatcher31);
        java.lang.String str35 = strTokenizer34.getContent();
        java.lang.String str36 = strTokenizer34.toString();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + "hi!" + "'", obj12.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + obj30 + "' != '" + "hi!" + "'", obj30.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "StrTokenizer[hi!]" + "'", str36.equals("StrTokenizer[hi!]"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft(1, 1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.appendNewLine();
        int int17 = strBuilder9.size();
        boolean boolean18 = strBuilder9.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder9.replaceAll('a', '#');
        int int24 = strBuilder21.lastIndexOf('a', 104);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int6 = strBuilder3.lastIndexOf("", (int) 'a');
        int int7 = strBuilder3.size();
        int int9 = strBuilder3.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.append(strBuilder10, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.replaceFirst(strMatcher14, "hi!");
        char[] charArray17 = strBuilder16.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer24.setEmptyTokenAsNull(false);
        int int29 = strTokenizer28.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer28.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer20.setIgnoredMatcher(strMatcher30);
        try {
            strTokenizer1.set((java.lang.Object) strTokenizer31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: set() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(strTokenizer31);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        java.lang.Class<?> wildcardClass7 = strBuilder1.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        char[] charArray4 = new char[] { '4', 'a', ' ', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray4, ' ', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.reset("");
        boolean boolean10 = strTokenizer7.hasNext();
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", ' ', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setDelimiterString("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int10 = strBuilder7.lastIndexOf("", (int) 'a');
        int int11 = strBuilder7.size();
        int int13 = strBuilder7.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder7.append(strBuilder14, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceFirst(strMatcher18, "hi!");
        char[] charArray21 = strBuilder20.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int28 = strBuilder25.lastIndexOf("", (int) 'a');
        int int29 = strBuilder25.size();
        int int30 = strBuilder25.length();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder25.deleteAll(strMatcher31);
        java.lang.String str34 = strBuilder32.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder32.deleteFirst('a');
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher38, strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(true);
        boolean boolean45 = strTokenizer42.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer42.setDelimiterChar('#');
        java.lang.String[] strArray48 = strTokenizer47.getTokenArray();
        java.lang.Object obj49 = strTokenizer47.next();
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer47.getDelimiterMatcher();
        int int51 = strBuilder32.lastIndexOf(strMatcher50);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher50, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer3.setQuoteMatcher(strMatcher50);
        java.lang.String str55 = strTokenizer54.previousToken();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + obj49 + "' != '" + "hi!" + "'", obj49.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNull(str55);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        int int8 = strBuilder6.indexOf("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strBuilder6.asTokenizer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder6.append("", 56, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.deleteFirst("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrMatcher strMatcher68 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer72.setIgnoreEmptyTokens(true);
        boolean boolean75 = strTokenizer72.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer72.setDelimiterChar('#');
        java.lang.String[] strArray78 = strTokenizer77.getTokenArray();
        java.lang.Object obj79 = strTokenizer77.next();
        org.apache.commons.lang.text.StrMatcher strMatcher80 = strTokenizer77.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer77.setDelimiterString("");
        java.lang.String[] strArray83 = strTokenizer82.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder1.appendWithSeparators((java.lang.Object[]) strArray83, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder86 = null;
        try {
            boolean boolean87 = strBuilder85.equalsIgnoreCase(strBuilder86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertTrue("'" + obj79 + "' != '" + "hi!" + "'", obj79.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(strBuilder85);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher3, strMatcher4);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.setIgnoreEmptyTokens(true);
        boolean boolean10 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer7.setDelimiterChar('#');
        java.lang.String[] strArray13 = strTokenizer12.getTokenArray();
        java.lang.Object obj14 = strTokenizer12.next();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer12.getIgnoredMatcher();
        int int17 = strBuilder1.lastIndexOf(strMatcher15, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder19.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int47 = strBuilder44.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder44.deleteAll("hi!");
        boolean boolean51 = strBuilder49.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.clear();
        boolean boolean53 = strBuilder42.equalsIgnoreCase(strBuilder49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder49.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder24.append(strBuilder49);
        java.lang.String str56 = strBuilder24.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder24.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder23.append(strBuilder24);
        boolean boolean60 = strBuilder1.equalsIgnoreCase(strBuilder59);
        char[] charArray65 = new char[] { '#', '#', '4', 'a' };
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.append(charArray65);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.clear();
        char[] charArray68 = strBuilder67.toCharArray();
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(charArray68);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("0.0", 'e', 'a');
        java.util.List list4 = strTokenizer3.getTokenList();
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.appendFixedWidthPadLeft((int) (short) 0, (int) (short) 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder13.append((long) 0);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher21, strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(true);
        boolean boolean28 = strTokenizer25.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer25.setDelimiterChar('#');
        java.lang.String[] strArray31 = strTokenizer30.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder13.appendWithSeparators((java.lang.Object[]) strArray31, "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder13.replaceAll("4  a#", "4  a#");
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj38 = strTokenizer37.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer37.getIgnoredMatcher();
        int int43 = strBuilder13.indexOf(strMatcher41, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder6.deleteFirst(strMatcher41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int16 = strBuilder14.indexOf('#');
        boolean boolean18 = strBuilder14.endsWith("");
        char[] charArray19 = strBuilder14.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray19);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder6.insert(56, charArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 56");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strTokenizer20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("       100");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        char[] charArray14 = strBuilder11.toCharArray((int) (byte) 1, 7);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher16, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer18.setEmptyTokenAsNull(false);
        int int23 = strTokenizer18.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer18.setQuoteChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer18.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer18.getDelimiterMatcher();
        int int30 = strBuilder11.lastIndexOf(strMatcher28, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder11.ensureCapacity(3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer24.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int32 = strBuilder29.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder29.deleteAll("hi!");
        boolean boolean36 = strBuilder34.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoreEmptyTokens(true);
        boolean boolean50 = strTokenizer47.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer47.setDelimiterChar('#');
        java.lang.String[] strArray53 = strTokenizer52.getTokenArray();
        java.lang.Object obj54 = strTokenizer52.next();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer52.getIgnoredMatcher();
        int int57 = strBuilder41.lastIndexOf(strMatcher55, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder34.replaceAll(strMatcher55, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer27.setQuoteMatcher(strMatcher55);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher62, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.setIgnoreEmptyTokens(true);
        boolean boolean69 = strTokenizer66.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer66.setDelimiterChar('#');
        java.lang.String[] strArray72 = strTokenizer71.getTokenArray();
        java.lang.Object obj73 = strTokenizer71.next();
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer71.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder78 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher81 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher80, strMatcher81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer84.setIgnoreEmptyTokens(true);
        boolean boolean87 = strTokenizer84.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer84.setDelimiterChar('#');
        java.lang.String[] strArray90 = strTokenizer89.getTokenArray();
        java.lang.Object obj91 = strTokenizer89.next();
        org.apache.commons.lang.text.StrMatcher strMatcher92 = strTokenizer89.getIgnoredMatcher();
        int int94 = strBuilder78.lastIndexOf(strMatcher92, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer95 = strTokenizer71.setTrimmerMatcher(strMatcher92);
        org.apache.commons.lang.text.StrMatcher strMatcher96 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer97 = strTokenizer27.setTrimmerMatcher(strMatcher96);
        java.lang.String str98 = strTokenizer27.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + "hi!" + "'", obj54.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + "hi!" + "'", obj73.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strArray90);
        org.junit.Assert.assertTrue("'" + obj91 + "' != '" + "hi!" + "'", obj91.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer95);
        org.junit.Assert.assertNotNull(strMatcher96);
        org.junit.Assert.assertNotNull(strTokenizer97);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str98.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        int int17 = strBuilder14.lastIndexOf('a', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.setNullText("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher23, strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.reset("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int34 = strBuilder31.lastIndexOf("", (int) 'a');
        int int35 = strBuilder31.size();
        int int37 = strBuilder31.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder31.append(strBuilder38, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.replaceFirst(strMatcher42, "hi!");
        char[] charArray45 = strBuilder44.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer25.reset(charArray45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray45);
        java.util.List list49 = strTokenizer48.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder21.appendWithSeparators((java.util.Collection) list49, "#4# a#4#org.apache.commons.lang.text.StrMatcher$NoMa");
        int int52 = strBuilder21.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher3);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher6, strMatcher7);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setIgnoreEmptyTokens(true);
        boolean boolean13 = strTokenizer10.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer10.setDelimiterChar('#');
        java.lang.String[] strArray16 = strTokenizer15.getTokenArray();
        java.lang.Object obj17 = strTokenizer15.next();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer15.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer4.setIgnoredMatcher(strMatcher18);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher23, strMatcher24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setIgnoreEmptyTokens(true);
        boolean boolean30 = strTokenizer27.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer27.setDelimiterChar('#');
        java.lang.String[] strArray33 = strTokenizer32.getTokenArray();
        java.lang.Object obj34 = strTokenizer32.next();
        org.apache.commons.lang.text.StrMatcher strMatcher35 = strTokenizer32.getIgnoredMatcher();
        int int37 = strBuilder21.lastIndexOf(strMatcher35, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher18, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray0, strMatcher35);
        boolean boolean40 = strTokenizer39.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer39.setDelimiterChar('a');
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + "hi!" + "'", obj17.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + obj34 + "' != '" + "hi!" + "'", obj34.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(strTokenizer42);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.append(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int17 = strBuilder12.length();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.deleteAll(strMatcher18);
        int int21 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.replaceFirst('4', ' ');
        int int27 = strBuilder1.lastIndexOf('a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int72 = strBuilder69.lastIndexOf("", (int) 'a');
        int int73 = strBuilder69.size();
        int int75 = strBuilder69.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder69.append(strBuilder76, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder79.replaceFirst(strMatcher80, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder79.delete((int) (short) 0, 100);
        boolean boolean87 = strBuilder85.contains("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) "#4#", (int) '4', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder67.append((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder92);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        char[] charArray15 = strBuilder14.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer23.setDelimiterChar('#');
        java.lang.String[] strArray29 = strTokenizer28.getTokenArray();
        java.lang.Object obj30 = strTokenizer28.next();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer28.getIgnoredMatcher();
        int int33 = strBuilder17.lastIndexOf(strMatcher31, 0);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher31, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.reset("4  a#");
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setEmptyTokenAsNull(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + obj30 + "' != '" + "hi!" + "'", obj30.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray6);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.reset("0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer24.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int32 = strBuilder29.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder29.deleteAll("hi!");
        boolean boolean36 = strBuilder34.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder34.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher43, strMatcher44);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoreEmptyTokens(true);
        boolean boolean50 = strTokenizer47.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer47.setDelimiterChar('#');
        java.lang.String[] strArray53 = strTokenizer52.getTokenArray();
        java.lang.Object obj54 = strTokenizer52.next();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer52.getIgnoredMatcher();
        int int57 = strBuilder41.lastIndexOf(strMatcher55, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder34.replaceAll(strMatcher55, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer27.setQuoteMatcher(strMatcher55);
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher62, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.setIgnoreEmptyTokens(true);
        boolean boolean69 = strTokenizer66.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer66.setDelimiterChar('#');
        java.lang.String[] strArray72 = strTokenizer71.getTokenArray();
        java.lang.Object obj73 = strTokenizer71.next();
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer71.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder78 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher81 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher80, strMatcher81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer84.setIgnoreEmptyTokens(true);
        boolean boolean87 = strTokenizer84.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer84.setDelimiterChar('#');
        java.lang.String[] strArray90 = strTokenizer89.getTokenArray();
        java.lang.Object obj91 = strTokenizer89.next();
        org.apache.commons.lang.text.StrMatcher strMatcher92 = strTokenizer89.getIgnoredMatcher();
        int int94 = strBuilder78.lastIndexOf(strMatcher92, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer95 = strTokenizer71.setTrimmerMatcher(strMatcher92);
        org.apache.commons.lang.text.StrMatcher strMatcher96 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer97 = strTokenizer27.setTrimmerMatcher(strMatcher96);
        org.apache.commons.lang.text.StrMatcher strMatcher98 = strTokenizer97.getDelimiterMatcher();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + "hi!" + "'", obj54.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + "hi!" + "'", obj73.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(strTokenizer89);
        org.junit.Assert.assertNotNull(strArray90);
        org.junit.Assert.assertTrue("'" + obj91 + "' != '" + "hi!" + "'", obj91.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer95);
        org.junit.Assert.assertNotNull(strMatcher96);
        org.junit.Assert.assertNotNull(strTokenizer97);
        org.junit.Assert.assertNotNull(strMatcher98);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        int int19 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        int int22 = strBuilder16.indexOf(strMatcher20, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        char[] charArray33 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder24.appendWithSeparators((java.util.Iterator) strTokenizer36, "#4#");
        boolean boolean39 = strBuilder16.equalsIgnoreCase(strBuilder38);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.deleteFirst('a');
        int int44 = strBuilder41.lastIndexOf(' ', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int16 = strBuilder13.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder13.deleteAll("hi!");
        boolean boolean20 = strBuilder18.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.appendFixedWidthPadLeft(1, 1, '4');
        char[] charArray26 = strBuilder21.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray26, '4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder11.append(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray26);
        java.lang.String str32 = strTokenizer31.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str32.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int12 = strBuilder9.lastIndexOf("", (int) 'a');
        int int13 = strBuilder9.size();
        int int15 = strBuilder9.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder9.append(strBuilder16, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.replaceFirst(strMatcher20, "hi!");
        char[] charArray23 = strBuilder22.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray23, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int30 = strBuilder27.lastIndexOf("", (int) 'a');
        int int31 = strBuilder27.size();
        int int32 = strBuilder27.length();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder27.deleteAll(strMatcher33);
        java.lang.String str36 = strBuilder34.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.deleteFirst('a');
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher40, strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setIgnoreEmptyTokens(true);
        boolean boolean47 = strTokenizer44.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer44.setDelimiterChar('#');
        java.lang.String[] strArray50 = strTokenizer49.getTokenArray();
        java.lang.Object obj51 = strTokenizer49.next();
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer49.getDelimiterMatcher();
        int int53 = strBuilder34.lastIndexOf(strMatcher52);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher52, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer7.setTrimmerMatcher(strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer7.setDelimiterString("10.0");
        int int59 = strTokenizer7.nextIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertTrue("'" + obj51 + "' != '" + "hi!" + "'", obj51.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("0");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder2.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder2.append(10.0d);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj8 = strTokenizer7.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer7.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        char[] charArray21 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray21);
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher23);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder12.appendWithSeparators((java.util.Iterator) strTokenizer24, "#4#");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer24.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer7.setIgnoredMatcher(strMatcher27);
        int int30 = strBuilder6.indexOf(strMatcher27, (-1));
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher27);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.reverse();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(strBuilder6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher14, strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.setIgnoreEmptyTokens(true);
        boolean boolean21 = strTokenizer18.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterChar('#');
        java.lang.String[] strArray24 = strTokenizer23.getTokenArray();
        java.lang.Object obj25 = strTokenizer23.next();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer23.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher26);
        int int29 = strBuilder1.indexOf(strMatcher26, (int) (short) 0);
        int int32 = strBuilder1.lastIndexOf("h!100#################################################################################################14", 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + obj25 + "' != '" + "hi!" + "'", obj25.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        char[] charArray5 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoredMatcher(strMatcher10);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher15, strMatcher16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer17.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(true);
        boolean boolean22 = strTokenizer19.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer19.setDelimiterChar('#');
        java.lang.String[] strArray25 = strTokenizer24.getTokenArray();
        java.lang.Object obj26 = strTokenizer24.next();
        org.apache.commons.lang.text.StrMatcher strMatcher27 = strTokenizer24.getIgnoredMatcher();
        int int29 = strBuilder13.lastIndexOf(strMatcher27, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int33 = strBuilder31.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int41 = strBuilder38.lastIndexOf("", (int) 'a');
        int int42 = strBuilder38.size();
        int int44 = strBuilder38.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder38.append(strBuilder45, (int) (short) 1, (int) '#');
        int int50 = strBuilder38.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder38.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int59 = strBuilder56.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder56.deleteAll("hi!");
        boolean boolean63 = strBuilder61.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder61.clear();
        boolean boolean65 = strBuilder54.equalsIgnoreCase(strBuilder61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strBuilder61.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder36.append(strBuilder61);
        java.lang.String str68 = strBuilder36.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder36.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder35.append(strBuilder36);
        boolean boolean72 = strBuilder13.equalsIgnoreCase(strBuilder71);
        int int73 = strBuilder71.length();
        org.apache.commons.lang.text.StrMatcher strMatcher75 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer76.setQuoteChar(' ');
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer78.getTrimmerMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder71.replaceFirst(strMatcher79, "#4#");
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer9.setDelimiterMatcher(strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setEmptyTokenAsNull(true);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + obj26 + "' != '" + "hi!" + "'", obj26.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strTokenizer84);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strBuilder1.asTokenizer();
        int int8 = strTokenizer7.nextIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer7.reset("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer7.setIgnoredChar('e');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer7.setIgnoreEmptyTokens(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        char[] charArray5 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        try {
            strTokenizer9.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj1 = strTokenizer0.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer0.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer3.reset();
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertNotNull(strTokenizer4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher4, strMatcher5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer6.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.setIgnoreEmptyTokens(true);
        boolean boolean11 = strTokenizer8.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer8.setDelimiterChar('#');
        java.lang.String[] strArray14 = strTokenizer13.getTokenArray();
        java.lang.Object obj15 = strTokenizer13.next();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer13.getIgnoredMatcher();
        int int18 = strBuilder2.lastIndexOf(strMatcher16, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int23 = strBuilder20.lastIndexOf("", (int) 'a');
        char[] charArray29 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder20.appendWithSeparators((java.util.Iterator) strTokenizer32, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder34.deleteFirst("#4# a#4#org.apache.commons.lang.text.StrMatcher$NoMa");
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher41, strMatcher42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.setIgnoreEmptyTokens(true);
        boolean boolean48 = strTokenizer45.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer45.setDelimiterChar('#');
        java.lang.String[] strArray51 = strTokenizer50.getTokenArray();
        java.lang.Object obj52 = strTokenizer50.next();
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer50.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher53);
        int int56 = strBuilder38.lastIndexOf(strMatcher53, 97);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("       100", strMatcher16, strMatcher53);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + "hi!" + "'", obj15.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + obj52 + "' != '" + "hi!" + "'", obj52.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int20 = strBuilder17.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder17.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int30 = strBuilder27.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.deleteAll("hi!");
        boolean boolean34 = strBuilder32.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int40 = strBuilder37.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer41 = strBuilder37.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder17.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder15.append(strBuilder43);
        char[] charArray45 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.append(charArray45);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.appendNull();
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher52);
        java.lang.String str54 = strTokenizer53.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer53.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("4a  ", strMatcher55);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder49.deleteFirst(strMatcher55);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strBuilder57);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        boolean boolean8 = strTokenizer5.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer5.setDelimiterChar('#');
        java.lang.String str11 = strTokenizer5.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer5.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((int) (short) 0, (int) (short) 0, '4');
        char[] charArray21 = new char[] { '4' };
        char[] charArray22 = strBuilder19.getChars(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer5.reset(charArray21);
        java.lang.Object obj24 = strTokenizer23.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer23.setDelimiterString("\n");
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(strTokenizer26);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        java.lang.String str7 = strBuilder1.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int18 = strBuilder12.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder12.append(strBuilder19, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceFirst(strMatcher23, "hi!");
        char[] charArray26 = strBuilder25.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray26);
        char[] charArray29 = strBuilder10.getChars(charArray26);
        int int32 = strBuilder10.indexOf("hi!", 10);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder10.setNullText("0");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int22 = strBuilder19.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.append(strBuilder19);
        char[] charArray26 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setIgnoreEmptyTokens(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.replaceFirst(' ', 'a');
        java.lang.String str34 = strBuilder28.substring((int) (short) 0, 56);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int11 = strBuilder8.lastIndexOf("", (int) 'a');
        int int12 = strBuilder8.size();
        int int14 = strBuilder8.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder8.append(strBuilder15, (int) (short) 1, (int) '#');
        int int20 = strBuilder8.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder8.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.deleteAll("hi!");
        boolean boolean33 = strBuilder31.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.clear();
        boolean boolean35 = strBuilder24.equalsIgnoreCase(strBuilder31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strBuilder31.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder6.append(strBuilder31);
        java.lang.String str38 = strBuilder6.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder6.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder5.append(strBuilder6);
        char[] charArray45 = new char[] { 'e', '4' };
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder41.insert((-1), charArray45, 6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray45);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft(1, 1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.append(' ');
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher17, strMatcher18);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        boolean boolean24 = strTokenizer21.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer21.setDelimiterChar('#');
        java.lang.Object obj27 = strTokenizer21.clone();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder9.appendWithSeparators((java.util.Iterator) strTokenizer21, "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder9.append((double) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.replaceFirst("1", "");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("false ");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        boolean boolean14 = strTokenizer11.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setDelimiterChar('#');
        java.lang.String[] strArray17 = strTokenizer16.getTokenArray();
        java.lang.Object obj18 = strTokenizer16.next();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.append((java.lang.Object) strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.replaceFirst('4', 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + "hi!" + "'", obj18.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        int int1 = strTokenizer0.nextIndex();
        java.lang.String str2 = strTokenizer0.nextToken();
        try {
            strTokenizer0.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher3, strMatcher4);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.setIgnoreEmptyTokens(true);
        boolean boolean10 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer7.setDelimiterChar('#');
        java.lang.String[] strArray13 = strTokenizer12.getTokenArray();
        java.lang.Object obj14 = strTokenizer12.next();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer12.getIgnoredMatcher();
        int int17 = strBuilder1.lastIndexOf(strMatcher15, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder19.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int47 = strBuilder44.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder44.deleteAll("hi!");
        boolean boolean51 = strBuilder49.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.clear();
        boolean boolean53 = strBuilder42.equalsIgnoreCase(strBuilder49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder49.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder24.append(strBuilder49);
        java.lang.String str56 = strBuilder24.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder24.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder23.append(strBuilder24);
        boolean boolean60 = strBuilder1.equalsIgnoreCase(strBuilder59);
        char[] charArray65 = new char[] { '#', '#', '4', 'a' };
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.append(charArray65);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder1.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder1.append(' ');
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        int int20 = strBuilder16.size();
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.append((double) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder16.clear();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder16.insert(56, 'e');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 56");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int20 = strBuilder17.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder17.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int30 = strBuilder27.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder27.deleteAll("hi!");
        boolean boolean34 = strBuilder32.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int40 = strBuilder37.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer41 = strBuilder37.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder35.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder17.append(stringBuffer41);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder15.append(strBuilder43);
        char[] charArray45 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder43.append(charArray45);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.deleteAll('a');
        int int50 = strBuilder48.lastIndexOf("#4#");
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj53 = strTokenizer52.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer52.setDelimiterChar('a');
        boolean boolean56 = strTokenizer55.isEmptyTokenAsNull();
        java.lang.String str57 = strTokenizer55.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder48.insert(0, (java.lang.Object) str57);
        java.lang.String str59 = strBuilder48.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        int int62 = strBuilder48.indexOf(strMatcher60, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        int int19 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.appendPadding(0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.deleteFirst('e');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int31 = strBuilder28.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.deleteAll("hi!");
        boolean boolean35 = strBuilder33.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder33.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder33.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder33.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int46 = strBuilder43.lastIndexOf("", (int) 'a');
        int int47 = strBuilder43.size();
        int int49 = strBuilder43.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder33.append(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder43.append((double) (byte) 100);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder26.append(strBuilder43, 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: length must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder11.deleteAll("hi!");
        boolean boolean18 = strBuilder16.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer25 = strBuilder21.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder19.append(stringBuffer25);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder1.append(stringBuffer25);
        java.lang.StringBuffer stringBuffer28 = strBuilder27.toStringBuffer();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher31, strMatcher32);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer33.reset("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int42 = strBuilder39.lastIndexOf("", (int) 'a');
        int int43 = strBuilder39.size();
        int int45 = strBuilder39.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder39.append(strBuilder46, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.replaceFirst(strMatcher50, "hi!");
        char[] charArray53 = strBuilder52.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer33.reset(charArray53);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder27.insert((int) (byte) 0, charArray53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray53, "444");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(stringBuffer28);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strBuilder56);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft(1, 1, '4');
        char[] charArray14 = strBuilder9.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray14, '4', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray14, '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        char[] charArray5 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoredMatcher(strMatcher10);
        int int12 = strTokenizer9.size();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int17 = strBuilder14.lastIndexOf("", (int) 'a');
        int int18 = strBuilder14.size();
        int int20 = strBuilder14.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder14.append(strBuilder21, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.replaceFirst(strMatcher25, "hi!");
        char[] charArray28 = strBuilder27.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher32, strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoreEmptyTokens(true);
        boolean boolean39 = strTokenizer36.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer36.setDelimiterChar('#');
        java.lang.String[] strArray42 = strTokenizer41.getTokenArray();
        java.lang.Object obj43 = strTokenizer41.next();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer41.getIgnoredMatcher();
        int int46 = strBuilder30.lastIndexOf(strMatcher44, 0);
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray28, strMatcher44, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer9.setDelimiterMatcher(strMatcher47);
        java.lang.String str50 = strTokenizer49.getContent();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + obj43 + "' != '" + "hi!" + "'", obj43.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "#4# a" + "'", str50.equals("#4# a"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.ensureCapacity((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int18 = strBuilder15.lastIndexOf("", (int) 'a');
        int int19 = strBuilder15.size();
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder15.append(strBuilder22, (int) (short) 1, (int) '#');
        int int27 = strBuilder15.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder15.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int36 = strBuilder33.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder33.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder15.append(strBuilder33);
        char[] charArray40 = strBuilder15.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray40, 'a');
        char[] charArray44 = strBuilder12.getChars(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray40, 'a', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer(charArray40, '4', 'e');
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray40, 'e', '4');
        int int54 = strTokenizer53.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!##4a", 'e');
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int22 = strBuilder19.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder1.append(strBuilder19);
        char[] charArray26 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray26, 'a', 'e');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        int int19 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.append((long) (short) 0);
        java.lang.String str24 = strBuilder21.midString(6, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        boolean boolean11 = strBuilder6.startsWith("hi!");
        int int14 = strBuilder6.lastIndexOf("\n", 56);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder18.lastIndexOf("", (int) 'a');
        int int22 = strBuilder18.size();
        int int24 = strBuilder18.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder18.append(strBuilder25, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.replaceFirst(strMatcher29, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.append((float) 1);
        int int35 = strBuilder33.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append(false);
        boolean boolean41 = strBuilder37.equalsIgnoreCase(strBuilder38);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int46 = strBuilder43.lastIndexOf("", (int) 'a');
        int int47 = strBuilder43.size();
        int int49 = strBuilder43.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder43.append(strBuilder50, (int) (short) 1, (int) '#');
        int int55 = strBuilder43.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder43.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str62 = strBuilder43.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder43.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder38.append(strBuilder64);
        char[] charArray71 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher73 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher73);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder64.append(charArray71);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder33.append(charArray71);
        org.apache.commons.lang.text.StrMatcher strMatcher78 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher78, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setIgnoreEmptyTokens(true);
        boolean boolean85 = strTokenizer82.isIgnoreEmptyTokens();
        java.lang.String str86 = strTokenizer82.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher87 = strTokenizer82.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer(charArray71, strMatcher87);
        try {
            strBuilder6.getChars((int) (byte) 1, 18, charArray71, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 18");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str86.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strMatcher87);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((float) 1);
        int int18 = strBuilder16.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append(false);
        boolean boolean24 = strBuilder20.equalsIgnoreCase(strBuilder21);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str45 = strBuilder26.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder26.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder21.append(strBuilder47);
        char[] charArray54 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder47.append(charArray54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder16.append(charArray54);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int64 = strBuilder61.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder61.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder61.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int74 = strBuilder71.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder71.deleteAll("hi!");
        boolean boolean78 = strBuilder76.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder76.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder81 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int84 = strBuilder81.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer85 = strBuilder81.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder79.append(stringBuffer85);
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder61.append(stringBuffer85);
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder16.append(stringBuffer85);
        boolean boolean90 = strBuilder16.startsWith("#4# a#4#org.apache.commons.lang.text.StrMatcher$NoMa");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer85);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        int int20 = strBuilder16.size();
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder16.appendPadding((int) (byte) 10, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder26.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.deleteFirst(' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.appendFixedWidthPadLeft(1, 1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append(true);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadRight((int) '#', 52, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.replaceAll("#4#", "44444444444444444444444444444497");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.replaceFirst(' ', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.replaceFirst("", "StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder34.clear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder35);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append("#4#");
        int int18 = strBuilder15.length();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("1.0");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int5 = strBuilder2.lastIndexOf("", (int) 'a');
        int int6 = strBuilder2.size();
        int int8 = strBuilder2.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder2.append(strBuilder9, (int) (short) 1, (int) '#');
        int int14 = strBuilder2.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder2.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int23 = strBuilder20.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder20.deleteAll("hi!");
        boolean boolean27 = strBuilder25.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.clear();
        boolean boolean29 = strBuilder18.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strBuilder25.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.append(strBuilder25);
        java.lang.String str32 = strBuilder0.toString();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder0.replace((int) 'a', (int) (short) 1, "                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((float) 1);
        int int18 = strBuilder16.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append(false);
        boolean boolean24 = strBuilder20.equalsIgnoreCase(strBuilder21);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str45 = strBuilder26.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder26.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder21.append(strBuilder47);
        char[] charArray54 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder47.append(charArray54);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder16.append(charArray54);
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.setIgnoreEmptyTokens(true);
        boolean boolean68 = strTokenizer65.isIgnoreEmptyTokens();
        java.lang.String str69 = strTokenizer65.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer65.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher70);
        org.apache.commons.lang.text.StrMatcher strMatcher73 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher74 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher73, strMatcher74);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.setIgnoreEmptyTokens(true);
        boolean boolean80 = strTokenizer77.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer77.setDelimiterChar('#');
        int int83 = strTokenizer77.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer77.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer77.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher88 = strTokenizer77.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer71.setIgnoredMatcher(strMatcher88);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str69.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strMatcher88);
        org.junit.Assert.assertNotNull(strTokenizer89);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder2.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.replaceFirst("", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.appendFixedWidthPadLeft((java.lang.Object) "", 0, 'a');
        java.lang.String str11 = strBuilder0.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int16 = strBuilder13.lastIndexOf("", (int) 'a');
        int int17 = strBuilder13.size();
        int int18 = strBuilder13.length();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder13.deleteAll(strMatcher19);
        int int22 = strBuilder13.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        int int28 = strBuilder24.size();
        int int29 = strBuilder24.length();
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder24.deleteAll(strMatcher30);
        int int33 = strBuilder24.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder13.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append((float) 1L);
        int int38 = strBuilder36.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.setNewLineText("0hi!");
        boolean boolean41 = strBuilder0.equals(strBuilder36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        boolean boolean1 = strBuilder0.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int6 = strBuilder3.lastIndexOf("", (int) 'a');
        int int7 = strBuilder3.size();
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(true);
        boolean boolean18 = strTokenizer15.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer15.setDelimiterChar('#');
        java.lang.String[] strArray21 = strTokenizer20.getTokenArray();
        java.lang.Object obj22 = strTokenizer20.next();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer20.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer20.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoreEmptyTokens(true);
        boolean boolean36 = strTokenizer33.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer33.setDelimiterChar('#');
        java.lang.String[] strArray39 = strTokenizer38.getTokenArray();
        java.lang.Object obj40 = strTokenizer38.next();
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer38.getIgnoredMatcher();
        int int43 = strBuilder27.lastIndexOf(strMatcher41, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer20.setTrimmerMatcher(strMatcher41);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.setIgnoreEmptyTokens(true);
        boolean boolean55 = strTokenizer52.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer52.setDelimiterChar('#');
        java.lang.String[] strArray58 = strTokenizer57.getTokenArray();
        java.lang.Object obj59 = strTokenizer57.next();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer57.getIgnoredMatcher();
        int int62 = strBuilder46.lastIndexOf(strMatcher60, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher41, strMatcher60);
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strMatcher41, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder66.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder69.insert((int) (byte) 100, true);
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder0.append(strBuilder72, (int) '#', 0);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder75.setLength((int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder77.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder78.insert(0, 7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + "hi!" + "'", obj40.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + obj59 + "' != '" + "hi!" + "'", obj59.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strBuilder81);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder2.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.replaceFirst("", "");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.appendFixedWidthPadLeft((java.lang.Object) "", 0, 'a');
        char[] charArray16 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray16);
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher18);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.deleteAll("hi!");
        boolean boolean28 = strBuilder26.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.setIgnoreEmptyTokens(true);
        boolean boolean42 = strTokenizer39.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer39.setDelimiterChar('#');
        java.lang.String[] strArray45 = strTokenizer44.getTokenArray();
        java.lang.Object obj46 = strTokenizer44.next();
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        int int49 = strBuilder33.lastIndexOf(strMatcher47, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder26.replaceAll(strMatcher47, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher55, strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer57.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer59.setIgnoreEmptyTokens(true);
        boolean boolean62 = strTokenizer59.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer59.setDelimiterChar('#');
        java.lang.String[] strArray65 = strTokenizer64.getTokenArray();
        java.lang.Object obj66 = strTokenizer64.next();
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer64.getIgnoredMatcher();
        int int69 = strBuilder53.lastIndexOf(strMatcher67, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray16, strMatcher47, strMatcher67);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder0.deleteFirst(strMatcher47);
        java.lang.Class<?> wildcardClass72 = strBuilder0.getClass();
        int int75 = strBuilder0.indexOf('#', 97);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder0.replaceAll(' ', 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + "hi!" + "'", obj46.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertTrue("'" + obj66 + "' != '" + "hi!" + "'", obj66.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        boolean boolean8 = strTokenizer5.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer5.setDelimiterChar('#');
        java.lang.String str11 = strTokenizer5.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer5.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.appendFixedWidthPadLeft((int) (short) 0, (int) (short) 0, '4');
        char[] charArray21 = new char[] { '4' };
        char[] charArray22 = strBuilder19.getChars(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer5.reset(charArray21);
        java.lang.Object obj24 = strTokenizer23.clone();
        java.lang.String str25 = strTokenizer23.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer23.reset();
        boolean boolean27 = strTokenizer23.isEmptyTokenAsNull();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "4" + "'", str25.equals("4"));
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder6.insert(0, (java.lang.Object) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder6.ensureCapacity((int) (byte) 1);
        java.lang.String str16 = strBuilder15.getNewLineText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        int int19 = strBuilder16.capacity();
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        int int22 = strBuilder16.indexOf(strMatcher20, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder16.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.deleteAll("hi!");
        boolean boolean33 = strBuilder31.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder31.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder31.appendFixedWidthPadRight((int) (short) 10, (int) (byte) -1, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder31.append((int) '4');
        boolean boolean43 = strBuilder24.equals(strBuilder42);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int72 = strBuilder69.lastIndexOf("", (int) 'a');
        int int73 = strBuilder69.size();
        int int75 = strBuilder69.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder76 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder69.append(strBuilder76, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder79.replaceFirst(strMatcher80, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder79.delete((int) (short) 0, 100);
        boolean boolean87 = strBuilder85.contains("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder67.appendFixedWidthPadLeft((java.lang.Object) "#4#", (int) '4', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder90.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder90.appendNull();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(strBuilder92);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        boolean boolean16 = strTokenizer13.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setDelimiterChar('#');
        java.lang.String[] strArray19 = strTokenizer18.getTokenArray();
        java.lang.Object obj20 = strTokenizer18.next();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer18.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer18.setDelimiterString("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        int int41 = strBuilder25.lastIndexOf(strMatcher39, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer18.setTrimmerMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoreEmptyTokens(true);
        boolean boolean53 = strTokenizer50.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterChar('#');
        java.lang.String[] strArray56 = strTokenizer55.getTokenArray();
        java.lang.Object obj57 = strTokenizer55.next();
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        int int60 = strBuilder44.lastIndexOf(strMatcher58, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strMatcher39, 100, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder64.insert((int) (byte) 10, (long) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder64.append((long) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder69.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder70.setCharAt(0, ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "hi!" + "'", obj20.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertTrue("'" + obj57 + "' != '" + "hi!" + "'", obj57.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder73);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.io.Writer writer18 = strBuilder17.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.replaceAll('e', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher24);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setIgnoreEmptyTokens(true);
        boolean boolean34 = strTokenizer31.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterChar('#');
        java.lang.String[] strArray37 = strTokenizer36.getTokenArray();
        java.lang.Object obj38 = strTokenizer36.next();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = strTokenizer36.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer25.setIgnoredMatcher(strMatcher39);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher44 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher44, strMatcher45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setIgnoreEmptyTokens(true);
        boolean boolean51 = strTokenizer48.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer48.setDelimiterChar('#');
        java.lang.String[] strArray54 = strTokenizer53.getTokenArray();
        java.lang.Object obj55 = strTokenizer53.next();
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer53.getIgnoredMatcher();
        int int58 = strBuilder42.lastIndexOf(strMatcher56, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher39, strMatcher56);
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder17.deleteFirst(strMatcher39);
        java.lang.StringBuffer stringBuffer61 = strBuilder60.toStringBuffer();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(writer18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + "hi!" + "'", obj55.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(stringBuffer61);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        char[] charArray15 = strBuilder14.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer23.setDelimiterChar('#');
        java.lang.String[] strArray29 = strTokenizer28.getTokenArray();
        java.lang.Object obj30 = strTokenizer28.next();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer28.getIgnoredMatcher();
        int int33 = strBuilder17.lastIndexOf(strMatcher31, 0);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher31, strMatcher34);
        java.lang.String[] strArray36 = strTokenizer35.getTokenArray();
        int int37 = strTokenizer35.previousIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + obj30 + "' != '" + "hi!" + "'", obj30.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int11 = strBuilder8.lastIndexOf("", (int) 'a');
        int int12 = strBuilder8.size();
        int int14 = strBuilder8.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder8.append(strBuilder15, (int) (short) 1, (int) '#');
        int int20 = strBuilder8.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder8.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder8.clear();
        boolean boolean26 = strBuilder1.equals((java.lang.Object) strBuilder25);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder1.deleteAll('4');
        char[] charArray34 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray34, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher39);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer40.getDelimiterMatcher();
        int int43 = strBuilder28.indexOf(strMatcher41, 85);
        char[] charArray45 = null;
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder28.insert(97, charArray45, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 97");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        int int8 = strBuilder6.indexOf("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strBuilder6.asTokenizer();
        java.lang.String str10 = strBuilder6.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder6.append(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        java.lang.String str10 = strBuilder8.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.appendFixedWidthPadRight((int) (short) 100, 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.insert(6, (float) 85);
        java.io.Writer writer20 = strBuilder19.asWriter();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(writer20);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder18.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder18.deleteAll("hi!");
        boolean boolean25 = strBuilder23.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.clear();
        int int28 = strBuilder26.indexOf("#4#");
        java.io.Writer writer29 = strBuilder26.asWriter();
        char[] charArray36 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder26.insert(0, charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer41.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int49 = strBuilder46.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.deleteAll("hi!");
        boolean boolean53 = strBuilder51.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder51.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher60, strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        boolean boolean67 = strTokenizer64.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer64.setDelimiterChar('#');
        java.lang.String[] strArray70 = strTokenizer69.getTokenArray();
        java.lang.Object obj71 = strTokenizer69.next();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer69.getIgnoredMatcher();
        int int74 = strBuilder58.lastIndexOf(strMatcher72, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder51.replaceAll(strMatcher72, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer44.setQuoteMatcher(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder9.deleteAll(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder78.minimizeCapacity();
        char[] charArray82 = strBuilder79.toCharArray((int) (short) 0, 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertTrue("'" + obj71 + "' != '" + "hi!" + "'", obj71.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(charArray82);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder17.appendWithSeparators((java.util.Iterator) strTokenizer23, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder28.replaceFirst(' ', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.replaceFirst("", "StrTokenizer[hi!]");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder31.deleteAll(' ');
        int int38 = strBuilder36.lastIndexOf("0");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        char[] charArray12 = strBuilder11.toCharArray();
        int int14 = strBuilder11.indexOf("0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.deleteAll("hi!");
        boolean boolean23 = strBuilder21.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.clear();
        int int26 = strBuilder24.indexOf("#4#");
        java.io.Writer writer27 = strBuilder24.asWriter();
        char[] charArray34 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher36);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder24.insert(0, charArray34);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder24.setLength(100);
        java.util.Collection collection41 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder24.appendWithSeparators(collection41, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.append(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append("StrTokenizer[hi!]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(writer27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.deleteFirst('#');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append("#");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int3 = strBuilder1.indexOf('#');
        boolean boolean5 = strBuilder1.endsWith("");
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        boolean boolean8 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int13 = strBuilder10.lastIndexOf("", (int) 'a');
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder10.appendWithSeparators((java.util.Iterator) strTokenizer22, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder26.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int39 = strBuilder36.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder36.deleteAll("hi!");
        boolean boolean43 = strBuilder41.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder41.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int49 = strBuilder46.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer50 = strBuilder46.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder44.append(stringBuffer50);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder26.append(stringBuffer50);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder24.append(strBuilder52);
        char[] charArray54 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder52.append(charArray54);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder55.ensureCapacity(0);
        org.apache.commons.lang.text.StrMatcher strMatcher59 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher59, strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer61.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer61.setEmptyTokenAsNull(false);
        int int66 = strTokenizer61.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer61.setQuoteChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer61.reset("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder55.appendWithSeparators((java.util.Iterator) strTokenizer61, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder74 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher77 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher76, strMatcher77);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer78.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoreEmptyTokens(true);
        boolean boolean83 = strTokenizer80.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer80.setDelimiterChar('#');
        java.lang.String[] strArray86 = strTokenizer85.getTokenArray();
        java.lang.Object obj87 = strTokenizer85.next();
        org.apache.commons.lang.text.StrMatcher strMatcher88 = strTokenizer85.getIgnoredMatcher();
        int int90 = strBuilder74.lastIndexOf(strMatcher88, 0);
        boolean boolean91 = strBuilder55.contains(strMatcher88);
        org.apache.commons.lang.text.StrTokenizer strTokenizer92 = strTokenizer7.setTrimmerMatcher(strMatcher88);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer50);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertTrue("'" + obj87 + "' != '" + "hi!" + "'", obj87.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(strTokenizer92);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int23 = strBuilder20.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder20.deleteAll("hi!");
        boolean boolean27 = strBuilder25.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.clear();
        int int30 = strBuilder28.indexOf("#4#");
        java.io.Writer writer31 = strBuilder28.asWriter();
        char[] charArray38 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray38);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray38, strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder28.insert(0, charArray38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder18.append(charArray38);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.insert((int) (byte) 10, ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(writer31);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer3.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher11, strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer13.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strTokenizer15.setIgnoreEmptyTokens(true);
        boolean boolean18 = strTokenizer15.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer15.setDelimiterChar('#');
        java.lang.String[] strArray21 = strTokenizer20.getTokenArray();
        java.lang.Object obj22 = strTokenizer20.next();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = strTokenizer20.getIgnoredMatcher();
        int int25 = strBuilder9.lastIndexOf(strMatcher23, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer7.setDelimiterMatcher(strMatcher23);
        boolean boolean27 = strTokenizer7.hasPrevious();
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer7.setTrimmerMatcher(strMatcher28);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strTokenizer29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("d4f6", '#', 'a');
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.ensureCapacity((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int18 = strBuilder15.lastIndexOf("", (int) 'a');
        int int19 = strBuilder15.size();
        int int21 = strBuilder15.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder15.append(strBuilder22, (int) (short) 1, (int) '#');
        int int27 = strBuilder15.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder15.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int36 = strBuilder33.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder33.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder15.append(strBuilder33);
        char[] charArray40 = strBuilder15.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray40, 'a');
        char[] charArray44 = strBuilder12.getChars(charArray40);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder12.appendNewLine();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(strBuilder45);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray19, "h!100#################################################################################################14");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer25);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("false ", 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setIgnoredChar('a');
        org.junit.Assert.assertNotNull(strTokenizer4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        int int20 = strBuilder16.size();
        int int22 = strBuilder16.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder16.append((double) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder16.clear();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.delete(3, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("#", ' ', '#');
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("1.0", "");
        org.apache.commons.lang.text.StrMatcher strMatcher3 = strTokenizer2.getQuoteMatcher();
        org.junit.Assert.assertNotNull(strMatcher3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("1", " ");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        char[] charArray12 = strBuilder11.toCharArray();
        int int14 = strBuilder11.indexOf("0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int19 = strBuilder16.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.deleteAll("hi!");
        boolean boolean23 = strBuilder21.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.clear();
        int int26 = strBuilder24.indexOf("#4#");
        java.io.Writer writer27 = strBuilder24.asWriter();
        char[] charArray34 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray34);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher36);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder24.insert(0, charArray34);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder24.setLength(100);
        java.util.Collection collection41 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder24.appendWithSeparators(collection41, "");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder11.append(strBuilder43);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder44.replaceAll("       100", "0hi!");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(writer27);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        char[] charArray5 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoredMatcher(strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.reset("0.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer9.reset();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("#4#");
        java.lang.String str2 = strTokenizer1.previousToken();
        java.lang.String[] strArray3 = strTokenizer1.getTokenArray();
        boolean boolean4 = strTokenizer1.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer1.reset();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strTokenizer5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        boolean boolean8 = strTokenizer5.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer5.setDelimiterChar('#');
        java.lang.String str11 = strTokenizer5.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer5.setEmptyTokenAsNull(false);
        java.lang.String str14 = strTokenizer5.nextToken();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.appendFixedWidthPadLeft((int) (short) 0, (int) (short) 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.insert((int) (byte) 0, (double) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int13 = strBuilder10.lastIndexOf("", (int) 'a');
        int int14 = strBuilder10.size();
        int int16 = strBuilder10.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder10.append(strBuilder17, (int) (short) 1, (int) '#');
        int int22 = strBuilder10.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder10.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int31 = strBuilder28.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder10.append(strBuilder28);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder1.appendFixedWidthPadLeft((java.lang.Object) strBuilder10, 32, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder10.deleteAll('a');
        int int41 = strBuilder39.lastIndexOf("d4f6");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int5 = strBuilder2.lastIndexOf("", (int) 'a');
        int int6 = strBuilder2.size();
        int int8 = strBuilder2.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder2.append(strBuilder9, (int) (short) 1, (int) '#');
        int int14 = strBuilder2.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder2.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int23 = strBuilder20.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder20.deleteAll("hi!");
        boolean boolean27 = strBuilder25.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.clear();
        boolean boolean29 = strBuilder18.equalsIgnoreCase(strBuilder25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strBuilder25.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder0.append(strBuilder25);
        java.lang.String str32 = strBuilder0.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder0.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append((double) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int42 = strBuilder39.lastIndexOf("", (int) 'a');
        int int43 = strBuilder39.size();
        int int45 = strBuilder39.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder39.append(strBuilder46, (int) (short) 1, (int) '#');
        int int51 = strBuilder39.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder39.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int60 = strBuilder57.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder57.deleteAll("hi!");
        boolean boolean64 = strBuilder62.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder62.clear();
        boolean boolean66 = strBuilder55.equalsIgnoreCase(strBuilder62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strBuilder62.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder37.append(strBuilder62);
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder37.reverse();
        java.lang.StringBuffer stringBuffer70 = strBuilder69.toStringBuffer();
        java.lang.Class<?> wildcardClass71 = stringBuffer70.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder34.append(stringBuffer70);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(stringBuffer70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(strBuilder72);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher3, strMatcher4);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.setIgnoreEmptyTokens(true);
        boolean boolean10 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer7.setDelimiterChar('#');
        java.lang.String[] strArray13 = strTokenizer12.getTokenArray();
        java.lang.Object obj14 = strTokenizer12.next();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer12.getIgnoredMatcher();
        int int17 = strBuilder1.lastIndexOf(strMatcher15, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder19.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int47 = strBuilder44.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder44.deleteAll("hi!");
        boolean boolean51 = strBuilder49.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.clear();
        boolean boolean53 = strBuilder42.equalsIgnoreCase(strBuilder49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder49.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder24.append(strBuilder49);
        java.lang.String str56 = strBuilder24.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder24.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder23.append(strBuilder24);
        boolean boolean60 = strBuilder1.equalsIgnoreCase(strBuilder59);
        char[] charArray65 = new char[] { '#', '#', '4', 'a' };
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.append(charArray65);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder66.deleteFirst(' ');
        java.lang.String str70 = strBuilder66.leftString(56);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder66.clear();
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!##4a" + "'", str70.equals("hi!##4a"));
        org.junit.Assert.assertNotNull(strBuilder71);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.insert((int) ' ', '#');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 32");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        int int17 = strBuilder14.lastIndexOf('a', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.setNullText("hi!");
        int int24 = strBuilder21.lastIndexOf("#4#", (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.insert(0, (float) 4);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int32 = strBuilder29.lastIndexOf("", (int) 'a');
        int int33 = strBuilder29.size();
        int int35 = strBuilder29.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder29.append(strBuilder36, (int) (short) 1, (int) '#');
        int int41 = strBuilder29.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder29.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher47, strMatcher48);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer51.setIgnoreEmptyTokens(true);
        boolean boolean54 = strTokenizer51.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder45.appendWithSeparators((java.util.Iterator) strTokenizer51, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer51.setQuoteChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder27.appendWithSeparators((java.util.Iterator) strTokenizer58, "false ");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder62.append((float) (short) -1);
        try {
            java.lang.String str67 = strBuilder64.substring(32, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder6.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder6.replaceAll('#', '4');
        java.lang.Class<?> wildcardClass15 = strBuilder6.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        int int1 = strTokenizer0.size();
        java.lang.Class<?> wildcardClass2 = strTokenizer0.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher4, strMatcher5);
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer6.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer8.setIgnoreEmptyTokens(true);
        boolean boolean11 = strTokenizer8.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer8.setDelimiterChar('#');
        java.lang.String[] strArray14 = strTokenizer13.getTokenArray();
        java.lang.Object obj15 = strTokenizer13.next();
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer13.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer13.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.reset("10.0");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        char[] charArray33 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder24.appendWithSeparators((java.util.Iterator) strTokenizer36, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int44 = strBuilder42.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.append(10.0d);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher49);
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher53 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher52, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.setIgnoreEmptyTokens(true);
        boolean boolean59 = strTokenizer56.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer56.setDelimiterChar('#');
        java.lang.String[] strArray62 = strTokenizer61.getTokenArray();
        java.lang.Object obj63 = strTokenizer61.next();
        org.apache.commons.lang.text.StrMatcher strMatcher64 = strTokenizer61.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer50.setIgnoredMatcher(strMatcher64);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher70 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher69, strMatcher70);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setIgnoreEmptyTokens(true);
        boolean boolean76 = strTokenizer73.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer73.setDelimiterChar('#');
        java.lang.String[] strArray79 = strTokenizer78.getTokenArray();
        java.lang.Object obj80 = strTokenizer78.next();
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer78.getIgnoredMatcher();
        int int83 = strBuilder67.lastIndexOf(strMatcher81, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher64, strMatcher81);
        int int86 = strBuilder46.lastIndexOf(strMatcher64, 3);
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder38.append((java.lang.Object) strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer22.setIgnoredMatcher(strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = strTokenizer0.setQuoteMatcher(strMatcher64);
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + "hi!" + "'", obj15.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertTrue("'" + obj63 + "' != '" + "hi!" + "'", obj63.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher64);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertNotNull(strArray79);
        org.junit.Assert.assertTrue("'" + obj80 + "' != '" + "hi!" + "'", obj80.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strTokenizer89);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("false ", 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher4);
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher7, strMatcher8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setIgnoreEmptyTokens(true);
        boolean boolean14 = strTokenizer11.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setDelimiterChar('#');
        java.lang.String[] strArray17 = strTokenizer16.getTokenArray();
        java.lang.Object obj18 = strTokenizer16.next();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer5.setIgnoredMatcher(strMatcher19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer20.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer2.setTrimmerMatcher(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + "hi!" + "'", obj18.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer22);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int17 = strBuilder12.length();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.deleteAll(strMatcher18);
        int int21 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append((float) 1L);
        int int26 = strBuilder24.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.setNewLineText("0hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher30, strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setIgnoreEmptyTokens(true);
        boolean boolean37 = strTokenizer34.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer34.setDelimiterChar('#');
        java.lang.String[] strArray40 = strTokenizer39.getTokenArray();
        java.lang.Object obj41 = strTokenizer39.next();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer39.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder24.appendWithSeparators((java.util.Iterator) strTokenizer39, "4a  ");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder24.insert(0, (double) 52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertTrue("'" + obj41 + "' != '" + "hi!" + "'", obj41.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder47);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        boolean boolean13 = strBuilder9.contains('a');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.insert((-1), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteAll(strMatcher7);
        int int10 = strBuilder1.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int15 = strBuilder12.lastIndexOf("", (int) 'a');
        int int16 = strBuilder12.size();
        int int17 = strBuilder12.length();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.deleteAll(strMatcher18);
        int int21 = strBuilder12.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append((java.lang.Object) "");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append((float) 1L);
        int int26 = strBuilder24.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.setNewLineText("0hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.deleteFirst(strMatcher29);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int35 = strBuilder32.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder32.deleteAll("hi!");
        boolean boolean39 = strBuilder37.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int45 = strBuilder42.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer46 = strBuilder42.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder40.append(stringBuffer46);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int52 = strBuilder49.lastIndexOf("", (int) 'a');
        int int53 = strBuilder49.size();
        int int55 = strBuilder49.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder56 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder49.append(strBuilder56, (int) (short) 1, (int) '#');
        int int61 = strBuilder49.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder49.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        boolean boolean66 = strBuilder40.equals(strBuilder49);
        java.lang.StringBuffer stringBuffer67 = strBuilder40.toStringBuffer();
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder30.append(stringBuffer67, (int) (byte) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stringBuffer67);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher3, strMatcher4);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.setIgnoreEmptyTokens(true);
        boolean boolean10 = strTokenizer7.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer7.setDelimiterChar('#');
        java.lang.String[] strArray13 = strTokenizer12.getTokenArray();
        java.lang.Object obj14 = strTokenizer12.next();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer12.getIgnoredMatcher();
        int int17 = strBuilder1.lastIndexOf(strMatcher15, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder19.indexOf('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.append(10.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int29 = strBuilder26.lastIndexOf("", (int) 'a');
        int int30 = strBuilder26.size();
        int int32 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(strBuilder33, (int) (short) 1, (int) '#');
        int int38 = strBuilder26.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder26.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int47 = strBuilder44.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder44.deleteAll("hi!");
        boolean boolean51 = strBuilder49.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.clear();
        boolean boolean53 = strBuilder42.equalsIgnoreCase(strBuilder49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder49.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder24.append(strBuilder49);
        java.lang.String str56 = strBuilder24.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder24.deleteAll('a');
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder23.append(strBuilder24);
        boolean boolean60 = strBuilder1.equalsIgnoreCase(strBuilder59);
        char[] charArray65 = new char[] { '#', '#', '4', 'a' };
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder1.append(charArray65);
        java.lang.String str67 = strBuilder1.toString();
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!##4a" + "'", str67.equals("hi!##4a"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher1);
        java.lang.String str3 = strTokenizer2.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer2.setDelimiterChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.reset("#4# a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer7.reset();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.insert(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.replaceAll("hi!", "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.replaceAll('#', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.replaceAll("1.0", "44444444444444444444444444444497");
        java.lang.String str19 = strBuilder15.getNewLineText();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int22 = strBuilder19.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder19.deleteAll("hi!");
        boolean boolean26 = strBuilder24.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.clear();
        boolean boolean28 = strBuilder17.equalsIgnoreCase(strBuilder24);
        java.lang.String str31 = strBuilder17.midString((int) (short) 100, 100);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder17.appendFixedWidthPadLeft((java.lang.Object) strTokenizer32, (int) '4', 'a');
        int int38 = strBuilder17.lastIndexOf("#4# a                                                                                                        ", 10);
        int int41 = strBuilder17.lastIndexOf('e', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder17.insert(5, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        char[] charArray10 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10, strMatcher12);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer13, "#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append(100.0f);
        boolean boolean19 = strBuilder15.startsWith("#4#");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int24 = strBuilder21.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.deleteAll("hi!");
        boolean boolean28 = strBuilder26.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.append((double) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder26.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int39 = strBuilder36.lastIndexOf("", (int) 'a');
        int int40 = strBuilder36.size();
        int int42 = strBuilder36.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder26.append(strBuilder36);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder15.append((java.lang.Object) strBuilder43);
        int int46 = strBuilder44.lastIndexOf('e');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(104);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int6 = strBuilder3.lastIndexOf("", (int) 'a');
        int int7 = strBuilder3.size();
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder3.deleteAll(strMatcher9);
        int int12 = strBuilder3.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int17 = strBuilder14.lastIndexOf("", (int) 'a');
        int int18 = strBuilder14.size();
        int int19 = strBuilder14.length();
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder14.deleteAll(strMatcher20);
        int int23 = strBuilder14.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder3.append((java.lang.Object) "");
        int int26 = strBuilder3.lastIndexOf("#4#");
        java.io.Writer writer27 = strBuilder3.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder1.append(strBuilder3);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder3.insert((int) (byte) 0, (double) (short) 100);
        int int33 = strBuilder31.indexOf('4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder31.delete((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(writer27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strBuilder36);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.replace(0, 4, "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("#4#", strMatcher12);
        java.lang.String str14 = strTokenizer13.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer13.getDelimiterMatcher();
        int int16 = strBuilder6.lastIndexOf(strMatcher15);
        try {
            java.lang.String str19 = strBuilder6.substring(4, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher2);
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher5, strMatcher6);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(true);
        boolean boolean12 = strTokenizer9.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer9.setDelimiterChar('#');
        java.lang.String[] strArray15 = strTokenizer14.getTokenArray();
        java.lang.Object obj16 = strTokenizer14.next();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer14.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer3.setIgnoredMatcher(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher22, strMatcher23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoreEmptyTokens(true);
        boolean boolean29 = strTokenizer26.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer26.setDelimiterChar('#');
        java.lang.String[] strArray32 = strTokenizer31.getTokenArray();
        java.lang.Object obj33 = strTokenizer31.next();
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer31.getIgnoredMatcher();
        int int36 = strBuilder20.lastIndexOf(strMatcher34, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher17, strMatcher34);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + "hi!" + "'", obj16.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + "hi!" + "'", obj33.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strMatcher38);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray19, 'a', ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer25);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Object obj1 = strTokenizer0.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer0.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int8 = strBuilder5.lastIndexOf("", (int) 'a');
        char[] charArray14 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray14);
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray14, strMatcher16);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder5.appendWithSeparators((java.util.Iterator) strTokenizer17, "#4#");
        org.apache.commons.lang.text.StrMatcher strMatcher20 = strTokenizer17.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer0.setIgnoredMatcher(strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer("#4#", '#');
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer24.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer21.setDelimiterMatcher(strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setDelimiterChar('#');
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        int int11 = strBuilder9.indexOf("#4#");
        java.io.Writer writer12 = strBuilder9.asWriter();
        char[] charArray19 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, strMatcher21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder9.insert(0, charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.setLength(100);
        java.util.Collection collection26 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder9.appendWithSeparators(collection26, "");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder28.replaceFirst('a', 'e');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        int int13 = strBuilder1.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder1.appendFixedWidthPadRight((int) (byte) 0, (-1), 'a');
        java.lang.String str20 = strBuilder1.substring(0, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int27 = strBuilder24.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder24.deleteAll("hi!");
        boolean boolean31 = strBuilder29.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder29.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher38, strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoreEmptyTokens(true);
        boolean boolean45 = strTokenizer42.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer42.setDelimiterChar('#');
        java.lang.String[] strArray48 = strTokenizer47.getTokenArray();
        java.lang.Object obj49 = strTokenizer47.next();
        org.apache.commons.lang.text.StrMatcher strMatcher50 = strTokenizer47.getIgnoredMatcher();
        int int52 = strBuilder36.lastIndexOf(strMatcher50, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder29.replaceAll(strMatcher50, "hi!");
        boolean boolean55 = strBuilder22.contains(strMatcher50);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder22.insert(0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder58.append((float) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int65 = strBuilder62.lastIndexOf("", (int) 'a');
        int int66 = strBuilder62.size();
        int int67 = strBuilder62.length();
        org.apache.commons.lang.text.StrMatcher strMatcher68 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder62.deleteAll(strMatcher68);
        java.lang.String str71 = strBuilder69.rightString((int) (short) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder69.deleteFirst('a');
        org.apache.commons.lang.text.StrMatcher strMatcher75 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher75, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = strTokenizer79.setIgnoreEmptyTokens(true);
        boolean boolean82 = strTokenizer79.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer79.setDelimiterChar('#');
        java.lang.String[] strArray85 = strTokenizer84.getTokenArray();
        java.lang.Object obj86 = strTokenizer84.next();
        org.apache.commons.lang.text.StrMatcher strMatcher87 = strTokenizer84.getDelimiterMatcher();
        int int88 = strBuilder69.lastIndexOf(strMatcher87);
        boolean boolean89 = strBuilder60.equals((java.lang.Object) int88);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder60.deleteCharAt((int) 'e');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 101");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + obj49 + "' != '" + "hi!" + "'", obj49.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(strTokenizer81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertNotNull(strArray85);
        org.junit.Assert.assertTrue("'" + obj86 + "' != '" + "hi!" + "'", obj86.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int6 = strBuilder1.length();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int11 = strBuilder8.lastIndexOf("", (int) 'a');
        int int12 = strBuilder8.size();
        int int14 = strBuilder8.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder8.append(strBuilder15, (int) (short) 1, (int) '#');
        int int20 = strBuilder8.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder8.appendFixedWidthPadLeft((int) 'a', (int) ' ', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder8.clear();
        boolean boolean26 = strBuilder1.equals((java.lang.Object) strBuilder25);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder1.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int33 = strBuilder30.lastIndexOf("", (int) 'a');
        int int34 = strBuilder30.size();
        int int36 = strBuilder30.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder30.append(strBuilder37, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.replaceFirst(strMatcher41, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.append((float) 1);
        int int47 = strBuilder45.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder45.replaceAll("", "#4#");
        boolean boolean51 = strBuilder1.equalsIgnoreCase(strBuilder50);
        boolean boolean53 = strBuilder50.endsWith("false ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        int int5 = strBuilder1.size();
        int int7 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.append(strBuilder8, (int) (short) 1, (int) '#');
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder11.replaceFirst(strMatcher12, "hi!");
        char[] charArray15 = strBuilder14.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoreEmptyTokens(true);
        boolean boolean26 = strTokenizer23.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer23.setDelimiterChar('#');
        java.lang.String[] strArray29 = strTokenizer28.getTokenArray();
        java.lang.Object obj30 = strTokenizer28.next();
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer28.getIgnoredMatcher();
        int int33 = strBuilder17.lastIndexOf(strMatcher31, 0);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray15, strMatcher31, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray15, '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + obj30 + "' != '" + "hi!" + "'", obj30.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int4 = strBuilder1.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll("hi!");
        boolean boolean8 = strBuilder6.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int14 = strBuilder11.lastIndexOf("", (int) 'a');
        java.lang.StringBuffer stringBuffer15 = strBuilder11.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(stringBuffer15);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int21 = strBuilder18.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder18.deleteAll("hi!");
        boolean boolean25 = strBuilder23.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.clear();
        int int28 = strBuilder26.indexOf("#4#");
        java.io.Writer writer29 = strBuilder26.asWriter();
        char[] charArray36 = new char[] { '#', '4', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher38);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder26.insert(0, charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer41.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 1);
        int int49 = strBuilder46.lastIndexOf("", (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder46.deleteAll("hi!");
        boolean boolean53 = strBuilder51.startsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder51.replaceFirst("hi!", "");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher60 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher60, strMatcher61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setIgnoreEmptyTokens(true);
        boolean boolean67 = strTokenizer64.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer64.setDelimiterChar('#');
        java.lang.String[] strArray70 = strTokenizer69.getTokenArray();
        java.lang.Object obj71 = strTokenizer69.next();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = strTokenizer69.getIgnoredMatcher();
        int int74 = strBuilder58.lastIndexOf(strMatcher72, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder51.replaceAll(strMatcher72, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer44.setQuoteMatcher(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder9.deleteAll(strMatcher72);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder78.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder78.appendNewLine();
        try {
            char char82 = strBuilder80.charAt((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertTrue("'" + obj71 + "' != '" + "hi!" + "'", obj71.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder80);
    }
}

